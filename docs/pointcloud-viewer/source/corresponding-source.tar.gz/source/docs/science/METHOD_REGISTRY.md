# Method registry

`src/science/methodRegistry.ts` is the single catalogue of the scientific
methods OpenLiDARViewer runs. Every algorithm that produces a reported number
has one stable identifier and an integer version, so provenance and reports can
name the exact method and revision behind a figure and a reader can trace it to
the paper that specifies it.

## Identifier and versioning rules

- Id form: `olv.<area>.<method>` (e.g. `olv.validation.spatial-block`). The
  id never changes once published.
- Version: an integer, bumped only when the method's behaviour changes in a
  way that could move its numbers (a new threshold, a corrected estimator, a
  different formula). A pure refactor that leaves the output identical does not
  bump it.
- Tag form: `id@version`, e.g. `olv.validation.spatial-block@2`.
- Citations are never fabricated. An internal composition with no single
  source paper says so.

## Registered methods

| Id | Ver | Method | Citation |
|---|---|---|---|
| `olv.ground.smrf` | 1 | SMRF-derived ground extraction; the shipped opening rule is the project's own cut-surface variant, which diverges from the published object-mask (see `groundFilter.ts`) | after Pingel, Clarke & McBride (2013) |
| `olv.terrain.slope-horn` | 1 | Horn slope & aspect | Horn (1981) |
| `olv.terrain.vrm` | 1 | Vector Ruggedness Measure | Sappington et al. (2007) |
| `olv.terrain.tpi` | 1 | Topographic Position Index | Weiss (2001) |
| `olv.contour.analytical` | 2 | Analytical iso-contour geometry; v2 places levels on multiples of the interval in world elevation (local origin added back) where v1 used the recentred local frame | internal (grid contour extraction) |
| `olv.contour.generalize` | 1 | Uniform contour generalization; the shipped pass is Douglas to Peucker followed by Chaikin corner-cutting, which also moves vertices (see `methodRegistry.ts`) | Douglas & Peucker (1973); Chaikin (1974) |
| `olv.contour.generalize.dp` | 1 | Douglas to Peucker contour simplification | Douglas & Peucker (1973) |
| `olv.contour.generalize.terrain-adaptive` | 1 | Terrain-adaptive contour generalization; feature-scaled Douglas to Peucker followed by the same Chaikin corner-cutting | internal (feature-scaled DP, then Chaikin) |
| `olv.class.derived-heuristic` | 3 | Derived point classification (heuristic) | Zhang et al. (2003); internal composition |
| `olv.render.draw-precision-bound` | 1 | Per-draw eye-space precision bound: upper bound on the binary32 error of `modelView * vec4(p, 1.0)` for the active cloud at the current camera, compared with 1 mm; a diagnostic, not a draw gate, and NOT_TESTED where the shader contract is not verified (see `docs/architecture/draw-precision-contract.md`); projection, divide by w and survey accuracy not covered | A. Urias, "Per-Draw Precision Bounds for Large-Coordinate Rendering in WebGL2 and WebGPU"; checker SHA-256 `53229a0e2682fb103097eaef028079a40b6fa1a5f0c78fbf1da2b0b3c4598b6b` |
| `olv.render.draw-precision-lod` | 1 | Certified level-of-detail selection for one draw, the single-node case of the controller: the coarsest level k (one point per occupied 1 mm * 2^k cell, at its centre) with sigma * H_k + B_k <= tau under faithful rounding; selected within the limit, not drawn; no camera regions or multi-node selection | A. Urias, per-draw precision bounds (controller) |
| `olv.storage.grid-history` | 1 | Storage grid history: whether the stored integer X and Y of a LAS or LAZ file are compatible with a candidate earlier storage grid (same-frame refinements; 0.001, 0.01 and 0.1 m grids for a file in another unit; 0.01 and 0.1 ft grids turned 0 and whole degrees to 5 either way for a file in metres); predicted reciprocal peaks scored against an empirical null of 300 wavevectors, Fisher-combined and Bonferroni-corrected below 0.01 with the amplitude ratio in [0.5, 2]; at most 12 000 points in at least 20 windows; compatibility with a grid, not how the file was produced | internal (lattice visibility with an incoherent window spectrum and Fisher's method) |
| `olv.topology.linkage-record` | 1 | Source acquisition topology linkage record | internal (provenance record) |
| `olv.provenance.source-interpretation` | 1 | Source interpretation and data basis record | internal (provenance record) |
| `olv.dtm.geodesic-fill` | 1 | DTM raster + void fill; the fill is geodesic, an Euclidean IDW prefill only seeds it (see `methodRegistry.ts`); cells outside the data footprint are left as no data. Computes what `olv.dtm.idw-fill@2` computed; new records are stamped with this id | internal |
| `olv.dtm.idw-fill` | 2 | Legacy id of the same method, superseded by `olv.dtm.geodesic-fill@1`; kept registered so exports and sessions stamped with it at version 1 or 2 resolve; v2 leaves cells outside the data footprint as no data, v1 filled every void within the fill radius | internal |
| `olv.terrain.evidence.support` | 2 | DTM cell support raster: ground-return count, interpolation distance, cell evidence state (v2 adds 5 edge affected, 6 unresolved), nearest-support distance, vertical dispersion (MAD of the cell's returns) and survey-edge distance on the DEM grid; describes support, not accuracy | internal (export of the DTM cell-confidence grid) |
| `olv.terrain.evidence.sensitivity` | 1 | DTM model sensitivity raster, written only on request: per-cell highest minus lowest height over a fixed four-member ensemble (canonical, ground filter slope 0.15, slope 0.2, inverse distance weighting void fill) and the number of members with a height; describes model sensitivity, not accuracy | internal (ensemble recorded in `validation/protocols/evidencedem-sensitivity-ensemble-v1.md`) |
| `olv.terrain.evidence.residual` | 1 | DTM leave-local-out reconstruction residual: each measured cell held out and rebuilt by the canonical geodesic fill from its measured 8-neighbours; every measured cell up to 250,000, otherwise every k-th; shows how well neighbours predict a cell, not accuracy | internal (rules recorded in `validation/protocols/evidencedem-attention-v1.md`, version 2 section) |
| `olv.terrain.evidence.attention` | 2 | DTM attention raster: level 0 to 3 and one dominant reason per cell; each input normalised to 0 to 1 by a fixed rule, level is the highest score banded at 0.33, 0.67 and 1, no weighted blend; v2 writes a measured cell skipped by residual sampling, that no other input flags, as NoData with reason 8 (unresolved) where v1 wrote level 0; written only on request; the reason code table is part of this version; describes where to look, not accuracy | internal (rules recorded in `validation/protocols/evidencedem-attention-v1.md`) |
| `olv.validation.holdout-rmse` | 2 | Hold-out vertical accuracy (classify-inside-fold) | ASPRS (2014) formulas, hold-out basis |
| `olv.validation.spatial-block` | 2 | Spatial-block cross-validation | Roberts et al. (2017) |
| `olv.validation.reliability-wilson` | 1 | Measured-cell reliability | Wilson (1927) |
| `olv.registration.icp-planar` | 1 | Planar rigid ICP | Besl & McKay (1992); Umeyama (1991) |
| `olv.registration.epoch-horizontal-icp` | 3 | Repeat-epoch horizontal alignment (local frames, observability-gated; yaw + XY applied); v3 keeps the supplied coordinates of epochs that declare one horizontal CRS (no registration estimated, registration uncertainty not quantified) and fits pairs without a common CRS only when the undamped point-to-plane information matrix of yaw, x, y and z has an eigenvalue ratio and a conditional horizontal information of at least 0.01 at every iteration, so a plane or a single slope is refused as unobservable; v2 fitted common-CRS epochs too and a +1 m uplift on a 0.5 slope applied a 0.40 m x shift; v2 starts epochs that declare one CRS at the identity pose, minimises point-to-plane distances over pairs within 3 mean point spacings (best 90 % kept), measures the overlap at that distance, and withholds a fit with overlap under 50 %, a residual over 0.75 spacings, or an RMS move beyond the correspondence distance; v1 started from the centroid and measured overlap at the caller residual limit, so epochs of different extent were shifted | Besl & McKay (1992); Chen & Medioni (1992), point-to-plane; Umeyama (1991) |
| `olv.volume.stockpile` | 3 | Stockpile cut-fill volume with model sensitivity band; v3 integrates over a horizontal grid (footprint-clipped cell area times median cell height, cells without points interpolated inside the covered extent and excluded outside it, the interpolated share reported, low-confidence above 25% and withheld above 50%) instead of the point-weighted sum of v1 and v2, and the lasso footprint is the drawn lasso on the horizontal plane instead of the selection's convex hull; v2 leaves LAS Withheld points out of the polygon Volume tool and records points read, Withheld excluded (or unknown) and points analysed, and keeps Overlap; v1 read every point | internal (area-weighted prismatic cut-fill); Sutherland & Hodgman (1974) |
| `olv.volume.stockpile-area-grid` | 4 | Area-weighted stockpile volume (grid integration); v4 interpolates unsupported cells inside the convex extent of the covered cell centres by inverse-distance weighting (w = 1/d², d between cell centres): a cell within 8 cells of cover (Chebyshev) uses every covered cell on the nearest square ring holding any plus the next ring; a cell deeper in a void uses the first covered cell along each of the 8 grid directions plus its nearest covered cell, so the fill is O(cells); cells outside the extent are excluded, nothing is zero-filled, and the figure is graded by the interpolated share (interpolated heights are not computed when that share exceeds the 50% withhold limit) | internal (area-weighted DoD); Sutherland & Hodgman (1974) |
| `olv.change.dtm-difference` | 4 | DTM-of-difference cut/fill (thresholded gain/loss/net); v4 compares a cell only where both DTMs hold a measured height, on a shared cell at least twice the sparser epoch's mean point spacing, and reports how many cells were left out because either surface is interpolated or extrapolated there; v3 takes σreg only from an independent stable-area vertical assessment (never an alignment fit residual, so it is unavailable in the app today), uses max(1.96·√(Σ known σ²), 0.1 m) labelled incomplete when some terms are missing, keeps the assumed 0.1 m only when none is known, and requires the grids' origin and cell size to agree to a few float64 ulps (capped at 1e-6 cell); v2 thresholded at the propagated minimum level of detection 1.96·√(σz_before² + σz_after² + σreg²) from hold-out RMSEz and the alignment 3-D RMS, falling back to an assumed 0.1 m when a term is missing; v1 used a fixed 0.1 m | Anderson (2019), LoD thresholding; Wheaton et al. (2010), propagated level of detection |
| `olv.change.dtm-difference.raw-net` | 4 | DTM-of-difference cut/fill (raw net + thresholded gross); v4 sums only cells measured in both epochs; v3 applies the dtm-difference v3 threshold rule and grid check to the gross figures (the raw net is unthresholded); v2 used the propagated minimum level of detection for the gross figures; v1 used a fixed 0.1 m | Anderson (2019), thresholded gross vs raw net; Wheaton et al. (2010), propagated level of detection |
| `olv.feature.building-footprint` | 1 | Building footprint candidate extraction | internal (connected-component + boundary trace) |
| `olv.feature.conductor-fit` | 1 | Conductor centreline and sag fit | internal (parabolic small-sag approximation) |
| `olv.profile.corridor-percentile` | 2 | Corridor-percentile profile; v2 leaves LAS Withheld points out and records points read, Withheld excluded (or unknown) and points analysed, and keeps Overlap; v1 read every point | internal (corridor binning, Hyndman & Fan (1996) type-7 quantile) |
| `olv.density.scan-report` | 2 | Scan report point density and spacing; v2 leaves LAS Withheld points out of the count and records points counted, Withheld excluded (or unknown) and points analysed, and keeps Overlap; v1 counted every point | internal (count over footprint) |
| `olv.simulation.terrain-flow.d8` | 2 | D8 single-flow-direction routing, by steepest descent per metre; NoData the survey encloses is a wall, and a cell beside NoData that reaches the grid edge drains out as at the grid edge | O'Callaghan & Mark (1984) |
| `olv.simulation.terrain-flow.priority-flood` | 6 | Priority-Flood depression conditioning onto a second surface, seeded at the grid boundary and at the rim of NoData that reaches it; NoData the survey encloses is a wall and cells it encloses are counted; v3 counts a cell as filled only when its original height is strictly below its spill level, so a flat lifted by the epsilon alone is not fill, and fill depth excludes the epsilon; v5 raises each filled cell one Float32 step above the cell it was reached from rather than a fixed 1 mm, so spill levels are not overstated; v6 conditions a Float64 surface, one Float64 step per filled cell, and orders the flood by the spill level without the rise, first in first out within a level, because the Float32 steps added up along a long flat until D8 drained its far end over a slightly higher exit | Barnes, Lehman & Mulla (2014) |
| `olv.simulation.terrain-flow.priority-flood.gap-outlet` | 4 | The same conditioning with NoData gaps read as drainage exits, declared for gaps that are open water; v2 takes the v3 fill definition above, v3 the v5 Float32-step rise, v4 the v6 Float64 surface and flood order | Barnes, Lehman & Mulla (2014) |
| `olv.simulation.terrain-flow.accumulation` | 1 | Cells draining through each cell; metric area withheld when the scale is unresolved | internal (dependency-ordered pass over the D8 graph) |
| `olv.simulation.terrain-flow.catchment` | 1 | Cells draining to a selected outlet | internal (reverse D8 traversal) |
| `olv.simulation.terrain-flow.depression-inventory` | 2 | Groups filled cells (original height strictly below the spill level) into 8-connected depressions with cell count, area, deepest fill (spill level minus original height) and outlet elevation; v2 no longer counts a level flat as a depression; raw mode lists sink candidates instead | internal (connected-component grouping over Priority-Flood's output) |
| `olv.simulation.terrain-flow.rational-peak` | 1 | Rational-method peak flow Q = C · i · A from a set rainfall intensity, a runoff coefficient and the D8 contributing area; steady state, uniform rain lasting at least the time of concentration, C lumps every loss, no storage or timing; withheld without metres, flagged above 0.8 km², a lower bound on an edge-contaminated catchment | Kuichling (1889); FHWA HEC-22 (2009), Eq. 3-1 and Table 3-1 (after ASCE 1960); Schwab et al. (1993) for woodland |
| `olv.simulation.terrain-flow.edge-contamination` | 1 | Flags cells whose D8 upslope area holds a survey-edge cell routing into the surface, so their contributing area is a lower bound; a catchment is contaminated when its outlet is | Lindsay (2016), WhiteboxTools EdgeContamination criterion; internal D8 implementation |
| `olv.simulation.terrain-flow.flow-length` | 1 | Distance along each cell's D8 path to a selected outlet (orthogonal step one cell size, diagonal √2 cell sizes on a square grid); a distance, not a travel time | internal (one pass up the reverse D8 tree) |
| `olv.simulation.terrain-flow.pour-point-snap` | 1 | Moves a pointer-picked outlet to the highest-upstream-count cell within 2 cells; keyboard selection is exact | after WhiteboxTools SnapPourPoints (Lindsay 2016); internal |
| `olv.simulation.terrain-access.local-step` | 2 | Step height of a move: how far its rise falls outside the bracket of the one-sided rises just behind and just past it along the same heading, and for a diagonal also the easier of its two corner paths, so a plane has no step and a ledge reads its height; v1 gated the raw height difference between the two cells, which on coarse cells limited grade. The 3×3 local relief is reported, not gated | internal (one-sided finite differences along the move) |
| `olv.simulation.terrain-access.directional-grade` | 1 | Directional longitudinal grade and cross slope, decomposed from the Horn gradient by heading | internal (vector decomposition of Horn 1981) |
| `olv.simulation.terrain-access.cost-map` | 4 | Terrain access hard eligibility (node/edge split) and soft traversability cost; v4 gates and costs the step limit on the local-step v2 discontinuity, so grade enters the cost once and the grade limit is the only slope limit; v3 adds the evidence-gap policy (conservative blocks cells whose slope used a synthesised Horn neighbour and, under an evaluated obstruction limit, cells with no above-ground return; exploratory allows them and reports their route share); v2 gates and costs an edge on the largest of the directional Horn grade at either endpoint and the edge's own rise/run, and the larger endpoint cross slope | internal (declared multi-term utilization cost) |
| `olv.simulation.terrain-access.astar` | 2 | Deterministic 8-connected A* over eligible terrain cells; v2 takes moves through the cost map's transition rule, which refuses a diagonal that cuts an unsupported corner or sweeps the declared width over unsupported area, with width clearance measured to cell rectangles | Hart, Nilsson & Raphael (1968) |

### Observatory

The `olv.observation.*` ids are registered in `src/science/methodRegistry.ts`.
Assumptions and status for each are in `docs/observatory/methods.md`, one section
per id.

| Id | Ver | Method | Citation |
|---|---|---|---|
| `olv.observation.rays` | 1 | Observation ray builder | internal (grid and posed-ray parameterisation) |
| `olv.observation.ledger` | 1 | Voxel evidence ledger and traversal | Amanatides & Woo (1987) |
| `olv.observation.states` | 1 | Observation state table | internal (state-transition rules) |
| `olv.observation.strength` | 1 | Observation strength components | internal (strength components) |
| `olv.observation.shadow-frontier` | 1 | Shadow frontier | Curless & Levoy (1996) |
| `olv.observation.coverage-gain` | 1 | Coverage Gain over candidate stations, with every term reported | Scott, Roth & Rivest (2003) |
| `olv.observation.station-suggestion` | 1 | Next-station suggestion by greedy selection against a hypothetical ledger copy | Scott, Roth & Rivest (2003) |

## Scope of registration

Registering a method names the algorithm; it does not upgrade the evidence
behind its output. The hold-out vertical accuracy uses the ASPRS 2014 formulas
on internally withheld points, not independent survey checkpoints, and the
evidence registry still governs whether any product may be presented as
validated. See `docs/validation/` and the evidence model.

Naming those formulas is not a conformance statement. They are the edition-1
(2014) forms, reproduced as diagnostics on withheld observations; ASPRS has
published later editions of the positional-accuracy standards, and OLV does not
claim conformance with any edition of them. The claim register prohibits
"ASPRS NVA/VVA compliance" outright, because conformance presumes independent
checkpoints this project does not have.
