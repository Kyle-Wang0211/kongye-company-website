# Release assets: what a published OpenLiDARViewer release contains

The source archive deliberately excludes generated `release/` output, so a
reviewer holding only the source zip cannot see which external assets exist or
how to check them. This page is that index. It is committed, versioned, and
ships inside the archive; the generated hashes live in the attached manifest.

## The closed asset set

A published release, stable or prerelease, attaches exactly these, and nothing else:

| Asset | What it is |
|---|---|
| `openlidarviewer-v<version>-source-<ts>.zip` | The source tree, from `git archive` of the tagged commit |
| `openlidarviewer-v<version>-deploy-<ts>-root.zip` | The built site, contents at the archive ROOT (not wrapped in `dist/`) |
| `sbom.json` | CycloneDX 1.6 SBOM for the production dependency set |
| `test-evidence-v<version>.json` | The authoritative record of the exact-tag gate run |
| `smoke-deploy-v<version>.json` | The record of the deploy archive being started in a browser, bound to that archive's SHA-256 |
| `gate.log` | The full gate output the evidence was derived from |
| `gate.log.sha256` | Hash of that log |
| `release-manifest-v<version>.json` | Binds tag, commit, toolchain, and every payload hash |
| `SHA256SUMS` | Hashes of every asset, manifest included |
| `RELEASE_NOTES_v<version>.md` | The human-readable notes |

"Exactly one of each" is enforced, not just expected: a leftover zip from a
previous cut is the failure that survives every other check, because each file
is individually valid and only the SET is wrong.

## The deploy archive is started, not just hashed

Every other check reads the deploy zip as a file. `smoke-deploy-v<version>.json`
records that a browser opened it: the release ran its smoke against a BUILD, then
packaged a second build and shipped that, so the archive a user downloads had
never been started. That gap hid a real defect. The shipped bundle fetched a
loaders.gl worker from a CDN, which the deploy's own Content-Security-Policy
blocks, and no leg could see it because `vite preview` applies no CSP.

The workflow runs `npm run test:smoke:deploy -- <the packaged zip>` after
packaging and before the payload is assembled, and nothing rebuilds or
repackages afterwards. The result names the archive, its SHA-256, the commit and
the checks that ran. `release:verify` requires it to be present, to record a
pass, to name executed checks, and to match the staged archive by BOTH filename
and digest, at the release's own tag and commit. A missing, failed, stale or
mismatched result fails the closed-set check, which blocks release-ready and so
blocks publication.

## How the hashes chain

There is a cycle to avoid here, and the resolution is not guessable, so it is
stated plainly:

```
release-manifest → hashes every PAYLOAD asset (zips, sbom, evidence,
                   gate.log, gate.log.sha256, release notes, deploy smoke)
                  (never itself, never SHA256SUMS)
SHA256SUMS       → hashes everything, the manifest included
```

Each covers what the other cannot. `npm run release:verify` walks both
directions, so a tampered file fails one side or the other whichever it is.

## Verifying a download

```bash
# 1. every asset is intact and matches the published list
shasum -a 256 -c SHA256SUMS
shasum -a 256 -c gate.log.sha256

# 2. the set is complete and self-consistent: no rebuild required
npm run release:verify -- --dir <downloaded-assets>
```

`release:verify` checks far more than hashes: that the manifest and the evidence
name the same commit as the tag, that the evidence is authoritative and was
produced on the canonical toolchain, that the E4 claims recorded in the evidence are
exactly the ones the claim register lists, that the bundle is under its ceiling, that the source archive
carries its required files and none of the forbidden ones, and that the deploy
archive is the site root.

## Why the evidence is an attached asset, not a committed file

Evidence is collected FROM a gate run. Committing it necessarily creates a new
commit, so a committed record can only ever describe the commit *before* the one
it ships in. That one-commit gap is small and it is exactly the ambiguity that
makes "the tag is the tested commit" unprovable.

The release workflow closes it by never committing the evidence at all: it
checks out the tag, gates that commit, generates the record as an artifact of
that same checkout, packages the same unchanged tree, and attaches all of it.
The tested, packaged, evidenced and manifested commit are then one object.

`docs/validation/test-evidence.json` remains in the repository as the last
committed **development** record. It is marked `releaseAuthoritative: false`
and must not be cited as release evidence.

## The Software Heritage identifier

`.zenodo.json` carries no Software Heritage relation at tag time, and a lint
refuses one. A snapshot identifier (`swh:1:snp:`) names the whole repository as
archived on one visit, and no visit of a release can precede its tag, so an
`isIdenticalTo` relation written before the tag names a state the release is
not. v0.6.7 shipped one that predated its own tag.

After the tag is public, request an archival visit at
<https://archive.softwareheritage.org/save/>, wait for the visit to complete,
and add the RELEASE identifier (`swh:1:rel:`, resolved from the tag) to the
Zenodo record as a metadata edit. Zenodo permits metadata edits without a new
version, so the deposit's files and DOI are unchanged.

## Reproducing the source archive

The source archive is byte-reproducible: names and entry timestamps come from
the commit, not the wall clock.

```bash
git checkout v<version>
SOURCE_DATE_EPOCH="$(git show -s --format=%ct HEAD)" bash scripts/package.sh out --source-only
shasum -a 256 out/*source*.zip     # matches the published hash
```

The release workflow sets `SOURCE_DATE_EPOCH` to the tagged commit's committer
time before the gate, the packaging and the manifest binding, and the manifest
records that value as `sourceDateEpoch`. `release:verify` refuses a release
manifest that records none, so the timestamp the archives were built with is
always readable from the manifest rather than reconstructed.

The deploy archive is **not** claimed to be byte-reproducible: the obfuscator
is free to vary between runs. Verify it by hash against the manifest, not by
rebuilding.
