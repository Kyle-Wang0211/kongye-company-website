# Usage

How to open a scan and move around it, then measure, annotate, inspect and
export it. To try
it without installing anything, open the live version at
<https://app.openlidarviewer.org/>.

## Opening a scan

Open the app in a modern WebGL/WebGPU-capable browser (Chrome or Edge work well). Drag a point-cloud file anywhere onto the page, or press "Launch a sample" on the empty state, which streams the swissSURFACE3D sample (83.8 MB) from a public bucket over the network. The sample asks for confirmation only when it is 250 MB or more on a cellular connection, or 1.2 GB or more on a phone. This one is below both, so no confirmation appears. The format is detected automatically and parsing runs in the background.

For LAS and LAZ files a short preload summary appears first: the format, the source point count, and how the file will be loaded. A status toast then tracks the load through its stages (reading, decoding, optimizing) and a very large file shows a live point counter and a progress bar. A Cancel control on the toast stops a load in progress; nothing is added to the scene if you cancel.

A "Project ready" card then summarises the file: its format, point count, bounding box and detected attributes, with a suggested navigation mode and a performance estimate. It dismisses on its own.

Supported imports are `LAS`, `LAZ`, `E57`, `PLY`, `OBJ`, `GLB`, `GLTF`, `XYZ`, `CSV`, `ASC`, `TXT`, `PCD`, `PTS`, `PTX`, and 3D Tiles (a single `.pnts` tile or a whole tileset). Large hierarchical-streaming formats, `COPC` (`.copc.laz`) and `EPT` (Entwine Point Tile, via an `ept.json` URL), open progressively through their octree hierarchies; see [`streaming.md`](streaming.md). Nothing is uploaded. The file is read and rendered entirely in your browser.

Dropping a second file opens it as an additional layer alongside the first; the Layers list in the Data tab lists every open scan, each with a visibility toggle and a remove control. The newest scan is the active one, which the Classes list, the scan report and exports describe; press another layer's name to make it active. The active scan's name is shown in bold.

## Closing a scan

Click Close scan in the tool dock to clear the current scan (and any additional layers) and return to the empty state. On a phone the button is under the ••• More tray, not in the primary row. From there you can drop, open, or sample another scan. Closing also clears the session's measurements, annotations, and saved views, so the next scan starts clean.

If closing would lose work, a "Close this scan?" dialog asks first and lists what would be discarded: measurements, annotations, saved views, class edits that differ from the file, computed results (Ready results from Analyse, Observatory, the labs and saved findings), or work held for recovery in this browser. Cancel has the focus, so a reflexive Enter keeps the scan open. The other choices are Close without saving and, when the session would keep something, Save session first, which downloads the session file and then closes. The session file stores measurements, annotations and saved views only. It does not store class edits, so the dialog says to export the scan as LAS to keep them. If the save fails, the scan stays open and the message reads "Session not saved. The scan is still open." A scan with no such work closes without a dialog.

## Styling the cloud

The View panel in the right rail controls how the cloud looks:

- Color by switches the colour mode: RGB, Height, Intensity, Class, Normal, Density, Return, GPS time, and the analysis-gated Coverage and Confidence. Only the modes the file actually contains are offered, and the best one is selected automatically. Normal shading maps each point's surface-normal direction to colour and appears for files that carry per-point normals, such as many E57 scans. Coverage and Confidence stay off until a terrain analysis has run.
- Point size sets the base on-screen size of each point.
- Detail shows the `shown / total` count. A cloud larger than the point budget is loaded at reduced density so the viewer stays responsive: see [performance.md](performance.md).

## Rendering

The Rendering section of the View panel tunes how the cloud is drawn:

- Eye Dome Lighting toggles screen-space depth shading. It darkens depth discontinuities so edges and 3D structure stand out, and the strength slider sets how pronounced the effect is. It is on by default on desktop WebGPU, and off on the WebGL 2 fallback and on phones, where it can still be switched on.
- Point size mode switches between Adaptive (points scale with camera distance, clamped so far points stay visible and near ones do not bloat) and Fixed, a constant on-screen size. A cloud opens at the smallest size in Adaptive mode and the point-size slider sets the base size for both modes. A size or mode you choose is remembered for the next session.
- Antialiasing toggles the smoothing of each point's round edge.

## Reference plane

The Reference plane section of the View panel (switch the panel from Basic to Advanced to see it) draws a grid at a position you choose, as a reference for reading heights and alignment by eye. It is not measured terrain. Nothing measures or snaps to it, no analysis reads it, and no data export contains it; a Save view snapshot shows it when it is on screen (see below). It is off by default. Turn it on with the Reference plane button, the `B` key, or Toggle reference plane in the command palette.

- Orientation is Horizontal (perpendicular to the scan's up axis), Vertical along X, Vertical along Y (along Z on a Y-up mesh scan), or Through 3 picked points.
- Nothing is drawn until you set an elevation. Type the origin and elevation, use Use picked point to take both from a point you click on the scan, or use Use scan minimum, which takes the lowest point over every visible layer. That point is often noise or a pit, and it is not ground. The horizontal origin starts at the scan's centre rounded to the major spacing, and the readout says "scan centre (rounded to grid)" until you type one, pick one, or press Use scan centre to go back to it. The readout shows the elevation, its unit and how it was set.
- Automatic spacing picks major lines on a 1, 2, 5 progression so they sit about 50 to 100 pixels apart on screen, with minor lines between them. It keeps a spacing until the zoom moves it well outside that range, so the grid does not flicker between two steps. Fixed spacing keeps the value you type, raised if needed to at least one millionth of the scan's size, and the readout says when it was raised. The readout shows the spacing, for example "Grid 5 m, minor 1 m".
- Lengths read metres or feet only when the coordinate system resolves that unit, and "units" otherwise. Geographic coordinates are degrees, which are not a length, so a geographic scan's grid reads "units". A vertical or three-point plane names a unit only when the horizontal and vertical units agree.
- Pick 3 points, then click three points on the scan. The plane passes through them exactly and is not fitted to the points around them, so pick noise tilts it. Points in a line, or nearly in a line, are refused and the plane stays as it was: the triangle's smallest height must be at least one thousandth of its longest side. Esc or Cancel picking stops a pick.

The grid covers the scan and one scan size around it. Lines are drawn at full strength while neighbours sit 14 pixels or more apart on screen and fade to nothing at 6 pixels, and so does the outer edge of the grid, so a low view toward the horizon ends in a fade rather than a band of stripes. Minor lines are left out when the view is within about 17 degrees of the plane. The lines test depth but do not write it, so points in front of the plane hide it and the plane never hides a point. The plane stays fixed to the scan's coordinates as the camera moves, in perspective, orthographic and Plan view. Its lines are drawn relative to a nearby anchor, so they hold still at large projected coordinates. A Save view snapshot includes the plane when it is on screen and names it in the PNG's `olv:reference-plane` text chunk. Visual Export Studio images never include it. The plane's settings are saved in the session file, and closing the scan removes the plane. When the open layers do not share a datum, the plane is not drawn and the panel says why, because there is no single coordinate frame to place it in. Coordinates, elevations and spacings beyond 1e9 are refused.

## Navigating

Switch modes with the Orbit | Walk | Fly | Pan control at the bottom centre, or the `1` / `2` / `3` / `4` keys. Orbit lets you drag to rotate, scroll to zoom, and double-click to focus. Walk is first-person, with WASD on the level and Space/C for height. Fly is free flight, where WASD follows where you look. Pan (`4`, or `G` from any mode) is the hand tool, which drags the scene under the pointer. The Plan chip looks straight down in parallel projection with the hand tool on the drag, and turning it off restores the view you had.

In Walk and Fly, click the scan to capture the cursor for mouse-look, and press `Esc` to release it. See [navigation.md](navigation.md).

## The scan report

The Scan report section of the View panel shows the headline metrics: point count, width, depth, height, density, spacing, and which attributes (RGB, intensity, classification) are present. When a LAS or LAZ file records them, it also shows the capture sensor, the source software, and the capture date. Open the Advanced report for the scan's georeferenced bounding box (the min and max corners in real-world coordinates) and integrity diagnostics. Those flag invalid coordinates, duplicate points and stray outliers, and compare the declared point count against the decoded one.

## Measuring

Click Measure in the tool dock to open the measurement toolbar. Pick a tool from it, then click points on the scan:

- Distance takes two clicks and reports the straight-line distance between them.
- Polyline takes any number of clicks and reports the total path length. Click the first vertex, double-click, press Enter or use the Finish polygon button to finish, and Backspace removes the last vertex.
- Area takes three or more clicks forming a polygon and reports both the true area in the polygon's own plane and the horizontal map-projected area. It closes the same ways a polyline finishes. A polygon that crosses itself, overlaps its own edges, collapses to a line, or has vertices far from one plane is not accepted, and a saved or imported one reports no area with the reason, never 0.
- Height takes two clicks and reports the vertical difference between them.
- Angle takes three clicks and reports the angle at the middle vertex.
- Slope takes two clicks and reports the rise, run, slope angle, and grade percentage.
- Profile takes two clicks and reports the full cross-section geometry of the line: 3D length, horizontal distance, vertical drop, and grade percentage. Reads in a single compact card ("12.5 m · Δh +2.3 m · 18.4%"); the overlay draws the 3D segment plus an L-bent ghost so the run and drop are visible separately. The profile summary and its PDF also give an Endpoint gradient: the net change between the first and last stations with data, and when stations between them are missing it says how many.
- Box takes two clicks on opposite corners of a diagonal and reports an axis-aligned width, depth, height and volume.
- Volume takes a polygon footprint, or a freeform shape drawn with the Lasso button, and reports cut, fill and net against a reference height. It leaves out noise classes 7 and 18 and Withheld points and counts them. On a cloud the loader reduced to one point per small cube, those labels are not available, and the volume records that instead of a count.

Snapping is off until you turn it on. The snap button cycles off, point and geometry, and needs points in memory and a perspective view.

While placing, undo removes the last point. Once placed, drag any point to move it, and a measurement can be renamed or deleted from the Measurements panel. Clear all empties the list. The units toggle switches every readout between metric and imperial. Export saves all measurements to a JSON session file, and Import loads one back. Measurements persist for the browser session.

When the scan is in geographic coordinates (degrees), every measurement except a height is marked as not a distance, and the exports print or write "not available: horizontal CRS units are not ground distances (geographic degrees, Web Mercator grid or geocentric frame)" in place of the figure. Heights, rises and box heights are still written. Nonzero values smaller than 0.0005 keep three significant digits in the exports, so a small segment does not export as 0. The bearing of a distance reads "grid" on a projected coordinate system with an EPSG code and "(local axes)" otherwise, and is not shown on a geographic one. The user guide describes each case in [USER_GUIDE.md](USER_GUIDE.md).

Measurement is for visual inspection. See the note in [limitations.md](limitations.md).

## Annotating

Annotations mark points of interest for review. Click Annotate in the tool dock, then click a point on the scan: a numbered marker drops on it and a compact card opens. Give the annotation a title and pick its category (note, info, warning or issue). A free-text note is optional. Keep the "Save current camera view" checkbox ticked to store the exact viewpoint you placed it from. Save commits the annotation; Cancel discards the draft, so an abandoned card never leaves a stray marker.

You can also link an annotation to a measurement: when the scan has measurements, the editor offers a "Linked measurement" selector, and a linked annotation shows the measurement's name in the panel.

The Annotations panel lists every placed marker with its category badge, title, and when it was last edited. Sort the list by created time, recent edit, category, or title, and use the search box to filter by title, note, or type. Each row jumps the camera to its annotation (restoring the saved viewpoint when one was captured) and offers Edit and delete; Clear all empties the list with a confirm step. Hovering a row highlights the matching marker in the scene.

Every scan stays on your device. Export the session (see Exporting) to save the whole inspection (measurements, annotations, and named views) to a JSON file and reload it later.

## Inspecting a point

Click Inspect in the tool dock, then click any point on the scan. A glowing marker drops on the nearest point and a compact card shows its real-world coordinates, distance from the camera, intensity, classification, RGB colour, source layer, and index, with attributes the file does not carry shown as "Not available". For a LAS or LAZ point the card also shows the return number and count, the point source ID, and the GPS time when the file records them, and the surface normal for clouds that carry one; those rows are simply omitted when the data is absent. For a georeferenced LAS or LAZ survey the coordinates are the absolute survey position, which is what engineers and topographers need. The Copy button puts the point's data on the clipboard as clean text. Clicking another point replaces the selection; Esc, Done, or clicking Inspect again exits.

The live probe (desktop) is Inspect without the click: turn on Probe in the tool dock and a small readout follows the cursor, showing the point under it as you hover. Navigation stays fully live, so you can orbit and probe at once. Probe is a hover affordance, so it is not offered on touch devices.

The picking tools (Measure, Inspect, Annotate, and Probe) are mutually exclusive; turning one on turns the others off.

## Saved views

In the Saved views section of the panel, click Save current view (or press `V`) to store a named view state: the camera plus the display state you are looking at. That state covers the clip box and colour mode, the class and elevation/intensity filters, and the render settings. Each saved view can be renamed in place; click Go to glide the camera back and reapply that state, or the `×` to delete it. Saved views are kept in the session file, so they survive an export and import, which means a report or paper can cite a view state by name ("Figure 3 is the 'north-scarp' state") and a reader with the same scan regenerates it. Views saved by older versions carry only a camera and restore exactly as they always did. One honest caveat for streamed scans (COPC/EPT): a restored view reproduces the same settings over whatever detail is resident at that moment, so expect the same picture, not necessarily the same individual points.

## Keyboard shortcuts

Press `?` for the shortcut sheet: every action with its key, searchable, from the same table the keys are dispatched from. The Help button in the tool dock opens the searchable Help overlay, whose Keyboard topic lists the same keys and whose Scientific states topic explains the words the app uses for how far a result can be trusted. Shortcuts are suppressed while you are typing in a field.

## Exporting

Save a snapshot, in the tool dock, saves the current view as a PNG; any placed measurements and annotations are burned into the image, so the snapshot works as inspection evidence. The Image export section of the Export tab adds Height map, Intensity, Class map, Normal map and View capture. The intensity, class and normal modes are disabled on a cloud without that channel, and the hover text says so. On a georeferenced scan, View capture downloads a top-down image with world file and projection sidecars, and its pixels with no drawn point are transparent. The quick Export buttons write the loaded cloud in real-world coordinates as a PLY or OBJ file, or as XYZ or CSV text; with a clip on they write only the points it keeps and add `-clip` to the file name. LAS and LAZ re-saves, with their coordinate system options, are in the Export tab's point cloud lane; see the [user guide](USER_GUIDE.md). The point cloud lane writes coordinates in the source's axis order; a local Y-up model is rotated to Z-up only when "Rotate a local Y-up model to Z-up" is ticked.

Report PDF. Export → Report PDF builds a multi-page report from the live working state. Pick a template first: Survey Summary is a compact handover with a cover, inspection summary, dataset summary, compact provenance, measurements and technical notes. Technical Report adds the full provenance, the file's declared source metadata, annotations and visuals. Scan QA is a data-quality summary with an explicit statement of what the report does not establish. The metric or imperial setting of the Measurements panel applies to the tables. In the dataset summary, Height reads in source units with "(vertical unit not declared)" when the file declares no vertical unit, and "(declared vertical unit is invalid)" when the declared factor is zero, negative or not a number. It carries "(includes noise classes 7 and 18)" whenever the on-screen Scan report does. The Exported stamp prints UTC with the zone named. For measurements on a geographic coordinate system, the report prints "not available: horizontal CRS units are not ground distances (geographic degrees, Web Mercator grid or geocentric frame)" in place of grades, angles, lengths, areas and volumes. The PDF engine loads only when you click the button, so the initial app payload stays unchanged for users who never need a report.

<!-- #region session-reference -->
<!-- The region markers on this page let the docs site's "Embed & session
     reference" include these sections verbatim; this file stays the single
     canonical copy. Keep the markers around their sections when editing. -->
Session round-trip (`.olvsession`). The session Export saves the full working state to a `.olvsession` JSON file. The file holds the camera, render settings and active colour mode. It also stores the annotations, measurements and named views, along with the scan metadata. Import loads one back, restoring the camera and view exactly. Measurements and annotations are matched to open scans by source content rather than file name; work for a scan that is not open is kept, placed when that scan is opened later in the same page, and written back by the next save. Class edits are not stored in the session file. To keep a reclassification, export the scan as LAS at display resolution. Older measurement-only and v2 session files still open via the v1/v2/v3 schema back-compat in the parser.
<!-- #endregion session-reference -->

## Mobile usage

1. Open OpenLiDARViewer on your phone.
2. Tap "Open scan."
3. Choose a compatible file from device storage or a cloud file provider.
4. Use touch gestures to navigate: drag to rotate, pinch to zoom, two fingers to pan.
5. Tap Measure to measure between points, or Annotate to mark and note a point of interest. Measure and Annotate are in the dock, and Analyse, Help, Save a snapshot and Copy view link sit under the ••• button.
6. Open the View tab in the bottom sheet to see the Scan report with the scan metadata.
7. Save a snapshot from the dock, or export a supported file format from the Export tab.

The annotation editor and panel use touch-sized controls on phones. The live probe is a hover tool, so it is desktop-only.

<!-- #region embed-reference -->
## Sharing a view

The Copy view link button in the bottom dock copies a link that reproduces the current view: the camera position and target, the colour mode, the point sizing, and the selected annotation. The link carries no scan data: the recipient opens the same scan themselves, and the saved view is applied on top. This keeps "share this view" working with no upload and no backend.

## Embedding

Append `?embed=1` to the URL to strip the chrome down to a bare canvas for use in an `<iframe>`. The embed surface is a small, documented set of URL flags and a validated `postMessage` bridge.

### URL flags

| Flag | Effect |
|---|---|
| `?embed=1` | Embed mode: hides the dock and panels, enables the bridge |
| `?ui=minimal` | Hides the dock and panels without enabling the bridge |
| `?measurements=1` | Surfaces the measurement tool layer in a bare view |
| `?annotations=1` | Surfaces the annotation tool layer in a bare view |

### postMessage bridge

In embed mode the viewer posts one `ready` message to the host page once the renderer has initialised: `{ source: 'openlidarviewer', type: 'ready', version }`, to each allowed origin (see below). The host page may then send commands with `iframe.contentWindow.postMessage(...)`. Each command is validated against a small, closed set of verbs; anything unrecognised or malformed is ignored:

| Command | Shape |
|---|---|
| Load a file | `{ type: 'load-file', buffer: ArrayBuffer, name: string }` |
| Jump the camera | `{ type: 'jump-camera', camera: { position, target, mode?, fov? } }` |
| Toggle a layer | `{ type: 'toggle-layer', id: string, visible: boolean }` |
| Focus an annotation | `{ type: 'focus-annotation', id: string }` |

### Embedding origin and security

Who may embed the viewer is decided in two places, and a host should set both.

**1. Response headers (a deployer's server).** The shipped deploy headers set `Content-Security-Policy: frame-ancestors 'self'` (which replaces the older `X-Frame-Options: SAMEORIGIN`), so out of the box a browser lets the viewer embed only in a page on the same origin. To embed it cross-origin, edit that directive to a deliberate allow-list, for example `frame-ancestors 'self' https://portal.example.org`, in both `public/.htaccess` and `public/_headers`.

**2. The viewer itself.** A static host that cannot send headers (a static host or an object-store bucket) cannot set `frame-ancestors`, so the browser lets any page frame the viewer there. The page that frames the viewer also chooses the viewer's URL, so the URL cannot be what authorises it. The viewer therefore decides for itself:

- A parent on the viewer's own origin is always trusted, with no configuration. A page served from the same origin needs nothing.
- A parent on another origin is trusted only if the deployer built the viewer with that origin in `OLV_EMBED_ORIGINS`, a comma-separated list of origins that is empty by default:

  ```sh
  OLV_EMBED_ORIGINS=https://portal.example.org,https://courses.example.edu npm run build:live
  ```

  The list is compiled into the build. A visitor's URL cannot add to it. Entries that are not `http` or `https` origins are dropped, and the build prints a warning for each. Packaging (`scripts/package.sh`) refuses a build that carries a list unless `OLV_ALLOW_EMBED_ORIGINS=1` is also set, so a list left exported in the shell does not reach a release archive by accident:

  ```sh
  OLV_EMBED_ORIGINS=https://portal.example.org OLV_ALLOW_EMBED_ORIGINS=1 scripts/package.sh
  ```
- `?embedParent=` and `?embedOrigins=` on the viewer URL are a request, not an authorisation. They can narrow the deployer's list to the origins that embed wants (`?embedParent=https://host.example.com`, or `?embedOrigins=https://a.example.com,https://b.example.com`); an origin they name that is not on the list is ignored.
- Where the browser reports the framing page (`location.ancestorOrigins`: Chromium and Safari, not Firefox), the viewer checks that origin against the rules and talks to it alone. Without it, a cross-origin parent can be told apart only by the origin of each message, which must be on the list.

When the page is framed and nothing above allows the framing page, the viewer runs in safe mode: it does not start, sends no `ready` message, ignores every message, and shows a plain notice with a link to open the viewer in its own tab. A page that is not framed is unaffected.

One case is not caught by this check. In a browser that does not report the framing page (Firefox) and with a non-empty `OLV_EMBED_ORIGINS` list, a cross-origin parent cannot be named, so the viewer starts with its full interface and an inert bridge: it answers only messages from origins on the list, but shows no notice to an unlisted framing page. To keep an unlisted site from framing the viewer at all, send `frame-ancestors` from the host (see the threat model).

Once a parent is trusted, the bridge accepts commands only from that parent frame, from an origin on the rules, and sends `ready` only to those origins. Commands from any other origin are ignored. A `load-file` buffer is capped at 256 MiB and must be a plain `ArrayBuffer` (not a typed-array view or a `SharedArrayBuffer`), with a file name of 1 to 255 characters. Transfer the buffer (`postMessage(msg, '*', [buffer])` with the real target origin) rather than cloning it: a receiver cannot tell the two apart, and a clone copies the whole file into the viewer's frame before the cap applies. For a larger scan, open it in the viewer itself.

## Developer diagnostics

Two URL flags surface developer diagnostics; neither appears in a normal session.

`?debug=1` shows a live performance overlay (frame rate and frame time, the GPU backend (WebGPU or WebGL 2), draw calls, the displayed and total point counts, and an estimated GPU memory figure) refreshed about four times a second, alongside the most recent load's stage-by-stage telemetry. The raw error detail for any failed load is also logged to the console under this flag.

`?benchmark=1` emits a structured benchmark result for each load (the time to first render and the full per-stage timing breakdown) to both the overlay and the console, so loading performance can be compared across versions.
<!-- #endregion embed-reference -->
