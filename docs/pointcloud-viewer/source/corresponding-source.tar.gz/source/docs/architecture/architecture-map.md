# Architecture map

The module graph as it stands, and the shape the decomposition is moving it
toward. `scripts/lint-layer-boundaries.mjs` enforces the dependency direction
below.

## Dependency direction

```
core math  →  science domain  →  application services  →  UI adapters  →  views
```

The layer linter enforces one import rule: **science and core must never
import UI or three.js.** `src/terrain`, `src/validation`, `src/analysis` and `src/science`
stay DOM-free and worker-safe, so a numeric module can run in a worker or a Node
test without dragging a renderer behind it. Everything in this document exists to
keep that arrow pointing one way.

## Layers

Sizes are `.ts` lines per layer, bucketed; `lint:architecture-truth` derives them
from the tree and fails when a cell drifts.

| Layer | Path | Size | Role |
|---|---|---:|---|
| Core numerics | `src/process`, `src/numeric.ts`, `src/units` | ~3.4k | Compensated sums, Welford, unit types. No dependencies. |
| Model | `src/model` | ~4.3k | `PointCloud`, layer model. Plain data. |
| Geo | `src/geo` | ~6.2k | CRS math, `ProjectSpatialFrame`, transforms. |
| Science domain | `src/terrain`, `src/validation`, `src/analysis`, `src/science` | ~55k | Ground filtering, DTM, contours, derivatives, hold-out RMSE, evidence model. UI-free by lint. |
| I/O | `src/io` | ~42k | Format loaders (LAS/LAZ/PLY/PCD/PTX/E57/…), COPC + EPT streaming sources, range transports, session. |
| Render | `src/render` | ~84k | three.js/WebGPU scene, streaming scheduler, measurement tools, colour modes. |
| Export / report | `src/export`, `src/report`, `src/convert` | ~22k | Studio exporters, PDF/report builders, batch conversion. |
| Application services | `src/app` | ~34k | Composition root and the services that own shared state. |
| UI | `src/ui` | ~48k | Panels, Inspector, Studio surfaces, onboarding. |
| Shell | `src/main.ts` | 4,175 | Wiring. A monolith under decomposition. |

## Composition root

`AppRuntime` (`src/app/AppRuntime.ts`) is created once at boot and owns one
`AppContext` (`src/app/appContext.ts`), which holds the shared mutable state
grouped into clusters. Each cluster has exactly one service that owns its
mutation:

| Cluster | Service | Owns |
|---|---|---|
| `layers` | `LayerService` | Visibility intent, solo isolation, CRS mismatch flags |
| `viewBookmarks` | `viewBookmarks` | Saved views: add / get / remove / rename / restore / clear |
| `scan` | `ScanService` | Active-scan selection, and the `activeCloud()` lookup |
| `scanRoute` | `ScanRouteService` | Route pinning, manual scan type, re-route debounce |
| `projectFrame` | `projectFrame` | The shared project origin and each layer's transform into it |

Supporting services in the same layer: `crsCoordinator`, `terrainAnalysisRunner`,
`inspectorCardRefreshers`, `staleChunkReload`.

Shared domain/application state is owned by services (`AppContext`, `CrsService`,
the layer/scan services); `main.ts` retains explicitly bounded shell-local
composition and lifecycle state. Moving domain state out is what makes the next
step possible: a block of orchestration can now move into its own module and close
over services, instead of closing over file-scope `let`s that pin it in place.

## The two monoliths, and the target shape

The exit condition is NOT a line count. A hard line target rewards the wrong
move: you can hit it by relocating view-bound glue into a "host" module that
re-exposes the whole class, which lowers the number without decoupling anything
or gaining a single test. That is the trap this decomposition exists to avoid.

The decomposition is finished when **every cluster with a genuine boundary and a Node-test
payoff is extracted and tested, and the irreducibly view-bound remainder is
enumerated below.** A cluster earns extraction when its logic can be decided
without three.js or the DOM. When the only thing left is GPU material setup,
scene-graph wiring, camera manipulation and event plumbing, the file is as
small as it should be, whatever the line count says.

`< 2,500` for `main.ts` and `< 2,000` for `Viewer.ts` remain recorded as a
directional `goal` in `docs/validation/monolith-size-baseline.json`, but no
guard enforces them. What IS enforced (`lint:monolith-size`) is that neither
file may GROW: the counts ratchet down only, so a decomposition step cannot be
quietly undone, and no vanity extraction is forced to chase a number.

### Extracted this cycle, each with Node tests it could not have before

- `computeLassoVolume` → `src/render/measure/lassoVolumeCompute.ts` (8 tests)
- the two-finger tracker → `src/render/touchTracker.ts` (11 tests)
- the render-frame decision → `src/render/renderActivityGate.ts` (9 tests)

Moved for locality rather than testability: the panel column's layout chrome
(measure-bar and dock clearance, the rail collapse, panel wheel containment)
now lives in `src/ui/panelChrome.ts`. It is ResizeObserver and CSS custom
property work with no logic a Node test could decide, but it is panel geometry,
so it belongs beside the panels.

### Checked and deliberately NOT extracted

Recorded so the next pass does not re-derive them:

- The filter cluster (`_classFiltered`, `_elevFilter*`, `_intenFilter*`),
  not CPU predicates. They are three.js shader uniforms folded in a TSL pass;
  there is no Node-testable logic to lift.
- Classification history (`_classEpochs`, `_classHistory`): its substance
  (`ClassEditHistory`, `ClassificationEpochs`, `applyClassSwap`,
  `applyPolygonReclassify`) is ALREADY extracted and tested. What remains on the
  Viewer is a thin GPU-upload wrapper.

`src/main.ts` (4,175): the largest blocks, which are the extraction
candidates:

`buildActionRegistry` is a thin assembler in `src/app/actionDefinitions.ts` over
seven contributors in `src/app/actions/` (camera, view, tools, analysis, export,
workflow, help), each taking only the collaborators its actions use; the shell
builds the registry on the first palette, sheet or Dataset Story use from a lazy
chunk. The candidates that remain:

| Block | ~Lines | Extraction target |
|---|---:|---|

Done: the Analyse panel's raster and relief previews (surface statistics, the
bare-earth elevation histogram, the canopy-height, coverage and relief tiles
with their legends, samplers and PNG export) now live in
`src/ui/analyseSurfaceTiles.ts` as `SurfaceTiles` over a narrow host (the
panel's map-context, basename and confidence-toggle callbacks, the current
result, and the slot for the confidence button). `AnalysePanel.ts` 3555 to
2865 lines, runtime fan-out 32 to 22, measured when the extraction landed; the
v0.6.9 tree reads 2911 lines and fan-out 23 after the UI wiring that followed.
The readout wording is Node-tested in `tests/analyseSurfaceTiles.test.ts`.

Done: the streaming panel's controls (quality, pause, cache, the full-cloud
grade with its re-entry guard and cancel) and the status poll now live in
`src/app/streamingUiCoordinator.ts` over a renderer port; the shell registers
the readers that share each poll tick (residency detail, the scan route's
settle one-shot, the benchmark). `tests/streamingUiCoordinator.test.ts` covers
the controls, the tick fan-out, the grade guard and the session end. The
Viewer stays the renderer; the scheduler is untouched.

Done: `syncInspectorVisuals`, `syncInspectorRendering`, the Visuals Studio
preset callbacks (RGB appearance, EDL, sky, white balance, workflow preset) and
`seedStreamingFilterExtents` now live in `src/app/inspectorVisualCoordinator.ts`
over read, write and view ports; the streaming filter seed is an explicit
unseeded/seeded state the shell resets on the streaming lifecycle.
`tests/inspectorVisualCoordinator.test.ts` covers preset matching, the seed
machine and the projections. main.ts lost its direct imports of
`terrainWorkflowPresets`, `rgbAppearance` and `skyPresets`.

Done: `applyScanRoute` (233 lines, with the manual "Treat as" override, the
settled one-shot bookkeeping and the space-export context) now lives in
`src/app/scanRouteCoordinator.ts` over narrow ports (geometry, frame, verdict,
view, analysis trigger); the shell's view port records each lazily-mounted
panel's intent for hydration. `tests/scanRouteCoordinator.test.ts` drives the
whole route with fakes. main.ts lost its direct imports of `scanShape`,
`scanRoute`, `objectMetrics` and `spaceMetrics`.

Done: `runStreamingModules` (~105 lines), the Scan Report assembler for a streaming
cloud, now lives in `src/app/streamingScanReport.ts` beside the row builders it
calls, takes the resolved frame as a parameter instead of reading the shell's
CRS service, and exports the cloud shape it reads as `StreamingReportCloud`
(`tests/streamingReportAssembler.test.ts`). The app toast (~55 lines, two
module-level variables) is `createToastHost` in `src/ui/panelChrome.ts`; the
shell keeps a one-line handle (`tests/toastHost.test.ts`). The Viewer import no
longer starts at module evaluation: `ensureViewer()` starts it from the idle
pre-warm on a capable connection and from every scan-open path, so the
existing Save-Data guard on the pre-warm decides, and the key dispatcher's
teardown is registered with the stage instead of discarded.

Done: `importSession` (~208 lines) lives in `src/app/sessionIo.ts`, called with a
`SessionIoDeps` object of ~16 accessors the shell binds to its own state, and
lazy-loaded from `main.ts` on the first `.olvsession` file (v0.7 shell headroom).
The pure cloud→fingerprint adapter (`scanFactsFromStreaming` / `scanFactsFromStatic`)
moved to `src/app/sessionScanFacts.ts` (re-exported unchanged off `sessionIo.ts`) because
`openScan.ts` calls it synchronously on every scan load and must stay eager; the
parse/verify/rebase halves it leans on already lived in `src/io/session.ts`
(`tests/sessionIo.test.ts`).

Done: `handleFile` (~336 lines) (the open/load pipeline) now lives in
`src/app/openScan.ts` as `openScan(file, deps)`, driven through an `OpenScanDeps`
object of accessor functions closing over the shell's services rather than the
Viewer class. The two genuinely pure decisions it made are extracted and
Node-tested: `layerChipCount` (the file-total vs strided-display count the Layers
chip shows) and `shouldResetSavedWork` (fresh-project vs additive open). They sit alongside
the three-way router's session / COPC / static dispatch (`tests/openScan.test.ts`).
`main.ts` keeps a thin `handleFile` delegate that binds its running state to the deps.

Done: `handleRemoteEpt` / `openStreamingCopc` (~406 lines) (the remote / streaming
open pipeline) now live in `src/app/openStreaming.ts`, driven through an
`OpenStreamingDeps` object of accessor functions closing over the shell's services
and its mutable streaming-session state (the load flag, the COPC / EPT decode
workers, the benchmark collector, the quality preset) rather than the Viewer class.
The pure decisions the extraction exposes are Node-tested (`isEptUrl` (the
COPC-vs-EPT routing predicate the shell's URL router dispatches on), `isAbortError`
(the user-cancel classifier both remote handlers surface through) and
`linkAbortSignals`) alongside the guarded remote-open paths: the one-load guard, the
URL-validation gate, and the honest error surfacing (`tests/openStreaming.test.ts`).
The SSRF URL validation (`validateRemoteEptUrl` / `validateRemoteCopcUrl`) is
preserved exactly. `main.ts` keeps thin `openStreamingCopc` / `handleRemoteEpt`
delegates that bind its running state to the deps.

Done: `generateReportPdf` / `exportGeoContext` (~402 lines) (the report / geo-context
export orchestration) now live in `src/app/reportExport.ts`, driven through a
`ReportExportDeps` object of accessor functions closing over the shell's services
and its resolved CRS rather than the Viewer class. The capture-type fingerprint
comes from `src/diagnostics/captureProvenance.ts`, the one store the Inspector
card, the report PDF and the image exports all read, so the three surfaces cannot
state different capture types for the same scan; it also carries the user's
capture-type override into the deliverables. The
report engine (which pulls pdf-lib) is passed as a lazy loader so the module stays
free of the boot graph. The pure decisions the extraction exposes are Node-tested:
`effectiveCrsName` (the CRS-label honesty rule: only a projected / geographic CRS
names the export frame, so a post-override label can't confidently place an export
in the CRS the user rejected), `reportPointCount` (the file-scale honesty rule the
PDF's Point Count follows, the same declared-total-over-strided-subset rule as the
Layers chip's `layerChipCount`) and `isNonTerrainVerdict` (the capture-lens
predicate that rules out an aerial density guess for a compact object / interior,
re-exported from `src/diagnostics/captureProvenance.ts`),
alongside `exportGeoContext`'s static → streaming → zero frame resolution
(`tests/reportExport.test.ts`). `main.ts` keeps thin `generateReportPdf` /
`exportGeoContext` delegates that bind its running state to the deps.

Done: `exportKml` / `kmlStatus` (~83 lines) now live in `src/app/kmlActions.ts`
alongside the new scan-area export, driven through a `KmlActionDeps` object of
accessor functions. Keeping the two KML products together puts each
one's readiness rule next to its export path, so a button cannot report ready for
a reason the exporter does not honour. The polygon geometry and its fail-closed
CRS gate are a separate pure module, `src/export/scanFootprint.ts`, testable with
no DOM, three.js or proj4 (`tests/scanFootprint.test.ts`); the serialiser is
`buildFootprintKml` in the existing `src/export/kmlExport.ts`. `main.ts` keeps
four thin delegates and the deps object.

Done: the scattered keyboard-shortcut handling (the five `window` keydown
listeners for Space / measure / Esc, L, T/O/P, ⌘K and the `?` sheet, plus the
former `bindShortcuts` for the global A/M/I/V / undo-redo / delete actions) now
lives in `src/ui/keyBindings.ts` as ONE declarative `KeyBinding[]` table driven
by a single `installKeyDispatch` window listener. Precedence is explicit
`priority` data rather than listener-registration order, which makes a future
collision lint possible (`findKeyCollisions` is exported for it). `src/ui/shortcuts.ts`
keeps only the pure focus-guard / measure-key helpers the table and tests import;
component-owned keys (NavController, Viewer Esc, Lasso) stay put and appear as
`reservedOnly` table entries (`tests/keyBindings.test.ts`).

Done: the restorable view-state cluster (~162 lines) now lives in
`src/app/viewStateCoordinator.ts`: `captureViewState`, `applyViewState`,
`saveCurrentView`, `refreshViewsUI` and `applyView`, driven through a
`ViewStateCoordinatorDeps` object of accessor functions. Capture and apply are
one contract with two surfaces (a `.olvsession`'s global fields and every named
saved view), so the saved-view operations layered on them belong beside them.
Every collaborator is named structurally (the viewer surface a view state
actually touches, the Inspector mirror, the class legend, the clip panel), so
the cluster decides against plain object fakes in Node: the empty-state camera
gate, the no-scan point-filter skip, the shell's restored-window write-back, the
`getCameraState` / bare-pose fallback, and the pre-v7 camera-only restore path
that must touch nothing but the pose (`tests/viewStateCoordinator.test.ts`). The
field order and the present/absent guards stay in `src/io/viewState.ts`.
`main.ts` keeps five thin delegates and the deps object.

Done: the Save view snapshot (`saveSnapshot`, ~45 lines with its scope stamp
and provenance stamping) now lives in `src/app/snapshotAction.ts`, loaded on the
first snapshot through `loadSnapshotAction()`. It takes the viewer structurally
plus the scope stamp and the reference plane's provenance note as accessors, so
the capture order, the stamping fallback and the error path are Node-tested
(`tests/snapshotAction.test.ts`). The reference plane itself is a new feature
outside the shell: its toggle is `src/ui/referencePlaneSection.ts` in the View
panel, and the overlay, controller and settings panel load together from
`src/app/workplaneMount.ts` on first use.

Done: the `?test=1` Playwright seam (`window.__OLV_TEST_API__`, ~78 lines) now
lives in `src/app/testSeam/testSeamMount.ts`, driven through a `TestSeamDeps`
object of accessor functions (`getViewer`, the active scan id and the reclassify
panel hooks). The `__OLV_TEST_SEAM__` compile-time guard stays at the call site
in `main.ts`, which reaches the module through `loadTestSeamMount()` in
`src/app/testSeam/testSeamLoader.ts`, so a shipped build drops both the call
and the chunk
(`npm run check:no-test-seam`). `main.ts` went from 4,426 to 4,348 lines.

`src/render/Viewer.ts` (5,924): the constructor and a handful of large
methods dominate:

Done: the renderer, scene, cameras and EDL pipeline are built by
`src/render/viewerRenderBootstrap.ts` (which also holds the EDL output-node
builder) with the settings the constructor held; the sizing, pixel-ratio,
clip-range, background and depth-mode decisions are pure in
`src/render/renderBootstrapPolicy.ts` and Node-tested
(`tests/renderBootstrapPolicy.test.ts`). The Viewer keeps the fields and the
view-bound wiring that follows. Fan-out unchanged (one import in, one out),
no cycle: the FOV constant moved to the policy module.

The count fell by 9 with the refinement-phase seam: the P6 phase bookkeeping
(the park timestamp, the readiness-verdict mapping and the transition call) was
inline in the adaptive-DPR branch, so it advanced only when DPR did. It now
lives in `src/render/refinementPhaseState.ts`, which the Viewer advances every
frame and both consumers (DPR, the streaming scheduler) read.

The count fell by 37 with the profile seam. The constructor held the whole
profile-sampler walk (eligibility, the streaming gate, the buffer
concatenation and the sampler call) inline in a callback, where nothing could
test it without a WebGL context. `src/render/measure/profileSectionSeam.ts`
owns that walk now and serves the raw section over the same corridor from the
same eligibility decision, so a chart and the returns under it cannot describe
different scenes. The Viewer keeps accessors onto what it holds
(`ProfileSectionSeamDeps`) and the `profileSeam` handle.

An earlier cycle raised the count by 20 for `derivedLayerHost()`, a structural
host that lends scene membership and a redraw request so an overlay module owns
its own objects and disposal. That growth is now more than repaid.

Spans below are the symbol's real extent, read from the TypeScript symbol graph
rather than estimated by pattern-matching: an earlier revision of this table
overstated `_onResize` by 10× and listed a colour-write block that had already
been extracted, and both errors pointed the decomposition at the wrong work.

| Block | Lines | Extraction target |
|---|---:|---|
| `constructor` | 435 | controls, tools and listener wiring (view-bound remainder) |

Done: the per-frame render loop body (`_startLoop`, 107 lines) now lives in
`src/render/renderLoop.ts` as `runRenderFrame(host)` behind a structural
`RenderLoopHost`, so the paint-path choice, the EDL snap-back on settle, the
streaming tick cadence and the tool-overlay gating test against a fake host
without a WebGL or rAF context (`tests/renderLoop.test.ts`). `Viewer` keeps a
thin `_startLoop` that binds its state to the host and owns the
requestAnimationFrame scheduling (browser-only, e2e-covered).

Done: `_buildExportAdapter` (265 lines) now lives in `src/render/exportAdapter.ts`,
which takes a structural host rather than the Viewer, so the Studio's scene
reads are unit-testable without a WebGL context (`tests/exportAdapter.test.ts`).
`Viewer` keeps a twelve-line factory that binds its own state to that host.

Done: the colour-legend / scalar-range reads (`activeColorbar`, `elevationExtent`,
`intensityExtent`) now live in `src/render/colorLegend.ts` behind the same host
shape, so the origin math, seeded gating and extent scans test without a WebGL
context (`tests/viewerActiveColorbar.test.ts`). `Viewer` keeps three thin
delegates and one host binding.

Done: the `snapshot` capture pipeline (and its four overlay-compositing draw
helpers) now lives in `src/render/snapshot.ts` behind a structural
`SnapshotHost`, so the option resolution, fast-path decision and `toBlob`-null
error path test without a canvas context (`tests/snapshot.test.ts`). The
overlay-compositing branch still needs a real 2-D canvas and stays on the e2e
export suite. `Viewer` keeps a one-line delegate and a host binding.

Done: the streaming session assembly (the `attachStreamingCloud` block that
lazily loaded the render engine, constructed the `StreamingRenderer` with the
Viewer *itself* as host, wired the scheduler's node-ready / node-evicted / tick
callbacks, and picked the commit path) now lives in
`src/render/streaming/streamingAttach.ts` as `buildStreamingSession(host, …)`
behind a structural `StreamingHost`, with `disposeStreamingSession` owning the
symmetric teardown. The `StreamingRenderer` no longer takes the concrete
`Viewer`: it takes a six-method `StreamingRendererHost` (the mesh factory + the
dissolve-uniform bookkeeping), which is the coupling the "passes the Viewer
itself as host" note below flagged. The decisions the extraction exposes are
Node-tested: the `shouldFadeIn` gate, the guarded fan-out to the two
display-only node hooks (a throwing legend/reroute hook must not break the
stream) with its benchmark bookkeeping, the fresh-per-node hook read, and the
teardown order (`tests/streamingAttach.test.ts`). `Viewer` keeps a thin
`attachStreamingCloud` that binds its state through `_buildStreamingHost` and
still owns the view-bound remainder: the fresh GPU-error slate, the ordered
detach-then-mount, the render-loop-independent heartbeat, and the
camera/nav/EDL/orbit setup in `_configureForStreaming`.

Each extraction is one gated step: move the block, have it take its collaborators
as parameters, keep the deterministic e2e project green, and re-run the coverage
ratchet. Behaviour does not change; only where the code lives.

The file is long because of breadth (roughly 110 fields and 200 methods), not
because a few blocks are large, so the line count falls slowly even as the
testable logic leaves. That is expected and fine: the goal is the extractions
above, not the number.

The streaming cluster's behavioural boundary is now extracted. The part
that had a genuine boundary (the session assembly that `attachStreamingCloud`
built inline, and the `StreamingRenderer` taking the Viewer *itself* as host)
now lives behind `StreamingHost` / `StreamingRendererHost` (see the Done entry
above). What stays on the Viewer under `_streaming*` is the irreducibly
view-bound remainder: `_configureForStreaming` (camera near/far, EDL uniforms,
nav base-speed, orbit-clamp envelope, measure datum), the detach-side orbit and
datum recompute, the per-frame `_tickStreaming` camera feed, and the heartbeat.
Lifting those behind a host would mean a wide accessor surface over the camera,
EDL uniforms and orbit state with no Node-testable decision to gain (GPU/camera
mutation, not logic) so they belong here. The EDL cluster (`_edl*`) is a
smaller follow-on. Everything else on the class (the constructor's
scene/pipeline build, the render loop's requestAnimationFrame scheduling, event
wiring) is the same view-bound remainder, and belongs here.

### Help, actions and keys share one truth

`ActionDescriptor` (`src/ui/actionRegistry.ts`) is the metadata the command
palette, the shortcut sheet and Help all read; `Action` adds `run()`. The
registry is assembled by `src/app/actionDefinitions.ts` from the contributors in
`src/app/actions/`, lazily. A key binding that fires an action names it in
`actionIds`; one that fires none carries its own `help` line, and
`shortcutDescriptors()` projects the table for Help. `src/app/helpCatalog.ts`
holds the curated topics (including the scientific states) and references
actions by id only, so `HelpOverlay` renders titles, hints and keys it never
authored. `tests/helpCatalog.test.ts` and `tests/keyBindingActionLinks.test.ts`
fail when a topic references a missing action, when a binding and its action
disagree on a key, or when a non-action binding has no line for Help.

## Test and gate topology

- Unit / integration: `tests/*.test.ts`, run in sharded buckets
  (`scripts/test-bucket.mjs`) because one large vitest process can fail to
  terminate on a constrained runner.
- End-to-end: `tests/e2e/*.spec.ts`, split into two Playwright projects:
  `deterministic` (blocking, 165 tests) and `gpu` (advisory, `@gpu`-tagged).
  Untagged specs block by default.
- Coverage ratchet: `npm run coverage`, scoped to the pure modules only.
- Mutation: `npm run mutation`, scoped to the numeric core.
- Release gate: `npm run test:release` runs the static checks and lints,
  then the build and bundle budget, then every bucket and the smoke specs; it prints a literal
  `GATE EXIT:` line, which is the only trustworthy signal.

## Keeping this document honest

Every module path named above is checked by `tests/architectureMap.test.ts`: if a
path disappears or moves, the test fails and this page must be updated in the same
change. A map that drifts from the tree is worse than no map.

One convention makes that work: a destination marked *(planned)* is an extraction
target that does not exist yet, and the check skips it. When the extraction lands,
drop the marker, and the check then covers the path like any other.
