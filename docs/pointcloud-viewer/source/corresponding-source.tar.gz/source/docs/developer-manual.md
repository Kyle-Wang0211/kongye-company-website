# OpenLiDARViewer: Developer Manual

A single-page, open-source, browser-based point-cloud viewer. This manual is
the reference for building, testing, extending, and shipping the project.

- Project README: [`../README.md`](../README.md)
- Architecture map: [`architecture.md`](architecture.md)
- Contributing guide: [`../CONTRIBUTING.md`](../.github/CONTRIBUTING.md)
- Release history: [`../CHANGELOG.md`](../CHANGELOG.md)

---

## 1. Purpose

OpenLiDARViewer opens drone LiDAR surveys, terrestrial laser scans, and phone
scans from one drag-and-drop, with no install and no upload step. Local
point-cloud files are read and rendered in the browser and are not uploaded.
Once a scan is open you can navigate it in 3D, recolor it and measure it. The
Scan Intelligence report describes the dataset, and the result can be exported.

---

## 2. Requirements

### 2.1 Functional requirements

| ID | Requirement |
|------|-------------|
| FR-1 | Open a scan by dropping a single file anywhere on the window. |
| FR-2 | Import twelve static formats: `.las`, `.laz`, `.e57`, `.ply`, `.obj`, `.glb`, `.gltf`, `.xyz`, `.csv`, `.pcd`, `.ptx`, `.pts`. |
| FR-3 | Detect format from magic bytes first, file extension second. |
| FR-4 | Parse and downsample off the main thread, in a Web Worker. |
| FR-5 | Recenter georeferenced clouds to a shared local origin, doing the subtraction in float64 before the float32 downcast, within a small bounded error. |
| FR-6 | Keep clouds within a point budget (voxel-downsampling, or stride decoding when far over budget) and always display the `shown / total` count. |
| FR-7 | Render with three.js using WebGPU, with an automatic WebGL 2 fallback. |
| FR-8 | Color by RGB, height, intensity, classification, or surface normal; auto-select the best mode on load; offer only the modes the file actually contains. |
| FR-9 | Hold multiple clouds in one scene, rebased onto a shared origin. |
| FR-10 | Navigate the cloud in Orbit, Walk, and Fly modes, with WASD movement and pointer-lock mouse-look. |
| FR-11 | Measure distance, polyline, area, height, angle, and slope inside the cloud; support point editing, a metric/imperial toggle, and JSON session export/import. |
| FR-12 | Run validation modules (Health Check, Scan Report) through an open analysis-module API and show the results in the Scan Intelligence panel. |
| FR-13 | Export the cloud to PLY, OBJ, XYZ, or CSV, and save the current view as a PNG, all client-side. |
| FR-14 | Save and restore named camera views. |
| FR-15 | Support an embed mode (`?embed=1`) that strips the chrome for `<iframe>` use. |
| FR-16 | Inspect a picked point: show its real-world coordinates and attributes, with one-click copy to the clipboard. |
| FR-17 | Close the current scan: clear every loaded cloud and return to the empty state, ready for another file. |
| FR-18 | Render with Eye Dome Lighting depth shading, adaptive or fixed point sizing, and antialiased round points: all tunable from the Rendering panel. |
| FR-19 | Plan a LAS/LAZ load from its header: fast-load huge clouds by stride decoding, guard against out-of-memory, report staged progress, and allow the load to be cancelled mid-flight. |
| FR-20 | Stream hierarchical point-cloud datasets (`COPC` `.copc.laz` and `EPT` `ept.json`) (local or remote) through a view-dependent scheduler with bounded residency. |
| FR-21 | Generate multi-page PDF technical reports: three built-in templates (Survey Summary, Technical Report, Scan QA), cover + dataset summary + image exports + annotations + measurements + technical notes, with branding (accent + logo) and metric/imperial unit awareness. |
| FR-22 | Round-trip the full working state (camera, render settings, colour mode, annotations, measurements, named views, scan metadata) through a `.olvsession` JSON package. |
| FR-23 | Export the Visual Export Studio image modes (orthographic RGB, height map, intensity, classification, depth, normal, and contour) with legend customisation. |

### 2.2 Non-functional requirements

| ID | Requirement |
|------|-------------|
| NFR-1 | Privacy: local files are read and rendered client-side and are not uploaded; no accounts, no telemetry. Remote datasets and location search fetch from their listed providers. |
| NFR-2 | Performance: parsing runs in a worker; clouds are capped by voxel downsampling at a point budget. |
| NFR-3 | Compatibility: works on modern evergreen browsers; WebGPU where available, WebGL 2 everywhere else. |
| NFR-4 | Zero friction: usable with no install and no file conversion. |
| NFR-5 | Quality: strict TypeScript; the algorithmic core is test-first; CI gates every change. |
| NFR-6 | Licensing: AGPL-3.0-only; citable via `CITATION.cff`. |
| NFR-7 | Deployability: builds to static files hostable on any CDN or GitHub Pages. |
| NFR-8 | Maintainability: one responsibility per file; analysis modules never import the renderer. |

---

## 3. Tech stack

| Layer | Choice | Why |
|-------|--------|-----|
| Language | TypeScript (strict) | Type safety across the IO, model, render, and UI layers. |
| Build / dev | Vite 8 | Fast dev server, first-class Web Worker and WASM handling. |
| Rendering | three.js 0.186 (`three/webgpu`, `three/tsl`) | WebGPU renderer with a built-in WebGL 2 fallback; `three/tsl` node graphs drive the point material and the Eye Dome Lighting post-processing pass on both backends. |
| Parsing | loaders.gl (`ply`, `obj`, `gltf`) + `laz-perf` + in-repo LAS and E57 parsers | loaders.gl reads PLY, OBJ and glTF; LAS point records are decoded in-repo; `laz-perf` WASM decodes LAZ; E57 is parsed by an in-repo TypeScript module set. |
| Unit tests | Vitest | Fast, ESM-native, Node environment for the algorithmic core. |
| E2E tests | Playwright | Drives the built app in a real browser. |

---

## 4. Prerequisites

- Node.js `^22.18.0` or `>=24.11.0` (the `engines` field in `package.json`) and npm 10 or later.
- A modern browser for development (Chrome or Edge recommended for WebGPU).

### 4.1 Windows

The `windows` job in `.github/workflows/ci.yml` runs a subset of the checks on
a `windows-latest` runner, so the first list below is measured rather than
assumed. The job is blocking through `ci-green`.

#### Run natively, verified in CI on Windows

| Command | |
|---------|---|
| `npm ci`, `npm install` | |
| `npm run dev`, `npm run build`, `npm run preview` | |
| `npm run typecheck` | |
| `npm run test:buckets:verify` | |
| `npm run test:unit` | the runner starts and the suite runs; two suites still fail, see below. Shard 1/3 is the one CI exercises, and the other buckets use the same runner |
| `npm run lint:position-access`, `lint:layer-boundaries`, `lint:main-deferral`, `lint:inline-imports`, `lint:unsafe-html`, `lint:no-host-paths` | |
| `npm run test:smoke:widths` | the startup smoke spec at 320, 375, 767, 768 and 1440 px |

#### Need WSL or Git Bash

These five npm scripts invoke `bash`, and `build:live` also uses
`date +%s` and shell arithmetic:

- `npm run gate` (`bash scripts/gate.sh`)
- `npm run package` and `npm run package:source` (`bash scripts/package.sh`)
- `npm run build:live`
- `npm run evidence`

`npm run test:release:execute` chains `build:live`, so the release gate needs
bash too. With Git Bash on PATH they work as they do elsewhere; that
combination has not been exercised in CI, only reasoned about from the scripts.

#### What has not been tested on Windows

Not known to be broken, just never run there:

- The remaining test buckets (`test:export`, `test:terrain`, `test:ui`,
  `test:slow`) and `npm run test:e2e`.
- `npm run coverage`, `npm run test:build`, `npm run test:smoke:live` and the
  other scripts that set an environment variable inline
  (`VAR=1 command`). npm runs scripts through `cmd.exe` on Windows, which does
  not parse that form.
- `npm run docs:build`, `npm run mutation`, and every `benchmark:` script.

#### Known Windows gaps in the tooling

Reported here rather than papered over:

- `scripts/test-bucket.mjs` kills a timed-out shard by killing the child
  directly. On POSIX it kills the whole process group, which also reclaims
  vitest's workers. Windows has no process groups, so a shard that hangs may
  leave workers behind.
- `tests/releaseAssetVerifier.test.ts` builds its fixtures with the `zip` CLI,
  which Windows does not ship. Its eight suites now skip when `zip` is not on
  PATH, so the leg is green rather than permanently red. They skip on the
  missing tool, not on the platform: a Windows machine with `zip` installed
  runs them, and a Linux machine without it does not pretend to.

  That leaves one boundary: **the Windows leg does not cover release-asset
  verification.** Nothing that ships is unverified, because the release gate
  runs on Linux where `zip` is present, but a green Windows tick should not be
  read as covering those 37 assertions.

  `npm run release:verify` also needs `unzip`, and
  `npm run validation:defects:replay` needs `ln`. Neither ships with Windows.
- One case in `tests/defectChronology.test.ts` fails on Windows even with
  full history. The cause has not been traced.
- `npm run benchmark:clean-clone` and `npm run benchmark:archive-portability`
  call `tar`. Windows 10 and later ship bsdtar under that name, so they may
  work; nobody has checked.
- Line endings must stay LF. `.gitattributes` sets `* text=auto eol=lf`, so a
  normal clone gives you LF whatever `core.autocrlf` says. If you defeat that,
  vitest stops parsing the `scripts/*.mjs` modules the lint suites import
  (`SyntaxError: Invalid or unexpected token`), and bash refuses `gate.sh` and
  `package.sh` outright.

---

## 5. Getting started

```bash
git clone https://github.com/aurtechmx/openlidarviewer.git
cd openlidarviewer
npm install
npm run dev
```

Open the printed local URL and drop a scan, or press "Launch a sample", which streams the swissSURFACE3D sample (83.8 MB) over the network.

---

## 6. Project structure

```
src/
  io/                    One file per format or per IO concern.
    sniffFormat.ts         Format detection (magic bytes -> extension).
    lasHeader.ts           LAS public-header parser.
    coordinateBridge.ts    f64 -> f32 recentre — precision-critical.
    loadPlan.ts            Budget-aware load planning (pure, unit-tested).
    strideSample.ts        Stratified jittered stride sampling (pure, unit-tested).
    loadProgress.ts        Staged-progress vocabulary (pure, unit-tested).
    loadTelemetry.ts       Per-stage load timing (pure, unit-tested).
    loadLas/E57/Ply/Obj/Gltf/Xyz/Pcd/Ptx/Pts.ts   Format -> PointCloud loaders.
    e57/                   From-scratch E57 parser — header de-paging,
                           a minimal XML reader, and a CompressedVector decoder.
    copc/                  COPC source + worker decoder + chunk decode.
    ept/                   EPT detection, types, hierarchy walk, binary +
                           laszip tile decoders, chunk decoder, URL validation.
    range/                 RangeSource interface + Local/HTTP/Instrumented
                           range sources for streaming reads.
    parseBuffer.ts         Loader dispatch + budget-aware routing (DOM-free).
    loadFile.ts            File -> PointCloud: preflight + the parse worker.
    parseWorker.ts         The persistent Web Worker entry.
    lazPerfWasm.ts         laz-perf WASM glue for LAZ decoding.
    exporters.ts           PointCloud -> PLY / OBJ / XYZ / CSV text.
    session.ts             `.olvsession` v3 schema + serialise/parse helpers.
  model/
    PointCloud.ts          Normalized in-memory cloud model.
  process/
    voxelDownsample.ts     Voxel-grid downsampling.
  render/
    Viewer.ts              three.js WebGPU / WebGL 2 scene + EDL pipeline.
    colorModes.ts          RGB / height / intensity / classification / normal.
    edl.ts                 Pure Eye Dome Lighting maths (unit-tested).
    pointStyle.ts          Pure adaptive point-size curve (unit-tested).
    navMath.ts             Pure navigation math (unit-tested).
    NavController.ts       Orbit / Walk / Fly, keyboard, pointer-lock, tweens.
    measure/               Measurement toolkit — pure geometry, formatting,
                           serialisation, label layout, plus the controller
                           and SVG overlay.
    annotate/              Annotation model + store + controller + overlay.
    streaming/             Scheduler, octree, cache, node store, renderer,
                           streaming source contract, pure pick selection,
                           and the device-profile / tier-adaptation helpers.
    InspectTool.ts         Click a point to read its attributes.
    LiveProbe.ts           Live coord/attribute readout under the cursor.
    pointInfo.ts           Pure picked-point data + serialisation (unit-tested).
  export/                  Visual Export Studio — orthographic-RGB, height,
                           intensity, classification, depth, normal, contour
                           exporters + legend renderer + scan-report card.
  report/                  PDF Report Engine — types, branding, five
                           templates, section builders, asset composer,
                           pdf-lib renderer. All lazy-chunked.
  analysis/
    ModuleApi.ts           Analysis-module interface + registry.
    modules/               healthCheck.ts, scanReport.ts.
  ui/
    Stage / DropZone / Inspector / NavBar / ProjectCard / MeasurePanel /
    StreamingPanel / ToolDock / HelpOverlay / DebugOverlay / embedBridge / dom.ts
  lazyChunks.ts            Dynamic-import seam (kept outside the live
                           source-transform so Vite can statically analyse
                           every code-split boundary).
  main.ts                  Wires the viewer, navigation, UI, and modules.
tests/                     Vitest unit tests; tests/e2e/ holds Playwright specs.
```

As a rule, each `src/io/*` file owns exactly one format or one concern;
`Viewer.ts` owns all three.js state; analysis modules and the measurement
core consume plain data only and never import three.js. The "Scan
Intelligence" panel is built in `src/ui/Inspector.ts`.

---

## 7. Architecture

Data flow for a dropped file:

```
drop -> preflight { head-slice sniff -> LAS/LAZ header -> load plan }
     -> persistent Web Worker { decode per plan -> coordinate bridge
        -> voxel downsample } -> PointCloud -> Viewer (WebGPU / WebGL 2)
                                            -> analysis modules -> Scan Intelligence
```

Three load-bearing decisions:

1. The coordinate bridge. Georeferenced LAS data uses large UTM
   coordinates that overflow 32-bit floats. Every cloud is recentered to an
   integer local origin; the subtraction is done in float64 *before* the
   float32 downcast. `.las`/`.laz` records are decoded straight into that
   local frame (the float64 arithmetic precedes the float32 store) so both
   keep full precision with no intermediate global-coordinate pass.
2. Preflight, then parse in a worker. The format and, for LAS/LAZ, a
   budget-aware load plan are decided on the main thread from a 16 KB head
   slice, so an unsupported file fails before any large read. Parsing and
   downsampling then run in a long-lived worker, reused across loads, so the
   UI stays responsive on large surveys.
3. The analysis API. A module is `{ id, label, run(cloud, selection?) }`
   returning pass/warn/fail rows. Modules are pure functions over
   `PointCloud`: decoupled from rendering and easy to unit-test.

See [`architecture.md`](architecture.md) for the full map.

---

## 8. Commands

| Command | Purpose |
|---------|---------|
| `npm run dev` | Vite dev server with hot reload. |
| `npm run build` | Typecheck then produce the static production build in `dist/`. |
| `npm run build:live` | The deployment build: same as `build`, plus a source-transform pass on the project's own code (Vite mode `live`). Used only for the public live site. |
| `npm run preview` | Serve the production build locally. |
| `npm run typecheck` | `tsc --noEmit`: strict type checking. |
| `npm test` | Run the Vitest unit suite once. |
| `npm run test:watch` | Vitest in watch mode. |
| `npm run test:e2e` | Playwright end-to-end tests (run `npx playwright install --with-deps chromium` first). |
| `npm run test:smoke:widths` | The startup smoke spec at five viewport widths: 320, 375, 767, 768, 1440. One build and one preview server serve all five. |
| `npm run test:e2e:devices` | Opt-in, not run in CI: the phone, tablet and device-agnostic specs under phone and tablet device emulation (`playwright.devices.config.ts`). Cases pinned to a desktop viewport carry the `@desktop-only` tag and are excluded. Emulation is not a device: a pass speaks to layout and touch, not to the renderer on real hardware. |

A `?debug=1` URL parameter logs a per-stage load-timing breakdown (read, decode, downsample, GPU upload, total) to the browser console. It is useful when profiling the load pipeline and is off in normal use.

---

## 9. Testing strategy

- Unit (Vitest, Node). The algorithmic core is test-first: format
  sniffer, LAS header parser, coordinate bridge, `PointCloud`, every loader,
  the E57 parser, voxel downsampling, parse dispatch, the load planner, the
  stratified stride sampler, the staged-progress and telemetry helpers, color
  modes, navigation math, the
  Eye Dome Lighting depth maths and the adaptive point-size curve. The
  measurement core is covered too (geometry, formatting, serialization, label
  layout), along with the exporters and both analysis modules. Tests assert against deterministic
  fixtures (including a committed synthetic E57, `tests/fixtures/synthetic.e57`,
  generated by `scripts/make-e57-fixture.mjs`) with ground truth in
  `tests/fixtures/FIXTURES.md`.
- End-to-end (Playwright). `tests/e2e/viewer.spec.ts` drives the built
  app. It loads a sample and confirms the cloud renders and the Scan Report
  appears, then loads a second cloud and drops an E57 scan. It also closes a scan
  and loads another, and checks embed mode. `tests/e2e/measure.spec.ts` covers the measurement
  toolbar with its kind picker and units toggle, then round-trips a distance
  placement through session export. `tests/e2e/rendering.spec.ts` toggles Eye Dome Lighting
  (exercising the post-processing pipeline) and the point-size and
  antialiasing controls.
- Not unit-tested: `Viewer.ts`, `NavController.ts`, the measurement
  controller and SVG overlay, `InspectTool.ts`, and the worker entry require a
  browser/GPU and are covered by E2E plus manual checks. Their pure logic
  lives in `navMath.ts`, `pointInfo.ts`, and `render/measure/`, which *are*
  unit-tested.

---

## 10. Quality gates (CI)

`.github/workflows/ci.yml` runs on every pull request, every push to `main` and
every release tag. The `ci-green` job is the required check, and it passes only
when each of these jobs succeeds:

- `verify`: typecheck, static lints and both build contracts.
- `test`: the Vitest suite, sharded.
- `smoke`: smoke tests of the built app in Chromium, at desktop and phone widths.
- `e2e-deterministic`, `e2e-firefox`, `e2e-webkit`: Playwright suites.
- `windows`: the Node and browser checks on a Windows runner.
- `npm-audit`: `npm audit --omit=dev --audit-level=high` over the runtime
  dependencies.

`e2e-gpu`, `e2e-journeys` (the UX journey specs in `tests/e2e/journeys`, run
locally with `npm run test:e2e:journeys`) and `coverage` report results without
blocking a merge.

Pre-merge checklist for any PR into `main`: all review threads resolved,
`ci-green` passing, branch rebased on the latest `main`.

The release workflow (`.github/workflows/release.yml`) does not repeat the
Firefox, WebKit and Windows legs. Its `ci-at-tag` job checks through the GitHub
API that a CI run at the tagged commit completed with `ci-green` and every job
it needs at `success`, and `release-ready` depends on that job.

---

## 11. Coding standards

- Strict TypeScript: `verbatimModuleSyntax` (use `import type` for
  type-only imports), `erasableSyntaxOnly` (no `enum`, no `namespace`), and
  full `strict` mode.
- Conventional Commits: `type(scope): description`; `feat`, `fix`,
  `docs`, `test`, `ci`, `chore`, `refactor`, `perf`.
- Branching: trunk-based; short-lived `feature/*` and `fix/*` branches,
  merged into `main` via pull request.

---

## 12. Extending: writing an analysis module

Analysis is an open API. A module receives a `PointCloud` and returns rows;
it never touches the renderer.

```ts
import type { AnalysisModule } from '../ModuleApi';

export const myModule: AnalysisModule = {
  id: 'my-module',
  label: 'My Module',
  run(cloud) {
    return {
      rows: [
        { label: 'Points', value: String(cloud.pointCount), status: 'info' },
      ],
    };
  },
};
```

Register it in `main.ts` with `registry.register(myModule)` and add a
matching `tests/myModule.test.ts`.

---

## 13. Security & privacy

- Local files stay local. Files you open are read, parsed, and rendered in
  the browser and are not uploaded: there is no backend to send them to.
- No telemetry, no accounts. The network requests OpenLiDARViewer makes are:
  its own static assets; a remote dataset you open (fetched from that provider's
  host); the location search you initiate (Microsoft Planetary Computer); and, when you
  open a search result, a request to Planetary Computer's signing service with
  that tile's address.
- Runtime dependencies, as `package.json` lists them:

  | Package | Role |
  |---------|------|
  | `three` | WebGPU and WebGL 2 rendering |
  | `@loaders.gl/core` | Loader entry point for the loaders.gl parsers |
  | `@loaders.gl/ply` | PLY parsing |
  | `@loaders.gl/obj` | OBJ parsing |
  | `@loaders.gl/gltf` | glTF and GLB parsing |
  | `laz-perf` | LAZ decompression (WASM) |
  | `pdf-lib` | PDF report rendering |
  | `proj4` | Coordinate reprojection |
  | `@fontsource/jetbrains-mono` | Monospace typeface |
  | `@fontsource-variable/inter` | Listed, with no module importing it |

- CI installs from the lockfile. `npm audit --omit=dev --audit-level=high`
  runs on every pull request, every push to `main` and every release tag, and
  `ci-green` requires it.

---

## 14. Browser & platform support

| Browser | WebGPU | WebGL 2 fallback |
|---------|--------|------------------|
| Chrome / Edge | Default | Yes |
| Firefox | Windows; macOS on arm64 | Yes |
| Safari | iOS / macOS 26+ | Yes |

Where WebGPU is unavailable the viewer automatically uses WebGL 2. The active backend is shown in the UI.

### Cross-browser end-to-end results

The deterministic Playwright set (`grepInvert: /@gpu/`, 165 specs) runs on all
three engines. All three run in `ci.yml` and block merges
through `ci-green`.

| Engine | Passed | Skipped |
|--------|--------|---------|
| Chromium | 161 | 4 |
| Firefox | 158 | 7 |
| WebKit | 156 | 9 |

Every engine skips the same four. The extra skips are all one capability:
clipboard read. Five specs check that the camera moved by copying the "Copy
view link" share link and reading the pose back out of the clipboard. Only
Chromium implements the clipboard permission in Playwright: Firefox and WebKit
both reject `grantPermissions(['clipboard-read'])` with "Unknown permission",
and WebKit's `navigator.clipboard.readText()` also resolves to an empty
string instead of the copied text. Three of the five ask for the permission and
so skip on both engines; the other two read the clipboard without asking and
skip on WebKit only, since Firefox's failed `writeText` makes the app fall back
to putting the state in the address bar, which the oracle can still read.

The skips name that capability rather than loosening the assertion, and the
maths underneath stays covered engine-independently by `tests/navMath.test.ts`,
`tests/panMath.test.ts`, and `tests/touchGesture.test.ts`.

WebKit is also much slower than the other two here, because its WebGPU runs on a
software backend. A local WebKit run can show a few `page.goto` timeouts under
CPU pressure; they land on a different spec each run and pass when that spec runs
on its own, and CI's `retries: 1` absorbs them. Firefox finishes the same 165
specs in about a minute with none.

One backend difference is worth knowing when reading a failure: on a Mac,
Playwright's WebKit returns a real WebGPU adapter, while headless Chromium and
Firefox return none and fall back to WebGL 2. `edlDefaultEnabled` turns Eye Dome
Lighting on for desktop WebGPU only, so EDL starts on under WebKit and
off under the other two. Specs must not assume either starting state.

---

## 15. Deployment

`npm run build` emits static files in `dist/`. Host them on any static host
(any static host, object store or CDN): there is no server
component. For embedding, serve the same build and link with `?embed=1`.

Embedding from another origin needs two settings. A host that can send headers
widens `frame-ancestors` in `public/_headers` and `public/.htaccess`. A host that
cannot (GitHub Pages, a bucket) also cannot restrict who frames the viewer, so
the viewer decides for itself: build with `OLV_EMBED_ORIGINS` set to a
comma-separated list of the origins that may embed it (`https://portal.example.org`).
It is a build-time constant (`__OLV_EMBED_ORIGINS__`, empty by default); the
viewer's own origin is always trusted, and `?embedParent=` / `?embedOrigins=` in
the URL can only narrow the list. A framed page that no rule allows shows a
notice instead of starting. The policy lives in `src/ui/embedPolicy.ts` (pure,
unit-tested in `tests/embedPolicy.test.ts`), the notice in `src/ui/frameGuard.ts`,
and `src/ui/frameGuardBoot.ts` runs first: `src/main.ts` imports `src/ui/embedConfig.ts` before anything else, and that module imports the guard before anything else. If the policy cannot be evaluated the guard fails closed for a framed page. See
[usage.md](usage.md#embedding-origin-and-security).

---

## 16. Release history

The full per-release record (what shipped, where, and the supporting
test counts and build metrics) lives in [`../CHANGELOG.md`](../CHANGELOG.md).
The v0.3.3 release notes give a complete summary of every capability
shipped through this release.

---

## 17. Known limitations

OpenLiDARViewer is an actively maintained viewer, not a survey-grade processing suite.
Measurement is for visual inspection, large files are bound by browser memory
and GPU limits, and OBJ/glTF meshes are shown as their vertices. See
[`limitations.md`](limitations.md) for the full list.
