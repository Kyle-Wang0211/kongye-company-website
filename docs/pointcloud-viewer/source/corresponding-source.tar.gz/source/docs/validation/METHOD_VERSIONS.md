# Method versions

Every scientific method OpenLiDARViewer runs is identified by a stable `id@version` so a result can name the exact algorithmic path behind it, and a later release can improve one method without changing the meaning of the others. The authoritative catalogue is `docs/science/METHOD_REGISTRY.md` and its runtime companion `src/science/methodRegistry.ts`.

## Contour Studio geometry (v0.5.9)

The Contour Studio geometry products carry these method ids on the product and in the exported vector attributes (`method_id`, `method_version`):

- `olv.contour.analytical@2`: exact isolines of the terrain grid (marching squares, cell-centre registration). No smoothing or displacement. Levels are multiples of the interval in world elevation; `@1` placed them on multiples in the recentred local frame, which put a 5-unit interval at 334, 339, … whenever the floored origin was not itself a multiple.
- `olv.contour.generalize@1`: the shipped cartographic generalization: simplification at a bounded per-purpose tolerance (each Contour Studio purpose maps to a tolerance in grid cells) followed by Chaikin corner-cutting. This is the id stamped on every generalized Contour Studio export.
- `olv.contour.generalize.dp@1`: a Douglas to Peucker variant with a fixed tolerance, available in the geometry-product library.
- `olv.contour.generalize.terrain-adaptive@1`: a per-feature variant that scales tolerance by support, confidence, closure, and length within a bounded band, then applies the same Chaikin corner-cutting. This is the id stamped when a surface selects terrain-aware generalization, which reaches the shipped export path.

These ids are stamped by the geometry-product builders. Routing them through the canonical `ScientificAnalysisRecord` (which validates ids against the method registry) is part of the export wiring and is registered there when an exporter emits the record.

## DTM void fill (v0.7.1)

The delivered DTM method is `olv.dtm.geodesic-fill@1`: ground returns are binned to the grid and interior voids are filled by geodesic-distance propagation from measured cells, with an Euclidean inverse-distance prefill only seeding the provisional surface (`src/terrain/ground/geodesicFill.ts`). Earlier releases stamped the same computation as `olv.dtm.idw-fill@2`, an id that named the prefill rather than the algorithm. That id stays registered and marked superseded, so a session or export stamped with it at version 1 or 2 still resolves; its version 2 and `olv.dtm.geodesic-fill@1` describe the same behaviour, and its version 1 is the older fill that reached outside the data footprint. New records are stamped with the new id.

## Stability rule

An id is stable; a behavioural change bumps the `@version`. A number produced by `id@N` must not silently change meaning under the same id and version. When a method changes, its entry in `docs/science/METHOD_REGISTRY.md` and the version stamp move together.
