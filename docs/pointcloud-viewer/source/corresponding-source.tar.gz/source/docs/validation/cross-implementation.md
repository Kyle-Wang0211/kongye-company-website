# Cross-implementation validation (E4)

The evidence model's load-bearing boundary is E3 → E4. Everything at or below
E3 is checked against our own code or our own synthetic data. **E4
(`E4_CROSS_IMPLEMENTATION_VALIDATED`) means a second, independent implementation
agrees with our output within a stated tolerance.** This page is the procedure
for producing that independent output.

Eighteen products are at E4. Five are algorithm checks against GDAL:
`SLOPE-RASTER`, `ASPECT-RASTER`, `HILLSHADE`, `CONTOURS` and
`MEAS-AREA` (polygon area against GDAL/OGR `OGR_GEOM_AREA` on a committed
planar-polygon fixture, agreeing to machine precision, see
`tests/measureAreaCrossCheck.test.ts`). Slope, aspect and hillshade were compared
against GDAL 3.13.1 on the same frozen analytic fixture, and against the
surface's closed-form gradient, in the same run; contours were compared against
GDAL `gdal_contour` on a separate frozen analytic tilted plane (where linear
interpolation is exact, so the tolerance measures agreement, not interpolation
noise). The other three are surface-gridding checks against PDAL: `DSM` (max
return) and `DTM` (min return) were compared against PDAL 2.10.2
`writers.gdal` on three seeded synthetic clouds each, agreeing over 7500 cells.
The live DTM uses median aggregation, and its median gridding on measured cells
was also compared against R terra 1.9.46 `rasterize(fun = median)` and SciPy
1.17.1 `binned_statistic_2d(statistic = 'median')` on eight seeded clouds,
agreeing on 18498 and 18655 cells within 1×10⁻⁶ m after float32 rounding, with
matching occupancy masks, on a 1 m grid with origin (0, 0). Under protocol v2
and v3 the same comparison at 0.25, 0.5, 1, 2 and 5 m cells, with the grid
origin at the data minimum as `rasterizeDtm` builds it, agreed on 39850, 28499,
10980, 2808 and 447 cells; cells on an edge where a return lies were left out of every leg. A
seeded range study (protocol v5, rerunning v4 with exact reference I/O after v4
failed on 9-decimal reference output) agreed on 37012 cells over 50 cell sizes
from 0.1 to 10 m, on small and UTM-scale coordinates after LAS ingest, including
float32 ties. A DTM outside 0.1 to 10 m is not covered. terra is the independent reference;
SciPy bins over edges this project supplies. Interpolated (filled) cells are
not covered.
and `CHM` (clamped DSM minus DTM) was compared against the PDAL max grid
minus the PDAL min grid on the same clouds. The last two are terrain descriptors,
each checked three ways against an independent tool AND the closed form on a
controlled analytic fixture: `TPI` against gdaldem 3.13.1 TPI on a
low-amplitude quadratic (chosen so the reference's float32 mean accumulation
stays below the tolerance), and `VRM` against SAGA 7.8.2's Vector Ruggedness
Measure on a smooth tilted quadratic (chosen so Horn's normal and SAGA's
estimator converge), with OLV reproducing the closed-form Sappington VRM to under
1×10⁻⁹. The eleventh is a measurement rather than a raster: `MEAS-PROFILE`,
the corridor section profile, against a reference assembled from two tools
because no single one exposes the operation. OGR's SpatiaLite functions place
every point on the section line and R's `quantile(type = 7)` reduces each
station, so neither half of the profile is written twice here. One of its two
fixtures also carries a closed form: ten corridor elevations in an exact
arithmetic progression reduce to `first + step·(p/100)·(n − 1)`, with no sort and
no order statistic. The twelfth is a reader rather than an algorithm:
`E57-INGEST`, against PDAL 2.10.2 `readers.e57` over every point of a public
CC-BY terrestrial scan. Nine dimensions are compared (cartesian X/Y/Z, the
`nor:` namespaced surface normals, and colour) as an exact quantised integer sum
at a 1×10⁻⁶ quantum, which one wrong point of 1,788,994 cannot survive. The
thirteenth is a coordinate conversion: `CRS-UTM-PROJECTION`, against PROJ 9.8.1
`cs2cs` and GeographicLib 2.7 `GeoConvert` over 36 frozen WGS-84 coordinates.
The two legs answer different questions. GeoConvert applies the UTM zone rules
itself, so it is the independent check on zone selection, exception zones
included. `cs2cs` is handed an EPSG code built from the GeographicLib zone rather
than from the candidate, so the projection arithmetic is measured against a
target the candidate cannot move.

The fourteenth and fifteenth are statistics rather than products of a surface:
`HOLDOUT-RMSE` and `NVA-VVA`, against base R 4.6.1 over six frozen residual
vectors. Bias, RMSE and the maximum absolute residual agree to about 4.4×10⁻¹⁶
over eighteen comparisons, and the 95 percent figure, 1.96 times that RMSE,
agrees to about 8.9×10⁻¹⁶ over six, both under a 1×10⁻¹² tolerance. What that
establishes is that the formula is computed correctly outside TypeScript,
including that RMSE is the raw second moment rather than a standard deviation. The recomputation runs checkpointAccuracy and computeVerticalAccuracy on the
frozen residuals, not the hold-out procedure in holdoutValidateDtm, and it
excludes P95, so `NVA-VVA` covers the NVA figure only and the VVA-style P95 is
registered separately as `VVA-P95` at E3.
It establishes nothing about accuracy: both claims still require E5, the
held-out points still come from the same source as the interpolated ones, and
the tolerance was adopted alongside the result rather than preregistered.
Median, NMAD and P95 are excluded because R interpolates at type 7 while
`checkpointAccuracy` takes the nearest rank, a difference the study records
rather than resolves.

The sixteenth and seventeenth are the change pair, `CHANGE-RASTER` and
`CHANGE-VOLUME`, against GRASS 8.5.0 `r.mapcalc` and `r.univar` over eight
frozen synthetic epoch pairs at one metre, under `PROTO-CHANGE-GRASS-MAPCALC`.
Every case agrees with GRASS and with the closed-form volume each pair was built
from, on gain volume, loss volume, gained cells, lost cells and comparable
cells; both sides select the same 3007 comparable cells and the largest relative
difference is 7×10⁻⁶ under a 1×10⁻⁵ gate derived from the candidate's Float32
storage. Truth is scored first and implementation agreement second, because two
programs summing the same wrong cells agree perfectly. Only one-metre metre-CRS
grids were compared, agreement with GRASS on synthetic epoch pairs is not
accuracy against surveyed field change, and the protocol freeze is
`adopted-with-result` rather than a preregistration, because it landed in the
same commit as the first result.

The eighteenth is the flow router, `TERRAIN-FLOW-PULSE`, and it is the first
compared on real terrain against outputs two other programs published, rather
than against a reference run here. On two Bear Creek crops of a USGS NED DEM,
the Priority-Flood spill level equals TauDEM 5.3.8 PitRemove's filled elevation
on all 119,119 distinct cells (172,702 cell comparisons across three runs: crop A,
crop B with NoData as outlet, crop B with NoData as wall), under
`PROTO-FLOW-PITREMOVE-TAUDEM-BEAR-CREEK`. The crops were chosen so that a fill
computed on the crop alone reproduces TauDEM's whole-grid fill. On one 25 m window of the Riviere des Pluies catchment, Reunion, against GRASS GIS
8.3.2: 99.2% of catchment cells with a unique steepest descent take the same D8
direction (`PROTO-FLOW-D8-GRASS-REUNION`), the catchment from the mouth has a
Jaccard index of 0.999 (`PROTO-FLOW-CATCHMENT-GRASS-REUNION`), and 95.2% of
catchment cells are within 5% of the accumulation, 87.0% exact
(`PROTO-FLOW-ACCUMULATION-GRASS-REUNION`). The GRASS outputs come from a
single-flow router whose module the dataset does not name (inferred from the
output encoding to be `r.watershed` in single-flow mode, a least-cost router),
over a DEM that still holds closed depressions,
so routing agrees within the stated tolerances and not exactly. All four gates
were preregistered in `validation/protocols/flow-pulse-external-references-v1.md`
before the router ran on these data, after a feasibility run of a separate
scratch implementation against the same references. The same comparison lifts
`TERRAIN-FLOW-DEPRESSION-INVENTORY` to its required E3: in conditioned mode its
187 depressions match TauDEM's on count, cells, area, deepest fill and spill
level.

| Product | Reference | Test | Cells | Max difference | Tolerance |
|---|---|---|---|---|---|
| `SLOPE-RASTER` | GDAL 3.13.1 Horn slope | `tests/slopeCrossCheck.test.ts` | 11,564 interior | under 0.001° | 0.5° |
| `ASPECT-RASTER` | GDAL 3.13.1 Horn aspect | `tests/aspectCrossCheck.test.ts` | 10,932 interior, slope above 2° | 0.0002° | 0.5° circular |
| `HILLSHADE` | GDAL 3.13.1 Horn hillshade, az 315 / alt 45 / z 1 | `tests/hillshadeCrossCheck.test.ts` | 11,564 interior | 1.00 level (8-bit); 0.0000643 vs closed form | 1.0 on 0 to 255 |
| `CONTOURS` | GDAL 3.13.1 `gdal_contour` | `tests/contourCrossCheck.test.ts` | 2,222 vertices | 2.9×10⁻⁵ m vs GDAL (2.0×10⁻⁷ vs closed form) | 0.05 m |
| `DSM` | PDAL 2.10.2 `writers.gdal` max | `tests/groundFilterPdalAgreement.test.ts` | 7,500 (3 clouds) | under 4×10⁻⁶ m | 5×10⁻⁵ m |
| `DTM` | PDAL 2.10.2 `writers.gdal` min | `tests/groundFilterPdalAgreement.test.ts` | 7,500 (3 clouds) | under 4×10⁻⁶ m | 5×10⁻⁵ m |
| `DTM` (median, measured cells) | R terra 1.9.46 `rasterize` median; SciPy 1.17.1 `binned_statistic_2d` median | `tests/dtmMedianCrossCheck.test.ts` | 18,498 terra, 18,655 SciPy (8 clouds) | 0 after float32 rounding (3.8×10⁻⁶ m unrounded) | 1×10⁻⁶ m |
| `CHM` | PDAL 2.10.2 `writers.gdal` max minus min | `tests/chmCrossCheck.test.ts` | 7,500 (3 clouds) | under 8×10⁻⁶ m | 0.1 m |
| `TPI` | gdaldem 3.13.1 TPI (+ closed form) | `tests/tpiCrossCheck.test.ts` | 3,364 interior | under 9×10⁻⁷ | 1×10⁻⁵ |
| `VRM` | SAGA 7.8.2 VRM (+ closed form, ≤1×10⁻⁹) | `tests/vrmCrossCheck.test.ts` | 3,136 interior | under 2×10⁻⁵ vs SAGA | 1×10⁻⁴ |
| `E57-INGEST` | PDAL 2.10.2 `readers.e57` | `tests/e57PdalCrossDecode.test.ts` | 1,788,994 points × 9 dimensions | 0 (exact) | 1×10⁻⁶ m |
| `MEAS-PROFILE` | OGR/SpatiaLite 5.1.0 chainage + R 4.4.1 `quantile(type = 7)` (+ closed form on the ramp) | `tests/profileCrossCheck.test.ts` | 751 stations (3 parameter sets) | 3.6×10⁻¹⁵ m (0 on the ramp) | 1×10⁻⁶ m |
| `CRS-UTM-PROJECTION` | PROJ 9.8.1 `cs2cs` + GeographicLib 2.7 `GeoConvert` | `tests/geodesyOracleAgreement.test.ts` | 36 fixtures × 2 coordinates × 2 oracles | 4.531×10⁻⁴ m easting, 9.521×10⁻⁴ m northing (v0.6.6 series; under 3×10⁻⁹ m with the series used from v0.7.0) | 1.5×10⁻³ m |
| `HOLDOUT-RMSE` | base R 4.6.1 (bias, RMSE, max absolute residual) | `tests/statisticsRAgreement.test.ts` | 18 comparisons over 6 residual vectors | 4.4×10⁻¹⁶ m | 1×10⁻¹² m |
| `NVA-VVA` | base R 4.6.1 (1.96 × pooled RMSE) | `tests/statisticsRAgreement.test.ts` | 6 comparisons over 6 residual vectors | 8.9×10⁻¹⁶ m | 1×10⁻¹² m |
| `CHANGE-RASTER` | GRASS 8.5.0 `r.mapcalc` (+ closed form) | `tests/changeGrassAgreement.test.ts` | 3,007 comparable cells (8 epoch pairs) | 7×10⁻⁶ relative | 1×10⁻⁵ relative |
| `CHANGE-VOLUME` | GRASS 8.5.0 `r.univar` (+ closed form) | `tests/changeGrassAgreement.test.ts` | 3,007 comparable cells (8 epoch pairs) | 7×10⁻⁶ relative | 1×10⁻⁵ relative |
| `TERRAIN-FLOW-PULSE` | TauDEM 5.3.8 PitRemove (spill level) | `tests/flowPulseExternalReferences.test.ts` | 172,702 comparisons, 119,119 distinct cells (2 crops, 3 runs) | 0 (exact) | 0 after Float32 cast |
| `TERRAIN-FLOW-PULSE` | GRASS GIS 8.3.2 D8 direction | `tests/flowPulseExternalReferences.test.ts` | 70,656 uniquely steepest catchment cells | 99.21% agree | at least 98% agree |
| `TERRAIN-FLOW-PULSE` | GRASS GIS 8.3.2 catchment | `tests/flowPulseExternalReferences.test.ts` | 72,112 cells in either catchment | Jaccard 0.9990 | Jaccard at least 0.99 |
| `TERRAIN-FLOW-PULSE` | GRASS GIS 8.3.2 accumulation | `tests/flowPulseExternalReferences.test.ts` | 72,078 catchment cells | 95.2% within 5% (87.0% exact) | at least 90% within 5% |

Every tolerance above except aspect, the five rows from `CRS-UTM-PROJECTION` to
`CHANGE-VOLUME` and the four `TERRAIN-FLOW-PULSE` rows was registered in
`REFERENCE_SLOTS` before the references were generated. The four flow
tolerances are not reference slots: they were preregistered in
`validation/protocols/flow-pulse-external-references-v1.md`, committed with the
fixtures before the router ran on them. Aspect's 0.5 degree tolerance was carried
over from slope in the same change that produced its result, so it is adopted,
not preregistered. The two change tolerances were written in
the same change as their first result, so `PROTO-CHANGE-GRASS-MAPCALC` records
`adopted-with-result` rather than `preregistered`; the witness commit is named so
a reader can check that the fixture matrix, the level of detection and the
tolerance basis predate the GRASS run. The two R tolerances were written in the
same change as their first result, so their protocol records
`adopted-with-result` rather than `preregistered`. The UTM tolerance was written
in the same change as its first result, so its protocol records `adopted-with-result` rather than
`preregistered`. It was still set from the physical question and not from the
number that came back: a grid coordinate a reader treats as exact has to agree
with an independent implementation well inside the millimetre survey practice
rounds to. The two references agree with each other to 2×10⁻⁹ m over the same
fixtures, six orders below the gate, which is what makes the residual the
candidate's own rather than a disagreement between the references. That residual
changes sign across the fixture set, so it is series truncation and not an offset
in one direction. WGS 84 stands on both sides of every comparison, so no datum
transformation is exercised and no PROJ transformation grid is consulted, and
`latLonToUtm` takes no height, so vertical reference and ECEF are outside it. Each reference output, the exact command, the tool version and the
checksums are committed beside its input. The three GDAL rasters share one DEM,
each pinning it by hash; contours use their own tilted-plane DEM, because on a
plane linear interpolation is exact and the tolerance measures cross-implementation
agreement rather than the interpolation error a curved surface would add. The
DSM and DTM references are gridded from seeded synthetic clouds pinned by hash.

This validates the slope, aspect, hillshade and contour *algorithms*, and the
DSM and DTM cell gridding, against an independent implementation on known
inputs. The DSM and DTM checks use clouds where the reference radius is below
half a cell, so they cover the gridding step, not ground classification
(`GROUND-FILTER` stays partial) and not real-terrain void interpolation. None of
this establishes field or survey-grade accuracy, and it says nothing about the
other terrain products, each carries its own claim and its own evidence level.

## Hillshade agrees, but read its tolerance carefully

The hillshade figures carry a caveat the slope and aspect ones do not.

Both implementations compute the same illumination model,
`h = cos(zenith)·cos(slope) + sin(zenith)·sin(slope)·cos(azimuth − aspect)`,
over a Horn gradient, with the same compass-azimuth and altitude-above-horizon
conventions. They differ only in how they pack that intensity into a byte: we
write `round(255·h)`, GDAL writes `round(1 + 254·h)` and reserves level 0 for
nodata.

That difference is exactly `(1 − h)` levels. It is always under one level, for
any surface, which means it consumes most of a one-level tolerance budget by
itself. On this fixture it spends 0.900 of the 1.0, leaving about 0.1 of
headroom. **The ours-versus-GDAL leg on its own is therefore a weak instrument:
it would not catch a small shading error.**

What actually carries the hillshade claim is the other two results, which are
sharp:

- ours versus the closed form: max separation 0.0000643 of a level, RMSE
  0.0000072, over all 11,564 interior cells;
- and a zero-tolerance identity, re-encoding our intensity in GDAL's own scale,
  `round(1 + 254·h)`, reproduces the committed `hillshade-gdal.asc` exactly
  at every one of those cells.

The reported figures include the encoding difference rather than subtracting it,
so the headline number describes the two products as they ship. The application
writes `round(255·h)`; that is the encoding its rasters carry. Full detail in
`tests/fixtures/reference/hillshade/README.md`.

The check covers the single-direction model only. `computeMultiHillshade` is a
different illumination model with its own claim, unchanged by this.

Every remaining entry in `REFERENCE_SLOTS` still ships `pending`. No reference
output is bundled or fabricated; a product moves to E4 only after someone runs
the steps below and commits the real reference file.

## Aspect is a direction, and that changes the comparison

Slope is a magnitude; aspect is a bearing on a circle, undefined where the
ground is level. Unless the comparison handles circular
difference, flat cells, and frame and row order, it measures the wrong thing
without saying so. `tests/aspectCrossCheck.test.ts` handles all three:

- Circular difference. 359° and 1° are 2° apart, not 358°. Every pair is
  folded to its shortest angular separation before any tolerance is applied.
- Flat cells. `gdaldem aspect` writes NODATA where it detects a flat; our
  kernel returns 0, which is a real direction (due north). Comparing those two
  would compare a value against a placeholder, so cells whose *closed-form*
  slope is at or below 2° are excluded on all three legs, and the test fails
  if GDAL wrote NODATA anywhere inside the surviving set.
- Frame and row order. Ours is radians in the math frame (CCW from east,
  π/2 = north) on a northing-up grid; GDAL is degrees clockwise from north;
  ASCII Grid writes the northern row first while our kernel treats row+1 as
  north. `(90 − mathDeg) mod 360` converts the frame, and the rows are flipped
  in and back out. Getting only half of either conversion right yields a
  mirrored grid that still looks like a plausible aspect raster, which is how
  the v0.4.3 north-south aspect mirror shipped (see
  `src/terrain/ground/terrainDerivatives.ts`).

## Why this is not automated in CI

PDAL, GDAL, and CloudCompare are native tools with heavy dependencies; they do
not run in the browser or in the pure-data test sandbox. The comparison maths
runs in CI (the `crossCheck` unit tests); generating the reference output is a
manual, documented step run once per fixture on a workstation.

## What you need

- A small, public, redistributable point cloud with known provenance (for
  example a USGS 3DEP tile). Record its source and licence next to the fixture.
- PDAL (`pdal`) and GDAL (`gdalinfo`, `gdaldem`) on the workstation, or
  CloudCompare for the ground-filter comparison.

## Procedure per product

The goal is a reference raster on the same grid as ours (same origin, cell
size, extent, and row order), so the two can be compared cell for cell.

### DTM / DSM (PDAL)

1. Export our DTM/DSM for the fixture as an Esri ASCII Grid or GeoTIFF, and note
   its origin, cell size, and dimensions.
2. Produce the reference on the identical grid, e.g. for a DTM:

   ```
   pdal translate input.laz reference_dtm.tif \
     --writers.gdal.resolution=<cell_m> \
     --writers.gdal.output_type=idw \
     --writers.gdal.origin_x=<x0> --writers.gdal.origin_y=<y0> \
     --writers.gdal.width=<cols> --writers.gdal.height=<rows>
   ```

3. Read both grids in row order, align NODATA, and pass them to `crossCheck`
   with the tolerance from the product's `ReferenceSlot` (5×10⁻⁵ m for DTM/DSM).

### Slope / aspect / hillshade (GDAL)

1. Run GDAL against the same reference or source DEM:

   ```
   gdaldem slope reference_dtm.tif reference_slope.tif -compute_edges
   gdaldem aspect reference_dtm.tif reference_aspect.tif -alg Horn
   gdaldem hillshade reference_dtm.tif reference_hillshade.tif \
     -az 315 -alt 45 -z 1 -s 1 -alg Horn
   ```

2. Pass the sun parameters explicitly rather than relying on GDAL's defaults
   matching ours. They do today (315° / 45° / z 1), but a default that agrees
   today is not a comparison basis, if either side changed one, the two grids
   would be lit by different suns and the check would report a shading
   disagreement that is really a parameter disagreement. Then read both and
   compare with the slot tolerance (0.5° for slope, 0.5° circular for aspect,
   1 level for hillshade on 0 to 255).
3. For aspect, do not pass `-trigonometric` (it switches GDAL into our own
   frame and removes the conversion the check exists to test) and do not pass
   `-zero_for_flat` (it turns "no aspect" into "points north"). The full
   reasoning is in `tests/fixtures/reference/aspect/README.md`.
4. For hillshade, do not pass `-multidirectional`, `-combined` or `-igor`: each
   is a different illumination model. Note that GDAL's Byte band encodes the
   intensity as `1 + 254·h` with 0 reserved for nodata, while ours is `255·h`, compare the levels as they are and report the offset rather than removing
   it. See `tests/fixtures/reference/hillshade/README.md`.

### Contours (GDAL)

1. Generate the tilted-plane DEM, then run `gdal_contour` at the same interval
   the test uses:

   ```
   node scripts/make-contour-fixture.mjs
   gdal_contour -i 0.5 -a elev input-dem.asc contour-gdal.geojson
   ```

2. Use the plane fixture, not the quadratic slope DEM. Contour vertices are
   placed by linear edge interpolation on both sides, which is exact on a plane
   and only approximate on a curved surface, where the error is largest in
   low-gradient regions, so a curved DEM would fail contours for a reason that
   is not a bug. The comparison measures each of our vertices as its distance to
   the nearest GDAL contour of the same level, against the 0.05 m slot tolerance,
   and separately checks both against the analytic line so a wrong DEM or a
   half-cell georeferencing offset shows up rather than averaging into agreement.
   The full reasoning is in `tests/fixtures/reference/contour/README.md`.

### Section profile (OGR/SpatiaLite + R)

1. Generate the two point clouds, then run the reference pipeline:

   ```
   node scripts/make-profile-fixture.mjs
   node scripts/run-profile-reference.mjs
   ```

2. The second command runs two tools and computes nothing itself. `ogr2ogr`
   with the SQLite dialect builds the corridor table, `ST_Line_Locate_Point`
   for chainage, `ST_Distance` for the corridor test, the nearest station for
   the bin, and selects the elevation column as text, so the value R
   reduces is the value the sampler binned and no number is re-printed on the
   way. `Rscript` then applies `quantile(type = 7)` per station.

3. Both fixtures keep every point clear of a bin boundary and of the corridor
   edge, and every coordinate is exactly representable in Float32 and in double.
   That is what lets a 1×10⁻⁶ m tolerance measure the algorithm rather than a
   tie-break or a transcode. The ramp fixture is also checked against the closed
   form its surface implies, on both sides.

### Ground filter (CloudCompare or PDAL SMRF)

1. Run an independent ground classifier (PDAL `filters.smrf`, or CloudCompare's
   CSF) on the fixture.
2. Compare the per-point ground/non-ground labels against ours. Tolerance is 0
   (exact class), reported as agreement fraction rather than RMSE.

## Recording the result

When a reference is generated:

1. Commit the reference file under `tests/fixtures/reference/` with a short
   `README` naming the tool, version, command, and the source cloud's licence.
2. Flip that slot's `status` from `pending` to `supplied` in `REFERENCE_SLOTS`.
3. Add a test that loads both grids and asserts the `crossCheck` verdict.
4. If the verdict is `agree`, raise the claim's `currentEvidence` to
   `E4_CROSS_IMPLEMENTATION_VALIDATED` and set `externalValidationStatus:
   partial` in `claim-register.yaml`, citing the reference tool and version.
   If it is `disagree`, leave the claim where it is and open an issue with the
   `crossCheck` report; do not promote.

## What E4 does and does not mean

E4 means two independent implementations agree. It does not mean either one
is correct against the physical world; that is E5 (field ground truth). A DTM
that matches PDAL within 5 cm still carries no survey certification. Keep the
field-validation caveats in place after any E4 promotion.
