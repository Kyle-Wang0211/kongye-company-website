# Evidence model

Every scientific product OpenLiDARViewer generates
carries an evidence level, an explicit statement of how strongly the
claim is supported, and a required level it must reach before it may be
exported as a *validated* (non-exploratory) result. This replaces the single
`Production` status previously used in the validation matrix, which conflated
"the code works" with "the science is validated".

The canonical, machine-readable register is
[`claim-register.yaml`](./claim-register.yaml). The evidence-level identifiers
and gate logic live in [`src/validation/evidenceLevel.ts`](../../src/validation/evidenceLevel.ts)
(unit-tested in `tests/evidenceLevel.test.ts`).

## The ladder

Ordered weakest → strongest; higher is stronger.

| Level | Meaning |
|---|---|
| `E0_IMPLEMENTED` | Code exists and runs. Correctness not assessed. |
| `E1_UNIT_VERIFIED` | Unit tests pin the implementation against hand-worked expectations. |
| `E2_ANALYTICALLY_VERIFIED` | Output checked against a closed-form / analytic ground truth (e.g. slope of a synthetic plane = atan(gradient)). |
| `E3_SYNTHETICALLY_VALIDATED` | Validated end-to-end against generated known-truth fixtures (synthetic surfaces, labelled clouds we created). |
| `E4_CROSS_IMPLEMENTATION_VALIDATED` | A second, independent implementation (PDAL, GDAL, CloudCompare, …) agrees within a stated tolerance. |
| `E5_EXTERNALLY_VALIDATED` | Validated against external field ground truth by a PROSPECTIVE study: the protocol and its tolerance frozen before the observations, and the operators independent of this project. See "What E5 costs" below. |
| `E6_INDEPENDENTLY_REPRODUCED` | An independent party reproduced the result from the archived artifact. |

The load-bearing boundary is E3 → E4. Everything at or below E3 is verified
only against *our own* code or *our own* synthetic data. Per the non-negotiable
rules, precision is not accuracy and synthetic validation is not field
validation, so **nothing at or below E3 may claim independent or field-grade
accuracy**. Independent evidence begins at E4; field-grade validity at E5.

## What E5 costs, and why data alone does not buy it

The one-line definition above understates E5, so this section states the whole
price. `scripts/verify-field-study.mjs` enforces it, and two of its rules are
about the STUDY rather than the data:

F10 refuses a protocol written afterwards. A study whose
`preregistration.registeredAt` falls after `fieldwork.startedAt` is rejected with
"a protocol written after the observations is a report, and its tolerance was
chosen knowing the answer." The tolerance has to be committed while the result is
still unknown.
F9 refuses operators who built the software: `operators.independent` cannot
be true for anyone affiliated with this project. Each operator also has an entry
in `operators.members` (`affiliation`, `independent`), one per operator, so the
list length must equal `operators.count`. F9 fails if any member is not
independent, and if the group is called independent while a member is not.

The consequence is easy to miss when reading the ladder alone. An archival
dataset cannot reach E5, however good it is. A published survey with a thousand independent checkpoints was observed
before any protocol here existed, so F10 refuses it on ordering alone. The
distinction being drawn is between measuring how well the software did on data
someone already collected, and committing to a tolerance in advance and then
finding out.

Archival external data is still worth acquiring. It widens the scope a claim has
been exercised over, it can move a claim to E4 against an independent
implementation, and it is how a weakness gets found. It sits at E4, and a
register entry should say so.

Of the 41 registered claims, 20 currently sit below their required level. Nineteen
of those require E5. One requires only E4: CONTOURS-CARTOGRAPHIC, where a
generalized contour needs the same independent check the analytical line
already has and does not have it. None of them is waiting on a download.

TERRAIN-FLOW-PULSE, the v0.7 field simulation, used to sit below its required
E4, because its second implementation had been written inside this project. It
now meets E4 on archival data, as described above: a
study pre-registered in `validation/protocols/flow-pulse-external-references-v1.md`
compared it with TauDEM 5.3.8 PitRemove on two Bear Creek crops (conditioning
identical on every compared cell) and with GRASS GIS 8.3.2 on a 25 m Reunion
catchment (routing within the stated tolerances of a single-flow router whose
module, inferred from the output encoding to be `r.watershed`, the dataset does
not name; not exactly). The same comparison took TERRAIN-FLOW-DEPRESSION-INVENTORY
to its required E3: its conditioned mode matches TauDEM depression for
depression, while its raw mode was not compared. Neither claim can reach E5 from
that data, for the ordering reason above.

## Per-claim fields

Each register entry records, at minimum:

- `claimId`, `product`, `algorithm`, `algorithmVersion`
- `claim`, the precise scientific statement, with the event and tolerance it refers to
- `currentEvidence`, `requiredEvidence`
- `supportingTests`, `supportingDatasets`
- `units`, `crsDatum`, applicable units and CRS/datum requirements
- `assumptions`, `failureModes`
- `exportAllowed`, `userLabel`
- `validationOwner`, `lastValidationDate`, `externalSource`

Replacing the old single `Production` status, every entry carries the split:

- `softwareStatus`, does the code work / ship?
- `evidenceLevel`, the ladder rung above.
- `externalValidationStatus`, `none` | `pending` | `partial` | `complete`.
- `approvedClaim`, the strongest statement the evidence permits.
- `prohibitedClaim`, statements the evidence does not permit (guards against overstatement).

## Export & badge gate

`exportDecision(current, required, exportAllowed)` in the module:

- meets required → exportable as a validated artifact;
- below required (but `exportAllowed`) → exportable only as an explicitly
  watermarked *exploratory* artifact carrying its refusal reason;
- `exportAllowed: false` → never offered, even exploratory.

The UI evidence badges map each level via `evidenceBadge(...)`
to: Not assessed / Analytic / Synthetic / Cross-implementation / External /
Independently reproduced.

## Processing-provenance manifest

Alongside the gate verdict, every terrain export's provenance embeds a
verify-only processing manifest (`src/science/processingManifest.ts`,
schema 1): the ordered list of registered methods that produced the artifact,
each op bound to the final parameters the provenance actually carries, chained
by SHA-256 hashes seeded from the manifest envelope (schema, build identity,
source name). `verifyProcessingManifest` recomputes the chain and reports the
first altered op, so a reviewer holding only the artifact (or a `.olvsession`
that embeds the same manifest) can confirm the record of *what was run, in
what order, with which settings* is self-consistent. The hashes are unkeyed
and the manifest is unsigned, so anyone who edits it can recompute the chain:
a pass does not show who wrote it, and the import line says "self-consistent
(unsigned, author not verified)". The claim stops there: it is
ordering + parameters + a hash chain (self-consistency check), not an execution recipe, no executor
consumes it, and an op whose settings never reached the provenance says
`params not captured in this slice` rather than fabricating them.

When the cloud carried a source acquisition topology
(`src/model/OrganizedRange.ts`), the manifest leads with one further op,
`olv.topology.linkage-record`, derived by `src/science/sourceTopology.ts`. It
binds the set's organization, its frame count, the least faithful linkage state
across those frames (`exact`, `partial`, `unavailable`) and the reasons the
frames in that state carry, with a note saying what the state means for a
reader. It leads the chain because the topology describes the cloud that
entered the recorded steps, and it is an ordinary op, so it folds into the same
hashes and cannot be stripped or reworded while verification still passes. A
reviewer holding only a DTM built from a voxel-reduced organized scan can
therefore see that the display points feeding it were per-voxel centroids
rather than source records.

Absence is silence. A cloud that never carried an acquisition grid (an ordinary
LAS or PLY) adds no op at all, so its manifest is byte-identical to what the
same inputs produced before this record existed. Absent, `exact` and degraded
are three distinguishable answers, and the schema stays at 1 because the op
shape is unchanged.

## How to use it

- When adding or changing a product, add/update its register entry in the same
  change. A product with no register entry is treated as `E0` / not exportable.
- Existing caveats may be strengthened, never silently removed.
- When external evidence is unavailable, build the harness and write the dataset
  spec, then set `externalValidationStatus: pending`. Never infer it from
  density, format, or metadata.

## Tooling that moves a claim up the ladder

These exist now; they are the mechanisms, not the evidence. A claim only rises
when the mechanism is actually run against real data and the result committed.

- E3 → E4 (cross-implementation). `src/validation/crossCheck.ts` compares our
  grid to an independent tool's grid within a stated tolerance. The procedure is
  in [`cross-implementation.md`](./cross-implementation.md). `REFERENCE_SLOTS` holds
  16 slots. Thirteen are `supplied`, each an independent comparison against a
  tool such as GDAL, PDAL, SAGA, R or PROJ on a frozen fixture. Three are
  `pending` (GROUND-FILTER, CHANGE-RASTER, CHANGE-VOLUME). No reference output
  is bundled for a slot that has not been compared, and none is fabricated.
  The 18 claims at E4 in the claim register are a separate count.
- Internal error. `src/terrain/validate/spatialBlockHoldout.ts` adds a
  spatially-blocked hold-out with a bootstrap CI alongside the random point
  hold-out. It complements rather than replaces it: blocking changes the spatial
  arrangement of the withheld support, and the resulting contrast is
  protocol-dependent, not a bias correction. Whether the blocked figure comes out
  larger is a result of a given run. The two are only a geometry contrast when
  their recorded `classificationScope` agrees, which it does on the
  trusted-source-classification path and does not on the SMRF path. Neither is
  field accuracy (E5).
- Reliability vs support. `src/terrain/validate/reliabilitySplit.ts` reports
  measured-cell empirical reliability with a Wilson interval, kept separate from
  interpolated-cell model support, which carries no calibrated-probability claim.
- Unit safety. `src/units/units.ts` makes source-unit vs metre confusion a
  compile error at the measurement and CRS boundaries.
