# R terra reference for the DTM median gridding study.
# Run from the repository root:  Rscript --vanilla scripts/dtm-median-reference-terra.R
# Protocol: validation/protocols/dtm-median-gridding-v1.md
# Writes validation/cross-implementation/dtm-median/terra/<fixture>__median.asc
# (row 0 is the north row, NODATA -9999) and terra/reference-run.json.
suppressPackageStartupMessages(library(terra))
fix <- "validation/cross-implementation/pdal-pipeline/fixtures/"
out <- "validation/cross-implementation/dtm-median/terra/"
names <- c("pc-01-plane-buildings", "pc-02-rolling-buildings", "pc-03-ridge-buildings",
           "pc-04-plane-lowblunders", "pc-05-plane-gap", "pc-06-bare-plane",
           "pc-07-bare-rolling", "pc-08-bare-ridge")
template <- rast(ext(0, 50, 0, 50), resolution = 1, crs = "local")
rows <- character(0)
for (nm in names) {
  a <- read.csv(paste0(fix, nm, ".csv"))
  truth <- as.integer(strsplit(trimws(readChar(paste0(fix, nm, ".truth"), 1e7)), "")[[1]])
  sel <- a[truth == 1, ]
  v <- vect(sel, geom = c("X", "Y"), crs = "local")
  v$z <- sel$Z
  r <- rasterize(v, template, field = "z", fun = median)
  m <- as.matrix(r, wide = TRUE)  # row 1 is the north row
  path <- paste0(out, nm, "__median.asc")
  con <- file(path, "w")
  writeLines(c("ncols 50", "nrows 50", "xllcorner 0", "yllcorner 0", "cellsize 1", "NODATA_value -9999"), con)
  for (i in 1:50) writeLines(paste(ifelse(is.na(m[i, ]), "-9999", sprintf("%.9f", m[i, ])), collapse = " "), con)
  close(con)
  h <- system2("shasum", c("-a", "256", path), stdout = TRUE)
  rows <- c(rows, sprintf('    {"fixture": "%s", "returns": %d, "path": "%s", "sha256": "%s"}',
                          nm, nrow(sel), path, sub(" .*", "", h)))
}
js <- c("{",
  '  "tool": "terra::rasterize",', '  "fun": "median",',
  sprintf('  "R": "%s",', paste(R.version$major, R.version$minor, sep = ".")),
  sprintf('  "terra": "%s",', as.character(packageVersion("terra"))),
  sprintf('  "gdal": "%s",', gdal()),
  sprintf('  "platform": "%s",', R.version$platform),
  '  "commandLine": "Rscript --vanilla scripts/dtm-median-reference-terra.R",',
  '  "outputs": [', paste(rows, collapse = ",\n"), "  ]", "}")
writeLines(js, paste0(out, "reference-run.json"))

# Protocols v2 and v3 (validation/protocols/dtm-median-gridding-v2.md, -v3.md): cell sizes
# 0.25, 0.5, 1 (v3), 2 and 5 m, input shifted by (+0.37, +0.61) m, origin at the data
# minimum and extent from the rasterizeDtm rule. Writes
# terra/cell<s>/<fixture>__median.asc and terra/reference-run-v2.json.
rows2 <- character(0)
for (s in c(0.25, 0.5, 1, 2, 5)) {
  dir <- paste0(out, "cell", s, "/")
  dir.create(dir, showWarnings = FALSE)
  for (nm in names) {
    a <- read.csv(paste0(fix, nm, ".csv"))
    truth <- as.integer(strsplit(trimws(readChar(paste0(fix, nm, ".truth"), 1e7)), "")[[1]])
    sel <- a[truth == 1, ]
    x <- sel$X + 0.37
    y <- sel$Y + 0.61
    ox <- min(x); oy <- min(y)
    nc <- floor((max(x) - ox) / s) + 1
    nr <- floor((max(y) - oy) / s) + 1
    tpl <- rast(ext(ox, ox + nc * s, oy, oy + nr * s), ncols = nc, nrows = nr, crs = "local")
    v <- vect(data.frame(x = x, y = y, z = sel$Z), geom = c("x", "y"), crs = "local")
    r <- rasterize(v, tpl, field = "z", fun = median)
    m <- as.matrix(r, wide = TRUE)
    path <- paste0(dir, nm, "__median.asc")
    con <- file(path, "w")
    writeLines(c(sprintf("ncols %d", nc), sprintf("nrows %d", nr), sprintf("xllcorner %.17g", ox),
                 sprintf("yllcorner %.17g", oy), sprintf("cellsize %.17g", s), "NODATA_value -9999"), con)
    for (i in 1:nr) writeLines(paste(ifelse(is.na(m[i, ]), "-9999", sprintf("%.9f", m[i, ])), collapse = " "), con)
    close(con)
    h <- system2("shasum", c("-a", "256", path), stdout = TRUE)
    rows2 <- c(rows2, sprintf('    {"fixture": "%s", "cellSize": %s, "returns": %d, "path": "%s", "sha256": "%s"}',
                              nm, s, nrow(sel), path, sub(" .*", "", h)))
  }
}
js2 <- c("{",
  '  "tool": "terra::rasterize",', '  "fun": "median",',
  '  "protocol": "validation/protocols/dtm-median-gridding-v2.md",',
  sprintf('  "R": "%s",', paste(R.version$major, R.version$minor, sep = ".")),
  sprintf('  "terra": "%s",', as.character(packageVersion("terra"))),
  sprintf('  "gdal": "%s",', gdal()),
  sprintf('  "platform": "%s",', R.version$platform),
  '  "commandLine": "Rscript --vanilla scripts/dtm-median-reference-terra.R",',
  '  "outputs": [', paste(rows2, collapse = ",\n"), "  ]", "}")
writeLines(js2, paste0(out, "reference-run-v2.json"))

# Protocol v4 (validation/protocols/dtm-median-gridding-v4.md): 50 seeded draws
# from range/fixtures/ (local coordinates after OLV's ingest rule), grid from
# the data minimum. Writes range/terra/draw-NN__median.asc and
# range/terra/reference-run-range.json.
rf <- "validation/cross-implementation/dtm-median/range/fixtures/"
ro <- "validation/cross-implementation/dtm-median/range/terra/"
dir.create(ro, showWarnings = FALSE, recursive = TRUE)
draws <- read.csv(paste0(rf, "draws.csv"))
rows3 <- character(0)
for (k in seq_len(nrow(draws))) {
  d <- draws$draw[k]; s <- draws$cellSize[k]
  a <- read.csv(sprintf("%sdraw-%02d.csv", rf, d))
  ox <- min(a$x); oy <- min(a$y)
  nc <- floor((max(a$x) - ox) / s) + 1
  nr <- floor((max(a$y) - oy) / s) + 1
  tpl <- rast(ext(ox, ox + nc * s, oy, oy + nr * s), ncols = nc, nrows = nr, crs = "local")
  v <- vect(a, geom = c("x", "y"), crs = "local")
  r <- rasterize(v, tpl, field = "z", fun = median)
  m <- as.matrix(r, wide = TRUE)
  path <- sprintf("%sdraw-%02d__median.asc", ro, d)
  con <- file(path, "w")
  writeLines(c(sprintf("ncols %d", nc), sprintf("nrows %d", nr), sprintf("xllcorner %.17g", ox),
               sprintf("yllcorner %.17g", oy), sprintf("cellsize %.17g", s), "NODATA_value -9999"), con)
  for (i in 1:nr) writeLines(paste(ifelse(is.na(m[i, ]), "-9999", sprintf("%.9f", m[i, ])), collapse = " "), con)
  close(con)
  h <- system2("shasum", c("-a", "256", path), stdout = TRUE)
  rows3 <- c(rows3, sprintf('    {"draw": %d, "path": "%s", "sha256": "%s"}', d, path, sub(" .*", "", h)))
}
js3 <- c("{",
  '  "tool": "terra::rasterize",', '  "fun": "median",',
  '  "protocol": "validation/protocols/dtm-median-gridding-v4.md",',
  sprintf('  "R": "%s",', paste(R.version$major, R.version$minor, sep = ".")),
  sprintf('  "terra": "%s",', as.character(packageVersion("terra"))),
  sprintf('  "platform": "%s",', R.version$platform),
  '  "commandLine": "Rscript --vanilla scripts/dtm-median-reference-terra.R",',
  '  "outputs": [', paste(rows3, collapse = ",\n"), "  ]", "}")
writeLines(js3, paste0(ro, "reference-run-range.json"))

# Protocol v5 (validation/protocols/dtm-median-gridding-v5.md): the v4 draws,
# read exactly from range/fixtures/draw-NN.f64, every output value written as a
# hex float. Writes range-v5/terra/draw-NN__median.hex.asc and
# range-v5/terra/reference-run.json.
r5 <- "validation/cross-implementation/dtm-median/range-v5/terra/"
dir.create(r5, showWarnings = FALSE, recursive = TRUE)
rows5 <- character(0)
# Cell sizes read exactly from binary; read.csv does not round every decimal correctly.
sizes5 <- readBin(paste0(rf, "cellsizes.f64"), "double", n = nrow(draws), size = 8, endian = "little")
stopifnot(length(sizes5) == nrow(draws), all(abs(sizes5 - draws$cellSize) <= 4 * .Machine$double.eps * sizes5))
for (k in seq_len(nrow(draws))) {
  d <- draws$draw[k]
  fx <- sprintf("%sdraw-%02d.f64", rf, d)
  vals <- readBin(fx, "double", n = file.size(fx) / 8, size = 8, endian = "little")
  stopifnot(length(vals) == 3 * draws$points[k])
  a <- data.frame(x = vals[c(TRUE, FALSE, FALSE)], y = vals[c(FALSE, TRUE, FALSE)], z = vals[c(FALSE, FALSE, TRUE)])
  s <- sizes5[k]
  ox <- min(a$x); oy <- min(a$y)
  nc <- floor((max(a$x) - ox) / s) + 1
  nr <- floor((max(a$y) - oy) / s) + 1
  tpl <- rast(ext(ox, ox + nc * s, oy, oy + nr * s), ncols = nc, nrows = nr, crs = "local")
  r <- rasterize(vect(a, geom = c("x", "y"), crs = "local"), tpl, field = "z", fun = median)
  m <- as.matrix(r, wide = TRUE)
  path <- sprintf("%sdraw-%02d__median.hex.asc", r5, d)
  con <- file(path, "w")
  writeLines(c(sprintf("ncols %d", nc), sprintf("nrows %d", nr), sprintf("xllcorner %a", ox),
               sprintf("yllcorner %a", oy), sprintf("cellsize %a", s), "NODATA_value -9999"), con)
  for (i in 1:nr) writeLines(paste(ifelse(is.na(m[i, ]), "-9999", sprintf("%a", m[i, ])), collapse = " "), con)
  close(con)
  h <- system2("shasum", c("-a", "256", path), stdout = TRUE)
  rows5 <- c(rows5, sprintf('    {"draw": %d, "path": "%s", "sha256": "%s"}', d, path, sub(" .*", "", h)))
}
writeLines(c("{",
  '  "tool": "terra::rasterize",', '  "fun": "median",',
  '  "protocol": "validation/protocols/dtm-median-gridding-v5.md",',
  sprintf('  "R": "%s",', paste(R.version$major, R.version$minor, sep = ".")),
  sprintf('  "terra": "%s",', as.character(packageVersion("terra"))),
  sprintf('  "platform": "%s",', R.version$platform),
  '  "commandLine": "Rscript --vanilla scripts/dtm-median-reference-terra.R",',
  '  "outputs": [', paste(rows5, collapse = ",\n"), "  ]", "}"), paste0(r5, "reference-run.json"))
