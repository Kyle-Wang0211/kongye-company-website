#!/usr/bin/env node
/**
 * test-bucket.mjs — run one named slice of the unit suite.
 *
 * The unit suite (tests/*.test.ts) grew large enough that a single `vitest run`
 * is slow and can time out on a busy machine. This splits it into four
 * coverage-complete buckets so CI can run them in parallel and a developer can
 * run just the relevant slice:
 *
 *   unit     — the core (io, model, convert, math, formatting, geometry, …)
 *   terrain  — the analysis pipeline (DTM, contours, accuracy, CRS, coverage)
 *   ui       — panels, toolbars, navigation, sheets, theming, overlays
 *   slow     — heavy decode / streaming / integration / torture / benchmark
 *
 * The classification lives here, once. `unit` is the catch-all: every file
 * that matches no other bucket lands in it, so the four buckets always union to
 * the whole suite — a newly added test can never silently fall out of CI. Run
 * `node scripts/test-bucket.mjs --verify` to assert that partition holds.
 *
 * Usage:
 *   node scripts/test-bucket.mjs <unit|terrain|ui|slow> [extra vitest args]
 *   node scripts/test-bucket.mjs --verify
 *   node scripts/test-bucket.mjs --list
 *
 * Playwright specs under tests/e2e/ are not touched here — they run via
 * `npm run test:e2e`.
 */

import { readdirSync, readFileSync, rmSync } from 'node:fs';
import { BUCKETS, NESTED_TEST_DIRS, bucketOf } from './lib/testBuckets.mjs';
import { FILE_LIST_ENV, vitestRunArgs, writeFileList } from './lib/vitestFileList.mjs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join, sep } from 'node:path';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const TESTS_DIR = resolve(ROOT, 'tests');

function allTestFiles() {
  const top = readdirSync(TESTS_DIR).filter((f) => /\.(test|spec)\.ts$/.test(f));
  const nested = Object.keys(NESTED_TEST_DIRS).flatMap((dir) => {
    let entries;
    try {
      entries = readdirSync(join(TESTS_DIR, dir));
    } catch {
      return []; // the directory may legitimately not exist yet
    }
    return entries.filter((f) => /\.(test|spec)\.ts$/.test(f)).map((f) => `${dir}/${f}`);
  });
  return [...top, ...nested];
}

function filesFor(bucket) {
  return allTestFiles().filter((f) => bucketOf(f) === bucket);
}

const [, , arg, ...rest] = process.argv;

if (arg === '--verify') {
  const files = allTestFiles();
  const counts = Object.fromEntries(BUCKETS.map((b) => [b, 0]));
  for (const f of files) counts[bucketOf(f)]++;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const ok = total === files.length;
  for (const b of BUCKETS) console.log(`${b}: ${counts[b]}`);
  // Print the nested routing so the gate log shows WHERE those files ran, not
  // just that the partition adds up.
  for (const [dir, bucket] of Object.entries(NESTED_TEST_DIRS)) {
    console.log(`tests/${dir}/ → ${bucket} (explicit)`);
  }
  console.log(`total: ${total} / ${files.length} — partition ${ok ? 'OK' : 'BROKEN'}`);
  process.exit(ok ? 0 : 1);
}

// `--list` prints one `<bucket>\t<file>` line per test file. It exists so a
// checker can ask WHICH bucket regenerates a given evidence record without
// re-implementing the classification above; tests/releaseEvidenceOrder.test.ts
// is that caller, and a second copy of these regexes is exactly the drift the
// rest of this file is written to avoid.
if (arg === '--list') {
  for (const f of allTestFiles().sort()) console.log(`${bucketOf(f)}\ttests/${f}`);
  process.exit(0);
}

if (!BUCKETS.includes(arg)) {
  console.error(`usage: test-bucket.mjs <${BUCKETS.join('|')}|--verify|--list> [vitest args]`);
  process.exit(2);
}

const files = filesFor(arg).map((f) => `tests/${f}`);
if (files.length === 0) {
  console.error(`no test files matched bucket "${arg}"`);
  process.exit(1);
}

// Per-bucket runner policy (determinism over raw speed on CI):
//   slow    — WASM/LAZ decode + integration: cap to 2 workers so a decoder is
//             never starved, and give it a generous per-test timeout.
//   terrain — heavy DTM/surface builds that legitimately run ~10-14 s in
//             isolation: raise the timeout so parallel contention can't tip a
//             genuine 14 s test past the strict 15 s global limit.
// The fast buckets (unit/export/ui) keep the strict 15 s global timeout, so a
// real regression there still trips it. Every bucket pins a worker cap so a
// high-core machine can't over-subscribe the pool and hang at shutdown
// (EPIPE / "Worker exited unexpectedly") even when every assertion passes; 2
// also matches the ~2-core GitHub-hosted runners for reproducibility.
//
// --maxWorkers is a SINGLE-VALUE vitest option — passing it twice makes vitest
// reject the run ("Expected a single value … received [4, 2]") before a single
// test loads. So this script is the ONE source of the cap: if the caller already
// supplied --maxWorkers (a dev override), ours steps aside and theirs wins,
// never appended on top.
const callerSetsWorkers = rest.some((a) => a === '--maxWorkers' || a.startsWith('--maxWorkers='));
const WORKERS = callerSetsWorkers ? [] : ['--maxWorkers=2'];
const BUCKET_ARGS = {
  unit: [...WORKERS],
  export: [...WORKERS],
  ui: [...WORKERS],
  terrain: [...WORKERS, '--testTimeout=45000'],
  slow: [...WORKERS, '--testTimeout=60000'],
};
const bucketArgs = BUCKET_ARGS[arg] ?? [...WORKERS];

// A shard that has not finished in this long is wedged, not slow: the whole
// unit bucket runs in seconds and the slowest (streaming) in a couple of
// minutes. Killing it with a message beats inheriting a hang that the release
// gate reports as a nondescript failure ten minutes later.
const SHARD_TIMEOUT_MS = Number(process.env.OLV_SHARD_TIMEOUT_MS ?? 8 * 60 * 1000);
// How long `close` gets to arrive after the group is killed before the wait is
// abandoned. Short: by this point the shard is already over its budget, and a
// gate that hangs is worse than one that reports a kill it could not confirm.
const TIMEOUT_GRACE_MS = 2000;

// Run the LOCAL vitest binary, never `npx vitest`: npx interposes an extra
// process, so a kill lands on the wrapper while the real vitest and its whole
// worker pool survive, holding the inherited stdio pipe open forever. That is
// the shape of the release-gate hang where every shard printed "N passed" and
// the run still never returned.
const VITEST_BIN = resolve(ROOT, 'node_modules/.bin/vitest');

// On Windows that path is not runnable. npm writes three files into
// node_modules/.bin: an extensionless sh script (no PE header, CreateProcess
// refuses it), a .cmd and a .ps1. Spawning the .cmd instead is not a fix
// either — since the CVE-2024-27980 change, Node refuses to spawn .cmd/.bat
// without `shell: true`, and turning the shell on would put every test path
// through cmd.exe quoting.
//
// So on Windows the shard runs the vitest ENTRY MODULE under this process's
// own node. That keeps the property the comment above is about: one process,
// no wrapper, so a kill reaches the real runner. On POSIX nothing changes —
// the same .bin path is spawned as before.
const WINDOWS = process.platform === 'win32';
const VITEST_ENTRY = resolve(ROOT, 'node_modules/vitest/vitest.mjs');
const SPAWN_CMD = WINDOWS ? process.execPath : VITEST_BIN;
const SPAWN_PREFIX = WINDOWS ? [VITEST_ENTRY] : [];

/**
 * Run one vitest invocation over this bucket's files.
 *
 * Async `spawn` + `detached` makes each shard its own PROCESS GROUP LEADER, so
 * a timeout can kill the group (-pid) and reclaim the orphaned workers.
 * `spawnSync`'s own `timeout` only ever signalled the direct child, which is
 * why wedged workers kept the pipe open and the parent waited forever.
 * Resolves the same {status, signal, error} shape `resolveExit` expects.
 */

/**
 * Emit a machine-readable tally the release evidence collector can trust.
 *
 * The human `Tests N passed` line is printed by vitest through the shard's
 * INHERITED stdio. That reaches the terminal, but on a GitHub runner it can
 * race the gate's `tee` pipe and never land in `release/gate.log` — so the
 * collector, reading the log, saw zero tallies and failed a green run. The
 * fix does not depend on that stream at all: vitest also writes a JSON
 * summary to a file, and THIS parent process reads the file after the shard
 * exits and prints one `GATE TALLY` line to its own stdout — synchronously,
 * before the shard result is returned, so it is always inside the pipe.
 */
function readTally(file, bucket) {
  try {
    const r = JSON.parse(readFileSync(file, 'utf8'));
    const passed = Number(r.numPassedTests ?? 0);
    const skipped = Number(r.numPendingTests ?? 0) + Number(r.numTodoTests ?? 0);
    console.log(`GATE TALLY bucket=${bucket} passed=${passed} skipped=${skipped}`);
  } catch {
    // No file (a start failure, or a vitest that never wrote one): stay silent
    // and let the collector fall back to the human summary. A wrong number is
    // worse than an absent one, so never guess here.
  } finally {
    try { rmSync(file, { force: true }); } catch { /* best effort */ }
  }
}

// The private directories of shards still running. An exit that skips a
// shard's own cleanup (an uncaught error, process.exit) removes them here.
const activeLists = new Set();
process.on('exit', () => {
  for (const list of activeLists) {
    try { list.dispose(); } catch { /* best effort */ }
  }
});
// An interrupt or a termination skips the exit hook unless the process exits
// through it, so Ctrl-C and a CI cancel would leave the private directory behind.
// 128 plus the signal number is the conventional status.
process.on('SIGINT', () => process.exit(130));
process.on('SIGTERM', () => process.exit(143));

function runVitest(extra, label) {
  return new Promise((res) => {
    const started = Date.now();
    // The bucket's files travel in a JSON file that vitest.config.ts reads as
    // `include`, not as arguments: the unit bucket's list alone is longer than
    // the command line Windows accepts.
    const list = writeFileList(files);
    activeLists.add(list);
    const tallyFile = list.tallyPath;
    const child = spawn(
      SPAWN_CMD,
      vitestRunArgs({ prefix: SPAWN_PREFIX, bucketArgs, extra, passthrough, tallyFile }),
      // `detached` is what makes the shard a process-group leader so the
      // timeout below can kill the group. Windows has no process groups —
      // there `detached` only means "own console window", which would hide the
      // shard's output — so it stays off and the watchdog kills the child
      // directly (see the kill site).
      { cwd: ROOT, stdio: 'inherit', detached: !WINDOWS, env: { ...process.env, [FILE_LIST_ENV]: list.path } },
    );

    let timedOut = false;
    let settled = false;
    /**
     * The timeout must END THE WAIT, not merely ask the child to stop.
     *
     * The first version killed the group and then resolved only from
     * `child.on('close')`. `close` fires when every inherited stdio stream has
     * been released — so anything that survived the kill and still held the
     * pipe (a grandchild that escaped the group, a handle the signal did not
     * reach) meant `close` never fired, `finish` was never called, and the
     * promise hung forever: an eight-minute timeout that did not recover a
     * shard inside twelve minutes, because the timer had fired and had no way
     * to say so.
     *
     * So: kill the group, then give `close` a brief grace period to arrive
     * naturally, and settle regardless when it does not.
     */
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        // Negative pid = the whole group. The group may already be gone (the
        // race between the timer firing and a normal exit), hence the guard.
        // Windows rejects a negative pid outright and has no group to signal,
        // so there the child is killed directly. That is weaker — vitest's
        // worker processes can outlive it — and the Windows note in
        // docs/developer-manual.md says so rather than implying parity.
        if (WINDOWS) child.kill('SIGKILL');
        else process.kill(-child.pid, 'SIGKILL');
      } catch {
        /* group already reaped */
      }
      setTimeout(() => {
        finish({
          error: Object.assign(new Error('shard timed out'), { code: 'ETIMEDOUT' }),
          status: null,
          signal: null,
        });
      }, TIMEOUT_GRACE_MS).unref();
    }, SHARD_TIMEOUT_MS);

    const finish = (r) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      // On a clean pass, publish the tally the collector reads. Only on success:
      // a failed or killed shard reddens the gate before evidence is collected,
      // and its partial JSON would misreport the run.
      if (!r.error && !r.signal && r.status === 0) readTally(tallyFile, arg);
      else { try { rmSync(tallyFile, { force: true }); } catch { /* best effort */ } }
      try { list.dispose(); } catch { /* best effort */ }
      activeLists.delete(list);
      const secs = ((Date.now() - started) / 1000).toFixed(1);
      console.log(
        `[${label}] pid=${child.pid} elapsed=${secs}s code=${r.status ?? '-'} signal=${r.signal ?? '-'}`,
      );
      res(r);
    };

    child.on('error', (error) => finish({ error, status: null, signal: null }));
    // `close` (not `exit`) so inherited stdio is fully drained before we move on.
    child.on('close', (status, signal) => {
      if (timedOut) {
        finish({ error: Object.assign(new Error('shard timed out'), { code: 'ETIMEDOUT' }), status: null, signal: null });
        return;
      }
      finish({ status, signal, error: undefined });
    });
  });
}

/**
 * Turn a spawn result into an exit code, SAYING what happened.
 *
 * `spawnSync` reports a signal death as `status: null`, and collapsing that
 * with `?? 1` produced a bad failure mode: an exit 1 with no output and no
 * reason, indistinguishable from a test failure. A
 * release gate has to either succeed or state why it did not.
 */
function resolveExit(r, label) {
  if (r.error) {
    const timedOut = r.error.code === 'ETIMEDOUT';
    console.error(
      timedOut
        ? `\n✗ ${label} exceeded ${Math.round(SHARD_TIMEOUT_MS / 1000)}s and was killed. `
          + 'The assertions may all pass; this is the runner failing to terminate. '
          + 'Re-run that bucket alone to confirm, and raise OLV_SHARD_TIMEOUT_MS if the machine is slow.'
        : `\n✗ ${label} could not be started: ${r.error.message}`,
    );
    return timedOut ? 124 : 2;
  }
  if (r.signal) {
    console.error(
      `\n✗ ${label} was killed by ${r.signal} — no test failure was reported. `
      + 'This is a runner/environment fault, not a red suite.',
    );
    return 137;
  }
  if (r.status === null || r.status === undefined) {
    console.error(`\n✗ ${label} exited without a status code.`);
    return 1;
  }
  return r.status;
}

// `--shards=N` (plural) runs the bucket as N SEQUENTIAL sub-shards, each a fresh
// vitest process over a deterministic 1/N slice of the files (vitest --shard).
// This is the canonical reliable runner used by `test:release`: no single
// process holds hundreds of files, which is the shape that fails to terminate
// ("Worker exited unexpectedly") at shutdown on a constrained machine. CI runs
// the SAME script with `--shard=i/N` (singular) to run those slices in parallel;
// a singular `--shard` always wins and our custom `--shards` is stripped before
// vitest sees it, so `npm run test:unit -- --shard=1/3` does the right thing too.
const singleShard = rest.some((a) => a === '--shard' || a.startsWith('--shard='));
const multiShard = rest.find((a) => a === '--shards' || a.startsWith('--shards='));
/**
 * Extra arguments reach vitest untouched, so they are checked before they do.
 *
 * `spawn` is called without a shell, so nothing here can be a shell injection.
 * What it can be is a path: this script is run by agents and CI as well as by
 * hand, and an argument naming a file outside the repository would have vitest
 * read or write somewhere nobody intended. A flag or a test-name pattern is
 * left alone; anything shaped like a path has to resolve inside the tree.
 */
function checkedPassthrough(args) {
  for (const a of args) {
    if (a.includes('\0')) {
      console.error('test-bucket: an argument contains a null byte.');
      process.exit(2);
    }
    if (!a.startsWith('-') && /[/\\]/.test(a)) {
      const target = resolve(ROOT, a);
      if (target !== ROOT && !target.startsWith(ROOT + sep)) {
        console.error(`test-bucket: "${a}" points outside the repository.`);
        process.exit(2);
      }
    }
  }
  return args;
}

const passthrough = checkedPassthrough(rest.filter((a) => a !== multiShard));

if (multiShard && !singleShard) {
  const n = Number(multiShard.includes('=') ? multiShard.split('=')[1] : NaN);
  if (!Number.isInteger(n) || n < 1) {
    console.error(`--shards expects a positive integer, got "${multiShard}"`);
    process.exit(2);
  }
  let worst = 0;
  for (let i = 1; i <= n; i++) {
    console.log(`\n──── ${arg} shard ${i}/${n} ────`);
    const r = await runVitest([`--shard=${i}/${n}`], `${arg} shard ${i}/${n}`);
    const code = resolveExit(r, `${arg} shard ${i}/${n}`);
    if (code !== 0) worst = code;
  }
  process.exit(worst);
}

const result = await runVitest([], `${arg} bucket`);
process.exit(resolveExit(result, `${arg} bucket`));
