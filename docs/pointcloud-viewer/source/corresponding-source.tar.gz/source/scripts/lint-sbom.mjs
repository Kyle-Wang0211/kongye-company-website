#!/usr/bin/env node
/**
 * lint-sbom.mjs
 *
 * The SBOM is generated, shipped, and read by people who cannot regenerate it.
 * A stale one shipped once already: `metadata.component` still identified
 * alpha.2 while package.json was alpha.3. `lint:release-sync` now checks the
 * root identity, but nothing checked that the COMPONENT SET still describes the
 * lockfile it claims to describe — an SBOM can carry the right version header
 * and a dependency list from three releases ago.
 *
 * This validates SBOM IDENTITY and DEPENDENCY CONSISTENCY against package.json
 * and package-lock.json. It is not full CycloneDX schema validation; the
 * structural checks below cover bomFormat, specVersion and the components
 * array, nothing more. Claiming schema validation without running a schema
 * validator would be the kind of overstatement the rest of this file exists
 * to catch:
 *   1. structural shape (bomFormat / specVersion / components)
 *   2. root identity: name, version, bom-ref, purl
 *   3. every direct PRODUCTION dependency appears as a component
 *   4. each such component's version equals the LOCKED version
 *   5. no superseded root identity (an older version string in the root)
 *   7. every component's distribution SHA-512 equals the lockfile integrity
 *      of the tarball at that component's version
 *
 * Dev dependencies are deliberately NOT required: the SBOM is generated with
 * `--omit dev`, so their absence is correct, not drift.
 *
 * The rule logic is a pure function of a `read(path)` accessor so
 * tests/sbomLint.test.ts can exercise it against fixtures.
 *
 * Usage: `node scripts/lint-sbom.mjs` (also `npm run lint:sbom`).
 */

import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { isCliEntry } from './lib/isCliEntry.mjs';

/** Hex SHA-512 from an SRI integrity string ("sha512-<base64>"), or null. */
function sha512Hex(integrity) {
  if (typeof integrity !== 'string') return null;
  const entry = integrity.split(/\s+/).find((e) => e.startsWith('sha512-'));
  return entry ? Buffer.from(entry.slice(7), 'base64').toString('hex') : null;
}

/** Collect SBOM problems. `read(relPath)` returns text or null. */
export function collectSbomProblems(read) {
  const problems = [];
  const pkgText = read('package.json');
  const lockText = read('package-lock.json');
  const sbomText = read('sbom.json');

  if (pkgText == null) return { problems: ['package.json is missing.'], componentCount: 0 };
  if (lockText == null) return { problems: ['package-lock.json is missing.'], componentCount: 0 };
  if (sbomText == null) return { problems: ['sbom.json is missing.'], componentCount: 0 };

  const pkg = JSON.parse(pkgText);
  const lock = JSON.parse(lockText);
  const version = pkg.version;

  let sbom;
  try {
    sbom = JSON.parse(sbomText);
  } catch {
    return { problems: ['sbom.json is not valid JSON — regenerate it.'], componentCount: 0 };
  }

  // 1. Structural validity.
  if (sbom.bomFormat !== 'CycloneDX') {
    problems.push(`sbom.json bomFormat is "${sbom.bomFormat}", expected "CycloneDX".`);
  }
  if (!/^1\.\d+$/.test(String(sbom.specVersion ?? ''))) {
    problems.push(`sbom.json specVersion "${sbom.specVersion}" is not a CycloneDX 1.x version.`);
  }
  const components = Array.isArray(sbom.components) ? sbom.components : null;
  if (components == null) {
    problems.push('sbom.json has no components array.');
  } else if (components.length === 0) {
    problems.push('sbom.json lists zero components — it cannot describe this project.');
  }

  // 2. Root identity.
  const root = sbom?.metadata?.component ?? {};
  if (root.name !== 'openlidarviewer') {
    problems.push(`sbom.json root component name is "${root.name}", expected "openlidarviewer".`);
  }
  if (root.version !== version) {
    problems.push(
      `sbom.json root version is "${root.version}", expected "${version}" — regenerate the SBOM from this release's lockfile.`,
    );
  }
  for (const field of ['bom-ref', 'purl']) {
    const value = root[field];
    if (value && !String(value).includes(version)) {
      problems.push(`sbom.json root ${field} "${value}" does not identify v${version}.`);
    }
  }

  // 2b. Root FIRST-PARTY licence must equal package.json.license. Only the root
  // is checked; dependency components keep their own (often MIT) licences. A
  // stale root licence shipped once — an MIT root on the AGPL release.
  const rootLicenseId = Array.isArray(root.licenses) ? root.licenses[0]?.license?.id : undefined;
  if (rootLicenseId !== pkg.license) {
    problems.push(
      `sbom.json root component license is ${JSON.stringify(rootLicenseId)}, expected "${pkg.license}" (package.json.license).`,
    );
  }

  // 3 + 4. Direct production dependencies present, at their LOCKED versions.
  //
  // The locked version is the authority: a range in package.json ("^4.4.2")
  // legitimately resolves to something else ("4.4.3"), and the SBOM must
  // describe what is installed, not what was asked for.
  if (components) {
    // CycloneDX splits an npm scope into `group` + `name`: "@loaders.gl/core"
    // is stored as group "@loaders.gl", name "core". Keying on `name` alone
    // reports every scoped dependency as missing — a false failure against a
    // perfectly good SBOM, which is worse than no check at all.
    const byName = new Map();
    for (const c of components) {
      if (!c || !c.name) continue;
      byName.set(c.group ? `${c.group}/${c.name}` : c.name, c);
    }
    for (const name of Object.keys(pkg.dependencies ?? {})) {
      const comp = byName.get(name);
      if (!comp) {
        problems.push(`sbom.json is missing direct production dependency "${name}".`);
        continue;
      }
      const locked = lock.packages?.[`node_modules/${name}`]?.version;
      if (locked && comp.version !== locked) {
        problems.push(
          `sbom.json lists "${name}" at ${comp.version}, but package-lock resolves ${locked}.`,
        );
      }
    }
  }

  // 7. Distribution hashes. Each component's tarball SHA-512 must be the
  //    lockfile `integrity` of the package at the component's version. A
  //    version bump that moves the URL but keeps the old digest describes a
  //    tarball that does not exist.
  if (components) {
    const integrityByNameVersion = new Map();
    for (const [key, entry] of Object.entries(lock.packages ?? {})) {
      const at = key.lastIndexOf('node_modules/');
      if (at === -1 || !entry?.version || !entry?.integrity) continue;
      const name = key.slice(at + 'node_modules/'.length);
      integrityByNameVersion.set(`${name}@${entry.version}`, entry.integrity);
    }
    for (const c of components) {
      if (!c || !c.name) continue;
      const full = c.group ? `${c.group}/${c.name}` : c.name;
      for (const ref of c.externalReferences ?? []) {
        if (ref?.type !== 'distribution') continue;
        const sha = (ref.hashes ?? []).find((h) => h?.alg === 'SHA-512');
        if (!sha) {
          problems.push(`sbom.json component "${full}@${c.version}" has no SHA-512 distribution hash.`);
          continue;
        }
        const integrity = integrityByNameVersion.get(`${full}@${c.version}`);
        const expected = sha512Hex(integrity);
        if (expected == null) {
          problems.push(
            `sbom.json component "${full}@${c.version}" has no sha512 integrity in package-lock.json to check its hash against.`,
          );
        } else if (String(sha.content).toLowerCase() !== expected) {
          problems.push(
            `sbom.json SHA-512 for "${full}@${c.version}" does not match the package-lock integrity of that tarball.`,
          );
        }
      }
    }
  }

  // 6. Attribution completeness: every bundled component is credited in
  //    THIRD_PARTY_NOTICES.md. The SBOM is generated with `--omit dev`, so its
  //    component set is exactly what ships in `dist/`; each such package must
  //    carry its licence attribution. This closed the gap where the notice
  //    listed only the direct runtime deps and omitted the bundled transitive
  //    packages the build actually distributes.
  if (components) {
    const noticesText = read('docs/project/THIRD_PARTY_NOTICES.md');
    if (noticesText == null) {
      problems.push(
        'docs/project/THIRD_PARTY_NOTICES.md is missing — bundled components cannot be attributed.',
      );
    } else {
      for (const c of components) {
        if (!c || !c.name) continue;
        const full = c.group ? `${c.group}/${c.name}` : c.name;
        const esc = full.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Match the name as a whole token, not as the prefix of a longer name,
        // so "chalk" is not counted as covered by "chalk-template".
        if (!new RegExp(`${esc}(?![\\w./-])`).test(noticesText)) {
          problems.push(
            `docs/project/THIRD_PARTY_NOTICES.md does not attribute bundled package "${full}".`,
          );
        }
        // The generated section carries the package's copyright lines and
        // licence text; a heading per bundled package at its SBOM version.
        const gen = noticesText.split('<!-- generated:licence-texts:begin')[1] ?? '';
        if (!gen.includes(`\n#### ${full} ${c.version}\n`)) {
          problems.push(
            `docs/project/THIRD_PARTY_NOTICES.md has no copyright and licence-text entry for "${full} ${c.version}". ` +
              'Run node scripts/gen-third-party-notices.mjs.',
          );
        }
      }
    }
  }

  // 8. The whole production set, not only the direct dependencies. Every
  //    lockfile package that is not dev-only is shipped, so it must appear in
  //    the SBOM at its locked version (nested components included), and the
  //    SBOM must list nothing the lockfile does not install. A transitive
  //    change to the lockfile with an unregenerated SBOM fails here.
  if (components) {
    const locked = new Set();
    for (const [key, entry] of Object.entries(lock.packages ?? {})) {
      const at = key.lastIndexOf('node_modules/');
      if (at === -1 || entry?.dev || !entry?.version) continue;
      locked.add(`${key.slice(at + 'node_modules/'.length)}@${entry.version}`);
    }
    const listed = new Set();
    const walk = (c) => {
      if (!c || !c.name) return;
      listed.add(`${c.group ? `${c.group}/${c.name}` : c.name}@${c.version}`);
      for (const child of c.components ?? []) walk(child);
    };
    for (const c of components) walk(c);
    for (const id of locked) {
      if (!listed.has(id)) problems.push(`sbom.json does not list production package ${id} from package-lock.json.`);
    }
    for (const id of listed) {
      if (!locked.has(id)) problems.push(`sbom.json lists ${id}, which package-lock.json does not install for production.`);
    }
  }

  return { problems, componentCount: components ? components.length : 0, version };
}

// ── CLI ─────────────────────────────────────────────────────────────────────
function isMain() {
  return isCliEntry(import.meta.url);
}

if (isMain()) {
  const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const read = (p) => (existsSync(resolve(ROOT, p)) ? readFileSync(resolve(ROOT, p), 'utf8') : null);
  const { problems, componentCount, version } = collectSbomProblems(read);

  if (problems.length === 0) {
    console.log(
      `lint:sbom OK — root openlidarviewer@${version}, ${componentCount} components, every direct ` +
        `production dependency at its locked version, the full production set matching the lockfile, and every bundled component attributed in ` +
        `THIRD_PARTY_NOTICES.md (identity + consistency checks, not full schema validation).`,
    );
    process.exit(0);
  }

  console.error('lint:sbom FAILED');
  console.error('');
  for (const p of problems) console.error(`  • ${p}`);
  console.error('');
  console.error('  Regenerate with: npx @cyclonedx/cyclonedx-npm@6.0.1 --omit dev --output-file sbom.json');
  process.exit(1);
}
