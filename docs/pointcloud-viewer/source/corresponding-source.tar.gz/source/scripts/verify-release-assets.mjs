#!/usr/bin/env node
/**
 * verify-release-assets.mjs — validate an ALREADY-STAGED release without
 * rebuilding it.
 *
 * Everything else in the release path checks one link: the gate checks the
 * code, the evidence checks the run, the manifest binds the artifacts. Nothing
 * checked the SET — that exactly one source zip is present, that the manifest's
 * commit is the tag's commit, that the evidence inside the bundle describes the
 * bundle it shipped in, that no asset from a previous cut is sitting in the
 * directory. Those are the failures that survive every other gate, because each
 * individual file is perfectly valid.
 *
 * This runs against the staging directory and returns a binary exit code. It
 * rebuilds nothing, so it can be run on downloaded assets by someone who did
 * not produce them — which is the point.
 *
 * Usage: npm run release:verify -- --dir release/payload
 */

import './lib/confineGit.mjs';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { deploySmokeStructureProblems } from './lib/deploySmokeContract.mjs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
// eslint-disable-next-line import/no-relative-packages — same repo, ships in the archive
import { MANDATORY_RELEASE_STAGES, DEFERRED_RELEASE_STAGES, STAGE_STATES } from './collect-evidence.mjs';
import { requireBinaryOnPath } from './lib/binaryOnPath.mjs';
import { isCliEntry } from './lib/isCliEntry.mjs';

// Spawned programs are resolved to an absolute path by reading PATH, so the
// path that runs is a value this script can name rather than whatever the OS
// picks up. See scripts/lib/binaryOnPath.mjs.
const GIT = requireBinaryOnPath('git');
const UNZIP = requireBinaryOnPath('unzip');

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

/** Exactly one of each of these must be staged. */
const SINGLETONS = {
  sourceZip: /-source-\d{8}-\d{4}\.zip$/,
  deployZip: /-deploy-\d{8}-\d{4}-root\.zip$/,
  sbom: /^sbom\.json$/,
  evidence: /^test-evidence-v.+\.json$/,
  manifest: /^release-manifest-v.+\.json$/,
  gateLog: /^gate\.log$/,
  gateLogSha256: /^gate\.log\.sha256$/,
  releaseNotes: /^RELEASE_NOTES_v.+\.md$/,
  deploySmoke: /^smoke-deploy-v.+\.json$/,
  checksums: /^SHA256SUMS$/,
};

/**
 * What a source archive must carry, for a given release. The four versioned
 * evidence documents are the ones a reviewer actually opens; a fixed list
 * missed them entirely, so an archive without its own validation report
 * passed the contract.
 */
function sourceRequiredFor(version) {
  return [
    'package.json',
    'package-lock.json',
    'sbom.json',
    'CITATION.cff',
    'docs/project/DEPENDENCIES.md',
    'docs/project/THIRD_PARTY_NOTICES.md',
    'docs/validation/claim-register.yaml',
    'docs/release/RELEASE_ASSETS.md',
    'tests/fixtures/reference/slope/SHA256SUMS',
    `docs/releases/RELEASE_NOTES_v${version}.md`,
    `docs/releases/KNOWN_LIMITATIONS_v${version}.md`,
    `docs/releases/VALIDATION_REPORT_v${version}.md`,
    `docs/releases/REPRODUCIBILITY_v${version}.md`,
  ];
}

/** ...and must not carry any of these. */
const SOURCE_FORBIDDEN = [
  /(^|\/)node_modules\//,
  /(^|\/)dist\//,
  /(^|\/)\.git\//,
  // Anchored with ^ against the path AFTER the archive's top-level prefix is
  // stripped (see stripArchivePrefix). Matching `release/` at any depth flagged
  // docs/release/, documentation that must ship. What must not ship is the
  // generated release/ OUTPUT tree at the root, and only that.
  /^release\//,
  /(^|\/)coverage\//,
  /(^|\/)playwright-report\//,
  /(^|\/)test-results\//,
  /READINESS_REPORT/,
  /(^|\/)docs\/_audit\//,
];

/**
 * The deploy archive's root contract. LICENSE and THIRD_PARTY_NOTICES.md are
 * part of it: the archive is what people receive, so the licence terms and the
 * notices for bundled components must travel inside it.
 */
export const DEPLOY_REQUIRED = ['index.html', '.htaccess', '_headers', 'LICENSE', 'THIRD_PARTY_NOTICES.md'];

const sha256 = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');

/**
 * Strip the single shared top-level directory, if the archive has one.
 *
 * `git archive` prefixes every entry with `openlidarviewer-v<version>/`, while a
 * plain `zip -r . ` archive has no prefix. Anchored content rules only mean
 * something against a consistent root, so normalise before matching rather than
 * writing every pattern to tolerate both shapes.
 */
export function stripArchivePrefix(entries) {
  if (entries.length === 0) return entries;
  const first = entries[0].split('/')[0];
  if (!first) return entries;
  // Only a git-archive version prefix qualifies. A hand-rolled zip whose whole
  // content happens to live under one real directory (say `src/`) must NOT be
  // silently re-rooted, or every anchored content rule would fire against the
  // wrong paths.
  if (!/^openlidarviewer-v/.test(first)) return entries;
  const shared = entries.every((e) => e === first || e.startsWith(`${first}/`));
  if (!shared) return entries;
  return entries
    .map((e) => (e === first ? '' : e.slice(first.length + 1)))
    .filter(Boolean);
}

function zipEntries(zipPath) {
  // `unzip -Z1` lists entries without extracting — cheap, and it cannot be
  // fooled by a file that merely looks right on disk.
  // stderr is swallowed: a corrupt archive makes `unzip` print a multi-line
  // essay, and the useful signal is the throw, which the caller turns into one
  // clear line. Leaking that essay into a verification report buries the
  // findings a reader is actually scanning for.
  const out = execFileSync(UNZIP, ['-Z1', zipPath], {
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
    stdio: ['ignore', 'pipe', 'ignore'],
  });
  return out.split('\n').map((s) => s.trim()).filter(Boolean);
}

/**
 * The claim ids currently at E4, read from the machine-readable register in
 * document order — the same parse `collect-evidence.mjs` uses to WRITE the
 * evidence record, so the two cannot disagree about what the register says.
 * Returns null if the register is unreadable; `lint:claim-register` reports
 * that, and duplicating the complaint here would be noise.
 */
function readRegisterE4Claims() {
  try {
    const reg = readFileSync(resolve(ROOT, 'docs/validation/claim-register.yaml'), 'utf8');
    return [...reg.matchAll(/claimId:\s*([A-Z0-9-]+)[\s\S]*?currentEvidence:\s*(E\d)_/g)]
      .filter((m) => m[2] === 'E4')
      .map((m) => m[1]);
  } catch {
    return null;
  }
}

export function verifyStagedRelease(dir, opts = {}) {
  const problems = [];
  const note = (m) => problems.push(m);
  // Advisories are true statements about the release that are not defects.
  // They exist so a fact like "the cited mutation score predates this commit"
  // can be SAID without either blocking the release or being swallowed.
  const advisories = [];
  const advise = (m) => advisories.push(m);
  const pkgVersion =
    opts.version ?? JSON.parse(readFileSync(resolve(ROOT, 'package.json'), 'utf8')).version;
  const expectedTag = `v${pkgVersion}`;

  if (!existsSync(dir)) return { ok: false, problems: [`staging directory not found: ${dir}`], advisories };

  const names = readdirSync(dir).filter((n) => statSync(resolve(dir, n)).isFile());

  // ── 1. Exactly one of each required asset ────────────────────────────────
  const found = {};
  for (const [kind, re] of Object.entries(SINGLETONS)) {
    const hits = names.filter((n) => re.test(n));
    if (hits.length === 0) note(`missing required asset: ${kind}`);
    else if (hits.length > 1) note(`expected exactly one ${kind}, found ${hits.length}: ${hits.join(', ')}`);
    else found[kind] = hits[0];
  }
  // A stale asset from a previous cut is the quiet failure: every file is
  // individually valid, and the reader cannot tell which pair belongs together.
  for (const n of names) {
    // Ask "does this name carry a version, and is it OURS", rather than trying
    // to re-parse the version out. A prerelease like 0.6.0-alpha.3 contains the
    // same hyphen the filename uses as a separator, so every naive capture
    // stops at "0.6.0" and reports the current release as foreign — the exact
    // trap lint-release-sync documents for its README matcher.
    if (!/[-_]v\d/.test(n)) continue;
    if (!n.includes(`v${pkgVersion}`)) {
      note(`asset from another release is staged: ${n} (expected v${pkgVersion})`);
    }
  }
  if (problems.length > 0 && !found.manifest) return { ok: false, problems, advisories };

  // ── 2. Identity agreement across manifest, evidence, SBOM, filenames ─────
  let manifest = null;
  let evidence = null;
  try {
    manifest = JSON.parse(readFileSync(resolve(dir, found.manifest), 'utf8'));
  } catch { note('manifest is not valid JSON'); }
  try {
    evidence = JSON.parse(readFileSync(resolve(dir, found.evidence), 'utf8'));
  } catch { note('evidence is not valid JSON'); }

  if (manifest) {
    if (manifest.version !== pkgVersion) note(`manifest version ${manifest.version} != ${pkgVersion}`);
    if (manifest.tag !== expectedTag) note(`manifest tag ${manifest.tag} != ${expectedTag}`);
    if (!manifest.gitCommit) note('manifest names no commit');
    if (opts.tagCommit && manifest.gitCommit !== opts.tagCommit) {
      note(`manifest commit ${manifest.gitCommit} is not the tag target ${opts.tagCommit}`);
    }
  }
  if (evidence) {
    if (evidence.version !== pkgVersion) note(`evidence version ${evidence.version} != ${pkgVersion}`);
    if (evidence.tag !== expectedTag) note(`evidence tag ${evidence.tag} != ${expectedTag}`);
    if (evidence.releaseAuthoritative !== true) note('evidence is not release-authoritative');
    if (evidence.gateExit !== 0) note(`evidence gate exit is ${evidence.gateExit}`);
    // The EXACT canonical runtime, read independently from .nvmrc rather than
    // trusting whatever produced the JSON. A major-only test let evidence
    // naming v22.17.1 satisfy a tree pinned to 22.18.0, since both are major
    // 22. This mirrors the npm comparison below, which is already exact.
    let canonicalNode = null;
    try {
      canonicalNode = readFileSync(resolve(ROOT, '.nvmrc'), 'utf8').trim();
    } catch {
      note('.nvmrc is unreadable, so the canonical Node version cannot be checked');
    }
    if (canonicalNode !== null && evidence.nodeVersion !== `v${canonicalNode}`) {
      note(
        `evidence Node is ${evidence.nodeVersion ?? 'unknown'}, expected v${canonicalNode} (.nvmrc)`,
      );
    }
    // Fail closed: evidence with NO npm version recorded is evidence that
    // skipped the toolchain assertion, not evidence that passed it.
    // No literal default: a stale fallback silently accepted the previous pin
    // when packageManager could not be read. Unreadable means unchecked.
    let expectedNpm = null;
    try {
      const pm = JSON.parse(readFileSync(resolve(ROOT, 'package.json'), 'utf8')).packageManager;
      expectedNpm = String(pm ?? '').split('@')[1] || expectedNpm;
    } catch { /* fall back to the last known pin */ }
    if (expectedNpm === null) {
      note('package.json declares no packageManager, so the npm pin cannot be checked');
    } else if (evidence.npmVersion !== expectedNpm) {
      note(`evidence npm is ${evidence.npmVersion ?? 'unknown'}, expected ${expectedNpm}`);
    }
    // Every mandatory stage must be recorded as passed. gateExit alone once
    // meant only that the static gate ran.
    for (const s of MANDATORY_RELEASE_STAGES) {
      if (evidence.stages?.[s] !== 'passed') {
        note(`evidence does not record mandatory stage "${s}" as passed`);
      }
    }
    // A deferred stage may be `not-executed`, and that is the only thing that
    // makes deferral different from omission — so the state has to BE there,
    // and it has to be one of the three the vocabulary allows. An unrecognised
    // string would otherwise sail through as neither passed nor missing.
    for (const s of DEFERRED_RELEASE_STAGES) {
      const state = evidence.stages?.[s];
      if (state === undefined) {
        note(`evidence omits deferred stage "${s}"; it must be recorded, "not-executed" included`);
      } else if (!STAGE_STATES.includes(state)) {
        note(`evidence records stage "${s}" as "${state}", which is not a stage state`);
      } else if (state === 'failed') {
        note(`evidence records deferred stage "${s}" as failed`);
      }
    }
    // Deferral is only honest if the record names what it deferred TO.
    if (evidence.stages?.mutation === 'not-executed') {
      const m = evidence.mutation;
      if (!m?.measuredAtCommit) {
        note('mutation is recorded as not-executed but the evidence cites no measured result');
      } else if (m.score == null || m.break == null) {
        note('the cited mutation result carries no score or no break threshold');
      } else if (m.score < m.break) {
        note(`the cited mutation score ${m.score} is below the break threshold ${m.break}`);
      } else if (!m.coversReleaseCommit && m.measuredAtCommit !== evidence.commit) {
        // Not a defect: a cited figure from another commit is the expected
        // steady state between scheduled runs. It is recorded as an advisory
        // so the release page says out loud what the record already encodes.
        advise(
          `mutation score ${m.score} was measured at ${String(m.measuredAtCommit).slice(0, 12)}, ` +
            'not at the release commit',
        );
      }
    }
    // The expected E4 set is DERIVED from the claim register, not typed in
    // here. It was hard-coded to a single SLOPE-RASTER, which meant the second
    // product to reach E4 (ASPECT-RASTER) read as a release-asset defect
    // instead of as the promotion it was. Reading the register keeps this a
    // check that the evidence record matches the tree it was collected from.
    const expectedE4 = opts.expectedE4Claims ?? readRegisterE4Claims();
    if (evidence.science && expectedE4 !== null) {
      const got = evidence.science.e4Claims ?? [];
      if (evidence.science.e4ClaimCount !== expectedE4.length) {
        note(
          `expected ${expectedE4.length} E4 claim(s) per the claim register, ` +
            `evidence says ${evidence.science.e4ClaimCount}`,
        );
      }
      if (got.join(',') !== expectedE4.join(',')) {
        note(`E4 claims are [${got.join(', ')}], expected [${expectedE4.join(', ')}]`);
      }
    }
  }
  if (manifest) {
    // The manifest states the reproducible timestamp the archives were built
    // with, or it binds the build to nothing. Before the workflow set
    // SOURCE_DATE_EPOCH every published manifest recorded null here.
    const epoch = manifest.sourceDateEpoch;
    if (epoch == null) note('manifest records no sourceDateEpoch; a release manifest names the committer time the archives were built with');
    else if (!/^\d{9,11}$/.test(String(epoch))) note(`manifest sourceDateEpoch ${JSON.stringify(epoch)} is not a Unix time in seconds`);
  }
  if (manifest && evidence) {
    if (manifest.gitCommit && evidence.commit && manifest.gitCommit !== evidence.commit) {
      note(`manifest commit ${manifest.gitCommit} != evidence commit ${evidence.commit}`);
    }
    if (manifest.bundle?.liveEntryKiB !== evidence.bundle?.liveEntryKiB) {
      note('manifest and evidence disagree about the bundle size');
    }
    if (
      manifest.bundle?.liveEntryKiB != null &&
      manifest.bundle.liveEntryKiB > manifest.bundle.ceilingKiB
    ) {
      note(`bundle ${manifest.bundle.liveEntryKiB} KiB exceeds its ${manifest.bundle.ceilingKiB} KiB ceiling`);
    }
  }
  if (found.sbom) {
    try {
      const s = JSON.parse(readFileSync(resolve(dir, found.sbom), 'utf8'));
      if (s?.metadata?.component?.version !== pkgVersion) {
        note(`staged SBOM root version is ${s?.metadata?.component?.version}, expected ${pkgVersion}`);
      }
    } catch { note('staged sbom.json is not valid JSON'); }
  }
  if (found.releaseNotes && found.releaseNotes !== `RELEASE_NOTES_v${pkgVersion}.md`) {
    note(`release notes filename ${found.releaseNotes} does not name v${pkgVersion}`);
  }

  // ── 3. Integrity: manifest hashes, gate-log hash, SHA256SUMS ─────────────
  if (manifest?.artifacts) {
    for (const [kind, a] of Object.entries(manifest.artifacts)) {
      if (!a?.file) { note(`manifest artifact ${kind} has no filename`); continue; }
      const full = resolve(dir, a.file);
      if (!existsSync(full)) { note(`manifest names a missing artifact: ${a.file}`); continue; }
      const size = statSync(full).size;
      if (size === 0) note(`${a.file} is zero bytes`);
      if (a.sizeBytes !== size) note(`${a.file} size ${size} != manifest ${a.sizeBytes}`);
      const digest = sha256(full);
      if (a.sha256 !== digest) note(`${a.file} sha256 mismatch against the manifest`);
    }
  }
  if (found.gateLog && found.gateLogSha256) {
    const recorded = readFileSync(resolve(dir, found.gateLogSha256), 'utf8').trim().split(/\s+/)[0];
    const actual = sha256(resolve(dir, found.gateLog));
    if (recorded !== actual) note('gate.log does not match gate.log.sha256');
    if (evidence?.gateLogSha256 && evidence.gateLogSha256 !== actual) {
      note('gate.log does not match the hash recorded in the evidence');
    }
  }
  if (found.checksums) {
    const lines = readFileSync(resolve(dir, found.checksums), 'utf8')
      .split('\n').map((l) => l.trim()).filter(Boolean);
    for (const line of lines) {
      const [digest, ...rest] = line.split(/\s+/);
      const name = rest.join(' ').replace(/^\*/, '');
      const full = resolve(dir, name);
      if (!existsSync(full)) { note(`SHA256SUMS lists a missing file: ${name}`); continue; }
      if (sha256(full) !== digest) note(`SHA256SUMS mismatch for ${name}`);
    }
    // SHA256SUMS must cover the manifest — that is the half of the chain the
    // manifest cannot cover for itself.
    if (found.manifest && !lines.some((l) => l.endsWith(found.manifest))) {
      note('SHA256SUMS does not list the manifest');
    }
  }

  // ── 4. Archive contents ──────────────────────────────────────────────────
  if (found.sourceZip && !opts.skipZipContents) {
    let entries = null;
    try { entries = stripArchivePrefix(zipEntries(resolve(dir, found.sourceZip))); }
    catch { note(`source zip failed to list (corrupt?): ${found.sourceZip}`); }
    if (entries) {
      for (const req of sourceRequiredFor(pkgVersion)) {
        if (!entries.some((e) => e === req || e.endsWith(`/${req}`))) {
          note(`source zip is missing ${req}`);
        }
      }
      for (const bad of SOURCE_FORBIDDEN) {
        const hit = entries.find((e) => bad.test(e));
        if (hit) note(`source zip contains a forbidden path: ${hit}`);
      }
      const traversal = entries.find((e) => e.startsWith('/') || e.includes('../'));
      if (traversal) note(`source zip contains an unsafe path: ${traversal}`);
      const dupes = entries.filter((e, i) => entries.indexOf(e) !== i);
      if (dupes.length) note(`source zip has duplicate entries: ${dupes[0]}`);
    }
  }
  // ── The deploy archive was STARTED, and these are the bytes that were ────
  //
  // Every other check here reads the archive as a file. This one requires that
  // a browser opened it: the release chain gated on a smoke against a BUILD,
  // then packaged a second build and shipped that, so the archive users
  // download had never been run. The result is bound by digest, because a
  // result that does not name this file's bytes is a result about other bytes.
  if (found.deploySmoke) {
    // `parsed` starts as a sentinel, not null: JSON.parse legitimately returns
    // null for a file containing `null`, and the original code could not tell
    // that apart from "did not parse". Both then took the `if (smoke)` branch
    // as false and skipped EVERY check below, so a result file containing
    // `null`, `false`, `0` or `""` passed the release.
    const UNPARSED = Symbol('unparsed');
    let smoke = UNPARSED;
    try {
      smoke = JSON.parse(readFileSync(resolve(dir, found.deploySmoke), 'utf8'));
    } catch { note('deploy-smoke result is not valid JSON'); }
    if (smoke !== UNPARSED) {
      // Structure, schema, project identity, the pass flag and the required
      // check names, all from the contract the producer writes against.
      for (const p of deploySmokeStructureProblems(smoke)) note(p);
    }
    // Identity and binding need a well-formed object; the structure pass above
    // has already reported why it is not one.
    if (smoke !== UNPARSED && smoke !== null && typeof smoke === 'object' && !Array.isArray(smoke)) {
      if (smoke.version !== pkgVersion) {
        note(`deploy-smoke version ${smoke.version} != ${pkgVersion}`);
      }
      if (smoke.tag !== expectedTag) note(`deploy-smoke tag ${smoke.tag} != ${expectedTag}`);
      if (found.deployZip) {
        // Named the file that is actually staged, and hashed to the same bytes.
        // Either half alone is defeatable: a filename match says nothing about
        // content, and a digest with no filename could describe a different
        // archive that happens to be staged elsewhere.
        if (smoke.archive !== found.deployZip) {
          note(`deploy-smoke tested ${smoke.archive}, but ${found.deployZip} is staged`);
        }
        const staged = sha256(resolve(dir, found.deployZip));
        if (smoke.sha256 !== staged) {
          note(
            `deploy-smoke tested sha256 ${String(smoke.sha256).slice(0, 16)}…, ` +
              `but the staged archive is ${staged.slice(0, 16)}…`,
          );
        }
      }
      // The release identity the smoke ran under has to be the one shipping.
      const releaseCommit = opts.tagCommit ?? manifest?.gitCommit ?? null;
      if (releaseCommit && smoke.gitCommit && smoke.gitCommit !== releaseCommit) {
        note(`deploy-smoke ran at ${String(smoke.gitCommit).slice(0, 12)}, not the release commit ${String(releaseCommit).slice(0, 12)}`);
      }
      if (releaseCommit && !smoke.gitCommit) note('deploy-smoke result names no commit');
    }
  }

  if (found.deployZip && !opts.skipZipContents) {
    let entries = null;
    try { entries = zipEntries(resolve(dir, found.deployZip)); }
    catch { note(`deploy zip failed to list (corrupt?): ${found.deployZip}`); }
    if (entries) {
      for (const req of DEPLOY_REQUIRED) {
        if (!entries.includes(req)) note(`deploy zip root is missing ${req}`);
      }
      if (!entries.some((e) => e.startsWith('assets/'))) note('deploy zip root is missing assets/');
      // The deploy archive is the site ROOT. A wrapping dist/ directory would
      // deploy to example.com/dist/ and 404 everywhere.
      if (entries.some((e) => e.startsWith('dist/'))) {
        note('deploy zip is wrapped in a dist/ directory — it must be the site root');
      }
      const traversal = entries.find((e) => e.startsWith('/') || e.includes('../'));
      if (traversal) note(`deploy zip contains an unsafe path: ${traversal}`);
    }
  }

  return { ok: problems.length === 0, problems, advisories };
}

function isMain() {
  return isCliEntry(import.meta.url);
}

if (isMain()) {
  const argv = process.argv.slice(2);
  const i = argv.indexOf('--dir');
  const dir = i === -1 ? null : argv[i + 1];
  if (!dir) {
    console.error('usage: npm run release:verify -- --dir <staging-directory>');
    process.exit(2);
  }
  let tagCommit = null;
  try {
    const version = JSON.parse(readFileSync(resolve(ROOT, 'package.json'), 'utf8')).version;
    tagCommit = execFileSync(GIT, ['rev-list', '-n1', `v${version}`], {
      cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
  } catch { /* no tag locally: the identity checks that do not need it still run */ }

  const { ok, problems, advisories } = verifyStagedRelease(resolve(dir), { tagCommit });
  for (const a of advisories ?? []) console.log(`  ℹ ${a}`);
  if (ok) {
    console.log(`release:verify OK — ${dir} is a complete, self-consistent release asset set.`);
    process.exit(0);
  }
  console.error('release:verify FAILED');
  console.error('');
  for (const p of problems) console.error(`  • ${p}`);
  console.error('');
  process.exit(1);
}
