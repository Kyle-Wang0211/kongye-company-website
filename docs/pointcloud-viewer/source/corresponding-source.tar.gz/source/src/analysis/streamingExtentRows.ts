import type { SpatialContext } from '../geo/SpatialContext';
import { describeWithheldRead, withheldReadCounts } from '../science/withheldCounts';
import { groundMetresPermitted, heightScale, heightUnitsPermitted, horizontalGroundRefusal, spatialContextFrom } from '../geo/SpatialContext';
import type { CrsInfo } from '../io/crs';
import type { ResolvedCrs } from '../geo/CoordinateTypes';

/** One extent/density/spacing row the streaming Scan-report emits. */
export interface ExtentRowSpec {
  readonly label: string;
  readonly value: string;
  /**
   * true → the caller wraps this row with the class-scope honesty sentinel
   * (the full-cloud header figures — density / spacing — that a class filter
   * cannot scope). false → a plain info row.
   */
  readonly scoped: boolean;
}

export interface StreamingExtentResult {
  /**
   * Whether the source CRS declares a real linear unit. false when the CRS is
   * absent or carries `linearUnit: 'unknown'` — in which case the rows are in
   * raw source units and NOT labelled "m" / "pts/m²". Also false on a Web
   * Mercator grid or a geocentric frame, whose metres are not ground metres.
   */
  readonly unitConfirmed: boolean;
  /** Why a frame that names a metre unit is not ground metres; null otherwise. */
  readonly refusalReason: string | null;
  readonly rows: readonly ExtentRowSpec[];
}

/** The frame verdict the extent rows apply, for reports that build their own rows. */
export interface ExtentFrameVerdict {
  /** Horizontal spans may print as ground metres and densities as pts/m². */
  readonly groundMetres: boolean;
  /** Why a frame that names metres is not ground metres; null otherwise. */
  readonly groundRefusal: string | null;
  /** The up-axis span is a height in the frame's units. */
  readonly heightUnits: boolean;
}

/**
 * The verdict {@link streamingExtentRows} applies, for one source's CRS. The
 * Studio export card reads it so its Width/Depth/Density and height rows follow
 * the same gates as the scan reports.
 */
export function extentFrameVerdict(crs: CrsInfo | ResolvedCrs | null | undefined): ExtentFrameVerdict {
  const ctx = spatialContextFrom(crs);
  return {
    groundMetres: groundMetresPermitted(ctx),
    groundRefusal: horizontalGroundRefusal(ctx),
    heightUnits: heightUnitsPermitted(ctx),
  };
}

/**
 * The qualifier every Density and Spacing value carries: both are the count
 * over the axis-aligned bounding box, not over the area the points occupy.
 */
export const BOUNDING_BOX_ESTIMATE = '(bounding-box estimate)';

/**
 * The method tag the static and streaming Density and Spacing rows are
 * computed under (`methodRegistry.ts`). v2 leaves Withheld points out of the
 * count; v1 counted them.
 */
export const SCAN_DENSITY_METHOD_TAG = 'olv.density.scan-report@2';

/**
 * Build the Width / Depth / Height / Density / Spacing rows for the streaming
 * Scan-report, FAILING CLOSED on an unconfirmed linear unit.
 *
 * An unknown-unit CRS carries the inert placeholder `linearUnitToMetres: 1`,
 * and a CRS-less cloud resolves the same way. Multiplying a source span by
 * that factor and stamping "m" silently reports non-metre data as metres — a
 * state-plane-FEET COPC would over-report extent ~3.28× mislabelled as metres.
 * So metres are only claimed when the frame declares a real linear unit
 * (`ctx.linearUnitKnown`), the same gate the measure tool (`setCrsKnown`) and
 * the lasso (`densityUnitKnown`) already apply. When the unit is unconfirmed
 * the metre factor is dropped, the raw source span is shown, and the "m" /
 * "pts/m²" claim is withheld. The frame comes in as a {@link SpatialContext}
 * rather than a raw CRS subset, so the unit gate and the metre factors are read
 * from the one resolved model instead of a hand-rolled predicate.
 *
 * COPC/EPT are Z-up by spec, so the horizontal footprint is X·Y and height is
 * Z. The vertical span is converted only with a valid declared vertical unit
 * (`heightScale`); without one it stays in source units and the row says so.
 * It never borrows the horizontal factor.
 */
export function streamingExtentRows(
  header: { readonly min: readonly [number, number, number]; readonly max: readonly [number, number, number] },
  ctx: SpatialContext,
  sourcePointCount: number | null,
): StreamingExtentResult {
  // A Web Mercator grid or a geocentric frame names metres, but its X/Y spans
  // are not ground metres; they stay in source units like an unknown unit.
  const unitConfirmed = groundMetresPermitted(ctx);
  const refusalReason = horizontalGroundRefusal(ctx);

  // Apply the metre factor ONLY when the unit is real. Otherwise the span stays
  // in raw source units (factor 1) and is not labelled "m".
  const mpu = unitConfirmed ? ctx.linearUnitToMetres : 1;
  // The height converts only with a declared vertical unit, as in the static
  // scan report: without one it stays in source units and says so.
  const { factor: vmpu, suffix: heightUnit } = heightScale(ctx, heightUnitsPermitted(ctx));

  const w = (header.max[0] - header.min[0]) * mpu;
  const d = (header.max[1] - header.min[1]) * mpu;
  const h = (header.max[2] - header.min[2]) * vmpu;

  const lenUnit = unitConfirmed ? ' m' : ' (source units)';
  const rows: ExtentRowSpec[] = [
    { label: 'Width', value: `${w.toFixed(1)}${lenUnit}`, scoped: false },
    { label: 'Depth', value: `${d.toFixed(1)}${lenUnit}`, scoped: false },
    { label: 'Height', value: `${h.toFixed(1)}${heightUnit}`, scoped: false },
  ];

  const footprintArea = w * d;
  // A source that cannot state its total has no nominal density or spacing.
  // Absent rows, not zeroed ones: a density of zero reads as a measurement.
  if (footprintArea > 0 && sourcePointCount !== null && sourcePointCount > 0) {
    const density = sourcePointCount / footprintArea;
    const spacing = Math.sqrt(footprintArea / sourcePointCount);
    const densityUnit = unitConfirmed ? ' pts/m²' : ' pts/unit²';
    const spacingUnit = unitConfirmed ? ' m' : ' (source units)';
    rows.push(
      { label: 'Density', value: `${density.toFixed(1)}${densityUnit} ${BOUNDING_BOX_ESTIMATE}`, scoped: true },
      { label: 'Spacing', value: `${spacing.toFixed(2)}${spacingUnit} ${BOUNDING_BOX_ESTIMATE}`, scoped: true },
      // The total is the header's: no flag was read, so how many of those
      // points are Withheld is unknown and none are excluded.
      {
        label: 'Density basis',
        value: `${describeWithheldRead(withheldReadCounts(sourcePointCount, 0, false))} (${SCAN_DENSITY_METHOD_TAG})`,
        scoped: true,
      },
    );
  }

  return { unitConfirmed, refusalReason, rows };
}
