import type { PointCloud } from '../model/PointCloud';
import type { ClassScope } from '../render/class/classScope';
import type { SpatialContext } from '../geo/SpatialContext';
import type { DrawPrecisionView } from '../science/drawPrecision';
import type { StorageHistoryOutcome } from './storageHistoryRow';

export type AnalysisStatus = 'pass' | 'warn' | 'fail' | 'info';

export interface AnalysisRow {
  label: string;
  value: string;
  status: AnalysisStatus;
  /**
   * Figures behind the value, shown on hover. The value must stand on its own:
   * the detail adds the numbers a reader may want, it never carries a caveat
   * the value leaves out.
   */
  detail?: string;
  /** When true, the row is a diagnostic shown under "Advanced report". */
  advanced?: boolean;
  /**
   * Declared source-metadata grouping. `src-std` rows render inside the
   * collapsible "Source metadata" section; `src-ext` rows go in its
   * "Extended metadata (file-declared)" subsection. Both carry verbatim
   * file declarations — declared, not verified — so the Inspector renders
   * them under that disclosure and truncates long values with a tooltip.
   * (Tokens kept short deliberately: they ride the eager index bundle.)
   */
  group?: 'src-std' | 'src-ext';
  /**
   * Honesty stamp: the class scope this metric was computed under. Set only
   * on rows whose value changes with the class filter (count, density,
   * coverage, …). Absent or `{kind:'full'}` means the metric reflects the
   * whole cloud and renders exactly as it did before class scoping existed.
   */
  scope?: ClassScope;
}

export interface AnalysisResult {
  rows: AnalysisRow[];
  /** Optional result-level scope; rows may also carry their own. */
  scope?: ClassScope;
}

export interface Selection {
  pointIndices: number[];
}

/** Options threaded into a module run. Optional so existing callers compile unchanged. */
export interface RunOptions {
  /**
   * Restrict class-dependent metrics to the visible subset of classes. When
   * absent or `{kind:'full'}`, every module behaves byte-identically to before
   * class scoping existed.
   */
  scope?: ClassScope;
  /**
   * The RESOLVED active spatial context (`crsService.context()`), threaded from
   * the composition root so a module's unit gate and metric frame honour a user
   * CRS/unit override rather than re-deriving them from `cloud.metadata.crs`.
   * Absent only for pure-module callers/tests, which fall back to the cloud's
   * declared CRS — byte-identical to before for a same-unit no-override scan.
   * This changes the SOURCE of unit/frame truth, never a metric formula.
   */
  spatialContext?: SpatialContext;
  /**
   * The active cloud's draw at the current camera, for the per-draw precision
   * bound diagnostic (`science/drawPrecision.ts`). Absent for callers without a
   * viewer; the scan report then omits the rows.
   */
  drawPrecision?: DrawPrecisionView;
  /**
   * The outcome of the storage-grid test for this cloud (`science/storageHistory.ts`),
   * computed by the shell off the main thread. Absent for callers without it; the
   * scan report then omits the row.
   */
  storageHistory?: StorageHistoryOutcome;
}

export interface AnalysisModule {
  id: string;
  label: string;
  run(cloud: PointCloud, selection?: Selection, options?: RunOptions): AnalysisResult;
  /**
   * Optional: the same result as `run`, computed in steps with `pause()`
   * awaited between them so a long module does not hold the main thread in
   * one task. `pause()` resolves false when the result is no longer wanted
   * (the scan was replaced); the module then stops and resolves null.
   */
  runYielding?(
    cloud: PointCloud,
    pause: () => Promise<boolean>,
    selection?: Selection,
    options?: RunOptions,
  ): Promise<AnalysisResult | null>;
}

export class ModuleRegistry {
  private readonly _modules: Map<string, AnalysisModule> = new Map();

  register(m: AnalysisModule): void {
    if (this._modules.has(m.id)) {
      throw new Error(`Module with id "${m.id}" is already registered.`);
    }
    this._modules.set(m.id, m);
  }

  list(): AnalysisModule[] {
    return Array.from(this._modules.values());
  }

  get(id: string): AnalysisModule | undefined {
    return this._modules.get(id);
  }
}
