import type { AnalysisModule, AnalysisResult, AnalysisRow } from '../ModuleApi';
import type { PointCloud } from '../../model/PointCloud';
import { sourcePositions } from '../../model/pointFrames';
import { medianOf, sortedValueAt } from './orderStatistic';

/**
 * Compute per-axis median and MAD (median absolute deviation) for the
 * positions array. Returns arrays of length 3.
 */
function computeMedianAndMAD(positions: Float32Array, pointCount: number): {
  median: [number, number, number];
  mad: [number, number, number];
} {
  // ONE scratch buffer for all three axes, reused twice per axis. The earlier
  // shape allocated nine Float64Arrays of N (three axis copies, a `.slice()` per
  // axis, an `absDevs` per axis) where two passes over one buffer suffice.
  //
  // `medianOf` selects the middle value instead of sorting the axis. It returns
  // exactly what the sorted form did (NaN last, -0 before +0) and leaves the
  // scratch holding the same multiset, so folding `|v - median|` over it gives
  // the identical MAD. Six full sorts of a multi-million-point axis held the
  // page for seconds on open; selection runs in linear time.
  const scratch = new Float64Array(pointCount);

  const median: [number, number, number] = [0, 0, 0];
  const mad: [number, number, number] = [0, 0, 0];

  for (let axis = 0; axis < 3; axis++) {
    for (let i = 0; i < pointCount; i++) {
      scratch[i] = positions[i * 3 + axis];
    }
    const med = medianOf(scratch);
    median[axis] = med;

    for (let i = 0; i < pointCount; i++) {
      scratch[i] = Math.abs(scratch[i] - med);
    }
    mad[axis] = medianOf(scratch);
  }

  return { median, mad };
}

/** The value at quantile `q` of the finite entries of `a` (lower order statistic). Reorders `a`. */
function finiteQuantile(a: Float64Array, finite: number, q: number): number {
  return sortedValueAt(a, Math.floor(q * (finite - 1)));
}

/**
 * A MAD-equivalent scale per axis that is non-zero wherever the data allow
 * one. MAD is 0 whenever more than half the values on an axis are identical
 * (a quantised flat floor), and median ± 8·MAD then flags every point off the
 * median. The fallbacks are the interquartile range and then the 5-95 %
 * range, each converted to the MAD a normal sample with that range would
 * have (MAD = IQR / 2; MAD = 0.6745 · (P95 − P5) / 3.29). 0 means even the
 * 5-95 % range collapses: the axis has no spread to judge a stray against.
 */
function robustScales(positions: Float32Array, pointCount: number, mad: readonly number[]): [number, number, number] {
  const out: [number, number, number] = [mad[0], mad[1], mad[2]];
  let scratch: Float64Array | null = null;
  for (let axis = 0; axis < 3; axis++) {
    if (out[axis] > 0) continue;
    scratch ??= new Float64Array(pointCount);
    let finite = 0;
    for (let i = 0; i < pointCount; i++) {
      const v = positions[i * 3 + axis];
      if (Number.isFinite(v)) scratch[finite++] = v;
    }
    if (finite < 2) continue;
    const vals = scratch.subarray(0, finite);
    const iqr = finiteQuantile(vals, finite, 0.75) - finiteQuantile(vals, finite, 0.25);
    if (iqr > 0) { out[axis] = iqr / 2; continue; }
    const wide = finiteQuantile(vals, finite, 0.95) - finiteQuantile(vals, finite, 0.05);
    if (wide > 0) out[axis] = (0.6745 * wide) / 3.29;
  }
  return out;
}

function checkInvalidCoordinates(cloud: PointCloud): AnalysisRow {
  let invalidCount = 0;
  const pos = sourcePositions(cloud);
  for (const v of pos) {
    if (!Number.isFinite(v)) {
      invalidCount++;
    }
  }
  if (invalidCount > 0) {
    return {
      label: 'Invalid Coordinates',
      value: `${invalidCount} invalid value(s) (NaN or Infinite)`,
      status: 'fail',
    };
  }
  return {
    label: 'Invalid Coordinates',
    value: 'None',
    status: 'pass',
  };
}

function checkEmptyCloud(cloud: PointCloud): AnalysisRow {
  if (cloud.pointCount === 0) {
    return {
      label: 'Empty Cloud',
      value: 'Empty — 0 points',
      status: 'fail',
    };
  }
  // The check is a VERDICT (is this cloud empty?), so the pass value is the
  // verdict — printing the loaded point count here mislabelled the display-
  // sample count as an "Empty Cloud" figure. Point counts belong to the Scan
  // Report's Point Count / Loaded rows.
  return {
    label: 'Empty Cloud',
    value: 'None',
    status: 'pass',
  };
}

/** Locale-formatted integer for the health rows ("4,683,690"). */
function fmtCount(n: number): string {
  return n.toLocaleString('en-US');
}

function checkDeclaredVsDecoded(cloud: PointCloud): AnalysisRow {
  const label = 'Declared vs Decoded Count';
  // The count decoded from the file — not `pointCount`, which a downsampled
  // cloud would report as the reduced count and falsely flag as a mismatch.
  const decoded = cloud.decodedPointCount ?? cloud.pointCount;
  if (cloud.declaredPointCount === undefined) {
    return { label, value: `${fmtCount(decoded)} decoded (no declared count)`, status: 'info' };
  }
  const declared = cloud.declaredPointCount;
  if (declared === decoded) {
    return { label, value: `${fmtCount(declared)} (match)`, status: 'pass' };
  }

  // Deliberate display-sample cap: the budget plan decoded one record per
  // bucket of `loadStride`, so decoded < declared is the EXPECTED outcome of
  // the cap, not an anomaly. The stratified sampler keeps exactly one record
  // per bucket — ceil(declared / stride) — so anything at or above that is a
  // complete capped decode (informational); anything below it means the
  // decode genuinely lost points even after accounting for the cap (amber).
  const stride = cloud.loadStride ?? 1;
  if (stride > 1) {
    const expected = Math.ceil(declared / stride);
    if (decoded >= expected) {
      return {
        label,
        value: `Declared ${fmtCount(declared)} · decoded ${fmtCount(decoded)} (display sample cap)`,
        status: 'info',
      };
    }
    return {
      label,
      value:
        `Declared ${fmtCount(declared)}, expected ${fmtCount(expected)} after the ` +
        `display-sample cap, decoded ${fmtCount(decoded)} — decode lost points`,
      status: 'warn',
    };
  }

  // No full-decode count survived (a loader that doesn't record it, or an
  // older saved session): `decoded` above fell back to the in-memory count,
  // which a budget downsample legitimately reduces below `declared`. That is
  // NOT evidence of decode loss — report it neutrally rather than raising a
  // false anomaly. Genuine loss stays detectable on the paths that do record
  // the decode count (LAS/LAZ).
  if (cloud.decodedPointCount === undefined && cloud.pointCount < declared) {
    return {
      label,
      value:
        `Declared ${fmtCount(declared)} · ${fmtCount(cloud.pointCount)} in memory ` +
        `(display sample; full decode count not recorded)`,
      status: 'info',
    };
  }

  // A real mismatch on a full decode — the file header promised a different
  // count than the decoder produced.
  return {
    label,
    value: `Declared: ${fmtCount(declared)}, Decoded: ${fmtCount(decoded)}`,
    status: 'warn',
  };
}

/**
 * Scratch used to read a coordinate's IEEE-754 bit pattern. Module-level so the
 * duplicate scan allocates nothing per point.
 */
const _bitsScratch = new Float64Array(1);
const _bitsWords = new Uint32Array(_bitsScratch.buffer);

/** Vacant marker for the duplicate table; point indices are always ≥ 0. */
const EMPTY_SLOT = -1;

/**
 * The equality the duplicate scan counts by, and the ONLY definition the hash
 * is allowed to disagree with by being coarser, never finer.
 *
 * This is SameValueZero, which is exactly what the previous `"x,y,z"` string
 * key meant: `String(NaN)` is `"NaN"` for every payload, so all NaNs collided;
 * `String(-0)` is `"0"`, so -0 and +0 collided; and every other double has a
 * distinct shortest round-tripping representation, so no two unequal values
 * ever produced the same text. Keeping that definition here is what makes the
 * typed-array rewrite a drop-in — the reported count is unchanged, not merely
 * close.
 */
function sameValueZero(a: number, b: number): boolean {
  return a === b || (Number.isNaN(a) && Number.isNaN(b));
}

/**
 * Fold one coordinate into a running 32-bit hash by its bit pattern.
 *
 * Two normalisations keep the hash consistent with {@link sameValueZero}: -0 is
 * folded as +0 and every NaN payload is folded as one constant. Without them
 * two coordinates the confirm step calls equal could land in different buckets
 * and a real duplicate would be missed.
 */
function foldCoord(hash: number, v: number): number {
  let lo: number;
  let hi: number;
  if (Number.isNaN(v)) {
    // One bucket for every NaN, whatever its payload. Reading a NaN out of a
    // Float32Array yields the canonical quiet NaN on the engines we ship to, so
    // no test can currently distinguish this branch from falling through to the
    // bit read — it is here because the language does NOT guarantee that (a
    // conforming implementation may surface any NaN bit pattern), and a payload
    // that reached the hash unfolded would put two points the confirm step
    // calls equal in different buckets and UNDER-count duplicates.
    lo = 0x7ff80000;
    hi = 0;
  } else {
    _bitsScratch[0] = v === 0 ? 0 : v; // -0 → +0
    lo = _bitsWords[0];
    hi = _bitsWords[1];
  }
  let h = Math.imul(hash ^ lo, 0x9e3779b1);
  h = Math.imul(h ^ hi, 0x85ebca6b);
  return h ^ (h >>> 15);
}

/**
 * What the held buffer IS relative to the file, so the per-point verdicts
 * below can name their basis. `voxel` — the loader averaged the decoded
 * records into one centroid per occupied voxel (`decodedPointCount` above
 * the held count): duplicates cannot survive that step and an isolated
 * point is smoothed into its neighbours, so neither verdict says anything
 * about the file. `stride` — a 1-in-N record sample, nothing averaged.
 * `full` — every record is resident. No computation changes; only the
 * wording and the pass/info status of a clean result.
 */
function sampleBasis(cloud: PointCloud): { kind: 'full' | 'stride' | 'voxel'; note: string } {
  const n = cloud.pointCount;
  const decoded = cloud.decodedPointCount;
  if (decoded !== undefined && decoded > n) {
    return {
      kind: 'voxel',
      note: `checked on the ${fmtCount(n)}-point display sample (voxel centroids); not run on the full cloud`,
    };
  }
  const declared = cloud.declaredPointCount;
  if (declared !== undefined && declared > n) {
    return {
      kind: 'stride',
      note: `checked on the ${fmtCount(n)}-point display sample (1-in-${cloud.loadStride ?? '?'} stride); not run on the full cloud`,
    };
  }
  return { kind: 'full', note: '' };
}

function checkDuplicatePoints(cloud: PointCloud): AnalysisRow {
  const n = cloud.pointCount;
  if (n === 0) {
    return { label: 'Duplicate Points', value: 'N/A (empty cloud)', status: 'info' };
  }
  // One averaged centroid per occupied voxel cannot collide with another, so
  // scanning a voxel-reduced sample can only ever find "None" — a vacuous
  // result that would read as a finding about the file. Say it was not checked.
  const basis = sampleBasis(cloud);
  if (basis.kind === 'voxel') {
    return {
      label: 'Duplicate Points',
      value: 'Not checked: the display sample is voxel-reduced, so duplicates cannot be detected. Run on a full-resolution load.',
      status: 'info',
    };
  }

  // An open-addressed index table, NOT a `Set` of `"x,y,z"` strings.
  //
  // The string form allocated one JS string plus one Set entry per UNIQUE
  // point, which at the desktop point budget was the largest allocation in this
  // module by a wide margin — several hundred megabytes of short-lived strings
  // for a single integer — and on a mobile budget it was a plausible way to run
  // the tab out of memory. This table is one Int32Array of point indices sized
  // to the next power of two at or above 2n, so the load factor stays at or
  // below 0.5 and linear probing terminates quickly.
  //
  // The count stays EXACT. The hash only chooses a bucket; a collision is
  // resolved by comparing the actual three coordinates of the stored point
  // (`sameValueZero` per axis), so two distinct points that happen to hash
  // alike probe past each other instead of being miscounted as a duplicate.
  const pos = sourcePositions(cloud);
  let capacity = 1;
  while (capacity < n * 2) capacity *= 2;
  const mask = capacity - 1;
  const slots = new Int32Array(capacity).fill(EMPTY_SLOT);

  let duplicateCount = 0;
  for (let i = 0; i < n; i++) {
    const x = pos[i * 3];
    const y = pos[i * 3 + 1];
    const z = pos[i * 3 + 2];
    let bucket = foldCoord(foldCoord(foldCoord(0, x), y), z) & mask;
    for (;;) {
      const stored = slots[bucket];
      if (stored === EMPTY_SLOT) {
        slots[bucket] = i;
        break;
      }
      if (
        sameValueZero(pos[stored * 3], x) &&
        sameValueZero(pos[stored * 3 + 1], y) &&
        sameValueZero(pos[stored * 3 + 2], z)
      ) {
        duplicateCount++;
        break;
      }
      bucket = (bucket + 1) & mask;
    }
  }

  if (duplicateCount > 0) {
    return {
      label: 'Duplicate Points',
      value: `${duplicateCount} duplicate(s)`,
      status: 'warn',
    };
  }
  if (basis.kind === 'full') {
    return { label: 'Duplicate Points', value: 'None', status: 'pass' };
  }
  return { label: 'Duplicate Points', value: `None (${basis.note})`, status: 'pass' };
}

function checkStrayOutliers(cloud: PointCloud): AnalysisRow {
  const n = cloud.pointCount;
  if (n < 3) {
    return { label: 'Stray Outliers', value: 'N/A (too few points)', status: 'info' };
  }

  const pos = sourcePositions(cloud);
  const { median, mad } = computeMedianAndMAD(pos, n);
  const THRESHOLD = 8;
  // MAD where it is non-zero; otherwise a wider robust range (see robustScales).
  const scale = robustScales(pos, n, mad);
  const flat = [0, 1, 2].filter((axis) => !(scale[axis] > 0));
  if (flat.length > 0) {
    // No spread on an axis means no stray can be told from the rest of the
    // scan on it. Flagging every off-median point there (the old ±1e-9 band)
    // reported a flat floor's own ramp as outliers.
    const names = flat.map((axis) => 'XYZ'[axis]).join(', ');
    return {
      label: 'Stray Outliers',
      value: `Not assessable: at least 90% of points share one ${names} value, so there is no robust spread to measure strays against`,
      status: 'info',
    };
  }

  let outlierCount = 0;
  for (let i = 0; i < n; i++) {
    let isOutlier = false;
    for (let axis = 0; axis < 3; axis++) {
      const v = pos[i * 3 + axis];
      const range = THRESHOLD * scale[axis];
      if (Math.abs(v - median[axis]) > range) {
        isOutlier = true;
        break;
      }
    }
    if (isOutlier) outlierCount++;
  }

  if (outlierCount > 0) {
    return {
      label: 'Stray Outliers',
      value: `${outlierCount} outlier(s) beyond median ± 8·MAD${mad.some((m) => !(m > 0)) ? ' (MAD from the interquantile range where it is 0)' : ''}`,
      status: 'warn',
    };
  }
  // Voxel averaging suppresses exactly the isolated points this check looks
  // for, so a clean result over centroids is disclosed, not passed.
  const basis = sampleBasis(cloud);
  if (basis.kind === 'full') {
    return { label: 'Stray Outliers', value: 'None', status: 'pass' };
  }
  return {
    label: 'Stray Outliers',
    value: `None — ${basis.note}`,
    status: basis.kind === 'voxel' ? 'info' : 'pass',
  };
}

/**
 * Per-cloud result memo. Every check reads only the cloud's IMMUTABLE fields
 * (positions, point counts) — no scope, no classification — so the result is a
 * pure function of the cloud and is identical on every re-run. The two heavy
 * checks (the median/MAD sort + the duplicate-scan table) re-ran on every
 * Inspector refresh — a class toggle, a tab switch — stalling the main thread
 * on a multi-million-point scan. Keyed by the cloud via a WeakMap so the
 * entry is collected with the cloud; nothing to invalidate because nothing the
 * checks read can change without a new cloud.
 */
const _resultCache = new WeakMap<PointCloud, AnalysisResult>();

export const healthCheck: AnalysisModule = {
  id: 'health-check',
  label: 'Health Check',

  run(cloud: PointCloud): AnalysisResult {
    const cached = _resultCache.get(cloud);
    if (cached) return cached;
    return finish(cloud, CHECKS.map((check) => check(cloud)));
  },

  // The five checks together are one 0.5 s task on a few-million-point scan;
  // run apart, each is its own task and input is handled between them.
  async runYielding(cloud: PointCloud, pause: () => Promise<boolean>): Promise<AnalysisResult | null> {
    const cached = _resultCache.get(cloud);
    if (cached) return cached;
    const rows: AnalysisRow[] = [];
    for (let i = 0; i < CHECKS.length; i++) {
      if (i > 0 && !(await pause())) return null;
      rows.push(CHECKS[i]!(cloud));
    }
    return finish(cloud, rows);
  },
};

/** The checks, in report order. */
const CHECKS: ReadonlyArray<(cloud: PointCloud) => AnalysisRow> = [
  checkInvalidCoordinates,
  checkEmptyCloud,
  checkDeclaredVsDecoded,
  checkDuplicatePoints,
  checkStrayOutliers,
];

/** Every health-check row is a diagnostic, surfaced under "Advanced report"; memoised per cloud. */
function finish(cloud: PointCloud, rows: AnalysisRow[]): AnalysisResult {
  const result: AnalysisResult = { rows: rows.map((row) => ({ ...row, advanced: true })) };
  _resultCache.set(cloud, result);
  return result;
}
