/**
 * actionDefinitions.ts
 *
 * The command-palette / shortcut-sheet action registry: one assembler over the
 * contributors in `src/app/actions/`, each of which receives only the shell
 * collaborators its own actions use. Nothing here has behaviour of its own.
 * The shell builds the registry on the first surface that needs it (palette,
 * sheet, a Dataset Story click), so none of this rides the startup chunk.
 *
 * Two collaborators are read through getters: `viewer` is a `let` assigned
 * after boot, and `tour` starts null and is set later. Both resolve when a
 * handler fires, not when the registry is built.
 */
import type { Action } from '../ui/actionRegistry';
import type { Viewer } from '../render/Viewer';
import type { TourHandle } from '../ui/onboarding/bootTour';
import type { WorkflowController } from '../ui/WorkflowController';
import type { SceneTool } from './toggleTool';
import type { WorkflowConfigPanel } from '../ui/WorkflowConfigPanel';
import type { WorkflowEvent } from '../render/workflow/workflowRecorder';
import type { ShortcutSheet } from '../ui/ShortcutSheet';
import type { LassoVolumeTool } from '../ui/LassoVolumeTool';
import type { CompassController } from '../ui/compassController';
import type { ViewBookmarksService } from './viewBookmarks';
import type { ThemeName } from '../ui/themes';
import type { TerrainAnalysisEntryDeps } from './openTerrainAnalysis';
import type { ObservatoryEntryDeps } from './openObservatoryRun';
import type { ScanStoryInputs } from '../intelligence/scanStory';
import { contributeCameraActions, type PlanViewActions } from './actions/cameraActions';
import { contributeViewActions } from './actions/viewActions';
import { contributeToolActions } from './actions/toolActions';
import { contributeAnalysisActions } from './actions/analysisActions';
import { contributeExportActions } from './actions/exportActions';
import { contributeWorkflowActions } from './actions/workflowActions';
import { contributeHelpActions } from './actions/helpActions';

export type { PlanViewActions } from './actions/cameraActions';

export interface ActionRegistryDeps {
  getViewer: () => Viewer;
  getTour: () => TourHandle | null;
  workflowController: WorkflowController;
  lassoVolumeTool: LassoVolumeTool;
  compass: CompassController;
  bookmarks: ViewBookmarksService;
  showLassoToast: (
    message: string,
    action?: { readonly label: string; readonly onClick: () => void },
  ) => void;
  setTheme: (name: ThemeName) => void;
  syncLassoButton: () => void;
  runDeriveClassification: () => Promise<void>;
  saveSnapshot: () => void | Promise<void>;
  copyShareLink: () => void | Promise<unknown>;
  /** The session file, the scan picker and the PDF report, as the panels run them. */
  exportSession: () => unknown;
  handleFile: (file: File) => unknown;
  openScan: () => void;
  exportReport: () => void | Promise<void>;
  terrainAnalysisEntry: TerrainAnalysisEntryDeps;
  observatoryEntry: ObservatoryEntryDeps;
  runFillUnclassified: () => Promise<void>;
  runTool: (tool: SceneTool) => void;
  buildCurrentStoryInputs: () => ScanStoryInputs;
  startWorkflowRecording: () => void;
  dispatchWorkflowEvent: (event: WorkflowEvent) => void;
  ensureWorkflowConfigPanel: () => Promise<WorkflowConfigPanel>;
  ensureShortcutSheet: () => Promise<ShortcutSheet>;
  hasScan: () => boolean;
  saveCurrentView: () => void;
  applyView: (index: number) => void;
  toggleOrbitInvert: (axis: 'x' | 'y') => void;
  resetNavigation: () => void;
  /** Show or hide the reference plane (the `view.reference-plane` action). */
  toggleReferencePlane: () => void;
  /** Re-flash the touch-gesture hint (the `nav.gestures` action). */
  showTouchGestures: () => void;
  planView: PlanViewActions;
}

/** Assemble the registry in its display order: camera, theme and view, tools, analyse, export, workflow, help. */
export function buildActionRegistry(deps: ActionRegistryDeps): Action[] {
  const capture: WorkflowController['capture'] = (event) => deps.workflowController.capture(event);
  const camera = contributeCameraActions({
    getViewer: deps.getViewer,
    planView: deps.planView,
    capture,
    showLassoToast: deps.showLassoToast,
  });
  const view = contributeViewActions({
    setTheme: deps.setTheme,
    capture,
    compass: deps.compass,
    bookmarks: deps.bookmarks,
    toggleOrbitInvert: deps.toggleOrbitInvert,
    resetNavigation: deps.resetNavigation,
    toggleReferencePlane: deps.toggleReferencePlane,
    showTouchGestures: deps.showTouchGestures,
    hasScan: deps.hasScan,
    saveCurrentView: deps.saveCurrentView,
    applyView: deps.applyView,
    showLassoToast: deps.showLassoToast,
  });
  const tools = contributeToolActions({
    getViewer: deps.getViewer,
    workflowController: deps.workflowController,
    lassoVolumeTool: deps.lassoVolumeTool,
    syncLassoButton: deps.syncLassoButton,
    runDeriveClassification: deps.runDeriveClassification,
    runFillUnclassified: deps.runFillUnclassified,
    showLassoToast: deps.showLassoToast,
    runTool: deps.runTool,
  });
  const analysis = contributeAnalysisActions({
    terrainAnalysisEntry: deps.terrainAnalysisEntry,
    observatoryEntry: deps.observatoryEntry,
    buildCurrentStoryInputs: deps.buildCurrentStoryInputs,
  });
  const exports_ = contributeExportActions({
    saveSnapshot: deps.saveSnapshot,
    copyShareLink: deps.copyShareLink,
    exportSession: deps.exportSession,
    handleFile: deps.handleFile,
    openScan: deps.openScan,
    exportReport: deps.exportReport,
    buildCurrentStoryInputs: deps.buildCurrentStoryInputs,
    showLassoToast: deps.showLassoToast,
  });
  const workflow = contributeWorkflowActions({
    workflowController: deps.workflowController,
    startWorkflowRecording: deps.startWorkflowRecording,
    dispatchWorkflowEvent: deps.dispatchWorkflowEvent,
    ensureWorkflowConfigPanel: deps.ensureWorkflowConfigPanel,
    showLassoToast: deps.showLassoToast,
  });
  const help = contributeHelpActions({
    getTour: deps.getTour,
    ensureShortcutSheet: deps.ensureShortcutSheet,
    getViewer: deps.getViewer,
    notify: (message) => deps.showLassoToast(message),
  });
  // The theme rows sit between the camera rows and the tools, as before.
  const theme = view.filter((a) => a.section === 'Theme');
  const rest = view.filter((a) => a.section !== 'Theme');
  // Every run through the registry (a palette row, or an action the shell runs
  // by id) is one Session log line. Dock buttons and keys call their handlers
  // directly and are not logged as commands.
  return [...camera, ...theme, ...tools, ...analysis, ...exports_, ...workflow, ...rest, ...help].map(loggedAction);
}

/** Hand one line to the Session log as an event, so this chunk does not carry the log. */
function emitCommand(a: Action, status: 'done' | 'failed'): void {
  try {
    globalThis.document.dispatchEvent(new CustomEvent('olv-session-log', { detail: { kind: 'command', text: a.title, detail: a.section, status } }));
  } catch {
    /* no document here (a test host); nothing to log to */
  }
}

/**
 * `a`, logged once it has run: done, or failed when it threw. A run that
 * returns a promise is logged when the promise settles, and the promise is
 * handed back so its rejection still reaches the caller.
 */
export function loggedAction(a: Action): Action {
  // Copied by descriptor, so a state-aware title getter stays live.
  const copy = Object.defineProperties({}, Object.getOwnPropertyDescriptors(a)) as Action;
  const run = (): void => {
    let out: unknown;
    try {
      out = a.run();
    } catch (error) {
      emitCommand(a, 'failed');
      throw error;
    }
    if (out && typeof (out as PromiseLike<unknown>).then === 'function') {
      return Promise.resolve(out).then(
        () => emitCommand(a, 'done'),
        (error: unknown) => {
          emitCommand(a, 'failed');
          throw error;
        },
      ) as unknown as void;
    }
    emitCommand(a, 'done');
  };
  return Object.defineProperty(copy, 'run', { enumerable: true, value: run });
}
