/**
 * toolActions.ts
 *
 * The tool dock's actions: Measure, Inspect, Annotate, the two derived
 * classification runs, and the lasso volume with its selection basis.
 */
import type { Action } from '../../ui/actionRegistry';
import type { Viewer } from '../../render/Viewer';
import type { WorkflowController } from '../../ui/WorkflowController';
import type { LassoVolumeTool } from '../../ui/LassoVolumeTool';
import type { SceneTool } from '../toggleTool';
import { keyDisplayFor } from '../../ui/keyBindings';
import { actionTitle } from '../../ui/actionDescriptors';

export interface ToolActionDeps {
  getViewer: () => Viewer;
  workflowController: WorkflowController;
  lassoVolumeTool: LassoVolumeTool;
  syncLassoButton: () => void;
  runDeriveClassification: () => Promise<void>;
  runFillUnclassified: () => Promise<void>;
  showLassoToast: (message: string) => void;
  /**
   * The shared scene-tool command (`runSceneTool`). The dock and the keyboard
   * call the same function, so every entry point toggles, records and reveals
   * the Tools page identically.
   */
  runTool: (tool: SceneTool) => void;
}

export function contributeToolActions(deps: ToolActionDeps): Action[] {
  const actions: Action[] = [];
  actions.push(
    {
      id: 'tool.measure',
      keys: keyDisplayFor('tool-measure'),
      title: actionTitle('tool.measure'),
      section: 'Tools',
      hint: 'Activate the measurement toolbar.',
      keywords: ['distance', 'area', 'volume'],
      run: () => {
        deps.runTool('measure');
      },
    },
    {
      id: 'tool.inspect',
      keys: keyDisplayFor('tool-inspect'),
      title: actionTitle('tool.inspect'),
      section: 'Tools',
      hint: 'Read attributes of any point under the cursor.',
      keywords: ['point', 'point info', 'attributes'],
      run: () => {
        deps.runTool('inspect');
      },
    },
    {
      id: 'tool.annotate',
      keys: keyDisplayFor('tool-annotate'),
      title: actionTitle('tool.annotate'),
      section: 'Tools',
      hint: 'Drop notes, info, warnings, or issues on points.',
      keywords: ['note', 'comment', 'mark'],
      run: () => {
        deps.runTool('annotate');
      },
    },
    {
      id: 'tool.clip',
      title: actionTitle('tool.clip'),
      section: 'Tools',
      hint: 'Show only the points inside a box, or hide them.',
      keywords: ['slab', 'section', 'crop', 'box', 'hide'],
      help: {
        summary: 'Restricts what the viewer draws to an axis-aligned box without changing the source scan. A point-cloud export made while the clip is on carries the clipped points, not the whole cloud.',
      },
      run: () => {
        deps.runTool('clip');
      },
    },
    {
      id: 'tool.classify',
      title: 'Classify (derive)',
      section: 'Tools',
      hint: 'Derive a ground / vegetation / building classification for an unclassified scan (heuristic).',
      keywords: ['classification', 'ground', 'vegetation', 'building', 'segment', 'auto'],
      run: () => {
        void deps.runDeriveClassification();
      },
    },
    {
      id: 'tool.fillUnclassified',
      title: 'Fill unclassified points (derive)',
      section: 'Tools',
      hint: 'Derive only the unclassified points of a partially-classified scan, preserving every producer class (heuristic).',
      keywords: ['classification', 'fill', 'gaps', 'unclassified', 'producer', 'preserve'],
      run: () => {
        void deps.runFillUnclassified();
      },
    },
    {
      id: 'tool.lasso-volume',
      title: 'Lasso volume',
      section: 'Tools',
      keys: keyDisplayFor('lasso-toggle'),
      hint: 'Draw a freeform shape to measure a 3D volume.',
      keywords: ['select', 'shape', 'cut', 'fill'],
      run: () => {
        if (deps.lassoVolumeTool.enabled) {
          deps.lassoVolumeTool.disable();
          deps.getViewer().clearSelectionHighlight();
          deps.showLassoToast('Lasso off — back to navigation.');
        } else {
          deps.lassoVolumeTool.enable();
          deps.showLassoToast('Lasso armed — draw a shape on the canvas.');
        }
        deps.syncLassoButton();
      },
    },
    {
      id: 'tool.lasso-selection-basis',
      title: 'Lasso selection basis',
      section: 'Tools',
      hint: 'Whether a lasso measures every depth along the ray or only the surfaces the camera can see.',
      keywords: ['occlusion', 'hidden', 'behind', 'depth', 'through', 'visible', 'volume'],
      run: () => {
        // Two different measurements of the same drawn shape, so the toast
        // names the one now armed rather than reporting a setting changed.
        const next =
          deps.lassoVolumeTool.selectionBasis === 'occluded-excluded'
            ? 'through-surfaces'
            : 'occluded-excluded';
        deps.lassoVolumeTool.selectionBasis = next;
        deps.showLassoToast(
          next === 'occluded-excluded'
            ? 'Lasso measures visible surfaces only — points hidden behind nearer ones are left out.'
            : 'Lasso measures all depths along the ray — points behind a surface are included.',
        );
      },
    },
  );
  return actions;
}
