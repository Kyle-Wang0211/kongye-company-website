# Privacy

OpenLiDARViewer runs in your browser. This page describes what it does with
your data.

## Files you open

Files you open from your device are read and processed on your device. They
are not uploaded to any server.

## What leaves your device

The app contains no analytics and no telemetry. It sends nothing about you or
your use of it to the project or to anyone else. The network requests it makes
are these:

- the app's own files, from the site that serves it, and the full offline copy
  if you ask for one;
- a remote dataset or sample you open, from the server that hosts it;
- a location search in the public LiDAR catalogue, sent to Microsoft Planetary
  Computer, only when you run one, and, when you open a result, a request to
  its signing service carrying that tile's address.

The `?notelemetry=1` URL flag turns off the public LiDAR catalogue, including
its location search.

## Browser storage

The app stores some data in your browser, on your device only:

- session recovery data, so an interrupted session can be restored. Entries
  older than 7 days are deleted, and "Clear recovery data" in Help removes them
  at once;
- your preferences, such as theme, navigation and panel settings;
- local usage counts, shown in the Session Stats panel and never sent anywhere
  (the `?notelemetry=1` URL flag turns them off as well);
- a cache of the app's own files, kept by its service worker so the app loads
  faster;
- the full offline copy of the app, only if you choose to make it available
  offline.

You can remove all of it by clearing the site data for the app in your browser.

The Session log is not stored: it lives in this tab's memory, a reload clears
it, and it leaves your device only if you copy or export it.

## Remote datasets and samples

When you open a remote dataset, a sample, or search a public data catalogue,
the data is downloaded directly from the server that hosts it. That server sees
your IP address and which files and tiles you request, and its own privacy
terms apply.

## Warranty

OpenLiDARViewer is provided as is, without warranty of any kind; see sections
15 and 16 of the GNU AGPL in [LICENSE](LICENSE).
