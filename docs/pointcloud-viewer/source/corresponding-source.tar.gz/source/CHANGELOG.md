# Changelog

The format is based on Keep a Changelog and the project follows Semantic Versioning.

## [Unreleased]

## [0.7.1-alpha.1] - 2026-10-25

An alpha on the way to v0.7.1. It has no tag and no DOI, its test figures are
not release-authoritative, and the real-scan walkthrough in the packaged build
has not been done. v0.7.0 is the current published release.

### Added

- Open scan, Open session, Save session and Report PDF in the command palette. They run the same paths as their controls; Report PDF uses the default template.
- Undo after Clear in the measure toolbar: a toast offers to put every deleted measurement back for 8 seconds.
- A Delete button on the measurement result card, and a Copy button on each Measurements row, both doing what the list's own controls do.
- A polygon volume shows its base level, the median of the outline's vertex heights, under the result, marked local when the scan has no datum. Copy result and the PDF report carry it, and the measurement CSV and GeoJSON write it as `base_level`.
- Error toasts have a Dismiss control and a Show in Session log action.
- A Created layers list on the Data tab, under the Classes block, for scans with or without classes. It has one checkbox per overlay a run has drawn in the 3D view (Contours, Drainage lines from Flow Pulse, Access map from Terrain Access) and appears once one exists. The checkboxes follow the Analyse contour checkbox and the Lab toggles both ways. A hidden overlay is not drawn. A saved session and crash recovery keep each overlay's shown or hidden state and apply it when the overlay is drawn again; older sessions load as before.
- Three external-reference windows under `validation/field-simulation/external-references/` (CC-BY-4.0, credited in the third-party notices and credits page), registered as OLV-DS-117 to OLV-DS-121, with four protocol records, five study manifests and `tests/flowPulseExternalReferences.test.ts`. TauDEM 5.3.8 and GRASS GIS 8.3.2 are registered as oracles.
- Six RichDEM test and example grids (GPL-3.0, credited in the notices and credits page) under `validation/field-simulation/richdem-references/`, registered as OLV-DS-122 to OLV-DS-127, with `tests/flowPulseRichDemReferences.test.ts` under a pre-registered protocol. On RichDEM's own depression-filling test grid the Priority-Flood spill level equals RichDEM's expected fill on all 100 cells and the inventory lists the same three depressions; on its flow-accumulation test grid the accumulation over RichDEM's directions equals its expected output on all 100 cells. Recorded as corroboration; no evidence level moved. RichDEM is registered as an oracle.
- A pinned set of small test files from LASzip, laspy, libE57Format, PROJ and the Point Cloud Library, with tests that open each one through the normal load path and check the outcome the upstream project's own tests state.
- A Storage history row in the scan report for a LAS or LAZ file opened from disk. It tests whether the file's stored integer X and Y are compatible with a candidate earlier storage grid: multiples of the file's own step, 0.001, 0.01 and 0.1 m grids for a file in another unit, and 0.01 and 0.1 ft grids turned 0 or a whole number of degrees up to 5 either way for a file in metres. The row reads "coordinates supported on a 0.01 ft grid rotated 3°", "none detected", or "not tested" with the reason (a streamed scan, too few points, a load that did not keep the file's integers, a geographic frame). Its hover text carries the Fisher-combined p-value before and after the Bonferroni correction over the tested candidates, the measured-to-predicted amplitude ratio and the windows and points that entered. The test runs in a worker on at most 12,000 points in at least 20 windows against 300 null wavevectors, about a second for any file size, and the row updates when it ends. A supported grid is one the stored integers are compatible with; the row says nothing about how or by whom the file was produced, and a grid outside the candidate set is not found. Registered as `olv.storage.grid-history@1` with claim STORAGE-HISTORY at E2; the capability is a preview.
- `npm run validate:zenodo-small`: opens `iPhone.laz` from Zenodo record 15421291 (OLV-DS-055) through the serial, whole-file, pooled-browser and COPC node paths, and compares every point with laspy and lazrs and with each other after checking the file hashes. It also reads OLV's LAS exports back independently, checks CRS provenance from opening through session and export, checks the published reference points against `spheres-epsg5514.csv`, and runs the open-and-assign-CRS journey in the app. It writes `results.json` and `summary.md` and exits non-zero on a missing input, wrong hash, missing dependency or mismatch. See `docs/validation/zenodo-small-study.md`. No evidence level moved.
- Pressing a layer's name in the Layers list makes it the active scan, the one the Classes list, scan report and exports describe. The list marks the active scan. Before, only opening a scan or removing the active one changed it.

### Changed

- Contour GeoJSON features carry the pooled run score as `presentationSupport` instead of `meanConfidence`.
- The lasso stockpile toast warns when the lasso was drawn more than 20° from straight down: raised points can then fall outside the footprint, and the toast says to draw in plan view.
- The PDF report's profile slope summary labels its third figure "Net … (total rise ÷ total run)" instead of "Avg". It is the summed rise over the summed run of the covered segments, not an average of the grades.
- Box measurements in CSV and GeoJSON exports cite a new MEAS-BOX claim (E3) for the box's own extents and volume. They cited the cut-fill volume claim, VOL-POINT-SAMPLE, which describes a different estimator.
- The MEAS-AREA claim describes the area the tool reports: the area in the polygon's own plane, which equals the planimetric area for a horizontal polygon. Its scope now states that the cross-implementation comparison covers horizontal polygons only.
- The approved wording for MEAS-AREA, E57-INGEST, TPI and VRM no longer calls their tolerances preregistered. Each protocol was adopted together with its result, and the wording now says so.
- The Scan Report's Density and Spacing values say "(bounding-box estimate)" on every scan, static or streamed. Both are the point count over the axis-aligned bounding box, so a diagonal strip or gappy coverage reads sparser than the area the points cover. Before, only a display-sample load said how they were worked out.
- The lasso stockpile toast no longer says "MEASURED" for a footprint with full coverage. It says "exploratory volume preview", as the stockpile volume's claim allows at every tier. In CSV and GeoJSON exports, `grid_authority` writes that tier as `exploratory_full_coverage` instead of `measured`; `preview` and `withheld` are unchanged.
- Measuring costs less on large scans. The hover pick waits while the camera moves, and snap grids are built while the Measure tool is open instead of for every scan as it opens.
- Terrain void filling visits only the edge of each search ring. Filled heights are unchanged.
- The page downloads about 240 KiB less (gzip) before a scan opens. The 3D renderer loads when you open a scan or when the browser is idle.
- Opening the file picker starts loading the viewer and the file reader, as dragging a file over the page already did.
- Large LAS, LAZ and E57 files reach their final points sooner.
- Streamed scans spend less time choosing nodes while the camera moves, and a node keeps its shader through its fade in and fade out.
- Turning the class, elevation or intensity filter on or off rebuilds the point shaders only the first time after a scan opens.
- A scan without RGB is coloured once when it opens, and colouring by class takes about a quarter of the time.
- The scan report fills in after a large scan opens without holding the page for half a second.
- TERRAIN-FLOW-PULSE moves from E3 to E4. A comparison pre-registered in `validation/protocols/flow-pulse-external-references-v1.md`, with its gates fixed before Flow Pulse was run on the data, checked it against outputs two other programs published for real terrain. On two Bear Creek crops of a USGS NED DEM, chosen so that a fill computed on the crop alone reproduces TauDEM's whole-grid fill, the Priority-Flood spill level equals TauDEM 5.3.8 PitRemove's filled elevation on all 119,119 distinct cells (172,702 cell comparisons across three runs: crop A, crop B with NoData as outlet, crop B with NoData as wall). On one 25 m window of the Riviere des Pluies catchment, Reunion, against GRASS GIS 8.3.2: 99.21% of catchment cells with a unique steepest descent take the same D8 direction (gate 98%), the catchment from the mouth has a Jaccard index of 0.9990 (gate 0.99), and 95.2% of catchment cells are within 5% of the accumulation (gate 90%; 87.0% exact). The GRASS module is not named by the dataset; from the output encoding it is inferred to be r.watershed in single-flow mode, a least-cost router, so routing agrees within these tolerances and not exactly. D8 tie order, flat resolution, flow length and the peak-flow estimate were not compared, and agreement on archival data is not field validation.
- TERRAIN-FLOW-DEPRESSION-INVENTORY moves from E2 to its required E3. In conditioned mode, all 187 depressions on the two Bear Creek crops match TauDEM's filled depressions on count, cell count, area, maximum fill depth and spill level, which puts that mode at E4; raw mode was not compared, so the claim is recorded at E3. A second pre-registered check, `validation/protocols/depression-inventory-synthetic-suite-v1.md`, compared the inventory across all eight TF fixtures and five new constructed grids (nested depressions, corner-only contact, a depression open to the border, an enclosed NoData hole, non-square cells) with hand-derived values and an in-project Python oracle, in both NoData readings: every extent, count, area, depth, spill level, outlet elevation and fill volume agrees, area is withheld without a resolved horizontal scale, and the exported accumulation grid reads back north row first with its corner in place.
- The Measurements panel's session buttons read Save session and Open session. Every save ends in a toast stating how many measurements, annotations and saved views the file holds and that it holds no points.
- The measure toolbar's Undo is disabled until a point is drafted, and its tooltip says so. Backspace and Ctrl/Cmd+Z stay with the Measure tool while it is open; with nothing drafted the hint says where a finished measurement is deleted. Esc during a vertex drag puts the vertex back. The global Undo and Redo say in a toast what they undid or redid.
- Copy view link says Link copied only when the clipboard took the link, and a toast says what the link restores or that copying was blocked and the link is in the address bar. The button is disabled while a stream is the scene.
- Error toasts stay for the longer of six seconds and 0.4 seconds per word, up to thirty, and hold while hovered or focused.
- A snapshot is saved as `<scan>-view-YYYYMMDD-HHMMSS.png` and a toast names the file.
- On a phone, Open details on the result card opens the sheet to half height and focuses the row; choosing a tab or tapping the sheet's head opens it to half height.
- The advice for a file no probe recognised says to export it as LAS/LAZ, E57, PLY, PCD, PTX, PTS or XYZ from the software that made it.
- The command palette's no-match text says how to reach the shortcut sheet from the palette. The URL field's empty message names the 3D Tiles entry point, and a CORS block on an EPT dataset or tileset says the fix is at the host.
- The Colour by chips and the measure kind buttons carry aria-pressed, the scan canvas is an application region named with its keys, and a new measurement result is announced with its caveat through the one polite region.

### Fixed

- A WKT2 bound CRS (`BOUNDCRS`) takes its horizontal unit from its source CRS, the CRS the coordinates are in. The unit was read from the target CRS, so a US survey foot or international foot grid was treated as metres and every distance, area and volume came out about 3.28 times too large.
- Two scans whose CRS has no EPSG code and the same name, such as two custom "Site Grid" projections, are compared on their definition: projection method, parameters, datum, ellipsoid, units and axes. If the two definitions list the same parameters and any value differs, the scans are not placed in one frame or combined. When the definitions cannot be compared, for example one written as WKT1 and one as WKT2, one missing a parameter, or one missing entirely, the scans are left unknown to each other. The layer panel summary uses the same comparison and says when such a pair's alignment is unverified. An ortho export of two such scans with different definitions is not given one georeference.
- Marking scans as Local coordinates no longer places them in one shared frame. Each stays in its own frame, as a scan with no CRS does.
- A Created layers choice restored from a session is now saved again before its overlay is regenerated. Saving and reopening the session no longer loses it, and the recovery copy keeps it too. Closing the scan clears choices that were never applied.
- A COPC node whose compressed bytes are shorter than the size its hierarchy declares is refused as malformed. The LAZ decoder has no length check of its own and used to return a full set of points, partly decoded from memory past the end of the data.
- A chunked LAZ file is held to the same rule: a chunk whose bytes differ from the size in the file's chunk table, shorter or longer, is refused as malformed. A COPC node longer than its declared size is refused too.
- A saved session or recovery copy keeps the Created layers state of every overlay that exists. Up to 32 choices are kept, and choices for overlays not yet regenerated used to fill that limit first, so a session with 32 of them dropped the state of the overlays on screen. Overlays that exist now come first, then pending choices for known overlays.
- `lint:module-graph --baseline` with no file now exits 2 with a usage message. It used to fall back to the committed baseline.
- The Coordinate system and Vertical datum rows in Export readiness and the Dataset Story follow the coordinate system in use, including one chosen in the Coordinate system section. They used to read only what the file declared, so a scan the user had assigned a CRS to still showed Unknown until it was reopened.
- An export with an assigned CRS records the assignment in the file. The text record now carries a crs-assigned line naming the EPSG and stating that coordinates were not moved; before, the written WKT read like the source's own declaration.
- A LAS export says when it writes a return number or number of returns of 0 as 1. LAS starts both at 1 and the writers raise a 0 to 1; that change was not reported before. It now appears in the export log and as a conversion event in the file's own text record.
- A saved session keeps the name of the catalogue behind a catalogue-asserted CRS when it is opened again. Reading the session used to drop it, so the restored record no longer said whose statement the frame rested on.
- Dataset Intelligence gives no density tier on a Web Mercator or geocentric frame, or on a frame with no local vertical, as the Scan Report gives no pts/m² there. It used to tier those scans as if their grid units were ground metres.
- The stockpile volume breakdown caps its confidence by how much of the footprint the scan covers, as the volume record already did. Dense, even sampling over part of a footprint no longer reads high confidence.
- A scan that replaces the open one, such as a streamed scan opened over static layers or a static scan opened over a stream, starts with the clip box off and the elevation and intensity filters cleared. It used to keep the previous scan's clip box, and a stream opened over another stream kept the old filter range. A scan added beside open layers keeps both.
- The PDF report prints each measurement as the Measurements panel shows it. It used to format the figures itself, with more decimals, cubic metres where the panel shows cubic decimetres, no bearing on a distance and no angle on a slope.
- On phones, a streamed scan no longer keeps a visibility record for every node it evicts.
- DEM packages export on DEMs with more than 250,000 measured cells. The attention raster used to stop the export there.
- The terrain report, DEM package and export provenance no longer give the live DTM the registry E4. The DTM study covers min-return gridding only, and the live DTM uses median aggregation, so these said the DTM was not covered by the registered studies. The median studies under Validation below now cover measured cells for cell sizes from 0.1 to 10 m with the grid origin at the data minimum.
- Map sheets and the terrain report's contour rows use the cartographic contour claim when contours are generalised or smoothed, as the GeoJSON and DXF exports do.
- The map sheet calls its accuracy block an internal hold-out check instead of survey accuracy.
- Change detection says when it assumed the vertical unit from the horizontal unit.
- The terrain complexity summary warns when more than 10% of its cells are interpolated.
- Wording: the scan fitness verdict names hold-out residuals, Contour Studio no longer calls area and scale "validated", the precision check no longer says "certified level", and the Analyse help calls the hold-out an internal check.
- A withheld stockpile volume shows no cut-fill cross-check figure either, in the Measurements panel, the toast, the PDF report and the CSV and GeoJSON exports. The grid is withheld for a footprint the scan does not support, and the cross-check covered the same footprint.
- A scan opened after you changed the height trim is coloured with that trim, as the colour key states. It used the default trim of 5.
- With the project-wide height scale on, adding a layer in another colour mode leaves the height colours of the other layers on the range the colour key states. It used to widen their range to the new layer's heights.
- The DTM evidence line in the terrain report, the DEM package evidence contract and export provenance printed E4 on measured cells for every DTM, although the median studies covered one 1 m grid with its origin at (0, 0). It now reads E4 only when the run's cell size is within the studied range of 0.1 to 10 m and its grid origin is at the data minimum, and "measured cells not covered" otherwise.
- A LAS file whose WKT is a named local or engineering CRS (`LOCAL_CS`, `ENGCRS`) keeps that name and is treated as a local frame. Two layers in local frames with different names are reported as mismatched, are not combined, and change detection between them is refused. Two layers naming the same local frame are reported as unverified rather than matching.
- An engineering or local CRS inside a compound CRS (`COMPOUNDCRS`, `COMPD_CS`) is now read as a local frame with its own name. Two such layers sharing only the compound's name are no longer combined in terrain, profile, volume and other combined results. WKT with no readable horizontal or local CRS counts as no declared CRS. A streamed layer is now checked with the same local-frame name and CRS override as a loaded layer. The layer tooltip for an unresolved layer says to set the same CRS on each layer to combine them.
- A refusal written for the user, such as the tileset-by-URL guidance, the E57 and whole-file size caps and a graphics backend that cannot start, reaches the toast as written instead of as the category's general sentence.
- A browser with neither WebGPU nor WebGL 2 is told so when a scan opens, instead of the failure being reported as a fault in the file.
- A URL that fails to open shows its message under the URL field with Retry, for COPC, EPT and 3D Tiles alike.
- The warning that a PDF report was saved without some sections stays on screen; the progress toast used to erase it.
- A LAZ file whose compression record names a coder, compressor, item type or item version that LASzip does not define is refused with a message naming that field, instead of a generic "could not be read" line.
- LAS files whose ESRI-style WKT names a vertical CRS (`VERTCS`) could have their horizontal unit read from the vertical CRS, so a file in US survey feet reported its distances in metres. The horizontal unit now comes from the projected CRS.
- An E57 file that holds images but no 3D scans is refused with a message saying how many images it holds and that images are not displayed, instead of a generic decoding failure. A file with both scans and images opens with a warning that the images are not displayed.
- A remote COPC whose server answers a range request with 416 is reported as a file that changed on the server, or as a read past its end, instead of an unexpected-status transport error.
- A remote COPC read cancelled while its data is arriving, or cut off when the connection drops, now fails with a clear cancelled or connection-closed reason instead of a raw browser error.
- On a streamed scan, the clip box, Fit to scan, the clip's height and the reference plane follow the scan's data extent. They used to follow the octree's root cube, so the box was roughly as tall as it was wide.
- The lasso volume tool draws again on the built app. Its overlay set its size through a script-written `style` attribute, which the page's Content-Security-Policy blocks, so a drag drew nothing. The overlay now takes its layout from the stylesheet, and `npm run lint:no-inline-style-attr` fails on script-written style attributes in `src/`. It also catches unquoted and `${...}`-filled `style=` in markup, and a `//` inside a string no longer hides the rest of the line from it.
- Displayed volumes show 5 significant figures, the rule lengths and areas already follow, instead of two fixed decimals. This applies to the lasso result, the measurement panels and the PDF report: 499,909.60 m³ now reads 499,910 m³. CSV and GeoJSON exports keep the full values. A display-sample preview also says that its figure can change between runs.
- The box measurement's volume, the stockpile's ± figures and the change-detection volumes and their ± band now use the same 5-significant-figure rule as the other displayed volumes. A box volume read with up to 6 decimals (0.31680 m³ now reads 0.3168 m³), the stockpile ± figures were whole numbers (± 0.42 m³ read ± 0 m³), and change volumes had one decimal.
- The readiness card's Ground confidence printed the measured-cell and interpolated-cell mean confidence as "78% measured · 40% interpolated", which read as shares of the surface and disagreed with the Measured coverage card beside it. It now shows the measured-cell mean as 78/100 and names both means in its detail line ("measured cells 78/100 · interpolated cells 40/100"); the Inspector's Metric stability row reads "78/100 on measured cells". The share of measured and interpolated cells is on the Measured coverage card only.
- The scan fitness Classification row said "No ground classification" on a file whose returns carry class 2 whenever it had no vegetation, building or noise returns, because it tested for excluded classes instead of ground. It now reads ground as provided when the analysed codes include class 2 and the classification came from the file, matching the Terrain readiness check.
- A Box with both corners at one height, such as a footprint drawn with Draw clipping box on level ground, read "0 m³". It has no height, so its volume is withheld: the panel reads "no volume: set a height", the CSV evidence cell and the report finding state the reason, and the GeoJSON carries `volume_withheld` instead of `volume_m3`. Width, depth and the clip are unchanged.
- A box drawn with Draw clipping box is recorded as a clip region. It reads "21.0 m × 23.0 m · clip region: full scan height" with no height or volume, the CSV evidence cell and report finding say why, and the GeoJSON carries `volume_withheld`. It becomes a clip at the scan's full height also from the Measurements row and after a session reload. A box drawn with the Box tool keeps its height and volume.
- A page opened from the Tools or Data tab now shows a "← Back to Tools" (or Data) button under its title on a desktop, as Analyse pages already did. The only way back used to be the small crumb in the top bar. The button goes to the same place as the crumb and Escape; the crumb's Back shows while the left panel is collapsed.
- A chain total of box volumes added a clip region's full-scan-height volume. A clip region now adds nothing: a chain that mixes it with drawn boxes totals the drawn boxes and says clip regions were left out, and a chain of clip regions only reads "Volume withheld" with the reason.
- Opening a scan with no colour whose heights differ only by rounding (for example 1500 and 1500.0000000000002) froze the tab and then crashed it while drawing the elevation legend. The legend now shows the two end values for a range that narrow, and snapshots and figures with a legend do the same. The flow-length ticks in the watershed GIF stop the same way on a vanishingly small or unbounded range.
- Streamed COPC and EPT scans with colour could show different colours depending on which part of the scan loaded first. When the first part to load was very dark, later parts of a 16-bit file showed wrong colours (often black or noise), and parts loaded at the same time could disagree. A scan is now read as 16-bit colour as soon as any part has a value above 255, and parts already shown are reloaded to match, so the final colours are the same in any load order. A file whose colours never go above 255 is still read as 8-bit.
- On a large LAS or LAZ opened as a display sample, class shares (the Classes list on the Data page, the Scan Report's Classification line, the report PDF and the terrain Classification check) are taken from the strided records before the display reduction, which kept far fewer ground points than canopy points. Each names its basis, for example "Shares of an even sample of 8,786,971 points." After a class edit the shares describe the loaded points and say so. The per-class counts are unchanged.
- The Dataset Story named the bounding-box area as the point cloud's area. It now reads "bounding box", and after a terrain analysis it leads with the data area the terrain grid covers.
- The terrain Ground detail check compared a ground density measured on a sample with the QL figures. On a sample it now states the figure as from a sample of the points and makes no QL comparison, as the contour map sheet does.
- On a display sample the terrain stats read "Scan scope: full" and the Dataset Story's primary limiter read "None — full quality within its capture limits". The scope now reads "display sample" and the limiter names the sample.
- The pre-load message for a large LAS or LAZ opened as a display sample said the file would be read fully into memory. It now says the file is read as a sample of one record in N and gives the counts.
- The Scan Report's Classification line now updates after Auto-classify, Clear classes, a lasso edit, Restore, Undo and Redo.
- The Flow Pulse and Terrain Access map readouts said "Column 0, row 0, no elevation." before any cell was picked. They stay empty until a cell is picked or reached with the arrow keys.
- The measurement CSV left horizontal_m, vertical_m, rise_m, run_m and grade_pct empty for a Distance, although the Measure panel shows its run, rise and grade. Those columns are now filled, and withheld with the length when the points are closer than the scan's position step.
- A contour map sheet exported from Export › Contours read "Deliverable - Custom" after another purpose was chosen in Contour Studio. It now carries the purpose chosen in the Studio.
- When Auto-classify scan refuses because the scan carries producer classes, the reason now shows under the button as well as in the toast.
- A note whose scan was closed while its editor was open is no longer saved on Save. Before, it was given to the selected scan while keeping the closed scan's name and position, or saved with no scan when one scan was left.
- After an edit that keeps every class count, such as two classes swapped, class shares on a display sample are counted on the loaded points. Before, the Classes list, the Scan Report and the report PDF kept the shares of the file sample taken at load.
- Comparing a coordinate system with no EPSG code read trailing NUL characters with a pattern that slowed with the square of their number, so an EPT `srs.wkt` padded with NULs could hold the page for minutes. The comparison now trims them in one pass, as reading the coordinate system already did.
- The Technical Report has a Terrain analysis section when a terrain analysis has run: the internal hold-out RMSEz, the bare-earth relief, the share of measured ground cells and the points analysed. On a display sample its Min and Max elevation rows say "(display sample)".
- The terrain verdict said "points aren’t classified to ground" on a scan with ground classes where most points were unclassified. It now says that most points are unclassified, with the share.
- The Technical Report's terrain Basis row now states the same analysed basis as the contour map sheet. On a scan with source ground classes it printed the class 2 points the surface rests on as the points analysed; that count now has its own Surface points row.
- The measurement CSV now fills angle_deg for a Distance with the grade angle the Measure panel shows.
- A scan opened while Tools → Clip box was still open from the last scan, or from before a reload, opened on that page with the clip box drawn. A new scan now opens on the Tools home.
- The Terrain page asked for a LAS, LAZ, COPC or EPT file to be loaded while a scan was open and no terrain result existed yet. It now says there is no terrain result yet and points at Run terrain analysis.
- After Auto-classify returned the same codes the scan loaded with, the Classes list kept the shares of the even sample while the Scan Report counted the loaded points. Derived and cleared classes now always take their shares from the loaded points, in both places.
- Switching to another scan and back reset the Classes list of a scan with derived or cleared classes to the source's: it dropped the Derived caption and took its shares from the load sample, while the Scan Report still counted the loaded points, and Process Studio read the derived ground as the producer's. The list now takes the scan's own classification state, and the Auto-classify caption with its support and warning, on every switch and on open.
- A double-click while a measurement was paused with Space finished the measurement. While any tool is paused with Space, a double-click now focuses the camera, as it does with no tool, and the measurement stays open. While paused, a press on a vertex handle moves the camera instead of editing the vertex.
- Dragging a measurement vertex followed any pointer, so a second finger could end the drag. A cancelled touch or a window losing focus left the drag open, and turning the tool off mid-drag kept the half-dragged vertex. Only the pointer that began a drag now moves or ends it, and a cancel, a focus loss, a mouse button released outside the page, holding Space or a tool change puts the vertex back, along with the scans the measurement records it was picked on.
- With a clip box active, terrain analysis read the loaded points inside and outside the box while drawing, picking and point export kept only the clipped points, and nothing said so. The Terrain page now states this for as long as a clip is active.
- When the clip box, the class filter or the elevation or intensity filter hid every loaded point of the visible scans, the view went blank and nothing said why. A card now names what is on and offers Turn off clip or Reset filters, whichever applies, until something is drawn again.
- On a touch screen the area that takes a press on a measurement vertex was 24 px across, about half a fingertip. It is now 44 px where the main pointer is a finger, and stays 24 px for a mouse.
- A measurement vertex released before the next drawn frame stayed at the last frame's position. The release now places the vertex where the pointer was let go.
- Two scans with identical derived classes shared one Auto-classify caption, so switching scans could show the other scan's support and warning. Each scan now keeps its own caption.
- An undo or edit of another scan's classes recounted the Classes list with that scan's codes while a different scan was active. The list now recounts only for the active scan.
- The Terrain page's clip note said terrain results cover the whole scan. They cover the loaded points of the visible scans, which on a large or streaming scan is a sample of the file, and the note now says so.
- After a scan was removed, the contour map sheet's title, notes and file name, the Terrain Intelligence report's scan name and other terrain exports still named the last scan opened. They now name the active scan.
- Dragging a box measurement's corner past the opposite corner moved that corner too: each step resized the box as the last step had left it, so the box shrank to the last step and followed the pointer, and a release could save a box of zero size. Every step now resizes from the box as the drag began, with the opposite corner fixed.
- Reset filters or Turn off clip on the empty-view card dropped keyboard focus to the page when the card closed. Focus now moves to the scan view.

### Validation

- The DTM median range study, rerun under protocol `validation/protocols/dtm-median-gridding-v5.md` with exact reference input (float64 binary) and output (hex floats) and nothing else changed, passed: all 37012 compared cells over the 50 draws agree within 1e-6 m after float32 rounding, with matching occupancy, against R terra and SciPy and between them, including the float32 ties that LAS ingest produces. The DTM claim's measured-cell scope now covers any cell size from 0.1 to 10 m with the grid origin at the data minimum. The v4 result is kept as recorded. No evidence level changed.
- A seeded range study of DTM median gridding (protocol `validation/protocols/dtm-median-gridding-v4.md`, 50 cell sizes from 0.1 to 10 m, small and UTM-scale coordinates through the LAS ingest rule) did not pass its registered rule: 1580 of 37012 cells differ by one float32 step after rounding the reference, although every unrounded difference is under 1e-6 m and occupancy matches. The cause is the reference grids being written to 9 decimals, which moves even-count medians (exact float32 ties) off the tie. The DTM scope stays at the five studied cell sizes.
- DTM median gridding on measured cells compared with R terra and SciPy at 0.25, 0.5, 1, 2 and 5 m cells, with the grid origin at the data minimum as `rasterizeDtm` builds it, under protocols `validation/protocols/dtm-median-gridding-v2.md` and `-v3.md`, each committed before its runs. Every compared cell agreed within 1e-6 m after float32 rounding (39850, 28499, 10980, 2808 and 447 cells) with matching occupancy masks. The ten study manifests are added and those parameter sets join the DTM claim's scope. No evidence level changed.
- The E4 count in the test-evidence record, the claim register notes and THREATS_TO_VALIDITY.md now reads 18, matching the register. `lint:evidence` fails when the record's E4 claims differ from the register's.
- Field-study records list each operator in `operators.members` with an affiliation and an independence flag; the verifier fails a record whose member count differs from `operators.count`, whose members include one who is not independent, or whose group flag contradicts its members.
- The field-study verifier rejects a result whose |bias| exceeds its RMSE, whose RMSE exceeds its largest residual, or whose NMAD exceeds 1.4826 times its largest residual, allowing for the precision the figures were reported with.
- An RMSE below the reference instrument's stated accuracy is now a warning. The verifier fails it only when n·RMSE²/σ² is below the lower 1% quantile of χ² with n degrees of freedom.
- The live DTM's median gridding on measured cells agreed with R terra and SciPy on eight seeded point clouds (18498 and 18655 cells, within the 1e-6 m tolerance registered before the references were generated; occupancy masks match). The DTM claim now names this scope. Interpolated (filled) cells are not covered. The evidence resolver maps the live DTM's measured cells to that parameter set (E4) and leaves filled cells not covered, and the terrain report, the DEM package evidence contract and the export provenance name measured cells.
- `npm run validate:zenodo-small` now fails a comparison when the reference has an attribute that OLV reads for that format but OLV's output lacks it, including the comparisons of OLV's LAS exports. Attributes a path does not read, such as the scan angle and flag fields on the COPC streaming path, are still reported as not compared.
- `npm run lint:position-access` fails with a message naming the missing file when its baseline or frames file is absent, instead of writing new ones. It writes them only with `--update`. `--baseline` and `--frames` point it at other copies of those files.
- With two scans open, a note is owned by the scan it was placed on, not the selected scan. Notes placed while only one scan was open belong to that scan once a second static scan is opened. Reopening a session saved with several scans no longer gives notes that record no scan to the selected one; they stay without an owner.
- Opening a second scan no longer empties the saved-view list while the views are still stored.
- Cancelling a scan open while the replace question is settling stops the open. Before, the open scan and its work were replaced anyway.
- `npm run validate:zenodo-small` fails when one of its OLV exports was not written. Before, the run skipped every check for that export and still reported passed.
- The unreachable-module lint tests edit a temporary copy of `docs/validation/unreachable-modules.json`, through a new `--register <file>` option, instead of rewriting the committed file while other tests read it.
- The `lint:evidence` and defect chronology tests corrupt temporary copies of the release documents and the chronology CSV, through new `--doc-root <dir>` and `--views <dir>` options, instead of rewriting the committed files while other checks read them.

### Security

- A coordinate system text ending in a long run of NUL characters followed by another character, as an EPT `ept.json` can carry in `srs.wkt`, no longer stalls the tab. Trailing NULs are now trimmed in linear time; the result is unchanged.

## [0.7.0] - 2026-10-24

### Added

- Precision at this view in the Performance panel. Check precision states the per-draw bound for the open scan at the current camera against a 1 mm, 1 cm or 10 cm limit, under round-to-nearest arithmetic with the worst case under the WGSL and GLSL ES specs' faithful rounding beside it. A vertical unit the source declares but that cannot be read leaves the bound ungraded, with no millimetre verdict, here and in the scan report. Copy certificate copies a JSON record of both bounds with the checker's evidence states, the limit, the unit they were graded under, the stored extent and storage error, the camera position and model-view, the scan's SHA-256, the shader and the frame, with a digest of every input that can change the result and the method's citation. The record is taken when the button is pressed, so a scan or camera that changes while the file is hashed does not reach it. It bounds the rendering error against the stored coordinates, before projection, for every point inside that extent, not survey accuracy. The panel also names the coarsest certified level of detail for the current view: one point per occupied cell of 1 mm × 2^k, the coarsest whose distance to the stored points plus the faithful-rounding draw bound fits the limit, which is the controller of the same method for a single node (`olv.render.draw-precision-lod@1`). It is selected again with every reading; Check precision counts its points, and the certificate records the level with its points and bytes. The level is not drawn.
- An interactive 3D view cube in the top-right of the stage. It turns with the camera's pitch, yaw and roll in the scan's up-axis frame. Its six faces, twelve edges and eight corners each turn the camera to that direction around the current pivot at the current distance, so a click never resets the zoom; a face also updates Plan View exactly as the toolbar's view buttons do, and an edge or corner turns Plan View off. A Home control below it fits the scan (Frame all). Side faces read N/E/S/W only for a Z-up scan with a known CRS; a local or unknown-CRS scan reads Front/Back/Left/Right. The cube stays left of the expanded right rail and below the header and a floating colour key, and moves when the rail opens, closes or resizes. It loads lazily with its own stylesheet.
- Keyboard access to all 26 view cube views at any orientation. Tab enters the cube as one stop, the arrow keys move through the faces, edges and corners in a fixed order, Home and End jump, and Enter or Space turns the camera. A view hidden for pointers is outlined at its place with its name beside the cube while it has focus, and the new view is announced.
- A one-time hint after the first scan opens on a desktop: "Drag to orbit · Scroll to zoom · Double-click to focus". It is shown once and can be dismissed.
- Change detection thresholds the difference at a propagated minimum level of detection, 1.96·√(σz_before² + σz_after² + σreg²) (Wheaton et al. 2010). Each σz is that epoch's random-split hold-out RMSEz (point-vs-surface residual, ground re-classified from the training points only with the same train-only reclassifier Analyse uses, including the epoch's bias; not checkpoint accuracy nor a DEM-cell uncertainty), and the 95 % level holds only for normal, independent, unbiased errors. σreg is accepted only from an independent vertical assessment on stable reference areas, which the app does not have yet, so σreg is unavailable; alignment fit residuals are reported but are not used as σreg. Every term is in metres, as is the difference it thresholds; a term whose source unit has no known metre factor is treated as missing. With some terms known and some missing the threshold is max(1.96·√(Σ known σ²), 0.1 m), labelled incomplete (a lower bound, naming the missing terms), and the significance counts and detectable volumes say they were computed with it; the volume band's per-cell σ is then LoD/1.96. Only when no term is known is the fixed 0.1 m used, labelled "assumed, not measured". A level of detection passed by the caller is labelled user-set, and one below what the known terms imply is kept and warned. The change result states the value, its components and its basis, and gain and loss volumes use it. `olv.change.dtm-difference` and `olv.change.dtm-difference.raw-net` move to v3. The change result and Known limitations also state that a vertical offset between epochs is not estimated or removed, so a datum or bias shift reads as change.
- A Box measurement row in the Measurements panel has a "Clip" action ("Use as clipping region"). It copies the box's bounds into the Clip tool as an enabled keep-inside clip, opens Tools → Clip and says so in a toast. A box drawn on another scan, an unowned box while several scans are open, a box with non-finite corners and a box with zero extent on any axis are refused with a message. The clip is a copy: editing the box or the clip afterwards does not change the other, and the session format is unchanged.
- Focus mode gives the open scan the whole window. A "Focus" button in the header and a "Focus Mode" palette action collapse both rails and hide the wordmark, location crumbs, other header controls, rail grabbers and renderer chip; the navigation bar, compass, dock, measure guidance, state strip and toasts stay. "Exit focus" or Escape restores each rail exactly as it was, and Escape goes to an open dialog, the palette or an active tool first. Focus mode changes no camera, data, clipping or measurement state, saves nothing, and ends on navigation, when the scan closes or on a phone layout, where it is not offered because the sheet already gives the scan the screen. At 1440×900 it adds about 37% unobstructed canvas.
- A draw precision bound in the scan report ("Draw precision bound", with its scope under advanced rows). For the active static cloud and the current camera it gives an upper bound on the binary32 error of the eye-space point position, `modelView * vec4(p, 1.0)`, and compares it with 1 mm converted through the CRS linear unit; without an established unit it is shown in source units and not graded. It covers the position before projection only, not projection, the divide by w or survey accuracy, and it never gates a draw. It uses the MIT spe-check checker by A. Urias, from "Per-Draw Precision Bounds for Large-Coordinate Rendering in WebGL2 and WebGPU", vendored unchanged under `src/vendor/spe-check/` (upstream `spe_check.js` SHA-256 `53229a0e2682fb103097eaef028079a40b6fa1a5f0c78fbf1da2b0b3c4598b6b`), and is registered as `olv.render.draw-precision-bound@1`. Both the WebGPU and the WebGL 2 point paths were checked against the bounded expression (`docs/architecture/draw-precision-contract.md`); a path that has not been checked reports Not tested.
- A storage-grid diagnostics library, `src/diagnostics/latticeForensics.ts`. Given candidate grids and their Jacobians, it predicts the spectral peaks an earlier storage grid leaves in LAS and LAZ integers, scores them against random wavevectors, reports which candidates the points support, and tests whether the points sit on a supported grid's nodes. No panel calls it yet; Known limitations states its limits.
- "Export all N points" for a layer the loader reduced to a display sample, where N is the layer's declared count. It sits beside the Layer Health sample row, the status strip's Sampled basis and the Dataset Intelligence coverage note, and opens Export with "Convert at full resolution" ticked. When the estimated memory is over the device's ceiling, Export opens with the figures instead. Export summaries and the PDF report state the point basis: "full file (N points)" or "display sample (n of N points)".
- "Reload at higher density" for the same layers. The target is the smallest of the 8 M point GPU upload ceiling, what fits in this device's memory ceiling and the declared count, and a confirm dialog states it before the layer is reopened. The reload is refused on a phone or tablet, on a low-tier device, while class edits differ from the file, when the estimate is over the ceiling and when it would add no points, and the link says why. Measurements stay in place.
- Converted XYZ, ASC and LAS files record where they came from. They name the software and version, the source file and its SHA-256, and the CRS and where it came from. They also state the point basis and whether classes were edited in the app. A measurement CSV downloads with a `<name>-measurements.provenance.txt` sidecar carrying the same lines; the CSV itself is unchanged.
- Terrain Access names the one or two cost terms that add most to the route ("Cost driven mostly by: weak terrain support") and shows the p95 longitudinal grade, the total cost and the measured and interpolated share of route cells and the share below the profile's minimum confidence. A refusal for no eligible cell names the top reason with its count. The minimum-confidence input says what the 0 to 100 score measures, hints are linked to their inputs, Export stays disabled until a run has found a route, and the route and raster are written at the grid's position in the scan's coordinates.
- Terrain Access can apply its above-ground obstruction limit. The terrain run keeps its DSM on the DTM grid, and the Lab receives it as an above-ground surface bound to that run's DTM by the DTM product digest, so the "Constrain above-ground obstruction" control is enabled after a terrain run. A surface built with a different terrain surface is refused with `SURFACE_STALE`. A new evidence-gap policy in the profile decides cells whose slope and aspect used a synthesised Horn neighbour (the grid's outer ring or beside a void) and, under an evaluated obstruction limit, cells with no above-ground return: conservative blocks them, exploratory (the default) allows them and reports their share. The diagnostics, run record, diagnostics CSV and run card carry the route share of synthesised-neighbour cells and the policy applied. `olv.simulation.terrain-access.cost-map` is registered at v3.
- Flow Pulse labels an unusable terrain run: a banner above the result card reads "Terrain run not usable: read this as illustration only" for a Blocked or Preview verdict and gives the interpolated share, the checklist's ground row shows "!", and the export README states both. Exported outlet elevations match the on-screen readout, the rasters and path GeoJSON are placed at the grid's position in the scan's coordinates, and the ZIP carries a `.prj` when the CRS resolves.
- The Terrain Access map paints eligible cells with a cividis ramp on extra cost, hatches blocked cells, dots cells without enough evidence and draws the route with a cased line, and the Flow Pulse grid paints log upstream counts with viridis over a hillshade, draws outlets, sinks and flats, and moves small dots along the flow directions with a pause control. Both grids are drawn north-up, which they were not before, and the legends show the ramp and its unit. Reduced motion draws the route and path at once.
- A reference plane in the View panel (Reference plane section, `B`, or Toggle reference plane in the command palette), off by default. It draws a horizontal grid, one of two vertical grids, or a plane through three picked points, at an elevation the user sets by typing, by a picked point, or by the scan minimum, which the panel labels as the lowest point in the scan and not ground. The horizontal origin defaults to the scan centre rounded to the grid, and the readout says so. Automatic spacing follows a 1, 2, 5 progression about 50 to 100 px apart with hysteresis, or a fixed spacing can be typed. The grid covers the scan plus one scan size, and lines fade from full strength at 14 px apart on screen to nothing at 6 px, and at the grid's edge. A fixed spacing is raised to at least one millionth of the scan size, values beyond 1e9 are refused, and the plane is not drawn when the open layers share no datum. Lengths read metres or feet only when the coordinate system resolves the unit, and "units" otherwise, including for geographic degrees. Three picks in a line, or within one thousandth of their spread of a line, are refused. The plane is drawn anchor-relative from Float64 positions, is visual only (no analysis, measurement or digest reads it, which `tests/workplaneAnalysisInvariance.test.ts` checks), appears in a Save view snapshot only while drawn with an `olv:reference-plane` provenance chunk, never appears in a Visual Export Studio image, and is saved in the session file.
- An active-tool pill near the bottom of the viewport names the pointer tool that owns clicks ("Measuring distance", "Drawing box", "Adding annotation", "Inspecting points") and shows nothing while the scene is only orbited. Cancel runs the same exit as Esc, and Finish appears only when the tool has a polyline or area draft open. Clipping left on shows as a separate "Clip on" chip, not as an active tool. The Tools launcher now updates its rows in place, so a refresh keeps focus and hover on an unchanged row.

- Optional signature for integrity reports. "Sign this report" in the Export panel (off by default) adds an ECDSA P-256 / SHA-256 signature made with a key created in this browser, stored non-extractable in IndexedDB. The signature covers the same canonical report body as the digest, plus the algorithm, key id, the signer's claimed time, the app version and an optional signer label. "Show my public key" and "Copy public key" export the public half. The report verifier reports a valid signature from an unknown key as "Signed, signer unverified", can compare the signer against a public key you supply, and fails a report whose signature is invalid, malformed or unsupported. A signed report fails verification if its figures or signed metadata change. Every signed report carries the key's id, so reports signed with one key can be linked; a Delete signing key control removes the key. Unsigned reports verify exactly as before.
- Closing a scan that holds measurements, annotations, saved views, class edits that differ from the file or computed results now asks first. The dialog names what would be lost, keeps Cancel focused, offers Save session first where the session file can hold the work (measurements, annotations, views), and closes on Close without saving, or after the session is saved with Save session first. Escape and a click outside cancel and leave the scan as it is. A scan with none of that closes at once, as before.
- The Data tab shows the class list open for a classified scan: each class with its code, name, share of points and legend colour, a collapse control that remembers its state, and an Open Classes button to the full page. A scan with no classification keeps the compact "None detected" row. The rows only display; they never change a class.
- Flow Pulse has a rainfall control. Rainfall (peak-flow estimate) sets an intensity from 1 to 200 mm/h and a runoff coefficient C, with ground-cover presets at the midpoints of FHWA HEC-22 (2009) Table 3-1 and Schwab et al. (1993). The Lab estimates steady-state peak flow by the rational method, Q = C · i · A over the D8 contributing area, at the selected outlet and at the end of a traced path, in L/s, and draws as channels the cells whose estimate reaches 1 L/s, so more rain draws more of the network. The assumptions are stated with the figure: uniform rain lasting at least the time of concentration, C lumps every loss, no storage, timing or hydraulics. The estimate is flagged above 0.8 km² and withheld without metres. Particle speed remains a display encoding, not water velocity. `olv.simulation.terrain-flow.rational-peak@1`; claim TERRAIN-FLOW-RATIONAL-PEAK at E2.
- Export GIF on a selected Flow Pulse catchment writes an animated GIF that reveals the watershed by D8 flow length to the outlet, a distance and not a travel time, over a hillshade of the DTM, with the outlet ringed, channel lines at the current rainfall, a legend in metres, a scale bar, grid north and a footer giving the method, cell size, area, peak flow, CRS, version and date. The encoder is part of OLV and loads only when used.
- Flow Pulse marks catchments that reach the survey edge, where ground outside the survey may also drain in: their area and peak flow read "at least" in the selection, Largest drainage, the result card, the GIF and the ZIP (`olv.simulation.terrain-flow.edge-contamination@1`, after Lindsay 2016).
- In Flow Pulse catchment mode a pointer click snaps the outlet to the strongest channel within 2 cells and says where it moved from; Snap outlet to channel turns this off, and keyboard selection stays exact.
- The Flow Pulse ZIP records the selected catchment's outlet (column, row and cell-centre position in the scan's frame), its cell count, area and edge flag, and the rainfall settings and peak flow when set.
- The clip box is drawn in the scene as twelve edges, depth-tested with a faint pass through the points, while the clip is on or the Clip page is open, and follows every bound change. It is left out of snapshots, figures and image exports.
- On a display sample the Clip readout says it counts the points shown and estimates what a full-resolution export keeps. A clipped full-resolution export is sized from the clip's share of the source instead of the whole file, a clip that keeps no points says so and disables Export, and the readout explains a box that covers the whole scan, including with Keep outside.

### Changed

- Fewer repeated controls. The sample's Reload and Export all links show in the status bar and Layer Health, no longer a third time in Dataset Intelligence. In the Export tab the quick format section is named "Points on screen (PLY, OBJ, XYZ, CSV)", apart from the converter's formats, and the report section is named "PDF report" rather than repeating its button's label.
- A LAS or LAZ whose index does not fit in browser storage opens as an ordinary scan from an even sample of every record in the file, read in pieces across the device's cores, rather than as a one-tile stream of a few hundred chunks. Classification editing works on it, the scan report, provenance and PDFs give the file's own point count, format, density and checksum with the sample named as the point basis, and Reload at higher density reads the file again the same way. The header and its records are read in bounded pieces too: a header that places its points gigabytes into the file never sizes a read, and header records running past 4 MiB are refused by name.
- Flow Pulse opens with Priority-Flood conditioning, so the first view is the connected drainage; Raw terrain is one choice away and the run record names which was used.
- Terrain Access offers Walker, ATV and 4x4 vehicle example profiles above its fields. A click fills every required field with editable values to confirm, not a rating or a safety limit. The run record and export README name the example and say whether a value was edited.
- Flow Pulse and Terrain Access run in one click from the Analyse home: with no terrain run yet, the lab runs terrain first on its own page, then opens. Each result page leads with its map, three key figures and its actions; the verdict and every caveat sit in one status line that opens to the full text, and method, limitations and reading notes sit under Details. Flow Pulse shows its drainage in 3D when the result opens. A lab row capped by its terrain run shows the verdict and no longer offers Prepare terrain. Results and exports are unchanged.
- Flow Pulse draws flow accumulation as a drainage network. In the 3D view and on the Lab grid only cells whose log-scaled upstream count is at least 0.4 are drawn, as lines that are wider and brighter (deep blue to near white) where more cells drain through, over a dark casing; the scan stays visible between lines. The Lab grid's base is a grey hillshade lit from the north-west, and its moving particles follow the lines with fading trails. Upstream counts are counts of cells, not water. Results, digests and exports are unchanged.
- In the 3D view, Flow Pulse drainage lines follow each channel as one smoothed ribbon draped on the terrain, with tributaries joining their trunks at their own width and widths tapering along the line, in place of straight cell-to-cell segments. Results, digests and exports are unchanged.
- The curated dataset list holds six entries instead of twelve. Dropped: the 2010 San Francisco Coast and Golden Gate surveys, whose extents are mostly open water; Los Angeles 2016, superseded by Los Angeles block 2; and the second and third Denver DRCOG and the second Grand Canyon entries, which duplicated a denser one. All six were re-checked on 2026-10-19 (range request, CORS from the app origin, first data tile) and carry that date. The credits page states that sample data comes with no warranty and can be withdrawn by its provider.
- The v0.7 implementation ledger and its generated status table are no longer in the source archive; they stay in the repository. lint:known-limitations and lint:v070-status skip with a printed notice when run from an archive, and still fail in a git checkout when the ledger is missing.
- The georeferenced orthographic PNG (PNG + .pgw + .prj) now has transparent no-data: pixels with no points have alpha 0 and pixels with points have alpha 255, with no partly transparent pixels. The PNG carries an `olv:nodata` text chunk that says so. The world file, the raster size and the colours of fully covered pixels are unchanged; a pixel at least half covered is written opaque with its point colour. Screen rendering and every other snapshot or export stay opaque.
- The Data › Classes and Analyse › Terrain pages use the View panel's chips, section labels, rows and notes. The header Back shows only its arrow where the next crumb already names the page, and the left panel's card edge sits on its scroller, so content no longer runs under the Results bar or the page title.
- The "Two scans loaded" before/after prompt is offered only when the two scans can be compared in one horizontal frame and neither is a truncated load. Otherwise no prompt is shown; Compare in the Inspector is unchanged.
- Interface themes are now Blue, Field and an upgraded High contrast; the Light theme is retired and saved Light choices move to Field. High contrast now uses a pure black page, opaque panels, 2 px solid edges and a 3 px focus ring.
- A file that cannot be read as a point cloud now also says "To view a scan, open an E57 or LAS version of the file." The reason and Copy report stay as before.
- A file that cannot be read as a point cloud now also names the formats that open, unless its explanation already does. Other load errors keep their own wording. Copy report stays as before.
- While a file opens, the status keeps its name, detected format and loading scope on one line ("Sampled load", "Thinned for display", "Standard load" or "Streaming", read off the load plan) and any preflight warning under the progress line. Reading a file reports bytes read against its size. Repeated updates are paced, and screen readers hear each stage and every quarter of the read rather than every update. Display only: decoding, sampling, memory limits and exports are unchanged.
- The navigation modes are one compact segmented control, Orbit | Walk | Fly | Pan, with Frame all beside it, in place of the triangle of round pads. Shortcuts, pointer lock, the Pan availability rule, the speed slider, the camera presets, orthographic, Plan View and the Navigation panel (H) behave as before.
- The six axis views (Top, Bottom, Front, Back, Left, Right) moved from the Navigation panel to a "More" menu beside the mode selector, so they stay one click away with the panel closed or the view cube off. They are still in the command palette. The menu opens only when clicked and is not remembered.
- The view cube is on by default once a scan is open, except on phone-width screens, where it stays off until turned on; a stored off choice is kept. "Toggle compass" in the command palette and `?viewcube=1` / `?viewcube=0` still switch it.
- While Measure, Inspect or Annotate is active, the stage shows the Help guide's tip: "Hold Space while a tool is active to rotate or pan, then release to resume."
- "Draw clipping box" on the Clip page arms the Box measurement tool through the same command as the dock and stays on the Clip page, which shows the corner hint. The box it draws, and a Box finished looking straight down, clip at the scan's full height; other boxes keep their drawn height. When that box is finished, the result card offers "Isolate this box", which runs the same conversion as the Box row's "Use as clipping region", so the refusals and their messages are identical and the measurement is left as drawn. After Isolate from Draw clipping box the Box tool turns off. The clip is a copy of the box.
- A compact result card for the latest finished measurement sits at the top of the viewport, under the measurement toolbar. It shows the Measurements list's own formatted value and trust or unit caveat, offers Copy result, Open details (opens the Measure page and focuses the row) and, for a Box, the clip action, and is replaced by the next result. A value the list shows as withheld reads "No value to report" and cannot be copied; a missing value is never shown as zero. The card is dismissed by the next tool activation, its close control and by closing the scan.
- The Clip page leads with Draw clipping box, the enable box, Keep inside or Keep outside, Fit to scan and Turn off. The six numeric extents sit in an "Advanced" disclosure, closed by default, in local scene coordinates with the frame and unit named above them and three decimals rounded outward. A typed value applies on Enter or when the field is left, and a blank or invalid value left behind returns to the last valid bound. The arrow keys, and the wheel over a focused field, step a bound by 0.1 (1 with Shift) and apply at once. Turn off keeps the bounds, and the page opens unfolded. Returning to Tools lands on the Clip page when it was left open, and on a phone the page opens at half height.
- Fit to scan encloses every visible scan in the project frame, so a scan placed away from the origin is no longer hidden by its own fit (two scans 2 km apart kept 0 of 16 points). The numeric bounds are read as pairs: a minimum above its maximum, or a blank field, is not applied, the clip keeps its last valid bounds and the panel says so, and a bound such as 0.0004 is shown as 0.0004 instead of 0.
- While a clip is on, a small "Clipping on · Showing inside box" (or outside) chip with a Turn off button shows at the top of the viewport, below the recommended-view chip, so a missing part of the cloud has a visible reason. It reads the Clip panel's state, leaves the kept-point figure to the status strip, and goes away when the clip is turned off or the scan is closed.
- The class palette has higher contrast against the dark canvas and wider separation between classes. Every class colour reaches 3:1 contrast against the scene background, and Ground and Ignored Ground, which were nearly the same colour, are now an ochre and a pale sand. The colourblind palette is updated to match within its Okabe-Ito scheme.
- The intensity colour ramp defaults to the 2nd to 98th percentile of the loaded sample instead of the raw minimum and maximum, so a few saturated returns no longer wash out the ramp. The colorbar names the window and the sample it was taken from.
- The release workflow's `release-ready` job also needs a new `ci-at-tag` job, which reads the CI workflow's push-event runs for the tagged commit through the GitHub API and passes only when a completed run there has `ci-green` and every job it needs at `success`. A failed API call is retried twice before the job fails. A run missing after 15 minutes, pending after 120 minutes, or with a cancelled, skipped or failed required job keeps the release not ready. Publishing the draft release stays manual.
- `npm run benchmark:archive-portability` in a source tree with no Git repository and no `--archive` (or `OLV_ARCHIVE_DIR`) reports the check as skipped and says how to run it, instead of exiting with an error. The publication battery records the suite as skipped with the same reason, not as passed.
- Development dependencies vue and @vue/server-renderer 3.5.44, source-map-js 1.2.2 and fast-uri 3.1.8, updated inside their existing ranges. `npm audit` over the full tree reported 0 vulnerabilities at release; the production set was already 0.
- The View Inspector opens in Basic detail, with a Basic | Advanced switch at the top. Basic keeps colour mode, quick appearance presets, point size, the essential rendering toggles, saved views, layers, the dataset summary, layer health and the coordinate system. Advanced adds the full Visuals Studio, detailed rendering and navigation settings, white balance, the reference plane, the elevation and intensity filters, provenance, the scan report, Detail and session stats. Sections stay mounted and keep their open state. While Basic hides an active filter, declared limitations or scan report warnings, a notice names it and shows the section in one click, and links that open a hidden section reveal it. The choice is stored with the other Inspector section states.
- Visible interface text spells colour the British way throughout: the View panel section is "Colour by", and the streaming panel colour chip and its tooltips read "Colour". Code names, file formats and LAS field names are unchanged.
- Caution reads in one colour in the left panels. A new --caution token, set per theme to the PREVIEW state colour, now draws the class panel captions, the Review verdict, the Terrain PREVIEW verdicts and statuses, the caution workflow glyph and the Analyse home needs badge, which used three different ambers.
- The Export, converter, Clip and layer Compare buttons (.olv-bc-pill) are drawn as the View panel chip (.olv-chip): the same size, corners, hover, selected and disabled states, focus ring and press. The class name is kept.
- The contour map sheet, the SVG and the Analyse caption show interpolated contours and measured but sparse ground apart, each with its own line style and share, e.g. "4% interpolated · 45% sparse ground (by contour length)"; one "interpolated or uncertain" figure used to count both. GeoJSON features carry `basis`, the metadata adds `interpolatedLengthFraction`, `sparseLengthFraction` and `gapLengthFraction` (`interpolatedFraction` keeps its non-solid value), SVG paths carry `data-basis`, and DXF adds a CONTOUR_SPARSE layer. Dashed runs now break where interpolated support starts or stops; contour geometry and the DTM are unchanged.
- Each page shows one Back per layout: an Analyse page's own Back sits beside its title on a desktop, and the phone sheet's location line shows Back and the current page. Each Analyse card has one action; Terrain's is a filled Run terrain analysis. After a run the Terrain page leads with its verdict and Make contours, which opens Contour Studio, and the rest sits in collapsed rows; the per-product list, whose two shared grades Export readiness and the Process Studio rows under Why? already give, is left to the report. Contour Studio's choices and export buttons use the Analyse rail's type scale and button size, with the PDF map sheet first.
- Terrain Access measures a move's step height as a height discontinuity: how far the move's rise falls outside the rises of the terrain just behind and just past it along the same heading. A smooth slope has no step, so the grade limit is the only slope limit. Before, the step was the height difference between neighbouring cells, so on 2.6 m cells a 0.3 m step limit acted as a 6.7° grade cap that overrode the profile's grade limit. A diagonal move also checks its two corner cells, so a one-cell berm or ditch cannot be crossed between them, and the route cost counts grade once. `olv.simulation.terrain-access.local-step@2`, `olv.simulation.terrain-access.cost-map@4`.
- The Terrain Access run card lists the limits it applied. A refusal for no route names what closes the way and its share, a blocked start or goal says whether the cell is off the grid, has no elevation or fails a limit, the grid is checked before any cell is read, and a run reuses the preview's preparation when its inputs match.
- Flow Pulse routes on a Float64 conditioned surface and orders the Priority-Flood by the spill level, so a long filled flat can no longer drain over a higher exit; before, Float32 steps added up along the flat. Results on the StREAM Lab scan are unchanged; the field digest of a conditioned run changes. `olv.simulation.terrain-flow.priority-flood@6`, `.gap-outlet@4`.

### Fixed

- Closing a scan while Flow Pulse or Terrain Access is building its ground surface no longer opens the lab in a dialog over the empty app afterwards.
- A Flow Pulse or Terrain Access card blocked by something a terrain run cannot fix no longer starts one when its heading is clicked; the heading is a title, as on a card that can run.
- A LAZ opened as a sample is refused with a reason, rather than read whole, when its compressed chunks cannot be decoded separately: the sample's memory plan left the file's bytes out.
- Priority-Flood raises each filled cell one Float32 step above the cell it was reached from, as Barnes, Lehman and Mulla specify, instead of a fixed 1 mm. The larger rise reordered the flood, so a few spill levels came out up to centimetres high and some small depressions drained over the wrong rim; depression counts and fill depths now match an exact fill (`olv.simulation.terrain-flow.priority-flood@5`, `olv.simulation.terrain-flow.priority-flood.gap-outlet@3`).
- The scan report's in-memory resolution no longer converts Z with the horizontal unit when the source declares a vertical unit that cannot be read. The figure covers the horizontal axes and says so, and the precision permit still checks them.
- A Flow Pulse run on a sampled scan records its input as sampled, with the sample caveat, rather than as full coverage. The figure under the grid reads Surface (cells with a height) instead of Routed, and the outlet note says an outlet is where flow leaves the survey; a stream entering it shows as an edge channel.
- Contour labels on the map sheet sit centred on their line at any angle and are kept apart by the space they take once rotated, so a steep label no longer drifts off its contour or covers a neighbour.
- The terrain report no longer says every grid cell without ground returns will be interpolated: cells outside the survey stay empty, and the coverage rows give the split.
- The Profile Workbench plots heights in the source's vertical coordinate, as the Measurements chart and the profile sheet do; the point card's coordinates read in the same frame, and a chainage label that would run into the axis title is left out.
- The Flow Pulse export README names the flow direction codes correctly: 1 is north-east, 2 north, 3 north-west, 5 south-west, 6 south and 7 south-east. North and south were swapped. The direction raster itself is unchanged.
- The source file's checksum, which every report and terrain export records, is computed in the background once a scan opens and about a sixth faster, so the first contour map or report of a large file no longer waits for it. While it is still running, the export says so: the Report PDF button reads "Building report…" and the contour map dialog "Checking the source file…".
- On a phone, a page inside the sheet shows one Back: the sheet's location line carries it, so the page's own Back is hidden when both lead to the same place.
- The draw precision bound no longer reads "Not tested" when the camera's inverse matrix carries a bottom row within rounding of (0, 0, 0, 1); that row sets only w, which the bounded position does not use.
- Flow routing reads no-data that reaches the edge of the grid as ground outside the survey, so a strip drains out of its sides instead of ponding against them (`olv.simulation.terrain-flow.d8@2`; Priority-Flood seeds the same edge).
- A display sample of a scan that fills only part of its bounding box, such as a survey strip, lands near its point budget instead of a fraction of it.
- A reload no longer offers to compare the file with itself, and a layer a reload just made is not offered the same reload again. Export all points is not offered for a file too large to read whole.
- On a phone, the first touch outside the Project card dismisses it, so a message from the next action is not held behind it.
- The contour map title drops its "Contours" suffix rather than being cut off when the scan name is long.
- A terrain surface holds an elevation only inside the data's coverage: measured cells, gaps narrower than 16 cells, and holes the data surrounds. The void fill reached up to 24 cells past the edge of the data, so on a narrow survey strip contours, gap lines, Flow Pulse routes and Terrain Access costs appeared on empty ground beside it. Those cells now read as no data, and the no-data, void and unsupported shares in the terrain verdict, the contour review and the deliverable README are of the surveyed area, so the empty corners of a strip's grid do not count against it. The DTM method is `olv.dtm.idw-fill@2`.
- An E57 file can no longer make the reader allocate columns far beyond its size. Integer fields declared with a zero bit width add nothing to the minimum record size yet each decoded to 8 bytes per record, so a 64 MB file with 100 such fields asked for about 51 GB. A point prototype is now limited to 64 fields, a record whose fields hold no stored bits is refused, and the decoded columns are limited to 4 GB before any is allocated. The E57 XML depth limit is reported as a malformed file, like the other XML limits, and attribute text is read in linear time.
- Terrain analysis runs on a Web Mercator scan, such as a streamed USGS EPT dataset, instead of refusing it. Slopes, areas and densities use the WGS 84 ground scale at the scan's latitude (about 0.77 at Denver), checked against the geodesic distance of a 100 m grid step at 0°, 20°, 39.8°, 60° and 75°, and a 20° ground slope reads 20.0° through the real terrain core. The Analyse panel states the latitude, the factor and the largest error one factor leaves across the scan, and refuses a scan whose length or horizontal cell-area approximation passes 1% (a whole regional dataset), or whose position cannot be read, saying to zoom in or reproject. The coordinates and the DEM georeference stay in Web Mercator. The Measure tool, the scan report and change detection still withhold horizontal ground figures on Web Mercator. Refusals for the frame or scale read "Terrain analysis did not run." instead of "Analysis failed:".
- A refusal shown on the start screen is readable. The open toast had no stacking order, so the start screen's title and logo painted over it; it now sits on the raised layer the design tokens reserve for it.
- The storage refusal for a large LAS or LAZ states the file, its point count, the browser storage needed and available, and the remedy (convert to COPC, or free disk space) in two short paragraphs. The full calculation is in Copy report.
- A chunked LAZ in point formats 0 to 3, the LAS 1.0 to 1.3 formats most airborne surveys ship in, streams out of core and opens as a sample like formats 6 to 8. It was refused when too large to load whole. A sample of a chunked LAZ now takes an equal share from points spread across the whole file; it stopped at the target before the last part of the file.
- A large LAS or LAZ whose index cannot be built, because browser storage is too small, absent or cannot be read, opens as an evenly spread sample of the file, as many points as the device's render budget holds (1.2 to 3 million on a desktop), instead of being refused. The notice states the figures and that the view is a sample. The sample carries the file's own CRS, name and provenance, read from the file even without browser storage; the Inspector counts it as the points shown against the file's total and the scan report says it is a sample. Nothing of a scan it replaces stays on screen. A file too small to sample is still refused.
- Terrain analysis of a Web Mercator layer placed in a project takes its latitude from the project position. It added the layer's placement offset twice, so a layer 50 km from the project anchor near 60° N was scaled 0.68% wrong.
- The Web Mercator note states separate approximation bounds for horizontal lengths and horizontal cell areas, measured against the true ground figure, and no longer says one figure covers lengths, slopes and areas. A cell-area error is about twice a length error, so the single figure understated it: a footprint from 59.7° to 60.3° was accepted at 0.99% while its cell-area factor was off by up to 1.83%. A run is refused when either bound passes 1%, which narrows the accepted footprint, and the note says the bound is the projection approximation only.
- A measured figure is withheld with the reason when the positions its scan holds cannot give it within the 10 mm budget. The decision bounds the error from the step on each axis the figure uses, not from the rounded value, so a 5 mm separation 200 km from the origin, which read 0.0 cm or, at another rounding phase, 1.56 cm in the panel and 0.016 m in the CSV, is withheld either way. The step is read on the layer the measurement was taken on, less its placement. The panel headline and breakdown, scene labels, the profile chart, the CSV, GeoJSON, KML, the reports, profile report details and chain totals, box areas and volumes included, all apply it. A figure along a finely held axis, and a genuine zero on an adequately held scan, still read as before.
- The CRS suggestion for local coordinates no longer says a projected CRS gives survey-grade values.
- Development dependencies: vite 8.3.5, vitest and @vitest/coverage-v8 5.0.5, vite 6.4.5 under vitepress, and zod 4.6.7 under the mutation-testing tools. The full dependency audit reports no vulnerabilities.
- Release evidence and the release manifest take their channel from the version: 0.7.0 is recorded as stable and a version such as 0.7.0-alpha.1 as a prerelease. Both used to label every authoritative release a prerelease. A manifest is refused when the evidence's channel or tag does not match the version, and development records keep the development channel.
- A geographic (degree) scan beyond ±89° latitude is refused by terrain analysis with a reason naming a polar projected CRS. The east–west degree length used to be computed for 89° at any higher latitude: at 89.9° that is 1,949 m per degree instead of 195 m, and a 45° east–west plane read 5.7°. The longitude degree is now the ellipsoid's at the latitude asked, everywhere it is used, and the refusal is made before the terrain worker runs, so a large scan reports the latitude reason rather than a main-thread size limit.
- The build identity and the checks that read Git history use this project's repository only. A source archive extracted inside an unrelated Git checkout took that checkout's commit as its build identity, and three history checks read the other repository and failed. Every script that runs Git, the Vite build identity and the packaging and gate scripts now stop Git's repository search at the project root, through scripts/lib/confineGit.mjs.
- The stockpile model band is no longer described as calibrated. The reproducibility pack's M3 metric reported calibration while its own measurement was 60.5% coverage (95% interval 55.6–65.2%) against a nominal 68%; it now records the interval, states calibration only when the interval contains the nominal value, and generates its prose from that. The band's rows read "Surface spread term" and "Base-plane term", and the claim register, method summary and code comments state that its spread term applies a mean's standard-error form to a cell median.
- The stockpile volume claim no longer says a density gradient cannot bias the figure. Area weighting removes unequal weighting between cells; within a cell, where the points fall still moves the median on a surface that varies inside it. The claim register, method summaries and code comments say so, and tests characterise the bias: −6.25% on a ramp with points shifted toward each cell's low side.
- In Safari, a file a loader refuses shows the loader's reason, such as the Draco refusal, instead of the generic decoding-failure message. The parse worker could hold two copies of the error class, and the copy it checked did not match the one the loader threw.
- Contours drawn over a georeferenced PLY or OBJ are no longer rotated and mirrored; the overlay follows the terrain gather's up axis.
- The Scan Report, PDF scan metadata, feature candidates and acquisition-coverage fit read each layer's up axis, so a PLY under a CRS reports footprint X by Y and height as the Z span. A glTF under a CRS withholds those figures.
- The coordinate-system notice that a session sets stays visible with its Keep action, and names the CRS actually applied.
- A measurement label far off screen no longer hangs the label layout.
- Work whose owner layer is not open withholds heights instead of using the active layer's axis.
- An unreadable vertical unit is no longer replaced by the horizontal unit in the full-cloud grade, Classify and scan-type routing.
- A CRS change notifies measurement subscribers once, after profile and volume results are re-cut.
- The embed frame guard fails closed, and packaging refuses an embed allow-list left in the shell unless `OLV_ALLOW_EMBED_ORIGINS=1`.
- The gate runner only empties a step log directory inside `release/`.
- The CSP lint catches `<a href="x"onclick=…>`, skips commented policy lines, and Dependabot's GitHub Actions entry waits 7 days before offering a release, as npm does (Dependabot takes no separate major-version delay for actions).
- A WKT vertical unit is read by its conversion factor. UNIT["centimetre",0.01] and UNIT["millimetre",0.001] matched the metre name and resolved to 1 m per unit, so a 100-unit rise read 100 m in Measure and in the CSV vertical_m column instead of 1 m and 0.1 m. A yard (0.9144) or any other unit name with a valid factor resolved to unknown. The declared factor is now kept for WKT1 UNIT and WKT2 LENGTHUNIT, in compound and standalone vertical CRSs, and the 100-unit yard rise reads 91.44 m, as PDAL reads it. The unit is named metre, foot or US survey foot only when the factor is that unit. A name that disagrees with its factor, such as UNIT["metre",0.3048], is converted by the factor and the conflict is noted.
- A declared vertical unit that cannot be read (an angular unit, or a missing, zero, negative or non-finite factor) no longer produces metre heights. An angular VerticalUnitsGeoKey beside NAVD88 marked the vertical unit unknown, yet Measure and the CSV printed the 100-unit rise as 100 m, because the export frame replaced the missing factor with 1 and judged units by the horizontal scale alone. The vertical scale is now carried as valid, absent or invalid. An invalid one withholds every height and every figure built on one (3D length, tilted area, angle, grade, profile, box, volume) in the readout, trust grade, chain totals, lasso volume, CSV, GeoJSON, KML, PDF, findings and integrity report, with "height unit could not be interpreted". Plan figures are kept. The state follows each measurement's own layer, a saved session and a delayed export, and an invalid factor set on the measure tool no longer falls back to the horizontal unit.
- LAS conversion refuses a source whose vertical unit cannot be read, or whose vertical unit is not metre, foot or US survey foot, with the reason. Such a file was written with no vertical unit, which readers take as the horizontal unit.
- A projected CRS unit is read by its factor too. UNIT["centimetre",0.01], millimetre and kilometre matched the metre name and carried the token metre beside their factor, so labels read metres and LAS 1.2 output stamped ProjLinearUnits metre on centimetre coordinates. The unit is named metre, foot or US survey foot only when the factor is that unit; any other valid factor is kept and converts every horizontal figure, and its labels read "units of 0.01 m". LAS 1.2 output refuses such a unit, and LAS 1.4 keeps the source WKT that states it.
- Opening a session compares its unit claims with the scan by metres per unit. A session saved on a centimetre grid was not flagged against a metre scan, because the unknown token of a unit known by its factor read as no claim. A horizontal or recorded vertical factor that differs by more than 1e-9 relative now refuses the restore as a metre and foot mismatch does; a named foot and a declared 0.3048 agree, and a unit absent on either side is still no claim.
- Terrain analysis no longer rotates a PLY or OBJ scan whose shape reads as Y-up when the scan has a CRS. A surveyed facade PLY under EPSG:32613 was rotated from (x, y, z) to (x, -z, y) before the DTM, contours, map sheet and terrain exports were built. A PLY or OBJ under a CRS, from the file or assigned in the app, is now analysed as stored with sourceUpAxis z. A glTF or GLB under a CRS is declined with a reason that names the CRS and how to reconcile the axes. Up-axis detection is used only for a mesh with no CRS or set to Local, and the Analyse panel states the detected axis and any rotation.
- Terrain analysis reads a glTF or GLB with no CRS as Y-up, as the glTF specification states, instead of detecting its axis from the point layout. A 60 m wide, 60 m tall, 0.1 m thick wall stored Y-up read as Z-up, so it was routed as terrain and gridded with its 0.1 m thickness as the elevation range. It is now rotated to Z-up as (x, -z, y), routed as a wall, and the Analyse panel says it was rotated. Each layer's up axis is settled on its own before layers are combined: a PLY or OBJ with no CRS is read from its own points, not from the union with other layers, and layers whose up axes differ are declined until one side is hidden or locked.
- A PLY or OBJ under a projected CRS is measured, navigated and exported along Z, the axis terrain analysis and conversion already used. Measurement owner frames read the source format alone, so on a PLY under EPSG:32613 a 100 m rise read 0.0 cm (vertical_m 0) and a 100 m step north read 100.00 m (vertical_m 100) in the panel and the CSV, while a LAS read both correctly. One per-layer rule (src/geo/frame/layerUpFrame.ts) now settles each layer's up axis and its basis (specification, CRS, detected, explicit or unresolved) for measurement owner frames of active and inactive layers, the terrain gather, the converter, navigation up, standard views and the view cube, the coordinate readout, and the CSV, GeoJSON, KML, integrity report and PDF. A measurement on a glTF or GLB under a CRS prints the reason in place of any height, grade, profile, box or volume figure; its CSV and GeoJSON exports are refused and the PDF leaves it out with the reason. Assigning, replacing or clearing a CRS re-reads the axis of existing measurements, re-cuts their profiles and volumes and re-aligns navigation; stored coordinates do not move. Height colouring, the project elevation scale, the elevation filter and the colour legend use the same axis; when a CRS change moves it, colours and the legend are rebuilt and an active elevation filter is re-applied along the new axis, or cleared with the reason when its window no longer describes the scene's heights. A session records the resolved axis and basis beside the format axis, and each profile chart and volume records the axis it was cut along; on reopen a stored value is shifted only along that axis, and one cut along an axis the layer no longer resolves to (a file saved before this change, or a CRS changed since) is re-cut along the resolved frame, or withheld with the reason until it can be. Work held for a scan that is not open keeps its recorded cut axis; when none was recorded, its stored chart or cut and fill is withheld rather than moved along the format axis, and re-cut when the scan opens. Layer Health shows an Up axis row with the axis and its basis. A PLY or OBJ with no CRS keeps the Y-up rule. XYZ, E57, PCD, PTX, PTS and PNTS scans are read Z-up by the GeoJSON and Site KML gates, as terrain, measurement and the footprint already read them.
- Compare elevation no longer registers two epochs that declare the same horizontal CRS. They are compared in their supplied coordinates, and the panel and registration record state that no registration was estimated and that registration uncertainty is not quantified. On two 51 x 51 lattices with identical XY on a 0.5 slope, a +1 m uplift applied a 0.40 m x shift and read a mean change of 0.800 m; it now applies no shift and reads 1.000 m. Slope 1 read 0.458 m.
- Epoch alignment of pairs without a common declared CRS is refused as unobservable when the surface does not constrain yaw, x, y and z independently. The test runs on the point-to-plane information matrix before damping, and a plane or a single slope is refused. The record keeps the fitting residual, the residual at the applied pose and the registration uncertainty (not quantified) as separate fields. `olv.registration.epoch-horizontal-icp` is now version 3.
- LAS 1.4 export (point formats 6 and 7) always writes the coordinate system as an OGC WKT record (2112) and sets global encoding bit 4 when the file is georeferenced. A CRS known only from GeoTIFF keys was written as GeoKeys with bit 4 clear and reported as kept, and PDAL read such a file with an empty SRS. The source WKT is used when it is valid; otherwise the WKT is built from EPSG definitions checked against PROJ 9.8.1 (EPSG v12.029), as a compound with the vertical CRS when the vertical code is one of the stored ones. A WKT longer than 65,535 bytes is written as an extended VLR. A CRS with no stored definition is refused with a message that names the code and offers LAS 1.2.
- LAS 1.4 export writes the vertical CRS into the WKT. A horizontal-only WKT with the vertical datum and unit in GeoKeys was read by PDAL with no vertical CRS: EPSG:32613 over NAVD88 heights in US survey feet (EPSG:6360) reprojected to EPSG:32613+5703 kept 100 ftUS as 100 m instead of 30.48006096 m. The WKT is now a compound of the horizontal CRS (the source's, or the stored one after assign or reproject) and the VERT_CS of the vertical code in the unit of the heights; a source compound WKT is kept. A vertical code with no stored definition, or a height unit without a vertical datum that differs from the horizontal unit, is refused for LAS 1.4. After writing, the heights are checked again from the WKT record alone.
- Assigning an EPSG code resolves whether it is geographic or projected, and its unit, from the built-in registry and EPSG v12.029 tables. A code missing from the old geographic table was written as projected: EPSG:9990 (ITRF2020, geographic 2D) gave ProjectedCSTypeGeoKey 9990 and an X/Y scale of 0.001, so -111.12345678 was written as -111.123. A geographic code now writes GTModelTypeGeoKey 2, GeographicTypeGeoKey and a 1e-7 degree scale, and the re-quantisation is logged on its own line. A code of unknown kind, or a compound, geocentric, vertical or engineering code, is refused with a message that names it.
- The point-cloud converter no longer rotates a PLY, OBJ or glTF scan whose shape reads as Y-up. A surveyed facade PLY under EPSG:32613 exported (500000.000000, 4000000.058718, 100.000000) as (500000.000, -100.000, 4000000.059) under Keep and Assign, in XYZ, ASC, LAS 1.2 and LAS 1.4, still labelled EPSG:32613, and Assign reported "coordinates unchanged". Coordinates are now written in the source's axis order, and the scan's shape and the viewer's display orientation do not change them.
- Rotating a local Y-up model to Z-up is an explicit option, "Rotate a local Y-up model to Z-up", in the Export panel (for a scan with no CRS) and in the batch converter (Keep mode). It writes (x, y, z) as (x, -z, y), records the rotation in the report and in the file, and the report no longer says "coordinates unchanged" for that file. It is refused when the export keeps or assigns a CRS, and for a format that is Z-up by specification. A glTF source under a CRS is refused until its axes are reconciled, because glTF is Y-up by specification.
- The `# crs:` header of a converted XYZ or ASC file with no CRS reads "none recorded"; whether coordinates changed is stated by the conversion-event lines.
- Terrain Access reports the p95 longitudinal grade and cross slope at an exact length boundary correctly. With 100 equal diagonal edges valued 1 to 100 the p95 read 96; it now reads 95, the smallest value whose edges cover 95% of the route length.
- Terrain Access no longer reports the minimum terrain confidence as evaluated under the penalize unknown policy, where it blocks no cell and adds no cost. The run record, run card, diagnostics CSV and export README now mark it disclosed; under the block policy it stays evaluated.
- The Terrain Access why-not inspector names the move that misses its limit by the smallest share of that limit. It compared a step excess in metres with a grade excess in tangents before.
- Terrain Access refuses a run or preview whose cost weights include a negative or non-finite value, with the new `INVALID_WEIGHTS` code.
- PCD packed rgb colour is read as stored. Colours were darkened on load: a packed (128, 64, 255) showed as (55, 13, 255).
- PLY colour declared as ushort, short, float or double is narrowed by its declared type (16-bit values keep their top 8 bits, float values in 0..1 are scaled to 0..255). These colours were wrapped or truncated to the low byte. A wide colour in a layout that cannot be re-read is refused with a message.
- 3D Tiles point tiles with POSITION_QUANTIZED keep their quantisation step when the quantised volume is far from the origin. The volume offset was rounded to Float32 spacing (0.5 m at 4.7e6 m).
- An E57 Integer or ScaledInteger prototype field with no minimum or maximum is refused with a message. Such a field was packed in 0 bits and every value decoded as 0.
- E57 Integer and ScaledInteger intensity with no intensityLimits is normalised over the range the prototype field declares. A signed range no longer clamps every negative value to 0.
- On a geographic CRS the Measurements panel row and its run, rise, grade and area breakdown print the same refusal as the overlay and the exports instead of degree differences labelled as metres. Heights are still shown.
- Cut and fill volumes stay in cubic metres up to a cubic kilometre (2,345,678 m³ no longer reads 0.002 km³), and a volume below a cubic decimetre is shown with significant figures instead of 0 dm³.
- The lasso stockpile toast prints its base as an elevation, with the scan's recentred origin added back. When the loaded clouds share no datum it is labelled a local height.
- On a Y-up scan the lasso stockpile record keeps its area-weighted grid figure, authority, cross-check and PREVIEW label. The grid now integrates in the plane normal to the scan's up axis.
- A lasso stockpile record whose footprint coverage is below 80 % is no longer graded high: the coverage caps are applied again after the record takes the grid's coverage shares.
- Area ring planarity is judged against the ring's in-plane radius, so a ring gives the same verdict however it is turned within its plane.
- The PDF report's profile slope Avg is total rise over total run across the covered segments, not the unweighted mean of segment grades.
- A profile sheet whose ground unit is unknown states "units unknown" instead of horizontal and vertical 1:N scales, and keeps the vertical exaggeration.
- Chain totals use the panel's unit system and significant figures: a 3 mm total no longer reads 0.00 m, and imperial mode no longer prints metres.
- Imperial stations round to the hundredth before the 100 ft split, so 199.996 ft reads 2+00.00 instead of 1+100.00.
- The PDF report converts cubic metres to cubic yards with the exact yard (1 / 0.9144³) instead of 1.30795.
- Converted LAS and ASCII files take geographic or projected from the resolved CRS. A NAD83(2011) geographic scan (EPSG:6318) was tagged projected and quantised at 0.001 degree, up to 28 m of error; it is now tagged geographic at 1e-7 degree. CGCS2000 / 3-degree Gauss-Kruger (EPSG:4547) is tagged projected, and a geographic WKT with no EPSG code is quantised at a geographic scale. A code known only by number is classified from the EPSG dataset's geographic CRS list.
- EPSG:6349, the compound NAD83(2011) + NAVD88 height, no longer resolves to UTM zone 20N; NAD83(2011) / UTM covers 6330 to 6348.
- The ortho world file of a mounted layer exported on its own is placed at the layer's world coordinates. It was off by the layer's placement offset in the project frame.
- UTM to longitude and latitude in the KML and GeoJSON exports and the Inspector uses the sixth-order Kruger series. The previous series was off by 3.0 m at 27 E, 79.6 N and 53.6 m at 33 E, 80.1 N in zone 33; the new one agrees with proj4 to under 1 mm over the accepted grid.
- GeoJSON Area measurements and building footprints write the Polygon exterior ring counter-clockwise, as RFC 7946 requires. A ring picked or traced clockwise was written clockwise.
- Index contours are chosen on world elevation when the scan is in a recentred local frame. With a local origin of 337 m they were drawn at 342 m and 347 m instead of 340 m and 345 m, and with a fractional origin such as 337.4 m no contour was an index contour, so none was labelled. Labels, the exported `contour_type`, the overlay emphasis and the map sheet weights follow the corrected classification.
- The contour interval list judges "yields no contours" on world elevation, the same levels the contours are drawn at. A 5 m interval on a surface from 337.5 m to 341 m was disabled although it draws the 340 m contour.
- When an over-fine interval is thinned to the level cap, the kept levels are multiples of the thinned interval in world elevation, so index contours and their labels still appear. The kept levels used to count from the lowest level, which with a local origin of 337 m and a 2 m thinned interval put every level on an odd elevation and left no index contour. The top level is still kept so the summit contour survives, and the warning states the gap below it when that gap differs from the thinned interval.
- Geographic (latitude and longitude) grids convert degrees to metres with the WGS84 degree lengths at the grid latitude: 110,574 m to 111,694 m per degree of latitude and 111,319 m times about the cosine of latitude per degree of longitude. The north-south axis used 111,320 m, the equatorial degree of longitude, everywhere, which overstated north-south distances by up to 0.7% near the equator. Slope, aspect, densities, the grid recommendation, Flow Pulse and Terrain Access on geographic grids change accordingly; terrain cores saved under the previous version are recomputed.
- Change detection compares a cell only where both epochs hold a measured height. Cells interpolated or extrapolated in either DTM were differenced as if measured: two identical surfaces whose footprints differed by 30 % read 1,462 m³ of net change. The shared grid cell is at least twice the sparser epoch's mean point spacing, so cells between returns are not mostly fill, and the result states how many cells were left out and their share (olv.change.dtm-difference v4, olv.change.dtm-difference.raw-net v4).
- Epoch registration of pairs without a common declared CRS no longer applies a false shift to epochs of different extent. It starts at the unmoved pose, pairs points within three mean point spacings by point-to-plane distance, measures the overlap at that distance, and withholds a fit with overlap under 50 %, a residual over 0.75 spacings or a move beyond the pairing distance. An after epoch extending 30 % past the before epoch was shifted 13.74 m with 90 % overlap reported; it is now not shifted (olv.registration.epoch-horizontal-icp v3).
- The epoch alignment summary states the shift at the before sample's centroid. It printed the length of the transform's translation, whose yaw turns about the world origin, so at UTM coordinates a 0.5° yaw with a 0.36 m offset read as a shift of tens of kilometres. The registration readout states the same centroid shift and the yaw; the applied transform is unchanged.
- The health check's Stray Outliers row no longer flags every point off the median on an axis where more than half the points share one value. It falls back to the interquartile range, then the 5-95 % range, and reports the check as not assessable when both are zero. 600 points on a flat floor beside 400 on a 1-40 cm ramp read 400 outliers; they now read none.
- The 3×3 eigen solvers (geometry descriptors, normals, object oriented boxes) stop on an off-diagonal that is small relative to the matrix diagonal instead of below a fixed 1e-14 or 1e-12. A covariance with eigenvalues near 1e-14 was returned unrotated, its smallest eigenvalue 84 % high.
- The Terrain Access run card no longer shows an estimated obstruction limit as "Above-ground evidence unavailable". Each status the run record carries has its own wording, and the obstruction row reads estimated, with the note below it, when the surface is a sample or route cells have no return.
- A Terrain Access route with no added cost reads "Cost is distance alone under the configured weights." It no longer says every move was fully supported, which contradicted routes whose slope used substituted neighbours.
- The post-load suggestion ("Terrain scan ready", "Object scan ready", "Interior scan ready") hides when the user switches to another task instead of staying over that task until its timer ends.
- Opening a second scan hides the "Project ready" card of the scan opened before it. When another message took the top-centre lane while the new scan settled, the card stayed on screen naming the earlier scan.
- Terrain Access reads above-ground obstruction from the top return per cell without ASPRS noise (classes 7 and 18), so a single bird or noise return no longer blocks a cell; the full-cloud DSM and its products are unchanged.
- When the obstruction surface was built from a sample of the scan, the obstruction limit reads `estimated`, with the sentence "Above-ground obstruction is estimated from a sample of N of M points; thin returns such as posts or wires can be missed." in the run card, diagnostics CSV, README and run record.
- Route cells with no above-ground return (exploratory policy) make the obstruction limit read `estimated`, with the sentence "Above-ground obstruction could not be checked on K of R route cells: the surface has no above-ground evidence there, so those cells are not known to be clear."
- Under the conservative evidence policy, a ruggedness limit also blocks cells whose 3×3 ruggedness window holds a cell whose slope used a substituted neighbour, so ruggedness on a route found under it reads `evaluated`.
- Saved terrain cores from earlier builds are recomputed once (core payload format 5).
- A Planetary Computer catalogue EPSG no longer overrides a CRS the file declares itself; when the file declares none, the catalogue EPSG is shown as coming from the catalogue entry rather than as a user override, and sessions no longer treat it as user-confirmed.
- Legacy class 8 (Model Key-point) and 12 (Overlap Points) kept by Fill unclassified keep their meaning in a LAS 1.4 export. They are written as class 1 with the key-point or overlap flag, as a plain LAS 1.2 to 1.4 conversion writes them, including after undo and redo of the fill and in a clip-scoped export. Filled points are written as derived and are not reinterpreted.
- Terrain Access no longer reports a slope limit as evaluated when the slope it compared was computed with a substituted Horn neighbour. Under the exploratory evidence policy the run record marks cross-slope and longitudinal grade `estimated` when any route cell's window left the grid or touched NoData, and an evaluated ruggedness limit `estimated` when any route cell's VRM window holds such a cell. The run card, limitations, diagnostics CSV, README and run record give the same sentence, for example "Cross-slope estimated from substituted neighbours on 3 route cells (3 at the outer boundary, 0 beside interior NoData holes)." NoData connected to the grid edge counts as outer boundary and any other NoData as an interior hole. The preview and the cell inspector use the same wording. Under the conservative policy those cells stay blocked and the limits stay `evaluated`. A one-cell-wide corridor with a 0.01 cross-slope limit was previously routed with cross-slope `evaluated` and no lateral sample.
- The quick-format PLY, OBJ, XYZ and CSV export buttons honour an active clip box. They keep the same points as Export, through the same clip and placement step, state "Clipped: k of n points" in the PLY, OBJ and XYZ header and add `-clip` to the file name. A clip that keeps no points is refused with a message and the buttons stay usable.
- A quick-format point export describes the scan that was active when its button was pressed. The points, clip, CRS, coordinate precision, source SHA-256 and file name are captured before the writer loads, so a scan opened while the writer loads or the source is hashed no longer reaches the file.
- The PDF report describes the scan that was active when Report PDF was pressed. Its metadata, capture fingerprint, measurements, annotations, units and source SHA-256 are captured before the report engine loads, so a scan opened or a measurement added while the engine loads or the source is hashed no longer reaches the report.
- Site KML copies the annotations and measurements when it is requested, so a note added or a vertex moved while the KML writer loads no longer reaches the file.
- On 320 to 389 px phones the header full-screen toggle keeps its 44 px touch target and the quality button stays on screen; the privacy badge shortens to "Private" there, and screen readers still hear the full text.
- On Safari, pressing a view cube face no longer sometimes turns the camera to a nearby edge or corner.
- A hover tip hides when its control is pressed, instead of staying over the controls beneath it until the pointer moves.
- LAS export keeps the declared vertical CRS and vertical unit when the heights' unit differs from the horizontal one. A metre-grid LAS with NAVD88 heights in US survey feet no longer comes out labelled in metres. Contradictory vertical declarations are refused, an unreadable vertical unit is written without a vertical claim, and every LAS export is read back to confirm its Z range and vertical scale before it downloads.
- A saved session reopened in a new page restores its measurements and annotations onto the matching scans, matched by source content rather than file name. Work whose scan is not open is kept and written back by the next save instead of being dropped, and the import message counts restored, waiting, ambiguous and refused work from what was applied. A density reload keeps the layer's existing work.
- Session work kept because its scan was not open is restored when that scan is opened later in the same page, matched on the same source facts (content fingerprint, file origin, up axis and EPSG) as the import. The message names the scan and counts the measurements and annotations placed; work that still names a scan that is not open, or a source open twice, stays kept for the next save.
- Work in a session with no project frame that names several scans is kept and written back by the next save instead of being reported as not restored. Work it marks as placed in a project frame is still reported as not restored.
- A density reload keeps the layer in its Layers panel group, and a session saved after the reload records the group around the reloaded layer. Groups read from a session in a new page name the matching open scans.
- A height, grade, profile, box or cut/fill measured on a Z-up survey no longer reads 0 after a Y-up scan (PLY, OBJ, glTF) is opened, made active or removed. Each measurement reads along its own layer's up axis in the panel, CSV, GeoJSON, integrity report and PDF; a measurement whose points span layers with different up axes is withheld with the reason. Navigation follows the active layer's up axis.
- A remembered CRS override applies automatically only to the same source, matched by position as well as name, point count and extent. A file with the same name elsewhere is offered the remembered CRS with an Apply action instead, and every CRS consumer passes the source identity.
- A remembered CRS override also records a content fingerprint of the source, taken at open from bytes the open already reads or two small slices: the first and last 64 KiB of a local or fetched file, the COPC header slice and root hierarchy page, or the EPT manifest and root hierarchy, hashing at most the first 64 KiB of each part and recording each part's full length. Two files that agree on name, point count, extent and position but differ in those bytes are no longer treated as the same source. Fingerprints taken different ways are not compared, and records without one still match by position.
- A Planetary Computer pick records the catalogue EPSG under the asset file name with the catalogue item id and bounds, so it applies to the stream opened from that item. It was keyed by the item id, which no opened stream used. A same-named stream not opened from the catalogue is offered the EPSG instead.
- The Inspector's Coordinate system section shows a remembered but unapplied CRS ("A CRS (EPSG:n) was remembered for a file with this name.") with Apply and Dismiss while the offer is pending, in addition to the toast.
- Site KML works for an ordinary Z-up LAS or LAZ and a streamed COPC or EPT scan, and still refuses a mesh with an ambiguous frame. It places only annotations the active scan owns and states how many were withheld and why.
- The render loop restarts on returning to the tab only after the graphics backend has initialised, so the first frame no longer throws.
- Terrain Access no longer routes a diagonal move through the shared corner of two unsupported cells. A diagonal is refused when either orthogonal cell beside it is blocked, at any vehicle width, and for a positive width when the disc swept along the move meets a blocked cell. Route search, the traversability map and the why-not inspector apply the same rule. `olv.simulation.terrain-access.astar` is registered at v2, and the Terrain Access run record takes its model version from the method registry.
- Terrain Access width clearance measures to the edge of each blocked cell and to the survey edge, not to cell centres. A 1.2 m vehicle no longer passes a 1 m corridor, a vehicle exactly as wide as a corridor fits, and a vehicle wider than the supported terrain is refused with a reason naming the width.
- Terrain Access no longer accepts an above-ground obstruction limit it cannot apply. The "Constrain above-ground obstruction" control is disabled, with "Above-ground evidence unavailable; this constraint cannot be evaluated.", while no aligned above-ground surface is available, and a restored or programmatic profile that sets the limit anyway is refused with `OBSTRUCTION_EVIDENCE_UNAVAILABLE`. The run record (now schema version 2), the run card and the export README state for each constraint whether it was evaluated, disabled, unavailable or recorded but not enforced.
- Terrain Access reports the share of route cells below the profile's own minimum terrain confidence (`fractionBelowProfileConfidence`), counted over every route cell, measured or interpolated. It replaces `fractionLowConfidenceOrEdgeRisk`, which skipped measured cells, used a display threshold instead of the profile's, and claimed an edge risk no input carried. The measured/interpolated split is now provenance alone. The warning, run card, run record and diagnostics CSV give the same figure.
- Terrain Access subtracts an above-ground surface from the terrain only when its origin, array lengths, row orientation, horizontal CRS and vertical unit match the terrain's; otherwise the run is refused with `SURFACE_MISALIGNED`. An ROI mask of the wrong length or with values other than 0 and 1 is refused with `INVALID_ROI` instead of being ignored.
- A Terrain Access run's input digest covers confidence, the vertical unit factor, the horizontal scale and latitude, the ROI, the above-ground surface with its terrain binding and the points it rests on (sampled or not, points read and in the scan, noise returns left out, Withheld treatment), the evidence-gap policy and each routing method as an id and version pair as well as the terrain surface (`olv.simulation.terrain-access.input-digest.v5`). On a geographic frame it also names the degree-to-metre model (`wgs84-degree-series`). The surface-only digest is recorded beside it as `surfaceDigest`.
- An absolute-accuracy figure is refused unless its RMSE is finite and non-negative, its checkpoint count is a positive integer at or above the study's stated minimum, and it cites its evidence.
- Opening a large local LAS or LAZ over an open stream now offers Save / Replace / Cancel before any work starts, and applies the answer only after the new scan opens. If the user chooses Cancel, or the new file fails to open or is cancelled while it loads, the previous scan and its measurements, annotations and saved views stay as they were. Saved views are cleared only by Replace, work left over a replaced stream is never saved under the new file, and static layers keep their work and saved views.
- Close scan and opening a COPC, EPT or 3D Tiles scan over open layers now ask before discarding class edits on any open layer, not only the active one, including a hidden or locked layer. The question names the edited layers and points to exporting each as LAS, since the session file does not store class edits. Removing one layer from the Layers list asks only when that layer has class edits.
- With only a streamed scan open, CSV and GeoJSON exports no longer include measurements left from a replaced scan under the stream's name and origin; they leave them out and say why, as the session, KML and PDF report already did. Work placed while a streamed scan is opening is no longer discarded by the earlier Replace answer or given to the new scan; it is kept as work on the replaced scan and the user is told.
- A signed measurement integrity report refuses, naming the measurements it cannot place, instead of leaving records out of the file.
- With one layer left open after the first layer closed, GeoJSON, site KML and the session now place its work through its placement in the project frame, not its file origin, so coordinates and reopened sessions no longer shift by that offset.
- Opening or closing a layer no longer moves the layers already open: each keeps its placement while it stays open, a newly opened layer that does not fit the frame is the one held out, and the project origin holds while any layer that anchored it is open. A CRS override re-judges the frame at once.
- Each measurement reads out in the units of the scan it was taken on; switching the active scan no longer rescales measurements taken on another scan with different units. A height on a geographic CRS with no declared vertical unit is marked unit-unverified instead of metres.
- Removing the active layer makes the next open layer active and re-resolves its CRS, provenance and dataset card, instead of leaving exports with no active scan.
- A binary PLY with a CRLF or non-ASCII header now reads its body at the right byte; a PLY element with records but no properties, or a header longer than 64 KiB, is refused. A glTF node reached twice in one walk is refused and a glTF open emits at most 8 million vertices, and the PLY header must end on a line that reads `end_header`.
- KML descriptions are HTML-escaped before XML escaping, and contour SVG comments stay well-formed when a file name contains "--". The terrain engine verification hook is registered only in test builds.
- PDF report volume rows carry the same interpolated, outside-scan, preview, noise and reduced-sample clauses as the live readout, and a withheld volume states its reason.
- On Web Mercator and geocentric frames the scan report, streamed extents, PDF footprint and full-cloud grade no longer state widths, depths or densities in ground metres; they state why.
- An endpoint snapped to a voxel centroid of a reduced display sample is graded caution, not a measured return.
- Close scan keeps recovery work saved for other files and the work a Replace kept, and new work on a file that has saved recovery work is journaled beside it instead of being skipped. A write too large for the store is skipped without turning recovery off. A session whose origin is present but malformed is refused.
- A LAS or LAZ whose header bounds do not enclose its points takes its local origin from the points, so coordinates keep full precision, and says so. Reprojection to or from a geocentric CRS (EPSG:4978) is refused instead of writing wrong coordinates.
- Studio height, depth and contour cards report source heights. They had printed coordinates relative to the scan's internal origin, so a tile spanning -7.86 m to 39.72 m read 14.0 cm to 47.7 m.
- A Studio card drawn from a display sample says so and gives the loaded and declared point counts. Its classification coverage names the display sample it was measured on.
- On Web Mercator and geocentric frames, Studio cards give width and depth in source units with the reason and no density. Card heights use the vertical unit the colorbar shows, and when visible layers are not in one vertical frame the card leaves out the Z range and says why.
- The scan report's duplicate check reports "Not checked" on a voxel-reduced display sample instead of "None", because voxel centroids cannot coincide.
- A local glTF or GLB that names an external buffer or image (a relative file or a web address) is refused before parsing. Opening it no longer makes the browser request an address named inside the file.
- The E57 reader refuses an XML section larger than 64 MiB and XML nested deeper than 256 levels with a clear error, instead of exhausting memory or the call stack.
- The latest-result card no longer covers the active tool's Finish and Cancel controls when it grows: it stays above the bottom controls and scrolls inside itself.
- The view cube no longer shows click targets under 24 by 24 CSS px. Edge and corner targets are 24 px, and a face seen at a glancing angle that would project narrower than 24 px is hidden until the camera turns further (its view stays in the navigation menu and the command palette). This fixes an intermittent WCAG 2.2 target-size failure that depended on the cube's orientation.
- Converted LAS and LAZ files keep scan angle, user data, scan direction and edge-of-flight-line, and the scanner channel in LAS 1.4 (LAS 1.2 has no such field, so the loss is reported). The full-resolution decode behind the converter did not allocate those channels, so a converted LAS that carried them lost them; sources without them convert to the same bytes as before.
- XYZ, CSV, ASC, PLY and OBJ exports are written in chunks of about 4 million characters instead of one string, so a full-resolution export of tens of millions of points no longer fails with "Invalid string length" and needs about a third less peak memory. The output bytes are unchanged.
- The result card and its Copy text now state the same scene caveats as the Measurements panel. A height with an unknown vertical reference, an unresolved shared datum, incomparable layers or a borrowed vertical unit, and every volume, no longer reads as a bare number there.
- "Avg grade" on a profile is now "Endpoint gradient" (the PDF's "Mean grade" too). It is the net change between the first and last covered stations, so when stations between them are missing it says how many, for example "5.00% (spans 1 missing station)". The formula is unchanged.
- When several files are dropped at once, the open status reads "Opening 2 of 3 —" before the file name and offers two cancels: "Cancel" stops the current file and the rest continue, and "Cancel remaining files" stops it and opens no other. The last file of a drop, and a single file, show the one Cancel as before. Either cancel leaves the viewer as a single cancel does, and a file that fails still reports its own error while the rest continue.
- The Site KML writes absolute altitude only for an EGM96 geoid height. NAVD88, EGM2008 and other metric sea-level heights are no longer written as if they were EGM96: they are clamped to ground with the source elevation, unit and datum kept in each description.
- The "Analysed basis" line on the contour map, terrain report and DEM package no longer calls a further-reduced analysis the "display sample". When the analysis used a subsample of the loaded display sample, it now says so and gives the loaded count, for example "267,595 of 6,983,766 points (analysed subsample of the display sample, 2,408,349 loaded)".
- Keyboard navigation (Fly, Walk) no longer stops after a streaming COPC or EPT file replaces a static scan. Navigation now stays on while either a static layer or a streaming scene is present.
- A volume over a footprint with no measured points is now withheld with a "No usable coverage" reason instead of reading as zero, and volume confidence is capped by how much of the footprint was observed (below 50% coverage is low, below 80% at most medium).
- The measurement trust grade no longer calls an endpoint "on a measured return" because the snap cell was sized by the largest span of a flat or linear scan. The cell now follows point spacing, the on-a-return tolerance is half the local point spacing, and the green grade reads "Supported — close to measured points", which says measured points are near the endpoints and makes no accuracy claim.
- Measurement snapping and the support grade now work in the project frame across every visible, unlocked scan, so a vertex on a real return of a translated second scan, or on any scan other than the first, snaps and counts as supported. The snap index follows layer add, remove, visibility, lock and placement changes.
- E57 colour and intensity that the file flags invalid are now masked per point instead of only counted. The point keeps its position; the flagged value is drawn grey, left out of intensity ranges, the colour balance and voxel means, and exported as an empty CSV field or `nan` (XYZ, ASC). PLY, OBJ and LAS omit the attribute for the whole file when any exported point is flagged, and the file says so.
- Opening a streamed scan over an open one, and importing a session over measurements, annotations or saved views, now asks Save session / Replace / Cancel instead of keeping or overwriting that work silently. Replace keeps a recovery snapshot, a bad session file changes nothing, and a saved session no longer writes work from a replaced scan under the new scan's name and frame.
- Whole-file loading is capped at 1 GiB whatever the device reports: a larger LAS or LAZ opens out-of-core, and any other format, full-resolution export, reload or batch conversion over the cap is refused before the file is read.
- Plan View now turns off when the command palette changes the view or the projection, as it does from the navigation bar; Frame all, the R and T/O/P keys and a saved-view restore end it too, and the Ortho chip follows the projection. Every way out of Plan View except a saved-view restore now returns to the navigation mode used before it (Orbit if none), so the palette, the view cube and the keys end in the same mode as the Plan chip. Searching the palette for "perspective" now shows "Switch to perspective projection" while the view is orthographic.
- E57 loads report points whose colour or intensity the file flags invalid, keep flagged intensity out of the observed range, record the per-scan intensity normalisation (CSV names the column `intensity_normalised`; XYZ, ASC and LAS state it in their provenance), name channels dropped because some merged scans lack them, and skip a scan whose pose rotation is malformed or degenerate instead of placing it with the identity rotation.
- Measurement labels drawn in the scene now use the scan's unit status, as the Measurements panel does. A box or profile on a scan with no CRS read "13.200 m × 4.8000 m × 0.5000 cm · 317 dm³"; it now reads source units marked "(unit unverified)". On a confirmed metric or foot scan, the box sides share one unit and precision with the volume in the cube of that unit, the profile length and drop share one unit, and a height on a geographic frame no longer draws its horizontal leg in degrees.
- The view cube's faces, edges and corners no longer overlap at any camera orientation. A press on a face could fire an edge or corner target in WebKit, which hit-tests CSS 3D differently. Faces are now 2D parallelograms and every target is placed from the projected geometry: a face turned away is hidden, and an edge or corner that would cover a face's centre or another target is hidden.
- The active-tool pill no longer covers the bottom tool dock while it appears. It used to show at its stylesheet fallback spot and then glide up into place, overlapping the dock for roughly the first 100 ms. It is now seated while invisible and revealed on the next frame at its settled place; the entrance fades opacity only, and only an already-settled pill glides when it is re-seated. Reduced motion turns both off.
- The clip box now changes what is drawn. The viewer set `material.clippingPlanes`, which the WebGPU renderer (and its WebGL 2 backend) ignores, so the whole scan kept drawing while the readout said "1,093 of 35,291 points kept". The clip is a per-point keep test folded into the point size graph, like the class, elevation and intensity filters, so Inside, Outside, an Advanced bounds edit and Fit to scan all take effect on the next frame with no shader rebuild. Streaming nodes and clouds added while a clip is on carry it too.
- A Box drawn from two picks on the ground clipped to a slab a few centimetres thick, a 2D slice of the scan. When the box's height is under 5% of the scan's vertical range, "Use as clipping region" and "Isolate this box" give the clip the scan's full height and the toast says so. The measurement itself is left as drawn, and a box with no width or depth is still refused.
- Clicks, double-click focus, the F key, the hover probe and measurement vertices could land on points a clip had hidden, so focus flew to an invisible point and the orbit pivot sat in empty space. Picking now skips clipped-away points, and isolating a box glides the camera to the kept volume so orbit and zoom pivot there. The pick scan also asks the filter only about points that would win, instead of every point.
- Floating hints, toasts and notices no longer overlap each other. The latest-result card and the clip chip drop below a progress toast or the project card, not only the measurement toolbar. The hold-Space hint shown while a tool is active lifts above a bottom toast or the first-run hint instead of sitting on the same line, and the active-tool pill sits above that hint. The reload-recovery notice lifts above the dock, the phone status strip, the navigation row and any bottom toast in its corner.
- Change detection, terrain analysis, contours, DEM export, Flow Pulse and Terrain Access refuse a depth-positive-down vertical reference (NAVD88 depth, MSL depth and the other depth codes, or a WKT vertical axis declared DOWN) on either epoch, with "Depth-positive-down vertical reference; elevation workflows refuse it until normalisation is supported." The change pipeline reads Z as height, so a depth going from 10 m to 9 m, a 1 m rise, was reported as a 1 m³ loss on a 1 m² cell.
- A geocentric CRS (WKT1 GEOCCS, a WKT2 geodetic CRS with a Cartesian coordinate system, GeoTIFF model type 3, or a geocentric EPSG code such as 4978 or 4936) is no longer read as projected. Its name and EPSG code are kept, it resolves to a new geocentric kind, and measurement, terrain, change detection, footprint and change-raster exports refuse it with a reason. The official PROJ WKT2 for EPSG:4978 had parsed as "Unknown CRS", projected, with metric claims permitted.
- Web Mercator (EPSG:3857, 900913, 3785, 102100, 102113, or a definition naming Pseudo-Mercator or Popular Visualisation) no longer receives a safe-metric verdict. Its verdict is grid-only and blocking: horizontal lengths, areas, grades, slopes and volumes are withheld in the Measure tool and its exports as on a geographic CRS, heights are kept, and terrain and change workflows refuse it. A 100-unit segment had exported as 100 m, about 50 m on the ground at 60° N.
- A WKT2 geodetic CRS with an ellipsoidal coordinate system is read as geographic instead of projected.
- The geographic refusal wording in the Measure tool, the exports and the reports now names all three frames it covers: geographic degrees, a Web Mercator grid and a geocentric frame.
- A two-finger pinch on a touch screen no longer throws when a finger's pointer has already ended before the viewer releases it.
- A two-finger pinch keeps the point under the fingers in the perspective view when the opening fit has lifted the scan above the bottom bar. The lens shift was subtracted only in the orthographic view, so on a tablet the pinched point slid about 90 px.
- On a touch tablet narrower than 820 px in portrait (768 px on a small tablet) the header fits the screen. The GitHub link is hidden there and stays reachable from the Credits page; the link had sat past the right edge.
- On a phone the recommended-view chip's Apply and Dismiss buttons are 44 px touch targets; Dismiss was 22 by 20 px.

- The epoch alignment reported the solver's residual (yaw plus x/y/z) while applying only yaw and x/y, so two identical surfaces 1 m apart vertically read "0.00 m residual". It now reports both: the residual re-measured at the pose actually applied and the solver fit residual, each labelled. Neither is used as the registration term of the level of detection any more; σreg is accepted only from an independent assessment on stable reference areas, which the app does not have yet, so σreg is unavailable.
- Two DTMs are compared cell for cell only when their origins and cell sizes agree to four float64 ulps, capped at 1e-6 of a cell. The old origin tolerance was |coordinate|·1e-9, 5 mm at a northing of 5,000,000, and passed a 4 mm offset on 1 cm cells; such pairs are now refused as not on one grid.
- A measurement exports through the scan it was taken on. The GeoJSON, CSV and integrity report placed each measurement at its own scan's origin but labelled and converted it with the active scan's CRS, unit scales, up axis and source digest, so a UTM 12N measurement exported while a UTM 13N scan was active came out at longitude -105 instead of -111 under scan A's name. Each measurement now takes its CRS (a remembered override included), horizontal and vertical unit scales, up axis, CRS label, longitude/latitude mapping and source digest from its own scan, so the active scan no longer changes another scan's output. Measurements on scans whose frames differ are refused together, naming the scans, instead of being mixed; scans that share a frame still export together.
- Measurement outputs no longer borrow the active scan's context. When a measurement's owning scan, frame or permissions cannot be resolved, the result is withheld with a stated reason:
  - The PDF report holds only the measurements the active scan owns. A 10 m measurement on scan A had printed as 3.0480 m in scan B's report when B was in US survey feet; it is now left out, and the Measurements section states how many were withheld and why. The site KML applies the same rule and states it in the document description.
  - A measurement owned by a Web Mercator, geographic or geocentric scan keeps its refusal when another scan is active. The per-scan export frame derived its permission from "unit known and not geographic", so a Web Mercator owner exported `length_m` 10 while a UTM scan was active. The export frame now carries the frame's canonical permissions, `horizontalMetricRefused` and the new `verticalMetricRefused`, the same two flags the live Measure tool is set from; a known metre unit alone never permits a distance.
  - Adding findings converts only the measurements the active scan owns, in that scan's units and permissions. A measurement whose scan was closed had become a finding through the active scan (a 10 ft length labelled 10 m), and one taken on scan A was exported inside `b-findings.json` with B's dataset identity, CRS and digest. Both are now refused with a message naming the reason, so a findings report for a dataset holds only that dataset's findings.
  - A geocentric frame refuses heights as well as lengths. ECEF Z points at the North Pole, not up at the site, so a segment along it had read "height 1.0000 source units". A frame with no valid local vertical (geocentric, or a depth-positive-down reference) now withholds heights, grades, profiles and volumes in the live readout, the trust grade, the measurement chains, the profile CSV and every export; geographic and Web Mercator frames keep heights.
  - The integrity report records the classification epoch of the scan it names rather than the active scan's (A at epoch 3 with B active at 7 had recorded 7). A report whose measurements span two scans is refused, because it holds one dataset identity and one epoch.
  - A measurement with no recorded scan is withheld while several scans are open, instead of taking the active scan's frame.
- E57 intensity with declared `intensityLimits` is normalised as (v − min) / (max − min) to 0–65535, so a signed range such as −2048..2047 keeps its negative values instead of clamping them to 0. A unit-range float channel with declared limits now maps its declared minimum to 0 rather than scaling the absolute value by 65535. Without declared limits, or when the declared maximum equals the minimum, the previous rule applies.
- E57 colour is normalised per channel by each channel's declared `colorLimits` minimum and maximum, instead of by the largest of the three maxima with the minimums ignored. A scan without `colorLimits` uses the colour fields' declared Integer range, so 16-bit colour is no longer clipped to 255.
- LAS 1.2 and 1.4 exports round X, Y and Z to the integer grid with halves away from zero, as LAStools does, so a negative half step such as −2.5 is written as −3 rather than −2. The extended scan angle, the snapped header bounds and the int32 range check use the same rule.
- The Analyse ground density read high, and higher the more the load was thinned. It averaged per-cell densities over occupied cells only, which is the mean of a count given at least one point: a true 2 pts/m² read about 2.3 at full sampling and about 11 at a stride of 10. It is now the scaled ground-return count divided by the area of the ground surface's covered cells (measured plus interpolated), and the median is taken over blocks sized to hold about 20 analysed points. The quality score, the readiness cap, the USGS 3DEP density reference, the report, the map sheet and the panel all read the corrected figure.
- `HOLDOUT-RMSE` and `NVA-VVA` are scoped to what their R study exercises: RMSE, bias and the NVA figure recomputed from frozen residual vectors through checkpointAccuracy and computeVerticalAccuracy, not the hold-out procedure. The VVA-style P95, which the study excludes, is a new claim, `VVA-P95`, at E3, so the register holds 38 claims, 17 at E4. The two P95 conventions (type 7 in the hold-out, nearest rank in checkpoint accuracy) are documented, and the 0.6.7 entry now names R 4.6.1.
- The measured-cell reliability interval says it is narrower than nominal, because its tolerance comes from the same residuals and they are spatially correlated. Known limitations also states that the hold-out grid origin differs from the delivered grid.

- Flow Pulse no longer counts a level plateau as a depression. A cell counts as filled only when its original height is strictly below the spill level it was reached from (Barnes, Lehman & Mulla 2014); a flat that conditioning tilts by the epsilon so it can drain is counted separately. On a 41 x 41 plateau at 100 m with a 99 m edge, a conditioned run reported 1,482 raised cells, a 0.019 deepest fill and one 1,482-cell depression; it now reports none. Fill depth is the spill level minus the original height, without the epsilon added along a filled depression. `olv.simulation.terrain-flow.priority-flood` moves to v3, its `.gap-outlet` variant to v2 and `olv.simulation.terrain-flow.depression-inventory` to v2; the conditioned surface itself is unchanged.
- Terrain Access gates and reports a move's grade from the move itself. The longitudinal grade of an edge is now the largest of the Horn gradient along the heading at either end cell and the edge's own rise over its length, and its cross slope the larger of the two end cells' sideways components, so a move and its reverse get the same figures. Previously only the from-cell gradient was used: in a V-shaped valley with 0.8 side slopes, the climb out of the floor read as level and passed a 0.3 limit while the reverse move was blocked. Route diagnostics and the Lab show the same per-edge grade, the p95 grade and cross slope are weighted by edge length, and each cost driver is summed as edge length times its weighted share, as in the route cost. `olv.simulation.terrain-access.cost-map` is registered at v3, and four Terrain Access oracle fixtures (TA-3 control, TA-4, TA-8 unset, TA-10) have new expected costs, regenerated from the updated independent oracle.
- Building a Terrain Access grid from a DTM whose vertical unit factor is unresolved now throws instead of reading elevations as metres.
- The compass rose no longer spins the long way round when the heading crosses north, holds its last heading when the camera looks straight up or down instead of snapping to north, writes to the page only when its rounded angle changes, and has no rotation transition under reduced motion.
- A compass face click goes through the same handler as the navigation bar's view buttons, so Plan View ends (or, for the top view, stays on) exactly as it does from the bar.
- The Clip panel applies each committed edit to the view immediately and counts kept points once the edits pause. While a count is pending the last figure stays, dimmed, and a count queued for an older box, a closed scan or a hidden panel is dropped. The count covers every visible scan and names the active one, and it is redone when the layers under the clip change (reload, layer added, removed, shown, hidden or placed, or a new active layer).
- The measurement GeoJSON no longer writes an orthometric elevation (NAVD88, EGM96, EGM2008, MSL) as the third coordinate. RFC 7946 defines that value as metres above the WGS 84 ellipsoid, which differs from those datums by the local geoid height, and OLV has no geoid model. Positions are 2D unless the scan's heights are already WGS 84 ellipsoidal heights in metres (EPSG:4979) on an unshifted WGS 84 datum, which pass through unchanged. Each feature carries its source elevations unconverted in `elevations_source`, and the collection's `vertical_reference` names their datum and unit. The Site KML keeps absolute altitude for a metric sea-level datum, and its note now says that KML altitude is referenced to EGM96 and that a NAVD88 or other non-EGM96 height is written unconverted, up to about 1 to 2 m off.
- A measurement that is valid in 3D but collapses in longitude and latitude is no longer written as a degenerate shape. A vertical wall area became a Polygon with two distinct positions and a purely vertical distance a LineString with one; the GeoJSON now writes `geometry: null` with a `geometry_withheld` reason and keeps every measured property, and a clamped KML placemark keeps its description with no geometry. A KML with absolute altitude still draws the 3D shape.
- An angle whose vertex coincides with an end point read 0°. It is now undefined: the Measure tool refuses to save it and says why, the live readout shows "undefined (zero-length arm)", and the exports omit `angle_deg` and state the reason (`angle_withheld` in GeoJSON, the evidence cell in CSV, the KML description). Angles of 0° and 180° with two non-zero arms are unchanged.
- The change-detection difference raster no longer rounds to three decimals. The header keeps full double precision, so a geographic grid keeps its cell size and origin, and cell values keep Float32 precision, so a 0.0004 difference is no longer written as 0. A real -9999 difference moves the NODATA value below it instead of reading as empty. Invalid grid sizes and origins are refused with a message. The download adds a `.prj` and a metadata file naming the CRS, value unit, comparison basis (after minus before) and both scans, and is refused when the scans' CRS is unknown or has no definition to write.
- Map sheet scale bars print the exact segment values: a 1 m bar reads 0 0.25 0.5 0.75 1 and a 5 m bar 1.25 and 3.75, where they read 0.3, 0.8, 1.3 and 3.8. The contour SVG scale bar reads 2.5 for half of a 5 unit bar instead of 3, and map sheet grid labels keep the decimals a sub-unit grid step needs.
- On a compound CRS (horizontal and height units differ), on-screen distance, polyline, plane area, angle, slope and profile figures, the live labels and the area breakdown are computed in the same per-axis metre frame as the exports, so the screen and every export report the same value. An angle with arms (10,0,0) and (10,0,10) in metres with heights in feet read 45.0° on screen and 17.0° in the export; both now read 17.0°. These kinds are no longer graded red with the compound-CRS notice.
- A projected EPSG code with no unit key is no longer read as metres. GeoTIFF keys, WKT with no UNIT and EPT `srs` codes now take the unit from the CRS registry or a known metre family, and any other code (EPSG:2264, North Carolina in US survey feet, for one) reads as unknown, so measurement, volume and terrain tools state the unit is unverified rather than reporting feet as metres. A vertical EPSG code with no vertical unit key now sets the height unit (EPSG:6360 is NAVD88 in US survey feet), on the GeoTIFF, WKT and EPT paths. A declared vertical unit that contradicts the vertical code leaves the height unit unknown and is reported on the CRS. A declared vertical unit code that is not a length unit the app can read also leaves the height unit unknown rather than borrowing the horizontal unit.
- The measurement GeoJSON export writes WGS 84 longitude and latitude, as RFC 7946 requires, and no longer writes the pre-RFC `crs` member. It used to write positions in the scan's projected coordinates, which most GIS tools read as degrees and placed in the wrong spot. Positions go through the same conversion, datum refusals and NAD83-style caveat as the Site KML, and a height is written only for a declared metric height above sea level. Measured values in the properties are unchanged. A scan with a local or unknown coordinate system cannot be exported as GeoJSON; the refusal points to the CSV.
- Volumes no longer let densely scanned areas count for more. The polygon Volume tool, the lasso volume and the stockpile breakdown now integrate a horizontal grid, each cell contributing its footprint-clipped area times its median height (`olv.volume.stockpile@3`, `olv.volume.stockpile-area-grid@4`). A 10 m square scanned 9:1 denser on its raised half read 90 m³ for a true 50 m³ and now reads 56 m³; the residue is the one column of cells straddling the step. Cells without points are interpolated from their covered neighbours inside the covered extent and left out beyond it; every volume states its interpolated and excluded shares on screen, in the toast, the CSV, GeoJSON, KML, PDF report and saved session, is low-confidence above 25% interpolated, and is withheld with the reason above 50%. Filling those gaps takes time linear in the grid size, so a large void no longer stalls the page. The stockpile band's surface term is the grid's per-cell term and its base term spans the integrated area. `docs/validation/volume-known-answer-baseline.json` freezes two known-answer scenes.
- The lasso volume's footprint is the drawn lasso projected onto the horizontal plane at the reference height, not the convex hull of the selected points. An L-shaped 36 m² slab read 68 m² and 64 m³; it now reads 36 m² and 36 m³.
- Stockpile thickness and ground-band standard deviations divide by n − 1.
- Stationing rounds to centimetres before splitting kilometres from metres, so 999.999 m reads 1+000.00 instead of 0+1000.00.
- The Scan Fitness result no longer carries a headline accuracy string. It printed the internal hold-out RMSE as a symmetric "± m vertical" bound, which an RMSE is not; it was not shown anywhere, and the Vertical accuracy row already reports "RMSE x m (internal hold-out)".
- The general ICP solver reported the residual of its last solve, taken over correspondences found at the previous pose. It now re-pairs every source point at the returned pose and reports the trimmed nearest-neighbour RMS, together with the trim fraction that RMS excludes.
- The terrain report's Grid extent row rounded to whole units, so a geographic grid read "0 × 0 degrees". Degrees are now printed to three significant figures (for example 0.002 × 0.0015 degrees); metre and foot extents are unchanged.
- A lazy part of the app that fails to load with no chunk URL in the error, or with no way to check the server, no longer reloads the page. It shows a Retry action instead, and a reload is offered only after a dialog says that unsaved scans, measurements, annotations, class edits and results would be discarded. The page still reloads on its own when the server reports the chunk gone, with the same cooldown.
- Reload at higher density keeps the original layer when a finding was added, edited or deleted on it during the reload. The notice says its findings changed, and the reloaded copy is kept beside the original when it holds findings of its own.
- An Area polygon that crosses itself, overlaps its own edges, collapses to a line or has a non-finite vertex is no longer committed, and a saved or imported one reports no area. Validity is judged in the polygon's own best-fit plane, so a vertical wall or tilted plane is accepted, and a ring that sits far from any plane is refused. The Measure panel, aggregate totals, CSV, GeoJSON, KML, integrity report and PDF omit the area figures for such a record and state the reason, instead of exporting 0. Valid records export exactly as before, and the tabular exports still round area to three decimals. The shoelace area subtracts a local anchor and sums with compensation, so a 1 cm square far from the origin keeps its area.
- A polygon or lasso volume on a cloud the loader reduced no longer integrates noise (classes 7 and 18) or Withheld points as ordinary ones without saying so. A stride keeps the file's own records, so its volumes exclude both and count them. A voxel-reduced cloud holds centroids that carry the first member's class and no flags, so its volumes record that noise and Withheld exclusion was unavailable instead of a count, along with the reduction mode and the resident and declared point counts. The Measure panel, saved sessions, the measurement CSV, GeoJSON and KML, the integrity report and the PDF report all state it. Volumes on whole clouds are unchanged.
- Going offline after a scan was open could reload the page, which lands on an error page offline and loses the scan. A lazy part of the app that fails to load while offline no longer reloads the page; a message says the part could not load and that Make available offline keeps every tool available. While online, the page reloads only when the server no longer serves the missing file as a script, not when the request failed, timed out or was redirected. Saved findings in Export show a Try again button when their part could not load.
- A file declaring vertical CRS EPSG:6360 (NAVD88 height, US survey feet) showed "Vertical: unknown" in the status strip while Measure read its heights in feet. The strip, the Inspector and Measure now share one table of vertical CRS codes checked against the EPSG dataset: NAVD88 height in metres, feet and US survey feet (5703, 8228, 6360), NAVD88 depth (6357, 6358), NGVD29 (7968, 5702, 6359), MSL in feet and US survey feet (8050 to 8053) and LN02 (5728). EGM84 height is EPSG:5798; the table had listed it as 5612, which is Baltic 1977 depth. A WKT vertical CRS named "NAVD88 depth", "MSL depth" or "Baltic 1977 depth" now reads as depth, not as a height datum. A declared vertical unit with an unknown datum reads "Vertical: US survey feet, datum not recognised", or "datum not declared" when the file names none, instead of "unknown".
- On a file with no declared vertical unit, a Measure rise, slant, grade, height or volume borrowed the horizontal unit without saying so. On a projected CRS with a known unit, the Measurements panel now says "Heights are assumed to be in the horizontal unit (vertical unit not declared)", as the reference plane does. A measurement whose vertical reference is unknown reads "horizontal frame resolved" instead of "datum resolved". A Run, Rise and Slant line uses one unit for all three figures, in m or ft, so a small rise beside a long run is not rounded to zero.
- Save session gave no sign that class edits are not stored in the session file. It now says so when the open scan has class edits, and points to exporting the scan as LAS at display resolution to keep them. The Save tooltip and the user guide say the same.
- The Plan chip read pressed, and "Plan view on" showed, while the camera was still tilted. Both now wait until the camera has landed top-down. A mode change, view, preset or second press before it lands cancels the entry and puts the projection back.
- Long text in a PDF report ran below the footer and off the bottom of the page, and the lost text was not marked. A long technical note, annotation note, measurement name or value, declared E57 metadata field, profile coverage caveat, summary caveat or finding, cover row or dataset row now continues on the next page. The label of a value that continues is repeated at the top of the new page as "<label> (continued)", and a long label or finding value wraps instead of running past the right edge. The Terrain Intelligence and Space reports wrap and continue their row values, hints, warnings and notes the same way. Line breaks in a note print as new lines and tabs as spaces, where both used to print as "?". Text the user typed prints in full, however long. A field copied from the file that is longer than 8,000 characters stops there with "[… N characters omitted from this PDF]", except a CRS definition, digest or unit, which is never cut. The declared source metadata section stops after about 1,200 lines' worth of fields with a line that counts the fields left out. The general notes on a profile sheet end with "[... N more lines omitted]" when they do not fit their box.
- The profile chart in the PDF report joined the samples on either side of a sample with no coverage, and the slope line used an uncovered height, so a sample with a height but no points behind it could print "Max +500.00%". The report chart, the slope line and the live chart in the Measure panel now break the line at any sample with no finite height or a point count of 0, as the profile sheet already did. A single covered sample between two gaps is drawn as a dot on the report chart.
- "Contour map sheet (PDF)" in Export wrote no file and gave no message: the map sheet dialog closed after Export PDF and nothing downloaded. The button now runs the same export as the Contour Studio PDF, with the Studio's starting purpose, so the sheet carries the same evidence permit, labels and provenance. When the map sheet is refused, the dialog stays open, says why, and keeps the entered values out of the next dialog. The DEM package and contour map sheet buttons in Export are disabled when they cannot run and show the reason the Analyse panel gives, for example "No contours at this interval to export." or that the analysis belongs to a different scan. When the evidence gate refuses the sheet after the press, the reason is shown under the button and read out, instead of a "Blocked" flash alone. A second press while the first is starting opens no second dialog, and a press overtaken by a new analysis says "The analysis changed. Press again." A cancelled or refused map sheet leaves the panel's contour style for quick exports as it was, and a second Export in the same dialog after a refusal can still write the sheet.
- On a geographic CRS (degrees) the Measure panel marks every measurement but a height as not a distance, but the PDF report, profile sheet PDF, CSV, GeoJSON, KML, findings, integrity report, chain total and the measurement labels in snapshots and Studio images printed the grades, angles, lengths, areas and volumes as plain numbers. They now print "not available: geographic CRS (degrees are not distances)" in the PDF, chain and drawn labels, disable the profile sheet PDF as the profile CSV already was, leave the CSV cells empty, set GeoJSON properties to null with a `not_available` property, and record a null value with an empty unit in findings and integrity reports, which still verify. The GeoJSON evidence, CSV evidence cell, KML description and report notes name the reason. Heights, rises and box heights are still published. The PDF and findings label a length on an unconfirmed scale as source units instead of metres.
- The PDF profile block's Max, Min and Avg grade read the raw samples on a compound CRS, so a 10 m run rising 10 ft showed +100% beside a 30.48% summary. The grades now use the horizontal and vertical units separately.
- The measurement chain total applied one unit factor to figures that mix axes, so on metre eastings over foot heights a distance of 1 m across and 1 ft up summed as 1.414 m instead of 1.045 m, and a 45° angle stayed 45° instead of 16.95°. Chain lengths, areas, grades and angles now match the exported figure for each measurement, and an unconfirmed scale reads source units instead of metres.
- The stockpile base-plane caveat printed the native uncertainty with an "m" suffix, so on a foot survey it disagreed with the Base plane row. It now uses the vertical unit factor.
- The DTM and DSM GeoTIFFs in the DEM package and the contour deliverable lost their vertical CRS under a default GDAL read, because the files declared GeoTIFF 1.0 and GDAL drops the vertical part of a 1.0 file. A raster with a vertical CRS now declares GeoTIFF 1.1. The vertical CRS code also matches the unit of the heights: NAVD88 heights in US survey feet are written as EPSG:6360 and in international feet as EPSG:8228. They used to be written as EPSG:5703 with a foot unit key that GDAL ignores, so GDAL read the heights as metres. A code defined in a different unit from the heights is refused. The DTM and DSM carry no vertical CRS when the height unit is unknown, when EPSG has no code for that reference in the height unit, or when the code is a depth CRS. In both cases the unit stays as the band unit and the DEM package README says why. The CHM, support, evidence, sensitivity and attention rasters are byte-for-byte unchanged.
- A DEM raster declared NoData -9999 whatever its heights, so a measured height of -9999, or one that rounds to it as a float32 or at three decimals (-9998.9996, -9999.0003), was read as missing. Deep bathymetry in feet reaches that depth. The GeoTIFF and ASCII grid writers now keep -9999 only when no written height equals it, and otherwise use a value below every height. The DEM package writes the same value into every raster and its README, and a caller-given value that a height equals is refused.
- LAS files written by the converter recorded NAVD88 heights in feet as EPSG:5703 with a foot unit key, which PDAL reads as NAVD88 in metres. The vertical CRS code now matches the unit of the Z values (EPSG:6360 for US survey feet, EPSG:8228 for international feet), and a code whose unit contradicts the Z values is left off with the unit key kept.
- On a phone, the theme toggle (28 px), the performance button (30 px), the state-strip items (24 px tall), the colour legend's close button (20 px), More tools (40 px wide) and the toast action (31 px tall) were smaller than a 44 px touch target. With a touch screen at phone width every one of them is now at least 44 x 44 px, as are the Project card's close button and the recovery notice's buttons. The state strip keeps one row and scrolls sideways. Desktop layouts are unchanged.
- Opening a scan on a phone covered most of the screen with the Project card, the colour legend, the instant-analysis prompt, the touch hint and the recovery notice at once. On the phone layout these cards now take turns: one shows, the next appears when it is dismissed or times out, and the Project card goes first and closes on the first touch on the scan. The Project card shows the file name, format, points and size in two lines, and the colour legend opens as its one-line range with a button to show the ramp. After opening a scan, at least 60% of a 375 x 812 screen shows the scan.
- The "Analyse terrain" prompt appeared for a scan with an unknown CRS without saying what that means for the result. Terrain analysis still runs on such a scan, in source units, so the prompt now reads "Terrain scan ready, CRS unknown: results in source units."
- The recovery notice's "Discard" and "Clear" gave no hint of how they differ. They now read "Discard this work" and "Clear all saved work", and their tooltips say that the first deletes only this work and the second deletes all saved work for every file.
- A LAS 1.2 export no longer writes a class number whose meaning differs from the LAS 1.4 source, or drops the LAS 1.4 overlap flag, without asking. Each loss is refused until its own opt-in is ticked in Export or the batch converter: "Allow class numbers to change meaning" and "Allow the overlap flag to be dropped". The refusal names every opt-in the write needs and points to LAS 1.4, which keeps both. The file's record states that an allowed loss was allowed in the export request.
- When the camera never finished moving to top-down, Plan view changed the navigation mode anyway, which stopped the camera short and still showed Plan as on. Plan now changes the mode only after the move ends. If the move does not end, Plan turns off, the mode and projection are left as they were, and a message says "Plan view did not finish. Try Plan again." Changing the mode from the bar or a shortcut, choosing another view or preset, toggling Plan again or closing the scan drops the pending mode change.
- The six standard views and the Top, Iso, Oblique and Planar presets could crop a thin diagonal cloud off the screen edge. They now fit the visible bounds as seen from each view's direction at the current window shape, with 5% of the screen kept clear at each edge. A single point, or a line seen end-on, keeps the camera a safe distance in front of it. Some views sit slightly further out than before, Iso and portrait windows most.
- In the report verifier, a key file that finished reading late could replace a later key file or a key typed while it was read. Only the latest load or edit now fills the key field. A failed read says so, and typing clears that message.
- EPSG fields in Export and the batch converter take a whole number or `EPSG:` followed by one. `4326junk`, `32614.5`, `+4326` and `4326.0` are refused with a message instead of being cut down to a different code. The signer Compare in the report verifier shows which key it checked, and an older comparison no longer replaces the result for the key now in the box. Reproject says X and Y are transformed and Z is unchanged. The export status line keeps the CRS outcome when it lists warnings. The measurement export says downloads were requested and to keep both files together.
- A display-sample export used the source's base name and gave no sign in its provenance that it held part of the scan. It now ends the file name in `-sample`, adds `Display sample: N of M source points` to the provenance text, and keeps a status note that "Convert at full resolution" exports every point.
- A PNG exported from Chromium held partly transparent pixels inside the scan area. Snapshots, image exports and figures are now fully opaque in every browser engine, except the georeferenced orthographic PNG, whose no-data pixels are transparent.
- Epoch change and the volume tools read ASPRS noise classes 7 (low noise) and 18 (high noise) as ground change and as cut. They are now left out, as DTM, contours, slope and terrain already did. The compare panel names the count per epoch, for example "12 noise points (classes 7, 18) excluded", and the lasso toast and saved volume record carry the count. A file with no classification channel reads every point as before.
- Several readouts labelled numbers with a unit they were not in. The Scan Report Height, and the streamed extent rows, now read "source units (vertical unit not declared)" where the file declares no vertical unit, or an invalid one, instead of metres. The Scan Fitness card withholds its hold-out RMSE when the vertical unit is unresolved, and the live probe, the inspector and probe cards and the inspector's Distance row use the CRS's own unit labels instead of a literal " m". Both profile CSV buttons are disabled on a geographic CRS, and the grade under a line on a compound CRS comes from the converted run and rise.
- A batch conversion wrote a large E57 that decoded as a sample (one record in N) or a file that ended before its declared point count with no refusal and a plain "Converted" row. The batch converter now refuses such a file with the same message as the single export and converts the rest of the batch.
- The provenance line "Classes edited in app" read "yes" in a file whose classes were left out. It now reads "not applicable (classes omitted)" in LAS, XYZ and ASC output.
- An E57 with points the loader dropped as non-finite declared those points as part of the file, so its cloud counted as a display sample and "Export all points" refused it. The declared and decoded counts now exclude the dropped points.
- A newline in an input file's name or CRS name started a new line in XYZ and ASC headers and in provenance text. Every header line, provenance line and download name now has CR, LF, the Unicode line separators and other control characters replaced, and bidi and zero-width characters removed. File and entry names also lose Windows-reserved characters and trailing dots, get a leading underscore on device names such as `CON` or `LPT1.las`, and stop at 200 UTF-8 bytes with the extension kept. A leading dot becomes `_`, so no export name is a hidden file, and soft hyphens, word joiners and the Arabic letter mark are removed.
- `buildZip` refuses an entry name with a control character, a backslash, an absolute path or a `.` or `..` segment. The DEM, contour, Flow Pulse, Terrain Access, Observatory and Studio PNG packages pass the layer or file name through `safeEntryName`, so a name such as `site/a\b` still exports, as `b`.
- The export summary said "Classification included" for XYZ and ASC, which have no class column. It now says "Classification not written (XYZ has no class column)" and shows no derived or cleared class warning for those formats.
- Batch conversions tagged the output with the input file's CRS but recorded "CRS source unknown". They now record the CRS the file declares.
- XYZ and ASC exports left out class, class flags, returns, GPS time, scan angle, point source id, user data, scanner channel, scan direction and edge of flight line, and intensity or colour, without a trace. The header and the report now carry a `Conversion event ascii-fields-dropped:` line naming each one.
- An export with no points wrote a file with zero bounds. It now stops with "Nothing was exported".
- Batch output names that differ only in case or Unicode normalisation, such as `A.las` and `a.las`, get different numbers.
- When the conversion events did not fit the LAS text area, the converter dropped the record without a warning. It now measures the record in UTF-8 bytes, keeps the events that fit, counts the rest in a last line, and warns in the report, naming the provenance lines and events it left out.
- A report signature time in years 0000 to 0099 read as 1900 to 1999.
- A LAS 1.4 export to LAS 1.0 to 1.3 clipped scan angles that round beyond 90 degrees to 90 and dropped the scanner channel with only a success line in the report. The write is now refused until "Allow scan angles to clip and scanner channels to be dropped" is ticked in the Export panel or the batch converter; the opt-in covers these two losses and no others. An angle is clipped only when it rounds beyond 90 degrees (±90.5 and beyond); 90.4 is rounded to 90 and recorded without refusal, like any fractional angle inside the range. Angles exactly halfway between two degrees round away from zero, so -1.5 is written as -2 (it was -1). A refusal names every opt-in the write needs, so a file that wraps classes, clamps returns and clips angles lists all three controls at once.
- The class wrap, the dropped overlap flag, the return clamp, the scan angle and scanner channel losses, and the class translations and meaning changes are recorded in the exported file's Text Area Description record, one `Conversion event <id>:` line each with the affected point count, and say when the request allowed the loss. If the record is too long for the file, the existing provenance lines are dropped before any event and the report says so.
- The Export panel showed only the first warning of an export. It now shows "Exported N points with K warnings" with every warning and class translation listed beneath, including the clip scope, and the batch converter lists the same entries for each file.
- The LAS 1.2 class-wrap warning said "1 points" for a single point.
- Converting a LAS 1.0 to 1.3 file to LAS 1.4 kept class 8 (Model Key-point) as extended class 8, which LAS 1.4 reserves, and dropped its meaning. Those points are now written as class 1 with the key-point flag, as class 12 is written with the overlap flag, and the report counts them. Only classes read from the source file are translated; a derived or cleared classification is not.
- A LAS 1.4 export to LAS 1.0 to 1.3 carried classes such as 19 (Overhead Structure), which the legacy table reserves, with no warning. The number is still written unchanged, since the tables have no mapping, and the report now names each class whose meaning differs (8, 10 to 22) with the number of affected points. The same list applies when a legacy file with classes 10, 11 or 13 to 22 is written as LAS 1.4, where those numbers now have defined meanings.
- LAS 1.2 and 1.4 export re-quantised every coordinate at 1 mm with a new offset. It now keeps the source file's scale and offset when the source is LAS or LAZ, its header values are valid, the coordinates are the source's own and they fit int32. Within the extent Float32 positions resolve (16,384 m at a 1 mm scale) the exported X, Y and Z integer records equal the source's. Beyond it the scale and offset are kept and a record can differ by a few steps, which the provenance text states. A reprojected, voxel-reduced, streamed or non-LAS export is re-quantised as before, and the Text Area Description VLR carries a `Scale/offset:` line naming the case.
- glTF and GLB vertex colours read as linear, as the glTF 2.0 specification defines COLOR_0, and are encoded to sRGB before display. They were stored as if already sRGB, so midtones showed too dark: linear 0.5 displayed as sRGB 128 instead of 188. Existing glTF scans with vertex colour now look brighter in the midtones. Four-component colours are read at the right stride, where the alpha value had shifted into the next point's red.
- A GLB or glTF opened in the browser failed with "Decoding failed": the parser probed image-format support and decoded textures with the DOM `Image` constructor, which the parse worker does not have. Textures and texture-format extensions are now skipped, since only vertex geometry is kept.
- Normals that a file declares are kept: glTF NORMAL, PLY nx/ny/nz and 3D Tiles PNTS NORMAL or NORMAL_OCT16P. The Normal colour mode and the point inspector's normal row now work for these formats. A set with any non-finite or non-unit normal is dropped as a whole and the points are kept; nothing is estimated.
- In the orthographic projection and Plan view, a mouse wheel, trackpad pinch or touch pinch zoom now keeps the point under the cursor, or between the fingers, where it is on screen. The wheel and trackpad zoom moved the camera along the perspective ray through the cursor, which let the orthographic image slide by 2 to 3 pixels per wheel notch at an off-centre cursor on a 1000 by 800 canvas, and the slide added up over repeated notches. A touch pinch slid vertically while the opening view's lens shift was applied. Perspective zoom behaves as before.
- Terrain Access read a DTM's elevations as metres whatever their unit, so a US survey foot DTM read 3.28 times too steep and printed feet as metres. Elevations and the above-ground height are now converted to metres for slope, step height, ascent, descent and cost, and the cell readout and 3D overlay convert back for display. Apply profile stays off, and the elevation readout is withheld, until the vertical scale is resolved. A preview or run that throws now shows a refusal and restores the controls instead of leaving the lab busy, and moving the start or goal clears the old route, its figures and Export.
- A DEM package with no world origin wrote the CRS EPSG, the vertical GeoKeys and a `.prj` onto rasters it had not placed. It now writes none of them, and its README says the frame is local, not georeferenced.
- The E57 parser stored attribute and column names read from the file on ordinary objects, so a name such as `__proto__` or `constructor` could reach the object prototype. They are now stored on null-prototype maps.
- A wheel or trackpad zoom during a camera move, such as the move into Plan view, was held and applied all at once when the move ended, toward where the cursor had been. It is now ignored while the camera moves.
- The reference plane labelled heights in metres or feet when the file declared no vertical unit and the horizontal unit was known. The number and label stay, and the readout and snapshot note now add "Heights are assumed to be in the horizontal unit (vertical unit not declared)." In an oblique orthographic view, the plane's grid patch and spacing now follow the plane point at the screen centre.
- The PDF report printed Height in metres when the file declares no vertical unit, while the on-screen Scan Report printed the same height in source units. The PDF now applies the Scan Report rule and wording: "15.7 source units (vertical unit not declared)", or "(declared vertical unit is invalid)" for a declared factor that is zero, negative or not a number, which printed "0.0 m" before. Width and Depth follow the horizontal unit, a declared vertical unit converts Height by its own factor, and a Height in source units no longer takes the km, m or cm scale of Width and Depth. The CRS origin line in the PDF, export provenance and package READMEs reads "vertical datum not declared" instead of "vertical datum unknown from unknown". The recorded CRS origin fields are unchanged.
- The site and scan-area KML, the RFC 7946 contour GeoJSON and the accepted building-footprint GeoJSON wrote coordinates on other datums as exact WGS 84 longitude and latitude. A NAD27 geographic scan came out 34.6 m from its PROJ position at 100 W, 40 N, and a NAD27 / UTM 12N scan 61.7 m. These exports now refuse NAD27, a geographic CRS on an unlisted datum or with no EPSG code, and a projected CRS whose proj4 definition has no datum unless its EPSG datum is WGS 84. The KML buttons, the footprint export and the contour GeoJSON export show the reason: "This scan is on NAD27. Longitude and latitude export needs a datum transformation that OLV does not apply yet, and Reproject in OLV applies no NAD27 shift. Reproject the scan to WGS 84 with PROJ, GDAL or PDAL using the NADCON or NTv2 grids, then open the result." NAD83, ETRS89, RGF93, GDA94, GDA2020 and NZGD2000 scans still export, geographic or projected, and the KML description and GeoJSON metadata name the datum and the size of the difference (about 1 to 2 m for NAD83, about 1 m for ETRS89, RGF93 and NZGD2000, about 2 m for GDA94, about 0.4 m for GDA2020) instead of calling the coordinates WGS 84. A geographic point with latitude outside -90 to 90, longitude outside -180 to 180, or a non-finite value is refused; longitudes are not wrapped. EPSG codes 26929 to 26960 are NAD83 State Plane zones and are no longer decoded as UTM zones; EPSG:26929 (Alabama East) had placed a scan in UTM zone 29.
- Reproject in Export and the batch converter wrote a NAD27 scan to another datum with no NAD27 shift and stamped the target EPSG, so the result read as exact downstream. A reprojection into or out of NAD27 is now refused with a pointer to PROJ, GDAL or PDAL with the NADCON or NTv2 grids.
- The map sheet's orientation arrow and the compass rose's top face read "N" over grid north, and the distance bearing in the Measurements panel showed a bare value such as "042°" for any scan. The arrow and the rose now read "Grid N". The bearing reads "042° grid" on a projected CRS with an EPSG code, "042° (local axes)" with no CRS, a local engineering CRS or a Y-up scan, and is not shown on a geographic CRS. True north differs from grid north by 1.29 degrees in UTM zone 12 at 109 W, 40 N, and by up to 2.98 degrees in a UTM zone.
- The blocked hold-out RMSE showed a 95% interval of [RMSE, RMSE] whenever only one block was scored or the bootstrap was off, although no interval had been computed. The result now carries an interval status, the reason it is unavailable, the number of scored blocks and the uncovered share. The Analyse panel and the report show "Confidence interval unavailable" with the reason and keep the point RMSE. Intervals computed from two or more blocks are unchanged.
- A nonzero measurement no longer exports as 0 when it is smaller than 0.0005. The measurement CSV, GeoJSON and KML, the integrity report and the findings report keep three decimals for values of 0.0005 and above, as before, and keep three significant digits for smaller nonzero values, so a 0.0004 m segment reads 0.0004. Exact zero stays 0, and CSV and KML write tiny values without an exponent.
- The state strip showed "Export all N points" and "Reload all N points" run together at the page text size. They are now separate items with a gap, at the strip's own type size, with a hover and focus style, a 44 px target on touch screens and system link colors in forced-colors mode.
- The terrain status after a Withheld-aware recovery no longer says the surface was rebuilt at full resolution. It now says the source was re-decoded at the point budget taking every Nth point, so the surface is still a sample.
- The USGS density reference is no longer printed on the contour map sheet, the Analyse panel, the terrain report or the export provenance when the coverage is not a full read or points are missing for a reason other than Withheld exclusion. The sheet titles the block "Hold-out accuracy (preview)" and states the sample basis under the heading when the figures come from a sample or a preview surface.
- The technical report's Dataset summary Height row now carries "(includes noise classes 7 and 18)" whenever the on-screen Scan Report does.
- The technical report's Exported stamp and the scan-report footer now print UTC with the zone named, matching the map sheet.
- The dock button that closes a scan is named Close scan, and on a phone it sits under More instead of beside Frame, Measure, Inspect and Annotate, so one stray tap no longer discards the scan. It keeps its rose tint, its own group and its 44 px target, and tablet and desktop layouts are unchanged.
- On a tablet (a touch screen at least 768 px wide and 600 px tall whose primary pointer is coarse with no hover, which includes a tablet with an attached trackpad) the controls outside the rails, dock and dialogs are 44 px targets, and panel close buttons and Frame all are 48 px. This covers the navigation card and its speed slider, the scan-state items, the empty state, the command palette, the shortcut sheet, the tour, the floating panels, the location bar buttons, the catalogue inputs, the View panel head, and checkbox labels in the rails. The view cube grows to 144 px with 44 px circular buttons (a long label wraps instead of widening) and moves right of the left rail while it is open. The class, layer and group visibility checkboxes now sit inside a label, which is a 44 px box on a tablet; the label element and its inline-flex rule exist on every device. Mouse and phone layouts keep their sizes.
- The Export button tooltip no longer says a class filter limits what is written. Only an active clip limits a point-cloud export; hidden or soloed classes affect image exports only.
- On a phone the Measure and Inspect instruction (for example "Select the second point") was hidden, so only a pulsing dot said what to do next and screen readers got nothing. A compact status line beside the tool rail now shows it, up to two lines, and announces each change once.
- Profile exports are saved as `<scan name>-profile-<profile name>.pdf` (and `.csv`, `.png`), the style the map and report exports use, instead of the profile name alone. The sheet's PROJECT field names the scan, with the profile name beside the sheet name, and the horizontal CRS states its code once and is no longer cut off.
- A profile measured on a voxel-reduced display sample no longer reads as a full static source. The workbench status line, the PNG, the CSV, the PDF's general notes, the technical notes and the method sheet state the sample size and the declared size, and that percentiles are taken over the sample with no Withheld or noise exclusion. Counts print with thousands separators.
- The profile sheet qualifies its maximum grade as one station pair and no longer calls it the figure that governs buildability, prints height gain and loss in the same unit and at the same precision with a note that rise across a gap is not counted, prints lengths and heights at two decimals everywhere, names the declared vertical datum instead of "approximately mean sea level", writes "to" and "at" in place of an arrow and an at sign, calls a vertical scale below the horizontal a compression, and places the maximum-grade label clear of the profile line.
- The Terrain panel and the Analyse readiness badge no longer show a USGS density reference floor when the analysis ran on a sample of the points. The panel redraws those rows when the analysed basis arrives, and the panel, badge, map sheet and provenance take the floor from one function.
- The contour panel and the map sheet now print the same share of interpolated or uncertain contour length, taken from the export model.
- Point counts in the analysed-of-source lines (Scan report, streaming extent rows, change comparison, feature candidates), the measurement report caveats, the cloud exclusion warning and the Flow Pulse cell counts use thousands separators.
- The Terrain panel keeps a value and its unit (and the tolerance in "Measured reliability") on one line with a non-breaking space.
- The relief Colour label is no longer cut off by the colour select.
- On the map sheet, accuracy rows longer than the right column are shortened or wrapped, the sample note has its own row, and the readiness note moves below the rows.
- Technical report section headings are no longer underlined, and the closing caveat lines up with the findings list above it.
- A PREVIEW volume in the Measurements panel now states its reason in brackets, as the PDF report row does. The panel and the PDF build the volume caveat and withheld wording from the same functions.
- The site KML places a measurement whose owner records source-local coordinates at its file-frame position on a placed scan, as it already did for annotations. It was shifted by the placement offset.
- Export site KML is no longer offered when the file would hold only the note that measurements or annotations were withheld. Only measurements and annotations the active scan owns, saved views and the scan outline count as content. The export re-checks this, and that one scan is open, when clicked.
- On desktop the rail task header no longer repeats the header Back ("← Data" twice): while the location bar shows a Back to the same place, the rail shows only the page title. The rail keeps its Back while a workspace is open, when the header Back closes that workspace, and on the phone sheet.
- The E57 reader refuses an XML section with more than 200,000 elements or 400,000 attributes, with an error that names the limit. A file of 2 million empty elements, about 8 MB of XML, held about 1.3 GB of heap while it was parsed. The files in the libE57Format corpus, the PDAL sample and the project fixtures hold 8 to 60 elements.
- A PCD whose SIZE or COUNT entry for a declared field is zero, negative, fractional or not a number, or whose binary header gives fewer SIZE entries than fields, is refused. Such a header made the record size 0, which switched off the length checks while the loader still read POINTS records: a 200-byte file with POINTS 20000000 built a 20-million-point cloud. A repeated POINTS or SIZE line is read as the first one, the line the loader uses.
- EPT hierarchy loading stops at 2,000,000 nodes, the ceiling COPC already had, with an error entry and a notice that part of the scene is missing. The 4096-file limit alone admitted tens of millions of nodes. `EptStreamingPointCloud.open` takes an optional notice callback and the octree exposes `capNotice`.
- A COPC hierarchy entry that declares a data node larger than 128 MiB is dropped, and a read of such a node is refused. The size is an int32 from the file, so an entry could ask for 2 GiB.
- A range read of an exact length no longer allocates the full length before any byte arrives. A server that accepted a 1000 MB request and sent nothing held 1000 MB; the buffer now starts at 16 MiB and grows to the requested length once the bytes have filled it. A body shorter or longer than requested is still an error.
- An EPT manifest whose schema lists more than 64 attributes is refused, and the duplicate-name check is linear. A schema of 60,000 attributes took 3.7 s to check.
- A glTF or GLB is checked before parsing: an accessor with no bufferView, or a sparse accessor, whose zero-filled size (all such accessors together) exceeds 12 bytes per permitted vertex, 96 MB at the vertex cap, and an accessor count that is not a non-negative whole number, are refused. A 400-byte GLB declaring 300 million vertices reserved 3.6 GB.
- A glTF or GLB that lists KHR_draco_mesh_compression is refused with a message that the Draco decoder is not bundled. The glTF loader's library loader would otherwise fetch a decoder from a public CDN and evaluate it. `decompressMeshes` is off and the extension is excluded as well, and the comments in `loaderConfig.ts` now say that Draco is not bundled.
- A corrupt LAZ stream is reported as a malformed-file error. laz-perf threw a bare string for 87 of 400 mutated headers, which reached the caller with no category. A COPC file whose point record length is shorter than its point data record format requires is refused, as a LAS header already was.
- The remote URL host filter (COPC, EPT and 3D Tiles) refuses bare single-label host names such as `intranet`, the `.lan`, `.home.arpa`, `.intranet`, `.corp`, `.private` and `.localdomain` suffixes, IPv4 `192.0.0.0/24`, `198.18.0.0/15` and `224.0.0.0` up to `255.255.255.255`, and the IPv6 forms `::/96`, `64:ff9b::/96`, `2002::/16`, `2001::/32`, `fec0::/10`, `ff00::/8` and `100::/64`. IPv4-mapped and IPv4-translated IPv6 hosts are judged by the IPv4 address they carry. A name that resolves to a private address through DNS cannot be refused on its text.
- KML and floor plan SVG text drops the control characters XML 1.0 cannot carry (U+0000 to U+0008, U+000B, U+000C, U+000E to U+001F, U+FFFE, U+FFFF), and a measurement CSV cell holding a bare carriage return is quoted.

- The Export panel and the batch converter select LAS 1.2 and say why when LAS 1.4 cannot carry the CRS the export writes (a State Plane code, EPSG:28992 or EPSG:3006 has no stored WKT). The default export used to fail after Export was pressed. A kept CRS is still judged per file in the batch converter, and its row names LAS 1.2 as the way forward.
- The LAS 1.4 refusal ahead of the write now runs with the horizontal unit the writer uses, so a WKT-only foot grid with feet heights and no vertical datum is no longer refused by the check and accepted by the writer.
- A glTF or GLB with Draco compression shows its own refusal ("The Draco decoder is not bundled with this viewer…") when opened in the browser. The parse worker sent only the category, so the page showed "This file type isn't supported yet." in its place.
- Epoch registration reports "Residual at the applied pose not measurable: change exceeds the correspondence distance" instead of "Infinity m" when no sampled point has a partner within that distance, and the registration record stores null with the reason instead of Infinity.
- A PCD header line that names a key but is not written at the start of a line with one space after it (indented, or tab-separated) is refused. The loader skips such a line, so the size guard and the loader could read different POINTS counts from one file.
- A LAZ stream that fails in a way that is not corruption (a programming error) is no longer reported as a corrupt file; only the raw values laz-perf throws are rewrapped, and they are kept as the cause.
- Terrain Access degree fields accept only values between 0° and 90°; 190 was read as 10°.
- Flow Pulse withholds square metres when the unit factor is missing instead of assuming one metre per unit.

### Security

- Opening a session file no longer stalls the tab on a crafted file. Pick layers are resolved through a set, a project frame is limited to 512 layers, a session to 20,000 measurements (a larger one is refused with a message, not truncated) and a `.olvsession` to 64 MiB.
- A session's coordinate system is restored only when the file records it as a CRS the author confirmed. It applies to the open scan for the app session, a toast names the CRS and its unit, and it is saved on the device only if you choose Keep or confirm it in the Inspector.
- The analysis-history line on import now reads "chain is self-consistent (unsigned, author not verified)". The chain is an unkeyed SHA-256 fold, so a pass never meant the file was untouched or who wrote it.
- The measurement overlay draws at most 400 labels per frame (the measurement being drawn first, then those nearest the screen centre), and lays them out on a spatial grid.
- Embedding: `?embedParent=` and `?embedOrigins=` only request an origin. The viewer talks to a same-origin parent, or to a parent whose origin the deployer compiled in with `OLV_EMBED_ORIGINS` (empty by default). A page framed by anything else shows a notice with a link to open the viewer in its own tab and does not start. This matters on hosts that cannot send `frame-ancestors`. `load-file` is capped at 256 MiB. See docs/usage.md.
- A live build never includes the Playwright test seam, even with `OLV_TEST_SEAM=1` exported. `npm run package` and the deploy smoke run the seam, dev-flag and CSP checks on the files that ship.
- The credits page loads its styles from `credits.css` instead of an inline style the policy did not name, and `lint:csp-html` and `check:built-csp` now check every page's inline script and style hashes against the policy. `brand-mark-light.svg` is no longer cached as immutable. `lint:unsafe-html` covers `insertAdjacentHTML`, `outerHTML`, `createContextualFragment`, `DOMParser`, `document.write` and multi-line values.

## [0.7.0-alpha.1] - 2026-09-18

A development cut on the way to v0.7.0. It carries no DOI, and its test figures
are not release-authoritative.

### Added

- ASPRS class semantics come from one module rather than a table in each of eight places, and names are keyed by the point data record format. Class 12 is Overlap Points under formats 0 to 5 and reserved from format 6, where overlap is carried by a classification flag instead. Codes 19 to 22 are named, 23 to 63 are reserved, and only 64 and above are user definable. The tables were verified against the ASPRS LAS Specification 1.4 R15, Tables 8, 9, 16 and 17.
- Classification flags survive a load. Synthetic, Key-Point, Withheld and Overlap are read from both record layouts, normalised to one representation, carried on the point model through the sanitizer, and written back by both LAS writers. Round-trip tests write, decode and compare, covering every extended flag combination.
- `lint:disposal-registry` reads `docs/disposal-contracts.md` and refuses a resource documented with no owner or no disposal trigger.

### Fixed

- The LAS 1.2 write masked the classification byte with `0x1f`, which erased the Synthetic, Key-Point and Withheld flags held in bits 5 to 7 on every export.
- The point inspector named class 12 Overlap for every format while the export legend named it Reserved (12), and the legend reported every code from 19 up as a user class.
- Clipping dropped the classification flags it should have carried with the points it kept.

### Changed

- Class names follow the ASPRS spelling, which changes label text in the inspector, the legend, the profile views and the profile returns CSV.
- The interface typeface is Olv Font (SIL OFL 1.1, a modified Poppins), self-hosted as three Latin subsets of about 11 KB each, in place of Manrope. A metric-matched fallback face keeps the header still while the font loads, and coordinate readouts use tabular figures with a slashed zero.
- The brand emblem, favicons, app icons and share card are redrawn as vector artwork, with a deeper-blue emblem on the light theme. The page and manifest description is "Local-first browser-based point-cloud exploration".

## [0.6.9] - 2026-09-17

### Added

- The interactive stockpile volume is integrated over a grid instead of summed over a point sample. Each cell is clipped to the lasso polygon and contributes the median surface within it, registered as `olv.volume.stockpile-area-grid` at method generation 2, replacing `olv.volume.stockpile`. The estimate is live in the lasso toast with its authority on the result: MEASURED on a fully resident source, PREVIEW while it is not, and withheld where the scope does not support a figure. The claim VOL-STOCKPILE stays at E3. The canonical stockpile record beyond the toast is not integrated: the session record, the technical report and the measurement CSV still carry the point-sample cut and fill volume record.
- A local LAZ opens progressively; an ordinary LAS still reads whole under the memory guard, or through the out-of-core index when it is heavy. The header prefix is read first, a parse worker frames the file from it, a range source reads the chunk table, and chunks decode from a pool, so the file is never resident whole. A stand-in preview cloud is drawn while the decode continues, sampled by one global stride so only the preview budget crosses the worker boundary, the smaller of the render budget and 2,000,000 points. The load telemetry names the file, its bytes, the declared point count, the point format, the chunk count, the stride, the preview budget, and the requested, unique and re-read bytes. Measurements are in `docs/validation/local-laz-open-baseline.json`.
- A computed TerrainCore is persisted to the Origin Private File System and restored when the same analysis is asked for again. The key is the identity of the analysed input, a SHA-256 over the analysed positions and a SHA-256 over the classification with the core parameters and the method generation, not the identity of the file, and any mismatch recomputes. Only cores that took at least a second are persisted, and the store is bounded to 512 MiB by least-recent use. The benchmark in `docs/validation/terrain-core-opfs-restore-baseline.json` records fresh computes of 6.6 s, 6.2 s and 9.4 s against restore medians of 24 ms, 62 ms and 96 ms at 100k, 500k and 1M points, on Chromium against real OPFS at revision c14cc2c1 plus the benchmark commit, with byte-identical grids. `docs/terrain-intelligence.md` describes the cache.
- The Tools tab opens with a launcher card that lists Measure, Inspect point, Annotate and Clip box from the action registry with their keys and hints, counts what the session has placed so far, and collapses to a strip while a tool panel is active. Probe stays on the dock only.
- Help is derived from the action registry, the key binding table and the help catalog, covering 7 topics with search.
- One authorization backbone sits behind every contour permit, and a granted decision always states its claim set.
- The Dataset Story is mounted in the Analyse panel when a scan opens, and stays reachable from the palette.

### Changed

- A worker failure falls back to the main thread only for workloads measured as safe: 25,000 points and 1,000 estimated cells for terrain, 1,000,000 points for classification, from `docs/validation/sync-fallback-budget-baseline.json`. Anything larger refuses with a typed error stating that nothing was produced. Both worker clients hold a 120 s reply deadline, and the Analyse panel says when a result was computed on the main thread.
- Four numeric paths were rewritten for speed and held to byte identity against the code they replace: DTM cell samples are stored contiguously for the sorted aggregations, the ICP target is indexed once and the solver's buffers reused, the voxel accumulator is typed with an open-addressing lookup, and the two square-opening implementations in the morphology step are tested against each other. The timings, including a DTM aggregation median falling from 994 ms to 168 ms, are in `docs/validation/local-laz-open-baseline.json` at the revisions recorded there.
- `src/main.ts` goes from 5,557 lines to 4,977 and `src/render/Viewer.ts` from 6,423 to 6,223, with the Analyse panel at 2,911. The module graph holds 841 modules and no cycles. The scan route, the Viewer-to-Inspector visual synchronisation and the streaming panel controls each moved into a coordinator over narrow ports, the action registry is split into contributors and built lazily, the Viewer's render core is built in a bootstrap module, and the Analyse panel's raster and relief previews moved into a surface-tiles module. Fan-out on the concentration modules is watched and printed as a table: 112, 77 and 23.
- The source file is hashed in the indexer worker rather than on the main thread, and the load budget reads a device signal with the voxel reduction bounded.
- Headings are sentence case, values that carry the result take a focal size, hairlines are fewer, and motion is bounded under a reduced-motion preference.
- One owner holds the top-centre lane, the project card first and the recommended-view chip after it. Between 768 and 1100 px the dock folds Snapshot, Copy view link and Probe into More. The touch hint yields after the first gesture and is reopenable from the palette. On a phone the results come first and the sheet opens to half height when a run completes.
- Scientific state reads in one grammar across the interface, a glyph and a word, Export Health rows carry a glyph as a second channel, and the informational tier is styled.
- Analyse status is announced in a live region, the report verifier traps focus, a disabled export product explains why, ten empty states say what fills them, and the load stages read "Reading metadata" and "Preparing display".
- A classification run names an assumed unit and reports support rather than a percentage, and the corpus test is gated on the method identity with abort terminating the worker.
- The module-graph lint refuses to bank a raise and records fan-in, and a deposited release's limitations document keeps the counts it shipped with.
- The dev-tooling dependency group was bumped, including `@loaders.gl/las` from 4.4.5 to 4.5.1, and the bundler it pulls is pinned.

- Panel rows lead with the result: values take a 12 px size while labels stay at 11 px, the readouts that carry figures use tabular numbers, the dock and the workspace tab strip are concentric with what they contain, floating surfaces share one layered shadow, and a press has one scale.
- Layer Health folds frame and mount detail behind a disclosure when one layer is loaded, the Export summary keeps a neutral line and moves its caveat to a note, Provenance bounds read label left and figure right with the citation below, Workflow, RGB and Background are collapsible with their open state remembered, and Scan Intelligence replaces three unknown rows with one line.
- The persistent-core key comment names the store that now exists, and the unreachable register states the passport's remaining conditions as integration rather than canonicalisation.

### Fixed

- A stockpile estimate from a streaming source (COPC, EPT or an out-of-core index) stays at PREVIEW until the source is fully resident. Renderer readiness was read as source completeness.
- A terrain gather that several layers refuse to join names the shared-frame rule it applied, instead of reporting a bare refusal.
- A coordinate-system refusal links to the Help topic that explains it, and a shadowed help-overlay key binding is removed.
- A torn out-of-core index left payload files it no longer named; those are swept.
- The confidence surface no longer describes itself as calibrated, and the pooled row is dropped.
- Each reason string names the condition it reports.
- Scan output states the real analysed basis, withholds a capture type it has no evidence for, and analysis is reachable from the palette.
- A non-finite digest is refused, the layer table is derived rather than assembled twice, and navigation listeners are released.
- The Output panel's findings ledger is styled, empty launchers are hidden, and a site KML is written without measurements.
- The palette's hover follows the pointer only after the pointer moves, and the empty-state tooltip closes when the stage hides.

- A streaming source counts as complete only once its hierarchy is, not once every node known so far is resident. An EPT source opens shallow and deepens afterwards, so the stockpile authority, the profile provenance and the terrain resident-only flag read a coverage answer that can be unknown.
- Terrain Intelligence Report rows wrap a long label inside its column, a scan name wider than the page shrinks to fit, a verdict reason is printed once, and the stride-scaled ground density warning says the scale reaches the loaded display sample rather than the whole file.
- Export Health names a strided local file as a display sample instead of reporting an unknown scope, and the Layer Health loading row says which count is declared and which is resident.
- The top lane is handed on when the project card's fade ends rather than when it begins, with a bounded fallback for a card that reports no transition end, so the recommended-view chip no longer paints beside a card still on screen.

### Evidence

- No product changed evidence level. The register holds 34 claims: 2 at E1, 6 at E2, 9 at E3 and 17 at E4, with none at E5. The stockpile method change does not move VOL-STOCKPILE, which stays at E3 on synthetic known truth with field accuracy unestablished.

## [0.6.8] - 2026-09-12

### Added

- A heavy local file indexed into the Origin Private File System is found again on reopen instead of rebuilt. The cache is keyed by a whole-file SHA-256, so an edited file is a miss and never a wrong hit; a cheaper locator only decides whether computing that digest is worth it. Eviction skips any store another tab holds open and refuses to act when liveness cannot be determined, and a janitor sweeps stores an earlier session abandoned.
- Streaming reports readiness for the current view rather than the whole source, orders within-level refinement toward the centre of the view, and compensates point size while coarse nodes stand in for fine ones.
- Contours export as a package with a DXF, a validation record and the Contour Studio settings. A scientific artifact passport, an evidence boundary inspector and a SHA-256 over the DTM surface are implemented and tested but not reachable from any user path; they are listed in `docs/validation/unreachable-modules.json`.
- A Scan QA report replaces the retired acceptance checklist, stating the coordinate-quality verdict, classification provenance, the attributes the cloud carries and what the report does not establish.
- Derived analytical layers are listed in the Layers panel; hillshade can be styled with an elevation ramp; a coordinate readout follows the probe; the profile section filters its scatter by attribute and can draw its sample corridor in 3D; building and wire candidates open in a review surface; a findings ledger persists across a session.
- 3D Tiles using REPLACE refinement render correctly, hiding a parent only once every child is resident, and the 1.1 `contents[]` array on a tile is read.

### Changed

- Scan output names the population each number describes. A strided load carries the declared count, the decoded subset and a smaller analysis gather, and rows across the Scan Report, the dataset card, the Analyse fitness summary and the terrain and technical PDFs previously stated a figure without saying which. Classification reports its measured unclassified share rather than a hardcoded zero, the dataset card reports the resident count labelled `display-sample` rather than the declared count labelled `full`, and "Captured" and "Capture Sensor" are now "File created" and "System identifier", which is what those header fields hold.
- The canonical toolchain moves to Node 22.18.0 with npm 10.9.3, and the verifier reads the pin instead of a hardcoded version.
- The hold-out validation refuses an invalid split fraction, cell size or seed, a ground mask that does not cover the cloud, and a requested train-only reclassification that could not be produced, reporting the reason instead of substituting a default or the whole-cloud figure. Its record names which ground classification the surface was fitted from: `whole-cloud`, `train-only`, or `fixed-source-classification` when class 2 was trusted, and the spatially blocked figure records the same. The panel and report describe the contrast between the two figures from those records rather than asserting that the blocked figure predicts across a gap or runs larger.
- Residual figures are captioned in the unit they are in. On a frame with no stated vertical scale the panel, the terrain PDF, the review bar and `validation.json` say source Z units, and the ASPRS-style RMSEz, NVA and VVA fields are withheld.
- Two-epoch change reports no cut and fill volume and no elevation difference when the epochs cannot be confirmed to share a frame, when their grids differ in cell size, dimensions or origin, or when only one epoch's vertical scale resolves. The difference raster is exported only from a fully co-registered pair. Volumes use compensated sums, no comparable cells yields no value rather than zero, and the uncertainty band describes the raw net it accompanies.
- Checkpoint accuracy validates the per-stratum minimum and the output of a supplied uncertainty combination, refusing the record when either is unusable.
- The analysis receives whether the frame resolved a scale separately from the geometry factor, so the unit withholding above is reachable from the application; a placeholder factor of 1 had made it dead code on the live path.
- A comparison with no cell measured in both epochs reports that instead of a NaN volume and offers no raster; a geographic pair keeps its elevation differences.
- Re-resolving an unchanged coordinate system does not count as a frame change, so derived classifications, the terrain cache and the on-screen result survive an additive layer open; an invalidated derived classification is withheld from feature extraction.
- A terrain export from a placed layer publishes no origin rather than the layer's own.
- The kernel refuses impossible specifications instead of repairing them (cell size, percentile, ground-filter parameters, a classification that does not cover the cloud, an ASCII grid header that does not match its arrays), and the two evaluation kernels refuse unequal arrays rather than scoring the shorter one.
- An explicit trust of the source ground classification is refused when no class 2 points exist; no substitute filter runs.
- A two-epoch comparison honours a declared vertical scale on a geographic frame; the quality score judges the RMSE against its metre floor only on a resolved vertical scale and multiplies density by a cell area in the density's unit.

### Fixed

- A scan with no resolved linear unit states no metric figure it cannot measure. Withheld: the ground-return density and its USGS 3DEP floor comparison, the metre RMSEz, NVA and VVA on a map sheet, the complexity window and radius in ground metres, and the density threshold that caps readiness. The complexity summary now says the pts/m² threshold could not be applied; producing no caveat had read as clearing it.
- A stockpile preview read "± 41 m³ (1σ) · High confidence", the vocabulary of a calibrated interval. Its own claim register approves an exploratory preview with spatial correlation and base uncertainty unquantified: the sample term assumes independent thickness observations where returns are spatially correlated, and the base term is a heuristic spread that is zero for an explicit base. The band is named a model band and the grade states what it measures, the sampling.
- A TPI slope-position class read a non-finite slope as zero, which is the value that separates flat from middle-slope, so a cell whose slope never resolved could be labelled flat. It stays nodata.
- A lasso reclassify into a class the class filter was hiding landed the edit and hid its own result in the same frame, so the tool read as inert. The target class is revealed and the toast says the filter was opened. The user's other hidden classes stay hidden, and the derived-provenance caption survives the edit.
- The contour map sheet prints the build that drew it, in the footer, from the same provenance every other export stamps. A printed sheet could not be traced to the code that produced it.
- Moving the mouse over a parked scene changed its shading: pointer movement read as camera movement, so Eye Dome Lighting cut out and the pixel ratio dropped for a third of a second. Colour-mode switches, filter changes and canvas resizes did the same. Camera motion now carries its own signal, and walk and fly, which move the camera outside the orbit controls, are read from the camera pose each frame.
- Six modules each declared their own metre-to-foot factor, two of them rounded, so one length converted two ways depending on the surface that displayed it. A lint now compares conversion factors by value rather than by spelling.
- Adaptive precision banded on the raw float, so a value one unit in the last place below a decade gained a spurious significant digit and an exact 10 ft span read `10.0000 ft`.
- A focused resize grip resized its panel and orbited the camera at once, because the camera's focus guard recognised only input, textarea and select elements.
- The reclassify lasso painted above the panels and swallowed clicks meant for them.
- Object metrics measured in source units and labelled the result metres.
- Two tabs indexing heavy files at once could drop each other's cache-map entries, leaving a promoted store on disk that nothing referenced.
- The interior scan panel printed source-unit dimensions, areas and volumes as metres and feet when the unit was unknown.
- Measurement CSV and GeoJSON columns named `length_m`, `area_m2` and `volume_m3` on an unresolved unit are now `length_source`, `area_source2` and `volume_source3`; the dimensioned floor plan is refused and the grid recommendation withheld on the same condition.
- The epoch surface builder dropped the vertical unit factor, so a foot-vertical compound frame despiked at about 0.09 m instead of 0.30 m.
- Contour deliverables stated a unit and a grade that disagreed with the analysis that produced them.
- GeoTIFF fields that fit inline are written inline, and clip provenance is kept through the export.
- Slow touch gestures are kept, yaw rotates around world up, and ending a gesture cancels cleanly.
- The no-CDN loader options reach every parse call.
- Derived classes computed under a later-invalidated frame are withheld from a new analysis.
- The Coconino checkpoint artifacts state the universe they measure and agree with the register's DTM evidence level; the slope claim no longer records a border shortfall the corrected kernel and its matrix have closed.
- The DEM README, the contour deliverable and the readiness card labelled an unresolved unit as metres.
- A full three-axis epoch alignment on a compound frame applied the solved vertical shift in scaled rather than raw Z.
- The geographic grid recommendation multiplied relief by metres per degree and ignored the cosine of latitude.
- After a coordinate-system override the interior report and floor-plan buttons did nothing instead of refusing with a reason.
- `THREATS_TO_VALIDITY.md` and `DATA_AVAILABILITY.md` said the repository redistributes no external data while eight derived validation files are committed; both now distinguish raw clouds from derived crops, and `THIRD_PARTY_NOTICES.md` attributes each derived file, which CC BY 4.0 requires for the Estonian Land Board tile.

### Evidence

- No product changed evidence level. The register holds 34 claims: 2 at E1, 6 at E2, 9 at E3 and 17 at E4, with none at E5. The E5 work this cycle registers the Rogue tiles, makes the dev and holdout split deterministic and exposure-honest, and recomputes manifest invariants. The holdout has not been run.

## [0.6.7] - 2026-08-29

### Licensing

- OpenLiDARViewer is licensed under AGPL-3.0-only from this release onward. Releases through v0.6.6 were published under MIT and stay available under MIT; nothing already distributed changes terms. The move does not alter the license of any bundled third-party dependency or of any test or validation dataset, each of which keeps the terms it already carried. LICENSING.md, COMMERCIAL-LICENSING.md and docs/CLA.md record the current terms, the separate commercial option, and the contributor agreement.

### Added

- Heavy local files stream out of core. A very large uncompressed LAS and a chunked LAZ are indexed into temporary browser storage in the Origin Private File System and streamed from there, or refused with guidance when they cannot be, instead of being read whole into memory. A stratified preview sample renders at once and is marked incomplete until the full index swaps in behind it.
- 3D Tiles implicit tiling opens and streams. Quadtree and octree subtrees are read now, where an earlier release opened only an explicit tile hierarchy.

### Changed

- Five products reach `E4_CROSS_IMPLEMENTATION_VALIDATED` this cycle, taking the register from twelve to seventeen products at E4. Each was checked against an independent implementation on frozen synthetic or analytic fixtures; none is field accuracy against a surveyed reference, and no product reaches E5.
- `CRS-UTM-PROJECTION` reaches `E4_CROSS_IMPLEMENTATION_VALIDATED` as a new claim. A WGS-84 latitude and longitude projected to a WGS-84 UTM zone, hemisphere, easting and northing was checked against GeographicLib 2.7 and PROJ 9.8.1 over 36 frozen geodetic fixtures. Zone and hemisphere matched on all 36, including the widened Norway zone 32V and the Svalbard zones 31X, 33X, 35X and 37X; easting and northing agreed with both to under 1.5 mm, the largest differences being 4.531e-4 m in easting and 9.521e-4 m in northing. PROJ and GeographicLib agree with each other to 2.0e-9 m, so the residual is attributable to the candidate (study `CRS-UTM-PROJ-GEOGRAPHICLIB-THIRTYSIX-FIXTURES`). The datum is WGS 84 on both sides, so no datum transformation, PROJ grid, vertical reference or ECEF conversion is exercised; latitudes outside 80S to 84N are refused; and agreement with two implementations is not accuracy against a surveyed monument.
- `CHANGE-RASTER` reaches `E4_CROSS_IMPLEMENTATION_VALIDATED` from E2. Per-cell change was checked against GRASS 8.5.0 `r.mapcalc` over eight synthetic epoch pairs under protocol `PROTO-CHANGE-GRASS-MAPCALC`. Both sides select the same 3007 comparable cells, including a pair with holes in one epoch, and the largest relative difference is 7e-6 under a 1e-5 gate derived from Float32 storage (study `CHANGE-RASTER-GRASS-MAPCALC-EIGHT-PAIRS`). Only one-metre metre-CRS square-cell grids were compared; agreement on synthetic epoch pairs is not accuracy against surveyed field change; per-cell LoD95 is pending and co-registration error is absent by construction.
- `CHANGE-VOLUME` reaches `E4_CROSS_IMPLEMENTATION_VALIDATED` from E2. Integrated cut and fill volume was checked against GRASS 8.5.0 `r.univar` over the same eight synthetic epoch pairs, and against the closed-form integral each pair was built from, agreeing with both to within 1e-6 (study `CHANGE-VOLUME-GRASS-MAPCALC-EIGHT-PAIRS`). The same scope holds as for the raster, and change-volume uncertainty stays exploratory.
- `HOLDOUT-RMSE` and `NVA-VVA` reach `E4_CROSS_IMPLEMENTATION_VALIDATED` from E3. The internal holdout accuracy statistics were recomputed in base R 4.6.1 over six frozen residual vectors: bias, RMSE and max absolute residual agree to about 4.4e-16, and the 95 percent figure (1.96 times the pooled RMSE) agrees to about 8.9e-16 (studies `ACCURACY-RMSE-R-RESIDUALS` and `ACCURACY-NVA95-R-RESIDUALS`). The R leg establishes the computation, not accuracy: it confirms RMSE is the raw second moment and not a standard deviation, and that the multiplier is applied correctly. These are internal holdout diagnostics, so the held-out points share the source of the interpolated ones; this is not independent checkpoint accuracy and not ASPRS NVA/VVA compliance, and both claims still require E5. Median, NMAD and P95 are excluded from the R comparison because R interpolates quantiles at type 7 while the code takes the nearest rank.
- A memory-safety hardening wave, worked from an adversarial audit of the read paths. One shared decoded-byte budget now caps the LAZ chunk table, the LAZ chunks and windows, the LAS record batches, the COPC nodes and the out-of-core tiles together, so a malformed multi-gigabyte input is refused before it can allocate past that budget. The out-of-core store in the Origin Private File System is leak-free: every open takes a unique id, the store is promoted only inside the failure guard, each cancel or attach path either commits the store or deletes it, a short write is handled rather than left behind, and a startup janitor sweeps any store a previous session abandoned. First-node streaming admission reads the device it runs on, an over-ceiling non-streaming format fails closed, size caps were added to the batch converter and the metadata readers, and a truncated tile or source is refused rather than presented as a smaller complete scan.

### Fixed

- The profile PDF max-grade carries the sign the on-screen panel and the callout already show, so the exported sheet no longer contradicts itself.
- The Inspector elevation rows read the source vertical unit instead of assuming metres.
- Panel-rail observers that leaked are disposed.
- A degenerate profile no longer reports full coverage over zero returns.
- Closing the profile workbench restores the Analyse panel, so its contour controls no longer disappear with it.

## [0.6.6] - 2026-08-22

### Added

- An opt-in terrain-aware mode for cartographic contour generalization. Where the shipped pass applies one simplification tolerance to every line, terrain-aware scales that tolerance per feature from what the feature is: interpolated or low-confidence support, and small closed summits and depressions, keep more of their shape, while long strongly-measured lines generalize at the full tolerance. The per-feature factor is clamped so it can only ever make a line more faithful than the uniform pass, so the chosen tolerance remains the bound on every line, and the honesty-gated simplifier still refuses to drop a gap or low-confidence vertex under either mode. Exports record which pass ran, `olv.contour.generalize.terrain-adaptive@1` or `olv.contour.generalize@1`. Uniform stays the default, so contour geometry is unchanged for every existing purpose unless the mode is selected.

- Contours draw over the point cloud in the 3D scene as a derived layer, with panel controls for visibility, index emphasis, opacity and vertical lift. Solid and dashed support differ by colour and alpha rather than dash pattern, and a segment crossing a data gap is not drawn, so a drawn line never spans unmeasured ground. Re-analysis regenerates the layer in place and closing its source scan removes it. Each layer carries the digest of the analysis receipt that produced it, built through the provenance path exports already use. Receipts for the other analytical products need analysis-time provenance and are not included.
- An opt-in resident-stickiness pass for the streaming selector, enabled with `?stickiness=on`, which holds an already-resident node against a marginally better competitor to reduce swap churn at the point-budget boundary. A node with a finer candidate beneath it in the same tick competes on its raw score with no bonus, so retention cannot stall refinement. The default is unchanged and reproduces the v0.6.5 selection exactly; the option is not yet measured in a browser.
- A Work workspace mode that gathers the scene-work tools in one place, an Output panel that consolidates every export behind one surface, and a slimmer Streaming panel whose saved views moved to the Inspector. Process Studio reports live product status and can be docked from the command palette.
- Layer groups in the Layers panel. A group is a named, collapsible set of layer ids with visibility, solo, rename, collapse, select and a member picker. Each action writes through the existing `LayerService` calls one layer at a time, so a group never holds a second copy of visibility. Membership persists by stable layer id and is additive within session schema v8, so files written before groups existed load unchanged.
- An inspection issue workflow on annotations: a severity (low, medium, high, critical), an open or resolved status, and an observation date, with an issue list ordered worst first and a roll-up of what is still open. Resolved reads "marked resolved" throughout, because the viewer records the status and does not verify that anything was fixed. Severity is carried by a glyph and a word as well as by colour.
- One Speed to Quality performance control in the top bar, with an Auto position and an Advanced disclosure that keeps every underlying knob individually settable. It drives the streaming preset, the resident point budget, concurrent decodes, the device-pixel-ratio ceiling, Eye Dome Lighting and antialiasing. It does not touch the static load budget, which voxel-reduces the cloud that terrain analysis, measurement and export all read, so no slider position changes the computation applied to a given point set. On a streamed scan it does change the resident-point budget, so a resident-only measurement, analysis or export reads whatever is resident when it runs.
- A project-wide elevation colour scale, opt-in and applied per frame, so two scans in one project can share a range instead of each stretching its own.
- Krovák (EPSG:5514) ingest, iPhone PDRF7 reading, and footprint reprojection for any proj4-defined projected CRS rather than UTM alone. The Krovák definition uses a seven-parameter Bursa-Wolf shift, which agrees with authoritative PROJ to about 5 cm where the naive three-parameter shift is roughly 10 m out.
- Parsers for 3D Tiles `tileset.json` and PNTS, a local out-of-core read planner, and a cross-CRS project placement planner.
- Tie-point rigid registration with control-network validation, and a single planar ICP solver that the registration model now selects directly instead of refusing the planar case.
- A derived-layer model and store, a feature-extraction service over the building and conductor cores, a scientific receipt serializer over the analysis record, and a product executor registry: a foundation that invokes a registered compute core through `ProcessService.runIfAuthorized`, preparing one fail-closed execution seam. Production product routes do not pass through it yet, so it constrains nothing on its own in this release.
- Classifier v3: a structural-verticality cue and a wall-rescue pass.
- A Plan view: a top-down orthographic working view reachable from a chip in the navigation bar's Views row and from the command palette. Entering captures the mode and projection first, so leaving restores the scene as it was rather than as plan mode rewrote it, and aiming the camera elsewhere or turning the projection off drops the claim instead of holding a stale one.
- Tool preflight in Process Studio. A product or measurement tool that is blocked or review-only now says which condition limits it and offers the shortest action that lifts it, and the measurement tools gained a readiness surface they did not have. Conditions that no control can lift, such as waiting for coverage, read as guidance rather than as a button that does nothing.
- Absolute-accuracy evidence from surveyed reference spheres, gating the measurement leg and recording the findings that did not clear it.

### Changed

- The DSM, DTM and CHM surface products reach `E4_CROSS_IMPLEMENTATION_VALIDATED`. The DSM and DTM grids were each recomputed and compared against a committed PDAL 2.10.2 `writers.gdal` reference over three seeded synthetic clouds, agreeing over 7,500 cells to a maximum difference under 4×10⁻⁶ m within a 0.05 m registered tolerance (studies `DSM-PDAL-WRITERS-GDAL-CELL-CENTRED` and `DTM-PDAL-WRITERS-GDAL-CELL-CENTRED`); the CHM (clamped DSM minus DTM) agreed with the PDAL max grid minus the PDAL min grid over 7,500 cells to under 8×10⁻⁶ m within a 0.1 m registered tolerance (study `CHM-PDAL-WRITERS-GDAL-DIFFERENCE`). The check covers the cell gridding: the reference radius is below half a cell, so it does not exercise ground classification (`GROUND-FILTER` stays partial) or real-terrain void interpolation, and the DTM's required bar remains E5.
- The `TPI` and `VRM` terrain descriptors reach `E4_CROSS_IMPLEMENTATION_VALIDATED`, splitting the former combined `VRM-TPI` claim. Each is checked three ways against an independent tool AND the closed form on an analytic fixture designed to control the confound: `TPI` against gdaldem 3.13.1 over 3364 interior cells to under 9×10⁻⁷ within a 1×10⁻⁵ tolerance, on a low-amplitude quadratic (so the reference's float32 mean accumulation stays below tolerance); `VRM` (Sappington et al. 2007) against SAGA 7.8.2 over 3136 interior cells within a 1×10⁻⁴ tolerance, on a smooth tilted quadratic (so Horn's normal and SAGA's estimator converge), reproducing the closed-form Sappington VRM to under 1×10⁻⁹ (studies `TPI-GDALDEM-ANALYTIC` and `VRM-SAGA-ANALYTIC`).
- The cross-section profile (`MEAS-PROFILE`) reaches `E4_CROSS_IMPLEMENTATION_VALIDATED`, its required level. No single tool exposes a corridor percentile over a point cloud, so the reference is assembled from two: OGR/SpatiaLite 5.1.0 places every point on the section line (`ST_Line_Locate_Point`, `ST_Distance`) and R 4.4.1 `quantile(type = 7)` reduces each station, with the corridor query passing elevations through as text so neither side re-prints a number the other reads. Over 751 stations across three parameter sets the largest difference is 3.6×10⁻¹⁵ m against a 1×10⁻⁶ m tolerance registered before the reference existed, per-station corridor counts match exactly, and the four deliberately empty stations read as gaps on both sides. One of the two fixtures also carries a closed form, because ten corridor elevations in an exact arithmetic progression reduce without a sort, and both sides reproduce it exactly (study `MEAS-PROFILE-OGR-R-CORRIDOR`). Both fixtures are synthetic and hold every point clear of a bin boundary and of the corridor edge, so the tie-breaking there is untested and nothing here is accuracy against a surveyed section.
- `CHANGE-VOLUME` reaches `E2_ANALYTICALLY_VERIFIED`. Cut/fill volumes are checked against integrals solved on paper over analytic surface pairs: parallel planes at a fixed separation (area times separation, bit-exact), a plane tilted about the footprint centroid (same volume, since cell-centre quadrature is exact for a linear surface), a quadratic dome whose cell-centre sum and true integral differ by the closed-form defect k·L²s²/6 (so halving the cell size quarters the error), a cone against πR²H/3 and against its own level-of-detection truncation, a saddle whose lobes cancel, and a surface differenced against itself. The oracle enters at the grid pair, so it covers the integration and not the DTM build feeding it.
- `UNCERTAINTY-BAND` reaches `E2_ANALYTICALLY_VERIFIED`. The band is checked against the scaling laws its documented error model implies rather than against its own formula: the random term grows as the square root of the changed-cell count while the systematic co-registration term grows linearly with it, so relative error falls as 1/√N under survey noise and does not move at all under a registration bias. A single cell that just clears the level of detection sits exactly at the band's 95% detection threshold in volume terms, tying the two modules to one convention.
- E57 ingestion (`E57-INGEST`) reaches `E4_CROSS_IMPLEMENTATION_VALIDATED`. The decoded cartesian coordinates, namespaced surface normals and colour of a public CC-BY terrestrial scan were compared against PDAL 2.10.2 `readers.e57` over all 1,788,994 points and nine dimensions, as an exact quantised integer sum at a 1×10⁻⁶ quantum: a single point wrong by one micrometre fails the comparison instead of being absorbed into a mean. Every dimension agreed exactly (study `E57-INGEST-PDAL-CROSS-DECODE`). Intensity sits outside the comparison because PDAL rescales it by 65535/(max − min) without subtracting the minimum, so the two sides report different numbers for the same file. The scan is a CloudCompare re-export rather than a scanner-native write, so vendor extension blocks, multi-scan files and spherical coordinates are untested. Twelve products are now at E4.
- The terrain and measurement algorithms changed in this cycle. What changed is stated in Fixed below: the scan-shape aspect denominator, the reported dimensions of a scanned space, unit handling across the measurement and classification chains, the ICP overlap refusal, the change-volume band, and the USGS Quality Level floor. The contour generalization mode added above is opt-in and off by default, so contour geometry is unchanged for every existing purpose unless the mode is selected. The interactive surfaces added this cycle are listed in Added above.

### Fixed

- The USGS 3DEP Quality Level table read a QL3 density floor of 0.25 pts/m². The published floor is 0.5, so a survey between the two was awarded QL3 at half the required density. QL0, QL1 and QL2 were already correct. Datasets in that band now read below-QL3.
- Hiding the navigation legend took the view controls with it. Top, Front, Side, Iso and the orthographic toggle exist nowhere else in the app, and the dismissal is persisted, so hiding the help text removed them permanently and across sessions. The legend and the view rows are now separate regions.
- A cluster of unit-correctness defects: WKT2 `LENGTHUNIT` is parsed for linear and vertical units; the measurement chain scales vertical and volume quantities by the vertical unit; SMRF ground tolerances and classifier parameters are physical and converted at the boundary; camera flatness and project-card sizes read height off the up axis.
- A surface ICP fit with too little overlap is refused rather than reported, and a net volume is qualified with an uncertainty band.
- The reported L x W of a scanned space came from a rectangle whose direction was taken from the covariance eigenvectors of the footprint. A square room and a round one have no dominant direction, so sampling noise chose it and the rectangle drifted toward the diagonal: an 8 by 8 metre room read between 8.51 and 11.31 metres across twenty samplings of the same geometry, and a 29 by 14 room read 15.25 wide. Both sides now come from the smallest rectangle enclosing the footprint, the same one the scan-shape routing measures, so the panel and the router describe one rectangle and a room reads the same on every scan of it. The square room reads 8.00 and the 29 by 14 room reads 14.00.
- Classification reads review rather than ready when the source unit is unknown, and a resident-only surface reads review rather than blocked.
- Streaming corrections: in-flight decodes get eviction hysteresis and the budget counts decoded-pending nodes; a partial stream stays resident-only beside a static cloud; the streaming panel no longer reads ready with decoded-pending nodes.
- The Clip panel is reachable on mobile, the app lands on Data mode before render rather than after `openScan` resolves, and the layer Remove button is no longer overlapped by the workspace scrollbar.
- One font policy across all panels, enforced by a lint, with the Analyse and Streaming panels snapped to the type-scale tokens.
- A two-epoch change volume with no error budget at all is no longer reported as certain. Both terms of the band are built from caller-supplied numbers, so a level of detection of 0 with no co-registration RMSE collapsed the band to ±0, which cleared every threshold in the module and graded the least supported result available as detectable at 0% relative error and high confidence. An empty budget now reports as unquantified, and the compare panel says the ±0 band bounds nothing and names what to supply. A comparison with no changed cells is handled the same way.
- `ScanShape.aspect` divided the vertical extent by the longer side of the axis-aligned horizontal bounding box, which is a property of the source CRS axes rather than of the scan, so one scene read 0.17454 unrotated and 0.12446 at 45 degrees. Three comparisons against two thresholds route terrain on that value, so a scan near a threshold routed on how it happened to be oriented on disk. The denominator is now the longer side of the minimum-area rectangle enclosing the horizontal outline, which reproduces the axis-aligned extent on an axis-aligned footprint and gives 2r on a disc, so both thresholds keep their meaning. The value now holds through a sweep of angles and is exact on the four quarter turns. A hull of more than 512 vertices, which a densely sampled convex outline such as a silo wall or a scanner's outer ring produces, has the rectangle scan measure a uniformly spaced subset of it, and that subset is anchored to the hull's first vertex, so the measured size can still move by up to 1.9e-5 under rotation there; at or below 512 vertices the hull is measured whole. Every fixture keeps its kind, spaceKind, nonTerrain, up and confidence, and the largest aspect movement is 2.0 per cent. The `extent` field is untouched and still follows the axes.
- A projected CRS whose GeoTIFF keys carry no ProjectedCSCitationGeoKey (3073) was named from the systematic WGS 84 UTM ranges or, failing those, from the bare EPSG code, so a file on another datum lost the datum from its name: `utm15.las`, written by libLAS 1.2, read as `EPSG:26915` rather than as UTM zone 15N on NAD83. The projected display name now resolves in order: 3073, then the curated registry label for the EPSG code, which carries the datum, then the systematic WGS 84 UTM naming that covers all 120 zones including the ones the registry does not list, then GTCitationGeoKey (1026), then the bare `EPSG:<code>`. That file now reads `NAD83 / UTM zone 15N (EPSG:26915)`. 1026 ranks below both code-derived names because it guarantees only free text for the CRS the file is in, so a 32615 file whose 1026 read `NAD83` would otherwise print a geographic datum name over a metre grid. A WKT VLR outranks all five, an empty or whitespace-only 1026 falls through, and a geographic CRS still uses its own geographic citation.
- The LAS and LAZ stride sampler drew its jitter across the full step and clamped an overshoot onto the last record, so the final short bucket over-weighted that record: at count 11 with step 3 it took two thirds of the bucket's probability rather than one third, and at count 10 with step 100 it was drawn about nine times in ten. The draw is now across the records the bucket holds, so every record in every bucket is equally likely.
- An E57 CompressedVector holding zero records was refused. libE57Format closes such a section with an 8-byte data packet that declares no bytestreams and carries no length table, which failed the check that a packet declares one bytestream per prototype field. A packet declaring no bytestreams in a section declaring no records now ends the walk and every prototype column decodes to length 0. A packet that declares bytestreams still has to declare one per prototype field, and a section that declares records still has to supply them.
- EPT attribute widths were checked against one set of 1, 2, 4 and 8 bytes without reference to the declared type, so a field declaring `float` at 1 or 2 bytes reached the unsigned-integer branches of `readAttr` and returned an in-range wrong number with no error; on X, Y or Z that is a coordinate that looks valid. IEEE-754 has no 1-byte or 2-byte binary format, and widths are now keyed by type: `signed` and `unsigned` take 1, 2, 4 or 8, `float` takes 4 or 8. A present but malformed `scale` or `offset` was also treated as absent, so a manifest declaring a scale of 0.01 as a string decoded that axis at scale 1. Absent still takes the decoder default; present must be a finite number.
- Three 3D Tiles fail-opens. A `boundingVolume` declaring more than one of box, region and sphere produced a merged object, so the tile took whichever form the code read first; the declared key count is now checked before per-shape validation. A tile declaring a `refine` that names no strategy the specification defines silently took its parent's value, and a non-string `refine` raised a TypeError out of `toUpperCase` rather than a parse error; both go through one helper now, and an absent `refine` still inherits. A malformed `RTC_CENTER` in a PNTS feature table was downgraded to no centre, which placed a georeferenced tile at its local origin because POSITION is tile-local; it must now be three finite numbers, and absent still reads as no centre.
- `window.__OLV_TEST_API__` was mounted behind a runtime check on `?test=1` alone, so every shipped bundle carried it. Same-origin policy stops another page reading it, but a script already on the viewer's origin gained a stable surface that can place measurements and rewrite classifications, and those figures reach an exported integrity report whose digest signs them. The seam is now gated on a build-time constant, true for the dev server and for a build run with `OLV_TEST_SEAM=1`, which is what the Playwright webServer sets. Every other build substitutes false and the minifier drops the block, so the string `__OLV_TEST_API__` appears in no file under `dist`, and `?test=1` there parses as before and mounts nothing.
- `IDENTITY`, the base of every `TransformStore` stack, was exported unfrozen, so `readonly` bound at compile time only and a cast could redefine the original placement for every layer at once. It is frozen through the rows, since freezing the outer object leaves them writable.

## [0.6.5] - 2026-08-14

### Added

- A Process Studio panel in the left rail that reports what a loaded scan can safely produce (DTM, DSM, contours, building footprints, cross-epoch change, volume), each as `ready`, `review`, or `blocked` with a plain reason, alongside the adaptive processing stages and independent quality checks. It reads the same capability model the exporters read, so the panel and a real export never disagree, and it fails closed on an unconfirmed unit or a missing vertical reference.
- A feature-extraction core that turns classified building points into footprint candidates (occupancy grid, connected components, boundary trace, Douglas-Peucker simplification, dominance-gated orthogonalisation), exported as RFC 7946 GeoJSON marked as derived candidates, plus a conductor primitive that fits a centerline and a quadratic sag to linear point sets.
- A registration core: a Kabsch/Horn rigid solve, a trimmed general ICP, tie-point alignment, and a non-destructive Float64 transform store.
- Absolute-accuracy terrain evidence against surveyed checkpoints at two public USGS sites (Marsh Island, 101 checkpoints at 2.8 cm RMSE; AZ Coconino, a forested checkpoint at 3.9 cm), a slope cross-check on real steep Coconino terrain, and a ground-filter cross-check against PDAL on real low-relief Estonian terrain.

### Changed

- Multi-layer mounting is enabled. Two georeferenced layers that declare the same projected CRS place into one shared frame at their real separation, non-destructively; the Float64 per-layer-frame migration keeps every boundary reading the world coordinate in the frame it names.
- Contours are promoted to E4 with a GDAL `gdal_contour` cross-implementation check on a frozen analytic plane (agreement to 2.9e-5 m).
- Remote streaming is hardened: signed URLs are scrubbed from error messages, every range read is bounded in bytes and time, the remote object's identity is pinned across a load, and a streaming scan carries a stable shell id.

Full notes: [RELEASE_NOTES_v0.6.5.md](docs/releases/archive/RELEASE_NOTES_v0.6.5.md)

## [0.6.4] - 2026-08-07

### Added

- A building ground-support gate for classification (`buildingMinSupport`,
  default 0.66, in `src/render/class/deriveClassification.ts`). A candidate
  roof classifies as a building only where the ground beneath it is measured
  above the threshold, so scan-edge void artifacts are dropped while real
  buildings on fully measured ground are kept. `docs/validation/building-support-gate-eval.md`
  records a synthetic evaluation: on one labelled corpus the gate removes 480
  of 528 artifact roof points and keeps every real-building point.
- A standalone Auto-classify button in the Edit-classes panel, so
  classification runs on demand rather than only on load.
- `llms.txt` and `robots.txt` for automated-reader discoverability.

### Changed

- Automatic classification is return-number aware: a multi-return point is
  treated as vegetation rather than as a single hard surface.
- Auto-classify keeps the scan's natural colour instead of forcing the class
  palette, so a run no longer overwrites an RGB display the user chose.
- The Contour Studio purpose selection threads into the map-sheet PDF, and the
  purpose picker is compact with each option's description shown on hover.
- Four report and UI surfaces fail closed on an unknown CRS linear unit rather
  than presenting a length in an unstated unit. Annotation `worldPosition` is
  populated and the report frame is labelled.
- Remote COPC streaming replacement is transactional (gate F4): a failed swap
  no longer leaves the previous session partly torn down.
- The mobile GUI is restyled to match the console layout used on desktop, and
  the README is decluttered and leads with a hero image.

### Fixed

- WebGPU falls back to WebGL 2 when no adapter is present, which fixes an open
  crash on iOS WebKit.
- The classifier worker chunk is emitted in the obfuscated build, so on-demand
  classification loads on the shipped artifact.
- The contour-readiness card renders its value on one line instead of stacking
  it into a vertical column.

### Maintenance

- Multi-layer mounting is disabled (`MULTI_LAYER_MOUNT_ENABLED = false`) while
  the per-layer frame fixes land, and the flag is guarded so the shipped state
  cannot drift on.
- Streaming session assembly moved behind a `StreamingHost`, and the report and
  scan-open paths moved behind structural dependency objects, continuing the
  `Viewer.ts` decomposition.
- Loose documents at the repository root moved into `docs/project` and
  `docs/releases`.

## [0.6.3] - 2026-08-01

### Added

- Build provenance attestation for release archives and the SBOM. The release
  workflow signs a SLSA provenance statement through Sigstore, binding each
  archive to the workflow run and commit that produced it. Verify a downloaded
  archive with `gh attestation verify <file> --repo Aurtechmx/openlidarviewer`.
  This applies from the next release onward; assets published for v0.6.2 and
  earlier carry no attestation, and `release:verify` remains the check for
  those.

### Changed

- Mutation testing moved out of the tag-time gate. It ran roughly two hours of
  the v0.6.2 release gate's 2 h 20 m, against three numeric modules, and forced
  the gate job's timeout from 90 to 300 minutes. It now runs weekly and on
  demand in `.github/workflows/mutation.yml`. The release gate's timeout is
  back to 60 minutes, which is the twenty minutes the remaining stages measured
  plus headroom.
- The release record cites the mutation result instead of reproducing it.
  `mutation` left `MANDATORY_RELEASE_STAGES` and joined a new
  `DEFERRED_RELEASE_STAGES`. A deferred stage is always written into the record
  as `not-executed` rather than left out, and the record carries the score, the
  break threshold, the commit the score was measured at, and the workflow run
  that produced it. `coversReleaseCommit` states whether that commit is the
  release commit; where it is not, the record and the manifest say so instead
  of implying currency. Evidence schema version 2 becomes 3.
- A release record with no mutation result to cite, or one whose cited score
  sits under the `break: 75` threshold, is refused. `release:verify` repeats
  both checks against the shipped assets. It also gained an `advisories`
  channel for statements that are true without being defects, such as a cited
  score that predates the release commit.
- `scripts/collect-mutation-evidence.mjs` recomputes the score from Stryker's
  JSON report and re-checks the threshold, so a regression fails the scheduled
  run even where the runner's exit code is lost.

### Notes

- `docs/validation/mutation-evidence.json` is produced by the Mutation
  workflow; the repository does not ship a seeded copy, because there is no
  honest way to write one without running the measurement. Dispatch that
  workflow once before the next tag, or run the release gate with
  `OLV_GATE_MUTATION=1`, which runs the stage inline and cites the release
  commit directly.

## [0.6.2] - 2026-07-27

A validation-and-correction release. Twelve validation suites were added, covering
reproducibility, scaling, cross-platform portability, GPU-versus-CPU backend
equivalence, failure recovery, provenance integrity, contour correctness, LAS
round-trip fidelity, unit integrity and archive portability. Eighteen defects
are fixed. Twelve were exposed by a validation suite; six came from code review,
five of those carried from the v0.6.1 vertical-unit audit. Seventeen were missed
by the test suite as it stood at v0.6.1, which passes on the defective code. The
eighteenth cannot be evaluated against that suite, because the module carrying
two of its three faults did not exist then. Per-defect records are in
`validation/defects/defect-registry.json`.
The evidence ceiling moves from one cross-implemented product to
three, with aspect and hillshade joining slope at E4 against GDAL 3.13.1 on the
shared analytic DEM. The reproducibility comparator and its two-platform CI
matrix, darwin-arm64 and linux-x64, are in place, and the two-platform result is
tracked at `docs/validation/evidence/portability-v0.6.2/`: identical
science-scoped output on both platforms from the same seeded fixture, 15 artifact
hashes and 18 scalars at zero tolerance with none differing. That covers two
little-endian platforms, one commit and a synthetic fixture; Windows, big-endian
hosts and real scan data are outside it.

Four defects reached published v0.6.1 output. `docs/release/ERRATUM_v0.6.2.md`
states, for each, what the software did, which outputs carry the error and what
recovers a correct figure. Open limits are in `KNOWN_LIMITATIONS_v0.6.2.md`.

### Fixed

- **The RFC 7946 contour GeoJSON states its third ordinate in metres.**
  `toGeoJSONWgs84` (`src/terrain/contour/geojsonContours.ts`) wrote the DTM
  elevation into the third position element at its source value, so a foot
  vertical unit beside a WGS 84 ellipsoidal datum shipped 100 ft where RFC 7946
  section 3.1.1 requires metres. The ordinate now carries the metre equivalent,
  converted through the resolved vertical factor, and `metadata` records
  `elevationOrdinateUnit: 'metre'`. A factor that is unresolved or not positive
  drops the geometry to 2D with an `elevationNote` naming that cause, rather
  than asserting metres about a number of unknown unit. Every feature keeps
  `elevation`, `elevationUnit` and `elevationDatum` in the source unit.
- **A contour set declares the interval it emitted.** An over-fine request is
  thinned against the 200-level cap, but `intervalM` kept reporting the value
  that was asked for, so the GeoJSON `metadata.intervalM`, every feature's
  `interval` property and the index-contour classification all described a
  spacing the file did not have. `intervalM` is now the emitted spacing
  everywhere it appears, and the request survives beside it as
  `requestedIntervalM` — in the set, the export model, the GeoJSON metadata and
  the provenance op. Regeneration paths (the map-sheet interval picker, the
  Studio re-export) read the requested value, since they re-run the pipeline.
- **A flat surface says it is flat.** A constant grid returned one level with
  zero segments and no warning, so nothing downstream could tell a flat surface
  from a computed contour set without counting geometry. A set that produces no
  segments now states the reason, in the same shape the all-gap path uses:
  flat, an elevation range that falls between two adjacent levels, or no
  crossing cells.
- **The contour deliverable's GeoTIFF states its vertical unit.** The
  deliverable wrote `VerticalCSType` (GeoKey 4096) without `VerticalUnits`
  (4099), so the same DTM raster was ambiguous between metres and feet when it
  came from Contour Studio and unambiguous when it came from the DEM package.
  Both paths now derive the key through one shared helper. This closes the
  limitation recorded for v0.6.1.
- **The asynchronous and GPU derivative path carries the vertical-unit
  factor.** The async derivatives entry, the GPU kernel and the f32 reference
  took no `zScale`, so a foot-vertical grid came back about 3.28x too steep on
  every path except the synchronous one the pipeline uses today. The
  equivalence probe ran both sides at `zScale` 1 and could not see it; it now
  runs a foot-vertical pass as well. This closes the limitation recorded for
  v0.6.1.
- **`geodesicFill` walks in metres.** The step cost added a horizontal step in
  raw source units to a rise in vertical units. On a degree grid the step was
  about 1e-5 beside metre heights, so the cost went essentially vertical-only
  and the down-weighting of a walk over a ridge degenerated. The step now comes
  from the same per-axis metre conversion the slope stage uses, and the rise is
  converted too. This closes the limitation recorded for v0.6.1; see the
  correction below for its real scope.
- **The unused elevation-grid hillshade wrappers are deleted.**
  `computeSlopeDegrees` and `computeHillshade` hard-coded square cells, skipped
  the cos(latitude) correction and defaulted the vertical scale to 1. No
  production code called them. The live pipeline runs `hornSlopeAspect` with
  per-axis metres and a vertical factor and shades from the result; the truth
  tests now exercise that live two-step path. This closes the limitation
  recorded for v0.6.1.
- **The despike blunder floor is measured in metres.** `minDeviationM` is a
  metres constant, but the heights it was compared against are in native source
  units, so the 30 cm floor acted as 30 cm only on metric data. On a
  foot-vertical scan it meant 0.3 ft, about 9 cm, so the floor was about 3.28x
  too aggressive: real sub-30 cm terrain features were removed and silently
  re-interpolated. The removal count reached provenance, so two deliverables of
  one scan could disagree about how much data was cut.
- **The PDF report footprint reads a Y-up scan on the right axes.** The PDF path
  fed raw X/Y/Z bounds into `footprintMetres`, which assumed Z-up. A PLY, OBJ or
  glTF scan therefore printed its height as Depth, divided the point count by a
  vertical cross-section, and put the vertical unit factor on a ground span. The
  on-screen Scan Report has swizzled by `isZUpFormat` since it was written, so
  the two disagreed on every mesh-format scan. See the erratum for the figures a
  v0.6.1 report carries.
- **The streaming header box converts to cubic metres before density is
  tiered.** The static refresher scaled the bounding box by the CRS unit factors
  before the per-cubic-metre bucketing; the streaming one, a few lines below it,
  passed the raw header extents through. A foot-CRS tile's box is 35.31 times
  larger in source units, so one scan graded "sparse" streamed and "moderate"
  loaded statically.
- **A LAS 1.4 file keeps its vertical datum when it carries WKT plus GeoKeys.**
  `parseCrsFromVlrs` returned the WKT CRS and discarded the GeoKeyDirectory.
  This application's own 1.4 writer puts the vertical datum and vertical unit in
  those keys beside a horizontal-only WKT, so a NAVD88 height in feet came back
  with no vertical unit and the terrain tools fell back to metres. The WKT still
  owns the horizontal frame and any vertical axis it declares; only the vertical
  fields it leaves empty are filled from the keys. See the erratum.
- **A declared linear unit that cannot be resolved reads as unknown, not as
  metre.** `crsFromGeoTiff` resolved a `ProjLinearUnits` code outside
  9001/9002/9003 to metre with a factor of 1, so a file declaring British foot
  measured 3.28 times wrong and was indistinguishable from a file declaring no
  unit at all. A declared code the software cannot honour is now tagged unknown,
  which the downstream unit gates read to withhold the label; an absent key
  still takes the format default. See the erratum.
- **Three quantities stop being reported as measured when nothing was
  measured.** `spaceMetrics` sized its occupancy grid with a 1 metre placeholder
  cell on an axis with no extent and then multiplied that placeholder out as
  floor area, so a cloud of coincident points came back with 1 m2 of floor, 40
  points per m2 and a mean spacing of 0.158 m. The placeholder still divides and
  no longer contributes area. The PDF report returned a grade of 0 for a slope
  with no horizontal run, stating a level grade for a vertical face while the
  live overlay called the same two points "vertical"; it follows
  `gradePercentOf` and prints the same word. `formatLinear` had no finiteness
  guard and printed "NaN cm" where `formatVolume` in the same file already
  returned an em dash.
- **A prototype key is refused as a method id.** `METHOD_REGISTRY['__proto__']`
  and `['toString']` resolve on the prototype chain, so `method()` returned a
  truthy non-entry and `methodRef()` handed back `{id: undefined, version:
  undefined}`. Two different unregistered ids composed to one method tag and one
  record fingerprint. The own-property check the registry already had in
  `isMethodId` now governs both lookups.
- **The benchmark result verifier sees the files it publishes.** `toHashable`
  built its output on a plain literal, so assigning a `__proto__` key
  re-parented the object instead of creating an own property and the key
  vanished before hashing; two artifacts differing only there hashed the same.
  The verifier also checked only that every listed file is present, never that
  every present file is listed, and never re-derived the two artifact JSONs it
  publishes, so an entry removed from the listing took its file out of the
  digest check and an edited hash table with a refreshed digest passed.
- **The contour GeoJSON carries the run warnings and the canonical limitation
  wording.** The merge rule "model-derived keys win" applied to `warnings` too,
  so a run whose provenance carried a warning shipped a GeoJSON declaring an
  empty list while every text stamp of the same run printed it. The file now
  carries the de-duplicated union of both sources, model order then provenance
  order, which is stable because these artifacts are hashed. The writer's own
  copy of the not-survey-grade sentence is gone; it reads `NOT_SURVEY_GRADE_NOTE`,
  so a GeoJSON reader and a DXF, SVG or README reader get the same string.
- **A LAS file names the build that produced it.** The 32-byte generating
  software field was the fixed literal `OpenLiDARViewer converter`, so a LAS file
  could not answer which version or commit produced it while every other export
  could. It carries the product name, the release and the short commit, composed
  longest-first and accepted only when a candidate fits whole. A prefix of a
  commit hash names a build that does not exist, so the commit is dropped entire
  rather than truncated, an unresolved commit is never written, and when
  `+dirty` pushes the string past 32 bytes the commit goes with the marker.
- **The source archive no longer ships release pages whose include target is
  excluded.** Each `docs-site/releases/v0.4.x` and `v0.5.x` page is a bare
  `@include` of a `RELEASE_NOTES` file that `.gitattributes` already excludes, so
  the archive carried 15 pages that resolved to nothing. The sidebar reads the
  releases directory, so it follows the pages.

### Corrected

The four entries below correct statements or output published in v0.6.1.
`docs/release/ERRATUM_v0.6.2.md` carries the full text, including who is
affected and what recovers a correct figure.

- **Correction to `KNOWN_LIMITATIONS_v0.6.1.md`: the `geodesicFill` unit-mixing
  defect affected production surfaces.** That document states the defect
  "affects the non-default geodesic interpolation mode only; the default fill is
  unaffected". That is wrong, and it understated the defect.
  `src/terrain/ground/surfaceFromRaster.ts` sets `LIVE_INTERPOLATION` to
  `'geodesic'` and `src/terrain/contour/analyseContours.ts` reads it on the live
  path, so geodesic is the fill that built every DTM surface the application
  produced, not an optional mode. Which surfaces changed value is narrower than
  which used the path: the inverse-distance weights are normalised, so a single
  common factor cancels and a projected metre-over-metre or foot-over-foot frame
  interpolates identically before and after. Geographic (degree) frames and
  compound frames whose vertical unit differs from the horizontal one do change,
  because two different factors do not cancel.
- **Correction to v0.6.1 PDF reports: Depth and density are wrong for Y-up
  formats.** `footprintMetres` read a Y-up cloud's extents as Z-up, so every PDF
  report from a PLY, OBJ or glTF scan printed the height as Depth and divided
  the point count by a vertical cross-section. On a 30 by 40 m footprint 8 m
  tall with 120,000 points, Depth read 8 m against 40 m and density read 500
  pts/m2 against 100, a fivefold overstatement; on a compound CRS the vertical
  factor landed on a horizontal span and Height read 12.192 m against 2.4384 m.
  The on-screen Scan Report was correct throughout.
- **Correction to v0.6.1 measurements from a CRS declaring an unresolvable
  linear unit.** A projected CRS carrying `ProjLinearUnitsGeoKey` outside
  9001/9002/9003 resolved to metre with a factor of 1, so `toMetres(100)`
  returned 100 where roughly 30.48 is correct for a British-foot CRS, and the
  file was indistinguishable from one declaring no unit at all. v0.6.2 resolves
  such a code to unknown, which makes the file refusable rather than
  convertible: figures already produced from one are not repaired by reopening
  it.
- **Correction to v0.6.1 results computed from a LAS 1.4 file this application
  wrote.** `parseCrsFromVlrs` discarded the GeoKeyDirectory whenever a WKT was
  present, and the 1.4 writer puts the vertical datum and unit in those keys
  beside a horizontal-only WKT. `verticalEpsg` and the vertical unit read back
  as undefined, so a NAVD88 height in US survey feet was taken for metres, 3.28
  times wrong, and every elevation, contour interval, slope figure and cut/fill
  volume derived from it inherited that. The files on disk are correct; the loss
  was on read.

### Changed

- **The aspect raster is cross-implementation validated (E3 → E4).** Our Horn
  aspect was compared against GDAL 3.13.1's Horn aspect on the same frozen
  analytic DEM the slope reference uses, and against the surface's closed-form
  gradient. All three agreed to within 0.0002 degree over 10,932 interior cells,
  inside the 0.5 degree tolerance registered before the reference was generated.
  The GDAL raster, the command, the tool version and the checksums are committed
  under `tests/fixtures/reference/aspect/`. Aspect is compared as a bearing
  (circular difference) and only where the closed-form slope exceeds 2 degrees,
  because a level cell has no aspect: GDAL writes NODATA there and our kernel
  returns 0, which is a real direction. No algorithm changed; this is a change
  in what the evidence supports.
- **The hillshade raster is cross-implementation validated (E3 → E4).** The
  third terrain product compared against GDAL 3.13.1, on the DEM the slope and
  aspect references already share, pinned by hash rather than copied. Over
  11,564 interior cells: ours against the closed form max 0.0000643, GDAL
  against the closed form max 0.900, ours against GDAL max 1.00 as 8-bit levels,
  all inside the 1.0 registered before the comparison ran. Both sides implement
  the same illumination model over a Horn gradient and differ only in byte
  encoding: we write 255·h, GDAL writes 1 + 254·h with level 0 reserved for
  nodata. That offset is left visible in the reported figures rather than
  divided out, and our encoding is unchanged. It spends most of a one-level
  budget on its own, so the ours-against-GDAL leg is a weak instrument by
  itself; the claim rests on the closed-form leg and on re-encoding our
  intensity in GDAL's scale, which reproduces the reference exactly at every
  cell. The limit is recorded in the fixture README and in
  `docs/validation/THREATS_TO_VALIDITY.md`. The single-direction model only;
  `computeMultiHillshade` keeps its own claim and its own level.
- **The development toolchain moves to TypeScript 7.0.2, Vite 8.1.5 and
  Playwright 1.62.0.** TypeScript 7 is the native compiler and a major version,
  so the whole gate was re-run against it: the typecheck, all five test buckets
  and both builds pass with no change to application source. All three packages
  are development-only, so the shipped runtime dependency set and the SBOM are
  untouched. Vite 8.1.5 splits the output into 153 chunks where 8.0.12 produced
  140, which moves about 62 KiB out of the entry chunk; the total emitted
  JavaScript and the obfuscation coverage of the live build are unchanged.

### Added

- **Twelve validation suites, each runnable and each stating what it does not
  cover.** Reproducibility (`benchmark:repro`): one documented seed, 250k
  points, ten recorded runs, passing only when every science-scoped hash and
  scalar is identical across all ten, at zero tolerance. Scaling
  (`benchmark:scaling`): 50k through 1M, five runs a tier, each tier in its own
  process, no complexity class claimed. Cross-platform portability
  (`benchmark:repro:portable`, `benchmark:compare-platforms`): a per-platform
  leg and a comparator that checks the source-cloud hash first, then every
  science-scoped hash and scalar at zero tolerance. Backend equivalence
  (`benchmark:backends`): GPU against CPU, suppressed and recorded as
  backend-unavailable when a requested backend fell back, so a Node run cannot
  report the CPU agreeing with itself. Failure recovery (`benchmark:failures`):
  truncated bodies, corrupt headers, degenerate geometry, missing and
  unresolvable CRS, aborted reads, each with a healthy control off the same
  fixture. Provenance integrity (`benchmark:provenance`): whether every exported
  artifact names its source, its method chain with bound parameters, its build
  and its limitation, and whether an edit stays detectable once the attacker
  refreshes the digests. Contour correctness (`benchmark:contours`): generated
  contours against plane, cone, paraboloid and saddle, the topological
  invariants of a level set, and the declared-against-actual properties, with a
  negative control on every predicate. LAS round-trip fidelity
  (`benchmark:roundtrip`): both writers read back twice, once by an independent
  spec-offset decoder in float64 and once by the application's own loader, with
  tolerances derived from the scale factor the file declares. Unit integrity
  (`benchmark:units`): one physical scene through a metre CRS, a foot CRS, a
  compound frame and a Y-up axis order, comparing what each path reports.
  Archive portability (`benchmark:archive-portability`): the released source
  archive checked from an extract in a temp directory outside the repository,
  which refuses an archive directory inside the repo or carrying a `.git` so
  there is no working-tree fallback to pass by accident.
- **A two-platform CI matrix for the portability suite**, darwin-arm64 and
  linux-x64, with both legs always run: failing fast would leave the comparator
  with one platform, which reports as single-platform and establishes nothing.
  Byte order is a precondition rather than a result, and runtimes stay per
  platform because a median over two machines describes neither.

### Known limitations

- **Antimeridian-crossing contour geometry is not cut at 180 degrees.**
  RFC 7946 section 3.1.9 says a LineString crossing the antimeridian SHOULD be
  split into two parts there; `toGeoJSONWgs84`
  (`src/terrain/contour/geojsonContours.ts`) writes the line whole. That is a
  SHOULD rather than a MUST, and only a scan footprint straddling 180 degrees
  reaches it. A reader that interpolates in longitude between the two sides
  draws the segment the long way round the globe.
- **Opening a remote streaming source replaces the streaming source already
  open.** A COPC or EPT source opened by URL, including from the curated
  picker, closes any open stream and clears the open static layers before it
  attaches (`src/main.ts:6691`, `6729` for EPT, and the equivalent
  `clearOpenStaticLayers()` at `6434` for COPC). Only one remote stream is
  resident at a time. Static local scans differ: they accumulate as separate
  layers, each listed in the LAYERS panel with its own removal control. The
  source comment at `src/main.ts:6098` records the split, and streaming
  exclusivity is the intended behaviour, but no user-facing or release document
  states it. What the limitations documents do say is that streaming sources
  "are never merged with static ones", which a reader can take to mean two
  streams merge with each other. They do not; the second one replaces the
  first. Reachable in normal use, and confirmed by loading the curated Swiss
  COPC tile and then opening an adjacent tile by URL, which left only the
  second loaded. There is no known effect on the correctness of any result: the
  remaining stream is analysed in its own frame, as a single stream always was.
  The cost is workflow and expectation. It also means multi-layer behaviour
  cannot be exercised with two remote streams, so the multi-layer work that is
  staged behind `MULTI_LAYER_MOUNT_ENABLED` can only be exercised with static
  scans. No workaround places two streams in one session. Nothing is scheduled;
  concurrent streaming sources depend on the same shared-frame work that
  physical multi-layer mounting waits on.
- **What the new suites name as uncovered.** Each suite states its own gaps
  rather than leaving them implicit, and `KNOWN_LIMITATIONS_v0.6.2.md` carries
  the list in full: GPU-computed derivatives beyond the two engine probe
  surfaces, render-space lengths and the measurement HUD, rasterised report
  composition, LAZ output (the application has no encoder, so there is no LAZ
  file of its own to read back), third-party writer conformance, `npm ci` and a
  build from a clean extract, and Windows as a reproducibility leg.
- **The in-memory reconstruction is less precise than the LAS file it came
  from.** Points are stored as Float32 local to a render origin, so the
  application's read-back displaces further than the file's own quantisation
  bound. Measured by the round-trip suite: 1.9 mm over a 50 km extent where the
  file itself round-trips exactly, and 0.123 m over a 5000 km extent where the
  file's own bound is 1.25 mm. The written file is not affected; the loss is in
  what the viewer holds and measures.

## [0.6.1] - 2026-07-25

A defect-fix release. Three vertical-reference and input-guard defects found by
an audit of the v0.6.0 archive, each with a regression test that fails on the
v0.6.0 code. Nothing in the viewer's behaviour changes otherwise, and no
dependency was added.

### Fixed

- **LAS 1.4 conversion kept the vertical CRS and the vertical unit.** The
  writer treated the WKT record and the GeoKey record as alternatives, but the
  WKT it emits is horizontal-only and the vertical datum (GeoKey 4096) and
  vertical unit (4099) live only in the GeoKeys. A NAVD88 height in US survey
  feet came out of the conversion declaring no vertical datum and no vertical
  unit, so a reader takes feet for metres, a factor of 3.28. LAS 1.4 permits
  both records, so the vertical GeoKeys are now written alongside the WKT,
  which remains the sole horizontal authority. No GeoKey record is written when
  there is no vertical to add.
- **Contour GeoJSON states the elevation's real unit.** Every contour was
  labelled `metre` while the value is in the source vertical unit, so a
  compound CRS with feet over a metre grid shipped 100 ft labelled 100 m. The
  label is derived from the resolved vertical factor, and an unresolved factor
  reads unknown rather than defaulting to metre. The factor is carried on the
  terrain core so the contour model can state its own unit.
- **EPT laszip tiles refuse non-finite positions.** The laszip tile decoder
  skipped the finite-position backstop that the COPC chunk and EPT binary
  decoders both apply, so a header with an extreme but valid scale could
  overflow to infinite coordinates and reach the renderer as a blank cloud with
  no error. It now refuses with the same structured error its siblings raise.
- **A truncated `.e57` no longer hangs the session.** The XML parser could run
  without terminating on truncated input, and because the shared parse worker's
  gate was never released, every later file load in the same session hung with
  it.

### Changed

- The three bundled font packages move to 5.3.0, and the CI actions
  (`actions/checkout`, `actions/setup-node`) to their current majors.
- `CITATION.cff` carries the Zenodo DOIs for the archived release and for all
  versions.

### Added

- Benchmark framework scaffolding under `benchmarks/framework/`,
  `benchmarks/fixtures/` and `benchmarks/pipeline/`. This is internal
  scaffolding with its own tests and no runnable entry point: there is no npm
  script, no benchmark suite, and nothing in the application changes. It is
  recorded here because it is in the tree, not because it does anything yet.

## [0.6.0] - 2026-07-24

The stable v0.6 release. Spatial operations are deterministic, explicit and
non-destructive: the in-place Float32 rebase is removed and source geometry
is immutable by proof; mounting is a Float64 placement. Measurements carry
context lines and every layer gets a health card; streamed exports state
their resident-of-source scope in the file; corrupt COPC input fails with
structured errors (two real fixes: clamped past-EOF hierarchy ranges, raw
decompressor aborts crossing the worker boundary). Claims, stability and
language are governed by CLAIMS_AND_LIMITATIONS.md, STABILITY_POLICY.md and
lint:claims-language. Full detail in RELEASE_NOTES_v0.6.0.md.

## [0.6.0-alpha.3] - 2026-07-23

A decomposition and precision-groundwork cut, on the same footing as alpha.2:
almost nothing changes in the viewer. It continues pulling testable logic out
of the two monoliths, adds guards so that work cannot regress, and measures the
one open coordinate-integrity item so the fix has a number to beat. Alpha
caveat unchanged: for evaluation, and interfaces may still move before v0.6.0.

### Changed

- **The two monoliths shed more testable logic.** Extracted, each with Node
  tests it could not have while on the class: the lasso-volume walk, the
  two-finger tracking state machine, the render-frame decision, the streaming
  compatibility boundary (`src/render/*`), and from `main.ts` the remote-source
  naming/error text and two measure helpers (`src/app/remoteSourceNaming.ts`,
  `src/render/measure/measureDerivations.ts`). `Viewer.ts` 7,297 to 7,127,
  `main.ts` 7,636 to 7,520. The decomposition's exit condition is now the
  extraction of every cluster with a real boundary and a test payoff, not a
  line count — a hard line target rewards relocating glue.

### Added

- **Two shrink-only ratchets** (`lint:position-access`, `lint:monolith-size`):
  the world-coordinate read surface and the two large files may fall, never
  grow, so a decomposition step cannot be quietly undone and no vanity
  extraction is forced. Both run in the release gate.
- **A measured baseline for the in-place rebase** (`tests/rebasePrecisionBaseline`).
  The open Float32-transform item is bounded and does not compound: a mount and
  unmount moves a point 0.06 mm at 1 km, 3.9 mm at 100 km, and repeated cycles
  do not add to it. The defect is exact reversibility, not drift, which is a
  smaller problem than assumed and is what the Float64 migration will close.
- **A slope cross-implementation harness** (`tests/slopeCrossCheck`), ready for
  a GDAL reference to move `SLOPE-RASTER` from E3 to E4. The check stays skipped
  and the claim stays `pending` until the reference file is supplied.

## [0.6.0-alpha.2] - 2026-07-21

A stabilization cut. Almost nothing here is visible in the viewer: it makes the
test gates mean what they claim, starts the decomposition of the two monoliths,
and writes down the architecture so the rest of the work has a target. Alpha
caveat unchanged: this cut is for evaluation, and interfaces may still move
before v0.6.0.

### Changed

- **The end-to-end suite actually gates now.** 161 of the 166 e2e specs ran under
  `continue-on-error`, so only the smoke and mobile specs (about twelve tests)
  could ever block a build — a regression in any of the rest shipped green, which
  is the shape of gap that let a streaming blank-render bug reach a release.
  Playwright now has two projects: `deterministic` (blocking) and `gpu`
  (advisory, `@gpu`-tagged). 165 specs block; only the real-WebGPU equivalence
  probe stays advisory, because it legitimately falls back on a headless runner.
  An untagged spec blocks by default, so a new spec gates until it is shown to be
  GPU-variable.
- **No module-level mutable application state remains in `main.ts`.** The saved
  views, active-scan selection and scan-route clusters moved onto `AppContext`
  behind services (`viewBookmarks`, `ScanService`, `ScanRouteService`), joining
  `LayerService`. Eleven copies of `activeId ? getCloud(activeId) : null` became
  one `activeCloud()`, and the twice-spelled route-pinned predicate became one
  getter. This is a coupling change, not a size one — `main.ts` moved 7,587 to
  7,574 lines. Its value is that the orchestration blocks can now close over
  services instead of file-scope `let`s, which is what makes them movable at all.

### Added

- **A coverage ratchet over the pure modules** (`npm run coverage`): the numeric,
  geometric and model code a unit test can genuinely pin, deliberately excluding
  the render and UI layers and the two monoliths, where a repo-wide percentage is
  a number nobody acts on. Baseline lines 90.57 / statements 89.19 / functions
  87.75 / branches 82.73, with thresholds just underneath.
- **A mutation gate over the numeric core** (`npm run mutation`, advisory): the
  formulas where a wrong number is a silent scientific error rather than a crash.
  It earned its place immediately — `hornSlopeAspect`'s degenerate-input guard had
  17 surviving mutants, meaning a zero or NaN cell size could have produced an
  Infinity slope that propagates into confidence grades, RMSE bands and terrain
  ruggedness. Coverage rated that file ~90% because the lines *ran*. Now pinned;
  score 85.11 to 87.23.
- **An architecture map** (`docs/architecture/architecture-map.md`) with a drift
  check: every module path it names must resolve, or the test fails and the page
  moves in the same change. It caught itself on the first run.
- **A streaming origin-localisation guard.** The scheduler tests only ever used a
  cube at the origin, where subtracting the render origin is a no-op — so the
  alpha.1 EPT blank-render bug could not have been caught there. A case at
  UTM-scale coordinates now fails if that path regresses.

### Maintenance

- The stabilization work is tracked against measured baselines, separating
  what is provable in a sandbox from what needs a browser or a workstation.
  `docs/architecture/architecture-map.md` carries the module graph and the
  decomposition targets.

## [0.6.0-alpha.1] - 2026-07-18

First alpha of the v0.6 cycle: startup and streaming performance, a correctness-and-honesty hardening pass across the streaming, loader, and measurement paths, the foundation for a shared project coordinate frame, and the start of the internal restructuring that the v0.6 workflow features build on. Alpha caveat: this cut is for evaluation; interfaces and internals may still change before v0.6.0.

### Added

- **Stale-chunk recovery.** A tab left open across a deploy no longer breaks the first action that touches a swept-away code chunk: the failed dynamic import is classified (across Chromium/Firefox/Safari/Vite phrasings) and the page reloads once, guarded by a per-tab cooldown so a persistent failure surfaces an error instead of a reload loop. URL and query are preserved.
- **Dependency-singleton guard.** `npm run check:deps` fails the release gate if a second copy of three, laz-perf, proj4, or pdf-lib ever enters the tree (duplicate decoder/geometry state is a correctness risk, not just bloat); Vite dedupe backs it up at resolve time. A real duplicate laz-perf was collapsed by removing the unused `@loaders.gl/las` dependency.
- **Progressive streaming hierarchy.** Large public EPT datasets expose thousands of hierarchy sub-files; loading them all before the first points render made big projects look hung. The walk is split into a bounded first-paint pass plus a resumable background continuation, and the frontier drops every attempted key so a persistently-failing fetch can't spin into an allocation loop.
- **Shared project coordinate-frame foundation.** Value types (`ProjectSpatialFrame`, `LayerSpatialTransform`) and pure Float64 transform math for expressing multiple layers in one authoritative frame, so georeferenced scans with different origins can occupy their true relative positions rather than overlapping near local zero. The tested foundation ships; the scene wiring is staged and documented in `docs/architecture/project-spatial-frame.md`.

### Changed

- **Startup bundle.** The Analyse and Object panels now mount on first scan load instead of at boot, cutting the live entry chunk from 792 KiB; the bundle-budget guard's ceiling drops 800 → 720 KiB with an early-warning threshold at 680 so the win cannot silently erode. After the alpha hardening the live entry measures 693 KiB — within the 720 ceiling, above the 680 warning line.
- **Live probe pauses during camera drags.** The hover readout's detailed GPU pick is skipped while the user is actively orbiting or panning — you are navigating, not reading a value — and fires once as soon as the drag settles.
- **Measurement station tables build lazily.** Station rows render when their section is first expanded; exports are byte-identical.
- **Start-screen theming and layout.** The start-screen backdrop follows the selected theme, so Light and High-contrast re-theme the whole page rather than only the centre panel. A "Try a sample scan" action sits under the primary button for a visitor with no file on hand, the brand mark carries one slow drift that respects reduced-motion, and the format converter is a secondary link rather than a competing button.

### Fixed

- **Public COPC and EPT datasets open reliably.** Two separate causes could leave the viewer on "Streaming coarse geometry" with nothing drawn. The scheduler was advanced only by the render loop, which the browser pauses for a background or throttled tab, so a dataset opened in that state sat at zero resident nodes with no error; a steady heartbeat now drives the scheduler independently of the render loop. Separately, every EPT node's bounds were shifted by the render origin twice — once when the node was built and again in the shared scheduler — so every node fell one whole origin from the camera and was culled before it could draw; EPT node bounds are now world-space, matching the COPC contract, and the origin is applied once.
- **Consistent values across panel, report, and export.** A metric computed in more than one place no longer disagrees with itself on a foot-based, compound, or non-Z-up dataset: slope no longer reads about 3.28× too steep, a Y-up mesh (PLY/OBJ/GLB/glTF) is measured on its ground plane and height, the streaming scan panel and Dataset Intelligence convert source units to metres before printing, point density prints at the same precision everywhere, the export card reports the declared point count and tight data extent rather than a strided sample or the octree cube, and the change-detection raster, measurement GeoJSON/CSV/KML, and profile chart carry the file's own linear and vertical units. Single-unit metre datasets are byte-identical.
- **Polygon reclassification on non-Z-up scans.** For a non-Z-up up-axis, the polygon was projected onto an (east, north) basis while each point was tested in raw XY — mismatched spaces that reclassified the wrong points on rotated, Y-up, tilted, or non-origin clouds. Points now project through the same basis, height included; the Z-up fast path is unchanged.
- **COPC/EPT refinement flicker.** Streaming LOD transitions cross-faded with `transparent: true` while keeping depth writes for EDL, so overlapping coarse/fine layers z-fought and refining regions pulsed while a cloud streamed in. Transitions are now an opaque per-point dither dissolve driven through the size graph — no transparency, no z-fight, EDL stays exact — and an evicted node dissolves out from its current density instead of snapping to full.
- **Non-finite streaming nodes are refused.** The central sanitiser cleans file-loaded clouds but by contract skips streaming buffers; the COPC/EPT decoders now reject a node whose transform (a malformed header scale/offset/origin) or whose float source carries a NaN, with a structured error the scheduler backs off — instead of sending NaN to the GPU.
- **Sessions no longer rebase onto the wrong scan.** Import checks a session's stored scan fingerprint (extents primary, point count corroborating, name/CRS disclosure) against the loaded scan before rebasing its geometry: a clear mismatch is refused, a partial match disclosed, rather than silently realigning one scan's analysis onto another.
- **Stockpile confidence is honest about units.** A points/m² density can no longer earn HIGH confidence when the horizontal CRS unit is unknown (an unknown unit was silently treated as metres); the density row is labelled accordingly.
- **Profile elevations read against the right datum**, and the distance formatter no longer renders negative heights as centimetres.
- **Central non-finite sanitation across every file loader**, PCD included, and streaming elevation ranges now read from decoded data bounds rather than the octree cube, so a tall cube can't inflate the elevation legend. Streaming-only session exports store the active geographic origin instead of `[0,0,0]`.
- **Partial session matches now ask before applying.** A session whose scan fingerprint neither clearly matches nor clearly conflicts with the loaded scan no longer restores automatically — it surfaces an "Apply anyway" confirmation, so an unverified match can't quietly place measurements on the wrong scan.
- **No spurious PCD console warning.** A PCD file with a non-finite coordinate no longer prints three's `computeBoundingSphere(): Computed radius is NaN` — that one redundant message is suppressed for the parse (the point is still excluded and reported through the loader's own warning channel).

### Maintenance

- **Composition root.** New `AppRuntime`/`AppContext` own the shared application state (layer visibility/solo/comparison, active-scan selection, saved views) that previously lived in module-level mutables, and the first extracted service (`LayerService`) manages the layer list against it. Behaviour-preserving; groundwork for the v0.6 decomposition.
- **Anti-thrash streaming selection (opt-in).** The budget selector can give an already-shown node a small score bonus so budget-boundary noise can't bump it out and force a re-fade — the "regions pulsing" flicker — with a node being refined away exempt so LOD never freezes. Unit-tested and off by default: enabling it live needs reconciling with eviction protection and visual verification in a browser, so no behaviour changes in this cut.
- **Single-file test runner.** `npm run test:file <path>` mirrors the release buckets' terminating policy with a wall-clock watchdog and a greppable exit line, for fast red-to-green iteration without a full bucket.
- **Sub-sharded test buckets, everywhere.** The bucket runner grew a `--shards=N` mode that runs a bucket as N sequential deterministic slices (fresh vitest process each), so no single process holds hundreds of files — the shape that can fail to terminate ("Worker exited unexpectedly") at shutdown on a constrained machine. `test:release` uses it (unit ×3, terrain ×2, slow ×2); CI runs the same slices in parallel via `--shard=i/N`. The slices partition each bucket exactly.

## [0.5.9] - 2026-07-15

v0.5.9 launches Contour Studio — a post-analysis workflow that turns a correctly analysed LiDAR scan into an evidence-aware terrain deliverable, kept out of the crowded analysis panel — alongside scientific-correctness, unit, evidence-gate, provenance, and registration fixes that stand on their own. Headline additions: a verifiable hash-chained processing manifest, a labelled colorbar legend (live and burned into figures), named restorable view states (session schema v7), GPS-time and return-number colour modes, and purpose-driven contour exports whose geometry differs by purpose.

### Added

- **Verifiable processing-provenance manifest (schema 1).** Every terrain export's provenance now embeds one ordered, hash-chained record of the methods and final parameters that produced it (`processingManifest` beside the scientific record in the GeoJSON metadata, plus a one-line `Manifest` stamp — schema, shortened chain head, op count — in the DXF/SVG/README text block). Each op folds the previous hash plus its canonical serialization into a SHA-256 chain seeded from the manifest envelope (schema, build identity, source name), so editing any op, reordering, truncating, or rewording the envelope breaks verification at exactly the first altered position (`verifyProcessingManifest` reports the index). Parameters are bound only where the provenance carries them (coverage scope, VRM/TPI windows and radii, contour interval and shape style); an op whose settings never reached the provenance says `params not captured in this slice` instead of fabricating values. Honesty boundary: this is a *verify-only* record — ordering, parameters, tamper-evidence — not an execution recipe, and no executor consumes it. Saving a `.olvsession` after an analysis fills the v7-reserved `processingManifest` slot with the same manifest, so the session file carries the audit record of the numbers on screen.
- **Labelled colorbar legend — live and burned into figures.** A quantitative figure needs a labelled min/max colorbar, so the continuous scalar colour modes (elevation, intensity, GPS time, return number) now carry one on two single-sourced surfaces: a dismissible on-screen legend near the viewport (a lazy chunk — an RGB-only session never downloads it) and a burn-in on the right edge of saved views and Studio image exports, positioned clear of the scale bar, scan-report card, and class-scope banner. Both consumers read ONE spec-builder that labels the exact window the pixels normalise against (`rampRangeForMode` — the same function the colouring pass paints with; streaming legends read the renderer's seeded cloud-global ranges verbatim, and static and streaming paths drive the same overlay). Honesty rules throughout: the elevation unit comes from the resolved CRS (user overrides included) and an unknown unit shows no suffix — never a guessed "m"; a percentile-trimmed ramp is annotated "p5–p95 window" so clipped endpoints are never mistaken for true extremes; intensity renders a GRAYSCALE bar because that is how the points are actually painted, with no unit (a raw DN); GPS time is normalised to seconds from the window start and says so; and the categorical modes (RGB, classification, and friends) get no continuous bar at all — it would invent an ordering the renderer never used.
- **Named, restorable view states (session schema v7).** A saved view is no longer just a camera bookmark: pressing `V` (or Save current view in the panel, or "Save view state" in the command palette) captures the camera together with the clip box, colour mode, class filter, elevation/intensity filter windows, and render settings, and restoring the view reapplies the lot — camera strictly last, so nothing re-frames after the pose lands. States are serialized per-view in the `.olvsession` file through the same tolerant sub-parsers as the session's global fields, so a paper can cite "Figure 3 = view state 'north-scarp'" and a reviewer with the same scan regenerates it. The session schema bumps to v7 in this one coordinated step: it also reserves an opaque top-level `processingManifest` slot (passthrough, unvalidated) so the verifiable-processing-manifest workstream lands without another version bump. Migration is additive and honest — a v6 file imports with its camera-only views intact and restoring them behaves exactly as before (not even the FOV is touched), a bundle-free view still serializes byte-identically to the v6 writer's output, and unsupported future versions are still rejected. Streaming caveat: on a COPC/EPT scan a restored state reproduces the same settings over whatever detail is resident — the same picture, not a claim of identical point membership.
- **GPS-time and return-number colour modes.** Two continuous scalar colour modes join the chip row in the Inspector and the streaming panel, data-gated on their channel: "GPS time" ramps acquisition time (dark early → bright late) and "Return" ramps return ordinals (dark first → bright last), both defaulting to the colourblind-safe Cividis palette and available in the static and COPC/EPT streaming pipelines alike. Streaming nodes colour against one cloud-global window seeded from the coarsest resident node, so adjacent nodes never band at shared edges; the GPS-time range is percentile-clipped through the same core as elevation, so one garbage timestamp cannot compress the whole ramp, and non-finite values from a malformed chunk cannot poison the window. Honesty gate: classification keeps its categorical palette and `pointSourceId` deliberately gets no ramp mode — sequential colour on unordered flight-line ids would invent an ordering the data does not have.
- **Terrain Products launcher.** After analysis, the crowded panel no longer shows contour export controls inline; it shows a noticed launcher whose state (hidden / unavailable / exploratory / available) is computed from the analysis result and the CRS frame. The contour export controls move into a gated container revealed only when the launcher's action fires. The launcher, its state adapter, and its strings load lazily (a separate chunk), keeping Contour Studio out of the startup shell.
- **Contour Studio state + purpose model.** A serializable state (schema 1) with deterministic serialization, a schema-versioned parse with a migration seam, and a stable content hash. Five purpose presets (Engineering Plan, Survey Review, Terrain Research, Presentation Map, Custom) are bundles of defaults only; selecting one changes presentation settings and preserves user overrides, and cannot raise an evidence level because the state carries no evidence field.
- **Unit-safe contour level definitions.** Contour interval and base elevation are recorded in both the source vertical unit and metres, with the metre value null when the vertical unit is unknown, so a source-unit number is never presented as metres. Metric contour support is claimed only on a known vertical unit and a projected CRS; feet show a metric equivalent; unknown units render as "units unverified".
- **Contour Studio workspace + recommendations.** A workspace shell (purpose cards, an evidence ladder tied to the real launch state, and an export bar) and a review-bar model that surfaces the analysis's own grid and interval recommendations with their rationale. All of it loads lazily.
- **Analytical/cartographic geometry split.** Exact analytical isolines and a generalized cartographic product that references the analytical hash, records displacement statistics and a topology flag, and is never labelled exact. Cartographic exports apply a bounded per-purpose generalization tolerance; a terrain-aware per-feature variant (scaling tolerance by support, confidence, closure, and length within a bounded band) exists in the module library but is not the shipped export path.
- **Print-aware label engine.** Places contour labels on straight, low-curvature, supported runs with a suppression audit; an unsupported span is never labelled as if measured.
- **Evidence-gated exports.** A registry of the scientific exporters and one resolver that returns validated / exploratory / blocked and can only downgrade; a multipage PDF content model and a complete-deliverable-package model that omit unavailable files honestly, watermark exploratory output, and refuse to build a polished deliverable when blocked.
- **Publication artifacts.** `VALIDATION_REPORT_v0.5.9.md`, `docs/validation/THREATS_TO_VALIDITY.md`, `docs/validation/METHOD_VERSIONS.md`, `ARTIFACT_EVALUATION.md`, `REPRODUCIBILITY.md`, `DATA_AVAILABILITY.md`, a contour validation case manifest, and analytic contour validation (cone, paraboloid, tilted-plane) checked against closed-form truth.
- **Trimmed ICP registration.** Robust correspondence trimming with a median-based warm-start, so change-detection alignment resists gross blunders and scattered outliers instead of collapsing. Diagnostics (inlier fraction over the whole cloud, kept-set RMS) are reported honestly.

### Fixed

- **Hold-out validation runs train-only on the shipped path.** Ground classification is re-run per fold with the held-out points excluded, closing the classify-before-split optimism. The analyser (`computeTerrainCore`) passes a train-only reclassifier that re-runs the SAME SMRF classifier with the SAME resolved parameters on the training points only, so a held-out point never helps decide its own ground membership; the report's full-cloud disclosure is off because the leak is removed, not restated. Cost is bounded: the hold-out is a single deterministic split — one extra SMRF pass over the training share of the already-capped analysed cloud (ground-filter cost ≤ 2× per run). `olv.validation.holdout-rmse` is version 2. The spatially-blocked diagnostic still scores against the full-cloud mask and its threats-to-validity disclosure stands.
- **Contour Studio purposes export distinct geometry.** Selecting a purpose previously exported the on-screen default geometry byte-for-byte — the purpose changed only a provenance line, and the file was stamped with a `terrain-adaptive` generalize method whose module has no production caller. Each purpose now carries a bounded generalization tolerance (Survey Review 0 = exact analytical isolines; Terrain Research 0.25, Engineering Plan 0.5, Presentation Map 1.0, Custom 0.5 cells), so the four cartographic purposes serialize pairwise-distinct vertices; the exact tolerance and the honest `olv.contour.generalize` method id travel into the export provenance and the processing manifest, so a deliverable names the epsilon it used.
- **The Complete (ZIP) deliverable reflects the selected purpose.** It previously always bundled the exact analytical geometry and recorded no purpose; it now bundles the geometry for the chosen purpose (Survey Review's analytical isolines, or a cartographic purpose's generalized geometry at its tolerance) and stamps the geometry method, purpose, and tolerance into the deliverable provenance. The stamp is written only when the geometry is regenerated at the purpose's style, so it can never describe a bundle it does not match.
- **Complete-deliverable PDF named for what it is.** The multipage PDF inside the complete ZIP is a text technical report (contour summary, surface support, validation, method and provenance), not a rendered map sheet — only the standalone map-sheet PDF draws an actual map. It is now named `Contour_Report.pdf` ("Contour report (PDF)") instead of `Contour_Map.pdf`.
- **Honest elevation unit in the complete deliverable.** The deliverable README and PDF no longer assert that the vertical unit equals the horizontal unit; they report the real Z-axis unit when the CRS declares one separately, and "unknown" otherwise, so a foot-based scan never prints an unverified elevation unit.
- **Self-validating confidence calibration.** The reported calibration quality is now computed by deterministic K-fold cross-fitting, so no sample is scored by a calibrator trained on it. Out-of-fold reliability and Brier score are exposed.
- **Unit overclaiming on elevation.** Picked-point elevation no longer prints metres on a foot vertical datum or unknown units, and space reports no longer say "metres (assumed)" on unknown-scale data. Both route through the typed-unit helpers.
- **Signed EPT URLs keep their credential past the manifest.** A remote EPT manifest URL carrying an auth query (`?token=…`, an Azure SAS, a CDN signature) validated and loaded `ept.json`, then dropped the query when deriving the dataset directory — so the first `ept-hierarchy/…` request went out unsigned and 401/403'd. The query now rides every derived hierarchy and tile request. A per-object presigned signature bound to `ept.json` alone still cannot authorise the sibling hierarchy files; that case stays an honest hierarchy-fetch error rather than a silent stall.
- **Service worker caches only the build's own hashed bundles.** The offline worker cached anything under `/assets/` by path prefix, so a point cloud or EPT hierarchy a self-hoster placed there would have been written to Cache Storage — contradicting the worker's stated privacy contract. It now requires a Vite content-hash and a known application extension, so a `.las` / `.laz` / `.copc.laz` / `.bin` / `.zst` / `ept.json` / hierarchy file under `/assets/` is never cached. Covered by a test across those extensions and directories.
- **Restored real elevations in the contour map, DEM rasters, and complete deliverable.** A recentred scan's exports carried recentred-negative heights (a DTM of −450..−210 m where the source is ~+210..+450): the dropped vertical origin was already added back for measurements and vector contours, but not for the map-sheet labels or the DTM/DSM rasters. The map-sheet elevation labels, the DEM package's DTM/DSM `.asc`/`.tif`, and the complete deliverable's DTM GeoTIFF now add it back (a covered-cell-only copy — CHM stays a height difference, and the source grid is never mutated). Only the numbers are corrected; the vertical datum stays honestly "unknown".
- **Contour map sheet redesigned toward an official-grade deliverable.** One line-style table (shared with the legend so they cannot desync) gives a continuous hierarchy — a bold measured index skeleton, lighter measured intermediate, a lighter continuous tint for interpolated, and a broken line only for low-confidence gaps — so a heavily-interpolated preview reads as signal rather than dashed noise. The print-aware label engine now places the map's index labels (upright, on straight supported runs, collision-avoided, repeated along each line at print scale), an interior tick-cross graticule, a double map neatline and an outer sheet neatline, an explicit "local grid up — true north unknown" note in place of a compass arrow on an ungeoreferenced scan, and a three-column ruled title block whose PREVIEW / evidence verdict is wrapped within its column so it can no longer overlap the legend. Every honesty disclosure — preview readiness, interpolated fraction, the evidence-gate line, and the unknown-datum caveat — is preserved.

### Changed

- **Terrain intelligence report joins the unified evidence gate.** The report was the last Contour Studio product with a standalone gate; its Studio export now mints a permit through the same central evidence resolver as the vectors, map PDF, DEM package and complete deliverable (`contour.report`, governed by the DTM claim — the report can never claim more than the surface it summarises). A blocked permit refuses the export with the same blocked-button feedback as the other products; a granted permit's decision (validated / exploratory + watermark) is stamped into the report's provenance footer. The resolver only ever downgrades, and the report keeps honestly describing preview/blocked verdicts in its body; the direct panel convenience button keeps its own availability (no stamp), as the DEM's does.
- **Evidence gate coverage.** Measurements CSV, the integrity report, and the map-sheet PDF now route their claim status through the one central evidence gate rather than exporting ungated. The `exportGate` / `isValidatedExport` API is unchanged.
- **`test:release` runs the blocking mobile smoke.** The release command now includes the mobile responsive smoke (320 / 375 px, `visualsStudioMobile.spec.ts`) that CI already gates on, so the local release gate is a true superset of CI's blocking browser checks instead of omitting one.

## [0.5.8] - 2026-07-08

Architectural and scientific-provenance hardening. This release starts a staged
cleanup that ties every output to the exact build that produced it and stops the
viewer from asserting units it does not know.

### Added

- **Build identity.** Each build now carries one identity resolved at build
  time: version, git commit, a dirty-tree flag, build time, Node version and
  channel. It is stamped into every terrain export's provenance (text and JSON)
  and into the report PDF's creator metadata, so an artifact records which build
  made it, not just which release. When git is unavailable the commit is
  reported as `unknown` rather than fabricated, and the build time honours
  `SOURCE_DATE_EPOCH` for reproducible builds.
- **Layer-boundary lint.** A CI check fails the build if a science or core
  module (`terrain`, `validation`, `analysis`, `science`) imports the UI layer
  or three.js, keeping those modules pure and worker-safe.
- **Method registry.** A single catalogue of the scientific methods the viewer
  runs, each with a stable `id@version`, so provenance and reports can name the
  exact algorithm and revision behind a number.
- **Architecture cleanup plan.** `docs/architecture/v0.5.8-cleanup-plan.md`
  records the staged program and its current state.

### Fixed

- **Inspector units.** The picked-point card showed every projected and every
  local or unknown-CRS coordinate with a metre suffix. A foot-based survey
  therefore read as metres, and an unknown-unit scan asserted metres it never
  knew. Axes now follow the CRS's own linear unit (metre, foot), and an unknown
  unit shows no suffix instead of claiming metres.
- **Contour interval gate on foot data.** The interval honesty-gate compared the
  metre-valued hold-out RMSE against source-unit contour intervals, so a foot-CRS
  surface could offer intervals finer than its true vertical error. The RMSE is
  now expressed in the interval's own units before gating; the recommendation is
  invariant to the declared vertical scale.
- **Unit constructors reject non-finite input.** The branded-unit constructors
  now throw on NaN / ±Infinity, catching a poison value at its source instead of
  letting it propagate through every downstream computation.
- **Validation honesty.** The hold-out report now states explicitly that it
  withholds points from the surface fit only — ground classification runs over
  the full cloud — a mild optimism versus true classify-inside-fold validation.
- **Packaging.** An unanchored `build` entry in `.gitignore` had been silently
  excluding `src/build/buildIdentity.ts` from the source archive, breaking a
  clean checkout's typecheck and build. The ignore patterns are now root-anchored,
  the file is tracked, and a new `lint:no-ignored-src` gate fails the build if any
  source file is ever git-ignored.

### Changed

- **Claim register is generated, not hand-mirrored.** The runtime evidence
  registry is now generated from `docs/validation/claim-register.yaml`
  (`npm run gen:claim-registry`); `lint:claim-register` fails if the generated
  output drifts from the YAML, removing the two-place edit.
- **Plain-build chunk-isolation ceiling raised 516 → 520 KiB.** A committed
  contract decision: the boot-time input-aware mobile detection and the sub-KB
  scientific-record / export-provenance triggers added ~3.4 KB of eager shell
  surface since v0.5.6 (index measured 529,464 B, 1,080 B over the prior
  ceiling). The heavy code still rides lazy chunks — the shell-leak fingerprint
  guard confirms no decoder / pdf / WebGPU / TSL import entered the startup
  shell. `test:build` (plain build + chunk-isolation contract) is now part of
  `test:release`, so this contract is enforced on every release, not only the
  obfuscated live-build budget.

## [0.5.7] - 2026-07-05

Object and E57 capture honesty, plus an explicit evidence model. v0.5.7 makes
the viewer read a scan for what it is — a compact object, an interior, or a
local-frame terrestrial/handheld capture — and stops applying airborne-survey
and terrain framing where it does not belong. It also replaces the old single
"Production" status with a documented evidence ladder so every scientific claim
states how strongly it is supported.

### Added

- **Capture lens.** A single derivation composes the scan-shape verdict
  (object / interior / terrain) with the display profile (geo / terrestrial-scan
  / handheld / mesh) into one read used across the classifier, reports, and
  panels. It distinguishes "not terrain" (contours/coverage don't apply) from
  "local frame" (no geodetic CRS), so a terrestrial scan of a hillside keeps its
  contours but suppresses CRS, and a temple keeps its CRS suppression without
  losing shape context.
- **Declared-by-the-file provenance card.** When a scan carries a recognised
  display profile or an `olv:` provenance block (E57), the Inspector surfaces the
  declared capture app, sensor, and profile headline under an explicit "Declared
  by the file — not verified" qualifier. Values are shown verbatim; nothing here
  is inferred.
- **Evidence model.** A machine-readable claim register
  (`docs/validation/claim-register.yaml`) and an evidence ladder E0–E6
  (`src/validation/evidenceLevel.ts`) record, per product, the current evidence
  level, the level required to export as validated, and the approved and
  prohibited claims. Independent evidence begins at E4; nothing ships at E4+ yet,
  and the docs say so.
- **glTF capture stamps.** The glTF `asset.generator` string written by the
  capture app and a texture/material presence flag are read on load
  and fed to the display profile for handheld-capture identification.

### Changed

- **The capture-type classifier is now shape-aware.** A compact object or
  interior can no longer be labelled drone/aerial/spaceborne from point density
  alone — airborne capture is ruled out by geometry and the verdict is demoted to
  an honest "ground-based, method not determined" rather than a fabricated one.
  Direct evidence (software/sensor strings, the file's own declaration) still
  wins.
- **The Coordinate-system section hides for local-frame scans** (terrestrial /
  handheld / mesh), where a bare "CRS unknown" row reads as a defect rather than
  a fact. The geo/survey path is unchanged.
- **Validation docs corrected for overstatement.** The terrain matrix's
  "Production" status is replaced by evidence levels; the ground filter is
  described as an SMRF-core progressive-morphological subset; confidence,
  NVA/VVA-style, and QL wording are scoped to what the evidence supports; and the
  CRS limitation states precisely what is detected, converted, and propagated
  versus not reprojected.

## [0.5.6] - 2026-07-04

Point filtering. v0.5.6 connects the staged point-filter work to the live
renderer, starting with an elevation filter. Browser-native and local-first;
files never leave the device.

### Added

- **Elevation filter.** Hide points outside a chosen height window. The window
  is given in world units and converted to the scan's attribute space along its
  up-axis (Z-up for LAS/LAZ/E57, Y-up for phone scans); out-of-window points
  collapse to zero size on the GPU (they still run the vertex stage but produce
  no visible sprite and add no extra draw calls), and clearing the filter
  restores the scene exactly. Picking, measuring, snapping, and classification
  edits all respect the filter — you can't select a point you can't see. Works
  for static clouds and streaming COPC/EPT nodes, with an Inspector control.
- **Intensity filter.** Hide points outside a chosen intensity window, in the
  file's raw intensity units. Same GPU approach as the elevation filter; the
  control seeds from the cloud's own intensity range and is hidden for scans
  without an intensity channel.
- **Streaming point-cloud export.** Export the streamed-in (resident) points of
  a COPC/EPT scan to LAS or XYZ (optionally gzip-compressed as `.las.gz`) at
  display resolution. The export is flagged as a reduced view while the whole
  cloud is still streaming. (In-browser LAZ writing is not yet available.)
- **Clearer scan-loading feedback.** Opening a scan — a device file or a public
  or streaming dataset — now shows a prominent blue blinking "Opening…"
  indicator, so an in-flight load reads the same way from either entry point.
- **Readable GPU errors.** If the graphics backend fails to render a scan (a
  shader or pipeline error, which surfaces after the scan has already decoded),
  the reason is now shown as a message instead of leaving a blank view with no
  explanation.

### Fixed

- **Point filters no longer affect scans that don't use them.** The elevation
  and intensity filters now touch a scan's render path only while a filter is
  actually active; opening a scan without a filter renders exactly as it did
  before the filters existed.
- **Filters apply to interaction, not just the picture.** Picking, measuring,
  snapping, focus, probing, annotating, and lasso reclassification now reject
  points hidden by the elevation or intensity filter, so a hidden point can't
  become a measurement vertex or be rewritten by a class edit.
- **Streaming filter controls now appear.** A COPC/EPT scan seeds its elevation
  and intensity controls from the streamed data (previously they stayed hidden),
  and a static→streaming swap clears any leftover filter state.
- **Range-control accuracy.** Clearing a filter field no longer briefly applies
  a bogus zero bound, and re-seeding the extent for a new scan clears the prior
  scan's active filter so the control and the rendered scene always agree.
- **Sessions keep every measurement.** Profile, box, and volume measurements and
  their data (profile chart, corridor width, ground percentile, cut/fill volume
  record, resident-only flags) now survive a session round-trip instead of being
  silently dropped on import.
- **GPU error handling.** The graphics-error listener is now released on teardown
  and de-duplicated per scan, and a lost GPU device surfaces a clear message
  instead of a permanently blank canvas.
- **Startup hardening.** Guarded an empty-state initialisation path so a fresh
  page load can't error before a scan is opened.

### Known limitations

- Elevation/intensity filtering uses a single up-axis and reference origin, so a
  session with multiple layers at differing origins or mixed Z-up/Y-up axes may
  filter some layers inconsistently. Per-layer filtering is planned.

## [0.5.5] - 2026-07-03

Navigation, interface, reporting, and validation. v0.5.5 adds a Pan hand tool,
refines viewport navigation and point rendering, makes the side panels
collapsible, reduces the PDF report set to two documents, corrects scan-health
reporting for deliberately sampled datasets, and adds reproducible performance
diagnostics. Browser-native and local-first; files never leave the device.

### Added

- **Pan hand tool.** A fourth navigation mode. `4` selects Pan, `G` toggles it,
  and a middle-mouse drag pans temporarily from any other mode. A primary mouse,
  pen, or one-finger touch drag moves the scene while the wheel keeps zooming;
  camera orientation and view scale stay fixed. Pan mode is preserved in saved
  sessions and share links.
- **Frame-rate-independent wheel and trackpad zoom.** The same gesture reaches
  the same zoom on a 60, 120, or 144 Hz display, and zoom centres on the pointer
  so the point under the cursor stays put. The previous behaviour stays available
  with `?wheelDolly=legacy`.
- **Motion-adaptive resolution.** While the view moves, the renderer lowers the
  device-pixel ratio a little and restores it once you stop, keeping interaction
  smooth on dense scenes without a visible drop in sharpness. Disable with
  `?adaptiveDpr=off`.
- **Gaussian point-appearance mode.** A point style that softens ordinary point
  samples. It is not a trained 3D Gaussian Splat scene.
- **Collapsible side panels.** A one-tap handle collapses the left column; on the
  right, the Inspector and (when a COPC dataset streams) the streaming card each
  collapse on their own handle, so either can be hidden without the other. Each
  handle's state persists per browser and stays hidden until a scan is open and on
  small screens.
- **Reproducible performance diagnostics.** The optional debug overlay records
  frame-time percentiles (p50/p95/p99), counts of frames over common frame-time
  thresholds, the longest observed main-thread task where the browser supports
  it, the effective device-pixel ratio, and rendering and streaming counters,
  and copies them out as JSON. A deterministic scheduler baseline is included for
  regression testing. No general rendering or streaming speedup is claimed
  without device-specific evidence.

### Changed

- **The PDF report set is now two documents.** Survey Summary is a compact
  handover (inspection summary, dataset information, concise provenance,
  measurements, supplied technical notes). Technical Report is the full record,
  adding detailed provenance, file-declared source metadata, annotations, and
  visuals. Older report-template identifiers map to the nearest current template,
  so existing sessions and integrations still open.
- **Scan-health reporting separates three cases:** a complete decode, a
  deliberate display-sample cap, and a declared-versus-decoded count mismatch. A
  large LAS or LAZ file loaded with an intentional sampling stride reads as
  sampled rather than as having lost points. The decoded count and applied stride
  now cross the parsing-worker boundary intact. Classification coverage shows in
  the Classification row, repeated analysis caveats are merged, and an empty
  cloud reports a verdict instead of an unrelated point count.
- **Left-column panels share one width** so the rail reads as a single aligned
  stack, and its collapse handle sits flush against it. A wheel over any overlay
  panel now scrolls only that panel and never reaches the camera or the page.

### Removed

- **The Scan Acceptance report template.** Its metadata-presence rows did not
  amount to an acceptance test. Acceptance reporting should return only when it is
  backed by explicit, data-derived checks and user-defined criteria; legacy Scan
  Acceptance identifiers fall back to the nearest current template.

## [0.5.4] - 2026-07-02

Terrain science hardening. The "Terrain Complexity" reading is no longer a
heuristic: it is now backed by two literature-defined metrics computed from
the analysed DTM, with windows, units, derived confidence, and a cited
density caveat carried everywhere the number appears.

### Added

- **Real terrain-complexity metrics.** The terrain core now computes the
  Vector Ruggedness Measure (VRM, Sappington et al. 2007, doi:10.2193/2005-723)
  and the Topographic Position Index with Weiss (2001) six-class slope
  position — implemented from the primary literature, riding the existing
  Horn slope/aspect grids, and computed alongside the heavy core in the
  worker (never on the interactive path). VRM was chosen deliberately
  because it is slope-decoupled: a smooth 45° plane scores ~0 ruggedness,
  so steepness is never mistaken for complexity. Both metrics report
  median + IQR, state their window/radius in cells AND ground metres,
  state TPI's Z units, and carry a confidence derived from data support
  (valid fraction × window support) — never asserted.
- **The Dataset Intelligence "Terrain Complexity" row is engine-fed.**
  After a terrain run the row shows the band of the real VRM median
  (Low / Moderate / High / Very High) with the numeric median + IQR,
  window, and units one hover away (and in the Details panel). Until a run
  measures something it still reads "—" — nothing is fabricated.
- **A derived-metrics line on the Analyse panel** under the Terrain
  Assessment: VRM median [IQR] with its window, the dominant TPI landform
  class with its radius, units always stated, with the standard caveat
  treatment.
- **A cited density-reliability caveat.** When the scan-scaled ground
  density is below 4 pts/m², the complexity outputs carry: "point density
  N pts/m² is below the ≥4 pts/m² reliability threshold reported for
  detailed terrain/vegetation complexity (Münzinger et al. 2022,
  doi:10.1016/j.ufug.2022.127637); treat complexity as indicative." A
  warning, never a block; tested present at 2 pts/m² and absent at 6.
- **Complexity in reports and export provenance.** The terrain report and
  every export's provenance now record the metric names, window/radius in
  cells and ground units, Z units, the Horn slope/aspect convention note,
  the derived confidence, and the caveats — reproducible parameters,
  stamped word-for-word identically across README/DXF/SVG/GeoJSON/report
  (the provenance-consistency suite pins the new fields).

### Reproducibility

- `npm run repro` gains metric M5: VRM slope-independence on an analytic
  constant-45° plane vs. an equally steep rough surface, and a
  hand-computed TPI ridge-crest value with its class — CI-guarded, not
  asserted. Unit fixtures prove VRM is identical across feet/metre CRSs
  (dimensionless) and that TPI scales exactly with the Z unit.

### Scientific-audit response

A scientific audit of this release was answered in two groups: data-
correctness defects, each landed with a hand-computed regression test, and
honesty corrections — places where a formula was right but its label
claimed more than it measured. Formulas in the second group are unchanged;
the claims now state their true strength.

Data correctness:

- **EPT size-8 attributes decode by their declared type.** The binary tile
  decoder read every 8-byte dimension as Float64; `int64`/`uint64` now decode
  via BigInt and convert to Number only when exactly representable, so
  X/Y/Z-as-int64 layouts decode correctly and values beyond ±(2⁵³−1) throw
  the same typed malformed-file error the count validator uses.
- **EPT RGB bit depth is one dataset-level decision.** 8-bit-stuffed 16-bit
  colour (the same real-world wrinkle the COPC path already handles) is now
  detected once, pinned on the first decoded RGB tile, and shared through the
  decode-metadata seam — the old unconditional `>> 8` rendered such clouds
  black, and a per-tile decision could have split one cloud into two colour
  depths.
- **E57 scans without Cartesian X/Y/Z are skipped honestly.** A spherical-
  only scan used to inflate the merged allocation and leave phantom
  zero-coordinate points parked at the local origin; it now contributes
  nothing to counts, bounds, or attribute decisions, and a load warning
  (surfaced in the Scan Report) names the skipped scan.
- **E57 normals rotate with the scan pose** (rotation only, never the
  translation) instead of keeping the scanner's frame.
- **E57 pose quaternions are validated**: finite non-unit quaternions are
  normalised with a warning recording the norm; degenerate ones fall back to
  the identity with a warning — never silently scaled or NaN geometry.
- **Over-cap contour levels are thinned evenly, not truncated from the top.**
  The old cap deleted every level above it — summits vanished. Every k-th
  level is now kept with the top level forced in, so the minimum and maximum
  survive at an honestly-stated effective interval of k× the requested one.
- **Marching-squares saddles use the exact bilinear decider.** Connectivity
  now flips at the bilinear saddle value z* = (v0·v2 − v1·v3)/(v0+v2−v1−v3)
  rather than the corner mean — identical on symmetric saddles, correct on
  asymmetric ones where a dominant corner dragged the mean above the true
  saddle and mislinked the contour topology.

Honesty (labels fixed, math unchanged):

- **NVA/VVA are labelled "NVA-style / VVA-style (hold-out)"** everywhere they
  face the user, with tooltips disclosing that the figures apply the ASPRS
  2014 formulas to internally withheld points — not the independent survey
  checkpoints the standard defines them against — and that the VVA-analog is
  the p95 of ALL residuals, not vegetated-class checkpoints.
- **The USGS 3DEP Quality Level reads "(estimated)"** on the panel chip and
  the export-provenance stamp, and its tooltip discloses that the RMSEz leg
  is hold-out-based (the stride-scaled-density note already existed).
- **`checkCalibration` is now `checkConfidenceOrdering`** (result field
  `orderingConsistent`): a monotone confidence→error band ordering is a
  necessary condition for calibration, not calibration itself. The genuine
  PAV isotonic calibration in `calibrateConfidence` keeps its name.
- **Stockpile bands say what they are**: the headline prints "± N m³ (1σ)"
  explicitly, and every result carries a spatial-correlation caveat (the √N
  sampling term assumes independent residuals, which scan noise violates).
- **Change detection's "detectable" now means the ~95% level of detection**
  (|net| > 1.96σ) — the module's own documented LoD convention — instead of
  a bare 1σ bar that called a ~68% wiggle detectable.
- **The measured polygon area is described as the vector (Newell) area** —
  equal to the own-plane area for planar rings, a lower bound for non-planar
  ones — instead of "the true surface area".
- **A geographic frame analysed with an unknown latitude now warns** that the
  east–west scale is uncorrected (cos φ = 1) and derivatives are approximate,
  instead of degrading silently.

### Declared source metadata (E57) and inspection-PDF fixes

A metadata-rich E57 probe file exposed two gaps: the viewer surfaced almost
none of what the file declared about itself, and the Engineering Inspection
PDF asserted a density-derived capture type ("Drone-mounted LiDAR") over a
file whose own metadata declares a synthetic origin. Both are provenance
problems; both now honour the same rule — the viewer reports what the file
DECLARES, labelled as declared and never as verified.

Added:

- **E57 declared source metadata is captured end to end.** The schema reader
  now extracts the root-level provenance fields (guid, e57LibraryVersion,
  creationDateTime, coordinateMetadata) and per-scan fields (name, guid,
  description, sensorVendor / sensorModel / sensorSerialNumber, acquisition
  times, temperature / humidity / pressure, intensity + colour limits) —
  plus, generically, any extension-namespace String/Integer/Float leaf
  fields (e.g. an `olv:` block) at root or scan level, in document order,
  each with its namespace URI. Everything rides `CloudMetadata.
  sourceMetadata` as declared-only data: the E57 empty-element default
  (Integer/Float 0, String "") is treated as NOT declared, so a zero
  acquisition time or blank string is omitted rather than displayed as a
  fabricated value, and malformed metadata degrades to omission with a load
  warning, never a failed load.
- **The Inspector's Scan report gains a collapsible "Source metadata"
  section** listing the declared standard fields, with an "Extended metadata
  (file-declared)" subsection for extension-namespace fields — verbatim
  values (long ones truncated with the full text in the tooltip) under the
  disclosure "Declared by the file, not verified by OpenLiDARViewer". Only
  declared rows render; a metadata-less file shows nothing new.
- **The Engineering Inspection PDF gains a "Declared source metadata"
  section** with the same fields and the same not-verified disclosure,
  omitted entirely when the file declares nothing.
- **The capture-type classifier now consumes declarations as a signal.**
  When sensorModel / description / name / datasetType / accuracyClass
  declare a synthetic / procedural / reconstruction / reference origin, the
  verdict becomes "Declared: <value> (from file metadata)" — quoted
  verbatim, with the density heuristic demoted to a secondary
  low-confidence line and no literature accuracy ribbon attached (the cited
  physical capture-type bounds do not describe a declared synthetic
  source). Files without declared metadata classify exactly as before.

Fixed (Engineering Inspection PDF):

- **The page-1 text overlap.** A provenance citation containing a glyph
  outside WinAnsi ("Ruzgienė") threw mid-section; the per-section error
  isolation reverted the layout cursor, and the Measurements / Annotations
  headings drew OVER the already-rendered Provenance + Signals block. The
  citation line is now sanitised like every other drawn string, and — as
  defence in depth — a failed section resumes on a fresh page so no later
  text can ever land on partially-drawn content. A layout regression test
  parses the rendered content streams and pins the no-overlap rule.
- **Section-heading underlines span the heading text.** The rule under each
  section heading was a fixed 40 pt stub; it now spans the measured text
  width.
- **WinAnsi glyphs print as themselves.** The sanitiser replaced ², ³, ×,
  ÷, ±, °, —, – and friends with ASCII fallbacks ("m^2", "--", "1.96 x")
  even though Helvetica's WinAnsi encoding covers them; those glyphs now
  pass through verbatim (the Methods appendix follows suit), and only
  genuinely unencodable characters are mapped (≥ ≤ → ASCII, Greek → names,
  Latin-Extended letters in author names → base letters, anything else →
  a visible "?").
- **Keep-with-next pagination.** Placeholder-only sections ("No
  measurements taken…") reserve exactly their heading + body instead of a
  flat 60 pt, so a small section stays with its predecessor when it fits
  and breaks as one unit when it doesn't — no orphaned headings, no
  near-empty trailing page holding a two-line block.

### Point-cloud export correctness and provenance (verified against real user exports)

Real-world CSV/OBJ exports of a metadata-rich E57 exposed one
data-destroying defect and two disclosure gaps, all fixed here:

Data correctness:

- **E57 unit-range float intensity no longer binarizes to {0, 1}.** The
  loader stored intensity with a bare `Math.round` into the Uint16 store, so
  a file declaring continuous float intensity (the sample declares
  intensityLimits 0.2800009–0.7380647 over 1,564,029 points) collapsed to
  two values — the user's CSV export contained only 0 (551,801 rows) and
  1 (1,012,228 rows), and the intensity ramp and inspector saw the same
  wreckage. The E57 path now follows the PTS/PCD rule it missed: a
  unit-range channel (declared intensityMaximum ≤ 1, or an observed maximum
  ≤ 1 when the file declares no limits) rescales ×65535 into the 16-bit
  store — absolute scaling, never min–max stretching — while wider ranges
  stay raw. Exports carry the stored 0–65535 integers; against the real
  sample the channel now spans 18350–48369, continuous. Red-green pinned:
  the pre-fix fixture read `[0, 1, 1]`.
- **PLY and OBJ write geographic coordinates at 7 dp.** The v0.4.5 lat/lon
  precision fix (3 dp of a degree is ~110 m) reached only XYZ/CSV; the PLY
  and OBJ writers kept millimetre-style 3 dp on degrees. Both now use the
  same geographic-aware formatter; Z stays 3 dp, projected/local exports are
  byte-identical.

Honest disclosure:

- **Declared provenance rides the export headers.** XYZ (`#`), PLY
  (`comment`) and OBJ (`#`) exports of a cloud with declared source metadata
  now open with: exporter + version, source file name, declared source
  (sensorModel, else the declared scan name), declared license and declared
  limitations when present — verbatim values, single-line-flattened and
  length-capped so file text can never break the format — closed by the
  standing "declared by the file, not verified by OpenLiDARViewer"
  disclosure. Only declared fields print; a cloud that declares nothing gets
  no section, and metadata-less exports stay byte-identical to earlier
  releases. CSV deliberately stays pure data (no comment convention naive
  parsers survive): header row first, always.
- **Dropped channels are named, not silently vanished.** OBJ discloses
  intensity/classification as "not representable in OBJ — omitted" and
  normals as "not written by this exporter — omitted" (OBJ could carry
  `vn`; the wording claims no more than what happens); PLY discloses
  intensity/classification/normals; XYZ discloses normals (its intensity and
  classification ride as columns).

## [0.5.3] - 2026-07-01

A hardening patch on v0.5. Change detection gains real epoch alignment, the
viewer installs and runs offline (PWA), and a one-command harness reproduces
the evaluation — on top of seventeen defect fixes from two audit passes: nine
terrain/profile hardenings and eight Phase 0 Criticals.

### Changed

- **The on-canvas compass is now a discoverable, remembered control.** The
  compass / ViewCube gizmo from v0.5.2, previously reachable only through the
  `?viewcube=1` URL flag, can now be toggled from the command palette ("Toggle
  compass"), and the choice persists. It stays off by default: the app's left and
  right edges are full-height panel columns, so a persistent gizmo has no free
  corner without overlapping them. `?viewcube=1` and `?viewcube=0` still force it
  on or off. The animation loop pauses while the tab is hidden.

### Added

- **Two-cloud alignment in change detection.** The planar ICP core shipped in
  v0.5.2 is now wired into the two-epoch change-detection flow. Before two epochs
  are compared, the after cloud is coarse-registered onto the before cloud
  (yaw + horizontal shift only — a real vertical change is the signal, so z is
  preserved), and the fit is reported: the shift, the yaw, and the RMS residual
  appear in the compare result. A fit whose residual exceeds the gate is refused
  and the clouds are compared as-is, so alignment never invents a shift it can't
  stand behind. The pure core (`alignEpochClouds`) is unit-tested.
- **Installable and offline (PWA).** A service worker caches the app shell, so
  the viewer opens and runs with no network after the first visit, and it can be
  installed as a standalone app. The worker is local-first by construction: it
  caches only the same-origin app shell and never touches a cross-origin dataset
  request, so opening a remote scan still goes straight to its source and nothing
  the user loads is stored. Registered on production secure origins only.

### Reproducibility

- **A one-command evaluation harness** (`npm run repro`). It runs the pure
  analysis cores over deterministic synthetic fixtures with analytic ground truth
  and writes a metrics table plus reliability figures: the epoch-registration
  vertical-bias result (horizontal-only preserves a uniform vertical change while
  a full-3D fit absorbs it), planar-alignment recovery, stockpile ±-band coverage
  (empirical vs nominal 0.68), and report-digest determinism. The coverage and
  bias checks also run as a CI-guarded unit test, so the uncertainty claims are
  tested rather than asserted. A `REVIEWER_QUICKSTART.md` gives the
  clone → test → repro → verify path.

### Fixed

- **The deployed site no longer runs slower than a local build.** The live
  deployment's source transform rewrites property access into decode-wrapper
  calls — and inside per-POINT loops that meant one wrapper call per point per
  access. On a 2.5 M-point scan the deployed site burned seconds a plain build
  does not: the scan-attach main-thread task grew from 6.6 s to 10.2 s and a
  single measure/probe pick from 56 ms to 178 ms (3.2×, profiled headless
  A/B). The six modules that carry whole-cloud loops (health check, cloud
  bounds, colour encoding, pick math, snap grid, viewer attach/render loop)
  are now excluded from the transform, and the deployed build measures at
  parity with the plain one. Local files still never leave the machine — this
  was compute, not upload.
- **Opening a large local file no longer freezes the viewer for seconds.** The
  Scan Report's health check walks every point several times (duplicate-point
  scan, median/MAD, outliers, finite check) and ran synchronously at scan
  attach — ~5 s of frozen UI on a multi-million-point cloud, on top of the
  transform cost above. It now runs when the main thread next goes idle: the
  scan renders and navigates immediately and the report card fills in a beat
  later. Measured attach-path blocking fell from 6.6 s to 0.6 s at 2.5 M
  points.
- **Offline support now works on sub-path deployments.** The service worker
  registered as `/sw.js` — an origin-root path, so any deploy under a sub-path
  (GitHub Pages `…/repo/`) 404'd the registration and silently lost offline
  support and installability. The worker URL now resolves relative to the page
  (unit-tested), and the worker's sample-dataset cache exclusion resolves
  against its registration scope the same way.

Nine correctness hardenings from the v0.4.x terrain/profile audit, ported onto
the 0.5 pipeline (each verified at its current location before fixing, every
new expectation hand-computed):

- **Geographic (lat/lon) scans no longer collapse to a 1-cell grid.** The
  analysis runner's cell-size floor was a raw `0.25` in SOURCE units — on a
  degree CRS that forced 0.25° ≈ 28 km cells, flattening any scan under ~64° of
  extent to 1–2 cells. The floor is now 0.25 metres expressed in the source
  unit (degrees ÷ metres-per-degree, feet ÷ metres-per-foot; metres unchanged).
  Two-epoch change detection's shared grid had the same unit-blind floor and
  gets the same fix, with each cloud's CRS units threaded honestly from the
  loaded metadata (and surviving epoch alignment).
- **cos φ everywhere derivatives run, from the WORLD latitude.** v0.5.0 made
  the hold-out and cell-confidence slope fields per-axis, but both derived the
  "grid-centre latitude" from render-RECENTRED local Y — which is ≈ 0, so
  cos φ silently degraded to 1. The runner now recovers the true world latitude
  (cloud origin + local bbox centre) and threads it through the pipeline; the
  main derivative stage (slope/aspect/hillshade) is per-axis too, through the
  whole TerrainRasterEngine — CPU reference, the WGSL Horn kernel's uniform,
  and the per-session equivalence probe, which now runs an anisotropic pass so
  a GPU kernel that ignores the second axis can never pass the gate. Per-cell
  densities (and the USGS QL graded from them) fold the cos φ cell-area
  anisotropy in as √(cos φ). The CPU remains the reference by contract.
- **One percentile convention.** Three conventions coexisted: nearest-rank in
  `holdoutRmse` / `buildDsm` / `hillshade` vs the type-7 (NumPy/R/Excel
  PERCENTILE.INC) quantile in `rasterizeDtm` / `wallSlice`. Every p95 the
  pipeline reports now routes through one shared type-7 helper
  (`src/terrain/quantile.ts`), so a reported percentile is reproducible
  against standard tools regardless of which file computed it.
- **Contour correctness on fine and degree-denominated grids.** Contour
  stitching's endpoint-matching quantum was a fixed 1 mm — ≈ 111 m in degrees,
  welding a fine geographic grid's contours into one blob; it now scales with
  the grid cell (cell/1000, unit-free). The coarse-interval gate used the
  range-only rule `interval < range`, falsely rejecting e.g. a 1 m interval on
  a 0.4–1.2 m surface even though the 1.0 level crosses it; with real surface
  bounds it now uses the exact level-crossing test (`ceil(minZ/i)·i ≤ maxZ`).
  Marching-squares saddle cells (cases 5/10) are now disambiguated with the
  standard cell-average rule instead of a fixed pairing that silently assumed
  centre-below for both — mislinking basins on ridge/col terrain.
- **The ground-filter despike actually fires on small cells.** The documented
  `floorPercentile` despike was a silent no-op for cells with ≤ 20 returns
  (`ceil(0.05·n)−1 = 0` — the strict minimum, blunder included, still won).
  Once a cell has ≥ 3 returns, at least the single lowest return is now
  skipped; 1–2-return cells keep the minimum (no evidence to reject either).
- **Signed vertical grade.** A straight-DOWN pair reported `gradePercent` as
  an infinite CLIMB (`+Infinity`); the grade's sign now matches the rise's
  (±∞), agreeing with the ±90° the angle already reported — in both
  `slopeBetween` and `profileMetrics`.
- **Terrain worker point-count clamp.** An oversized caller-supplied point
  count would throw inside the terrain-core worker while rebuilding its typed
  array — silently costing the off-thread path via the fallback. The count is
  now clamped to what the buffer actually holds.
- **Geographic CRS measurements are refused, not mislabelled.** On a
  geographic (degree) CRS, X/Y are degrees while Z is linear, so lengths,
  areas, grades, profiles and volumes mix units and no scalar factor can
  repair them — a 0.35-"m" corridor is really ≈ 39 km. The measure stack now
  says so everywhere with ONE shared string: affected measurements carry the
  red refusal trust grade (not presentable — pure-vertical heights and
  unit-free angles keep their ordinary grade), the measure-bar hint carries
  the caveat, and the Measurements panel shows a persistent notice while the
  frame is geographic. Symmetric on a user override to a projected CRS.

Eight Critical-severity fixes from the Phase 0 baseline audit of the v0.5.x
line (each reproduced with a failing test before the fix wherever the surface
allows):

- **Applying epoch alignment no longer degrades a georeferenced survey.** The
  aligned after cloud was stored as ABSOLUTE world coordinates in a
  `Float32Array` with its origin collapsed to zero — at georeferenced
  magnitudes (UTM northing ~4,000,000) the float32 quantum is ~0.25–0.5 m,
  larger than the centimetre-level misalignment ICP corrects, so applying the
  alignment injected up to half a metre of horizontal jitter into the after
  cloud before rasterisation, on the most common real case (two georeferenced
  surveys). The transform is now computed in float64 world space and stored
  back LOCAL to the cloud's preserved origin; only the small residual rounds
  to float32.
- **Planar ICP is refused on geographic (degree) frames.** `alignEpochClouds`
  received the geographic flag on both clouds but never read it: the planar
  rigid model was fit in raw lon/lat, where 1° of longitude ≠ 1° of latitude
  (cos φ) — a solved yaw is a SHEAR in metres, the convergence tolerance was
  ~1.1 m expressed in degrees (declaring convergence long before a meaningful
  fit), and the residual gate compared degree numbers against a metre
  threshold. The transform could worsen registration off the equator while
  reporting success. Measurements already refuse geographic frames through
  the trust system; alignment now refuses them too — clouds untouched, with a
  distinct summary line pointing at reprojection.
- **Alignment reports metres, not source units.** The alignment result
  documents its shift and residual in metres and the UI prints "N m", but the
  values came out of the fit in the clouds' own units — a foot-CRS survey
  shifted 10 ft displayed as a "10.00 m shift", and the metre-denominated
  residual gate compared against feet. The unit seam now lives in one place:
  the gate converts to source units going into the fit, the reported shift
  and residual convert to metres coming out, and the applied transform stays
  in source units, as it must. Geographic frames never reach this seam — they
  are refused earlier.
- **Geographic epochs refuse cut/fill volumes instead of printing degrees² as
  m³.** The epoch-compare path passed geographic DTMs straight into volume
  integration, where a degree-sized cell area underreports volumes by ~10
  orders of magnitude, and the summary printed the result as "N m³" — worst
  case flagged MEASURED, because two epochs declaring the same geographic CRS
  and vertical datum pass every co-registration check. Volumes on a degree
  grid are now refused with the shared geographic-refusal reason; the Δz
  statistics remain valid and are still reported (z is a linear unit).
- **Lasso reclassify can no longer edit points you cannot see.** The lasso
  selection culled only points outside the view frustum, so a reclassify
  permanently rewrote points hidden by the active clip box or by a hidden
  ASPRS class — an edit to invisible data, contradicting the click-pick
  contract, which already refuses hidden points. The selection now runs
  through the same clip predicate the GPU clipping planes realise and the
  same class-visibility mask picking uses; in-place compaction, no allocation
  on the edit path.
- **A classification edit flags the on-screen analysis stale.** The edit hook
  promised cache invalidation AND a re-grade, but only cleared the
  terrain-core cache — the rendered verdict, contours, and coverage stayed on
  screen presented as current while reflecting the previous classification.
  The Analyse panel now shows a staleness caveat at the top of the results
  ("results reflect the previous classification — re-run Analyse"), cleared
  by the next run, and the contract now states what actually happens: a
  staleness disclosure, not a silent auto re-grade.
- **The clip box survives a session round-trip.** The v5 session schema
  documents a clip round-trip and the import side has restored it since v5,
  but export never emitted the clip — no session written by this app could
  carry one. Emitting it exposed two more gaps, fixed together: the
  reveal-time auto-frame destroyed a clip restored before the scan appeared
  (now skipped when the viewer already holds one), and the Clip panel never
  reflected a restored box (it now adopts the state — inputs, mode pills,
  enable box, readout — without re-firing the apply).
- **Visiting another page can no longer poison the offline app shell.** The
  service worker cached EVERY same-origin navigation response under the
  app-shell key, so opening the credits page (or landing on a 404/500 or a
  redirect tail) replaced the cached shell and the next offline launch served
  the wrong document as the app. The shell now refreshes only from an ok,
  non-redirected response to the registration-scope root (or its
  `/index.html`).

## [0.5.2] - 2026-06-29

A polish release: a stronger integrity digest, a richer earthwork report, an
opt-in on-canvas compass, and a build guard that closes the live-only 404 class
for good.

### Changed

- **The integrity report now uses SHA-256 by default.** The content digest that
  makes a measurement report tamper-evident is now a cryptographic-strength
  SHA-256 (manifest v3), computed synchronously so the core stays pure and
  deterministic. It is still an integrity digest, not a secret-keyed signature.
  A caller can inject the older FNV-1a checksum where speed matters more.
- **Volume findings carry the whole earthwork.** A volume measurement in the
  integrity report now reports the net as its headline with the cut and fill,
  the footprint area, the confidence tier, and any streaming-resident caveat
  riding along, instead of the fill alone.

### Added

- **On-canvas compass / ViewCube (opt-in).** A small compass gizmo shows which
  way the camera faces and snaps to a standard view on click. Behind `?viewcube=1`
  while it gets on-device verification; the heading/face math is unit-tested and
  the widget loads lazily.
- **Build guard against inline dynamic imports.** A new `lint:inline-imports`
  check fails the build if a runtime `import('./…')` reappears in `main.ts`,
  where the obfuscator could scramble the specifier into a deploy-only 404. Wired
  into the release gate and CI.
- **Release-sync guard.** A new `lint:release-sync` check fails the build unless
  the version in `package.json`, the lockfile, the README's current-release line,
  the changelog section, and the release-notes file all agree. Wired into the
  release gate and CI.
- **The integrity report records the version that produced it.** The exported
  report manifest now carries the app version, so a reader can tell whether a
  newer build would grade or label the scan differently. The field is covered by
  the report digest.
- **Re-opening an old session flags a version gap.** A saved session now stamps
  the app version that wrote it; opening one written by an earlier build shows a
  short notice that the current build may read the scan differently, so you can
  re-save. A session with no stamp reads as "an earlier version".
- **Verify an integrity report.** A new command-palette action ("Verify
  integrity report…") opens a report JSON, recomputes its digest against the
  algorithm the file names, and shows whether it is intact or has been modified,
  along with the producing version, classification epoch, and finding count. The
  handed-over report becomes a checkable artifact, not just a JSON dump.

### Foundations

These tested cores ship in source ahead of the interface that will use them, the
project's usual pattern:

- **Planar ICP alignment** (`icpRegister`) — coarse rigid alignment of one cloud
  onto another (3-D translation + yaw) with a reported RMS residual that refuses
  a fit it can't trust. The honest prerequisite for aligning two epochs before a
  change comparison.
- **Export-staleness helper** (`exportStaleness`) — compares a stamped producing
  version against the running one, so an export from an older build can be
  flagged for regeneration.

### Performance

- **Lighter startup.** The workflow-recorder settings popup now loads on first
  open instead of riding in the eager startup bundle, trimming the live index
  chunk (757 → 750 KiB) and shaving a little off first paint. The bundle ceiling
  was lowered to match, so the saved room can't silently creep back.
- The opt-in on-canvas compass animation loop pauses while the browser tab is
  hidden rather than running every frame in the background.

### Documentation

- The navigation guide and the User Guide now list the keyboard and mouse
  shortcuts (command palette, the `?` sheet, undo, right-click menu, hold-Space),
  sourced from the live key bindings.

### Maintenance

- The native-unit contract is documented on `StockpileBreakdown`, and the report
  export's `signed*` names were renamed to `integrity*` to match what the file
  actually is.

## [0.5.1] - 2026-06-28

Deepens the honest-uncertainty work. Stockpile/earthworks volume now reports an auditable
confidence band, manual classification editing lands end-to-end (class picker,
lasso reclassify, multi-step undo/redo), and measurements export as a
tamper-evident integrity report. Adds two-epoch change-detection uncertainty and
edit-aware provenance so an edited classification can never silently outlive the
numbers computed from it.

### Added

- **Stockpile / earthworks volume with a confidence band.** The lasso volume
  readout carries a ± band that states its own uncertainty — a sampling-error
  term (area·σ/√N) and a systematic base-plane term (a single horizontal base
  under sloped ground biases every thickness the same direction) combined in
  quadrature — plus a show-the-math breakdown and honest caveats.
- **Manual classification editing.** A class picker and a lasso-reclassify tool
  with real multi-step undo/redo, lazy-loaded beside the classification legend.
  Edits mutate the live class channel, so they round-trip straight into LAS
  export.
- **Tamper-evident integrity report.** Placed measurements export as a JSON
  report whose findings, dataset provenance, and classification edit-epoch are
  folded into a verifiable content digest (deterministic canonical hashing;
  default FNV-1a, named in the manifest as `digestAlgorithm`). Changing any
  figure without recomputing the digest breaks verification — a guard against
  accidental or casual edits, not a secret-keyed cryptographic signature
  (SHA-256 hashFn is injectable for that).
- **Two-epoch change-detection uncertainty.** A volume-change ± band (random
  cell noise that averages as √N plus a systematic co-registration term) that
  also reports whether the net change exceeds its own error — never presenting
  noise as a confident gain or loss.

### Changed

- **Undo now reaches every edit.** Ctrl/Cmd+Z (and Shift+Z / Ctrl+Y to redo)
  undoes whichever history you touched last — annotations or classification —
  and falls through to the other once one empties. Classification edits were
  previously reversible only from the reclassify panel's own buttons, so a
  keyboard undo did nothing after a lasso reclassify.
- **Hold Space to re-orient mid-tool.** While Measure, Inspect, or Annotate is
  active, holding Space hands the mouse back to camera navigation so you can
  rotate, pan, and zoom without leaving the tool, then release to resume.
- **Right-click menu on the scan.** Right-clicking a loaded cloud offers focus
  the pivot on the point under the cursor, frame the whole scan, or snap to the
  top / front / oblique view.
- **Accurate keyboard help.** The Help overlay now documents the up/down and
  sprint navigation keys, the measure-mode Enter/Backspace keys, and the
  broadened undo, matching what the viewer actually does.
- **More detail on capable desktops.** The high-end desktop tier (ample RAM and
  cores) now keeps more of a dense survey resident before automatic point
  reduction kicks in; mid and low tiers and mobile are unchanged, and the GPU
  safety ceiling still bounds every path.
- **Stockpile volumes flag a reduced cloud.** When a cloud was automatically
  reduced to fit the device, a lasso/stockpile volume now adds a caveat that the
  inside points are a representative sample of a denser survey — the ± band
  already widens with the thinner sample, and now the reason is stated.
- **Classification edits invalidate stale analysis.** Each edit (swap,
  reclassify, undo, redo) bumps a per-cloud edit epoch and drops the
  terrain-core cache, so the next Analyse recomputes against the edited classes
  instead of serving a grade that no longer matches the cloud.

### Fixed

- **Stockpile base-plane honesty.** Base uncertainty now models the systematic
  mis-fit of a flat base under sloped ground, not just point scatter — a sloped
  apron honestly widens the band instead of reporting a confidently-narrow
  number.
- **Sampling-error self-consistency.** The √N in the stockpile sampling error is
  taken over the same finite inside-height population its σ is computed on.
- **Reliable file downloads on Safari / iOS and for large exports.** Every export
  now funnels through one helper that releases the temporary blob URL only after
  the download has had a moment to start, instead of immediately — an immediate
  release could cancel large PDF / DEM / batch-ZIP / integrity-report downloads
  mid-transfer on some browsers.
- **Imported render state is range-checked.** A point size or field-of-view read
  back from a saved session is now clamped to a sane range, so a hand-edited or
  corrupted session file can't load the viewer into an unusable display state.

### Tooling

- The browser smoke test can now optionally run against the production
  (minified) build, catching build-only breakage that the development build
  never surfaces.

## [0.5.0] - 2026-06-26

Opens the v0.5 line (Measure · Place · Compare · Share): point snapping, KML
export, the Layers panel (isolate / lock / CRS-mismatch flagging), two-epoch
change detection, and the clip box. The line also gained a full-cloud quality
grade for streaming scans, an Evidence Capsule that carries trust grades inside
the shared session, per-measurement honesty grading, and a substantial
correctness, units, performance, and security hardening pass.

### Added

- **Full-cloud grade for streaming scans.** Streaming COPC/EPT scans can be
  graded against a deep octree sample rather than the preview tile — an
  areal-primary density tier, valid-point tracking, cancel support, and a Z
  graded in true metres via the vertical CRS unit. The grade is discarded if the
  scan is detached or replaced mid-decode.
- **Evidence Capsule.** Trust grades and provenance travel inside the shared
  `.olvsession`, so a re-opened session shows the same honesty assessment it was
  saved with.
- **Per-measurement honesty grade.** Each measurement carries a red/yellow/green
  grade with a "show why" breakdown and a refusal gate when the data can't
  support the claim.
- **Instant analysis-on-drop.** Dropping a scan surfaces the most relevant
  analysis one click away, before any upload.
- **Unified `.olvsession` open.** One router handles drop-to-open and the
  open-from-URL path consistently.
- **Drone capture-type classification** for dense low-altitude UAV flights, with
  capture-type confidence surfaced.
- **Elevation-difference export** (`.asc`) that honours the active clip box, plus
  three roadmap on-ramps (3D Tiles guidance, COPC conversion, co-registration
  checklist).

### Performance

- **EPT laszip tiles decode in a dedicated worker**, off the main thread —
  mirroring the COPC decode worker (request-id multiplexing, abort, stale-reply
  drop), with an in-process fallback and a browser round-trip e2e.
- **ClipPanel edits are debounced** and the **per-cloud health check is
  memoised**, so editing the clip extents or refreshing the Inspector no longer
  re-runs O(N) work on every keystroke.
- **Full-cloud grade streams into one buffer** instead of chunks plus a merged
  copy; the session parser, the measurement/KML exporters, and two-epoch change
  detection are lazy-loaded off the initial bundle; export downloads copy the
  payload only when it is a partial view; the default streaming point budget is
  trimmed to 2.5M and EDL is suspended while the camera moves.

### Fixed

- **Cut/fill volume on Y-up scans.** The Volume measurement integrated point
  heights along a hardcoded Z axis even on Y-up clouds (iPhone / mobile PLY,
  OBJ, GLB/GLTF exports), while the reference plane was already derived along
  the cloud's real up-axis — so the height axis and the reference disagreed and
  the reported cut/fill volume was wrong. The volume sampler now reads the
  configured world up (`_worldUp`), matching the profile sampler's earlier B1
  fix. Z-up surveys (LAS/LAZ/E57) and the streaming COPC/EPT path — Z-up by
  spec — are unaffected.
- **Clip control no longer throws on a fresh page.** The clip panel cleared its
  state during construction, which fired before the deferred 3D viewer existed
  and raised an uncaught error on every page load. The clear is now a no-op
  until a scan is open, matching every other startup-reachable viewer action.
- **Units reported in true metres.** Lasso volume, the scan report, scan-story
  footprint area, and change-detection cut/fill now convert from the source
  CRS's native units to metres (and m²/m³) instead of reporting raw projected
  units; per-axis slope on geographic grids applies the cos φ longitude factor.
- **Horizontal datum resolved once, never downgrading.** The datum is derived a
  single time and a known datum is never replaced by a coarser guess.
- **COPC RGB bit-depth decided once per file**, not per chunk, so colour can't
  shift between octree nodes; the EPT laszip path unifies the same way.
- **EPT laszip worker URL stays readable in the shipped build.** The obfuscated
  bundle's string transform could scramble the worker URL into a 404; the worker
  client is now excluded from that transform and both chunks are pinned.
- **A non-finite coordinate can no longer blow `PointCloud` bounds to infinity**;
  GPS Standard Time is declared in converted LAS global encoding; the streaming
  colour ramp seeds from the coarsest node; the shared parse-worker is serialised
  across concurrent loads; two epochs are aligned by origin before differencing.

### Changed

- **One sRGB colour seam.** The linear→sRGB OETF, previously carried as two
  byte-identical inline copies in `patchView.ts` and `colorProvenance.ts`,
  now lives once in `colorEncode.ts` as `linearToSrgbScalar` (the exact
  inverse of the existing `srgbToLinearScalar`). Both leaf modules already
  shared the decode direction; the encode direction is now converged too, so
  the provenance card and the neighbourhood splat can no longer drift from
  the curve the GPU upload uses.

### Security

- **Enforcing Content-Security-Policy** (`script-src 'self' 'wasm-unsafe-eval'`,
  `style-src 'self' 'unsafe-inline'`) shipped in both `.htaccess` and `_headers`,
  backed by an `unsafeHtml` injection-sink lint guard wired into CI.
- **Supply-chain hardening.** loaders.gl is pinned to local workers (no CDN
  fetch), and the CI workflows run with least-privilege permissions and bounded,
  capped test buckets.

## [0.4.9] - 2026-06-20

### Added

- **Data Fitness scorecard.** The Analyse panel now leads with one plain-language
  verdict and a six-row traffic-light scorecard — Location & height, Coverage,
  Ground detail, Vertical accuracy, Classification, Integrity — each with a
  metaphor icon and a shape-distinct tone glyph (check / dash / triangle, never
  colour alone). Caveats are non-hideable, and the USGS Quality Level badge is
  shown only when earned (georeferenced, density above floor,
  accuracy validated).
- **Portable security headers.** A `_headers` file ships alongside `.htaccess`
  so the same deploy bundle is hardened on Netlify / Cloudflare Pages-style
  static hosts, not only Apache-family ones.

### Changed

- **File-scale honesty across every surface.** Large clouds are strided for
  display, so the rendered count is a subset. The Scan Report, the Engineering
  Inspection PDF, the Provenance density, and the Layers chip now report the
  file's true point count and areal density (back-scaled from the sample), with
  a "Loaded" row disclosing the in-memory subset — a dense survey no longer
  reads as several times sparser than it is.
- **Capture-type detection.** Dense drone surveys (UAV LiDAR, ~100–1000 pts/m²
  over an open mapping footprint) classify as drone-mounted LiDAR rather than
  Terrestrial Laser Scan, matching the cited density literature.
- **Honest classification + terrain wording.** A classification dimension that
  carries no assigned classes reads "Present, unclassified" instead of a bare
  "Yes"; the Terrain Intelligence Report labels its ground-point counts "Ground
  points / Used in DTM" rather than the misreadable "Source points".
- **Analyse panel de-duplicated.** Each fact now has one home — the scorecard is
  the headline, the assessment block carries export readiness + terrain products
  + "Why?", and the collapsed Details holds the lone composite score and the
  unique validation detail.
- **Portable PWA manifest.** Relative `./` paths + `scope` so the app installs
  correctly under subpath hosting; `X-Frame-Options: SAMEORIGIN` added.

### Fixed

- The point cloud no longer clips to a square on browser zoom-out.
- Contour GeoJSON exports carry 3D coordinates (elevation) and per-feature
  evidence grades.
- Vertical units are honoured: `VerticalUnitsGeoKey` (4099) and the WKT vertical
  `UNIT` are parsed, and Z is scaled to metres for accuracy bucketing.
- Honest height wording for georeferenced scans. A horizontally-georeferenced
  scan with an undeclared vertical datum (common for drone LiDAR — absolute
  Z, no `VerticalCRS`) now reads "elevation datum not declared" rather than
  "heights are relative." Its heights are absolute; only the datum is unverified.
  Truly floating scans (no CRS) still read "relative."

### Under the hood

- A tested orchestration seam for the full-cloud grade (plan → coverage →
  back-scaled grade) landed ahead of its streaming surface.
- Brand assets trimmed ~1.05 MB from the deploy: the mark and favicon are
  re-rastered to display size, and the unused full-resolution logo master moved
  out of the shipped bundle (kept in the repo for regenerating share cards).

## [0.4.8] - 2026-06-17

### Added

- **Data sources & credits.** A new credits page (in-app `credits.html`, reachable
  from a Credits link in the header, mirrored in `docs/credits.md`) attributes the
  streamed sample datasets to their providers — USGS 3DEP, swisstopo, GURS, and AHN
  — and thanks the open-source projects the viewer is built on (three.js, loaders.gl,
  proj4, pdf-lib, laz-perf). The README gained an Acknowledgements section tying
  these together.

### Changed

- **Curated datasets restricted to confirmed-open sources.** The public-LiDAR
  picker now lists only datasets with a confirmed open licence — USGS 3DEP
  (public domain) and the swisstopo / GURS / AHN national programmes. Sample
  datasets whose licence could not be confirmed were removed, and the bundled
  "Public streaming demo" button (which pointed at an unlicensed demo bucket) was
  removed; the open-from-URL field still accepts any COPC/EPT URL.
- **Sessions remember the class-visibility filter.** Hiding classes (e.g. "ground
  only") and exporting an `.olvsession` now carries that filter; re-importing
  restores it. Schema v5, strictly additive — older sessions load unchanged.

### Fixed

- **Third-party notices completeness.** `THIRD_PARTY_NOTICES.md` now lists `proj4`
  (MIT) and the Manrope and JetBrains Mono fonts (OFL-1.1), which were bundled but
  previously unlisted.
- Corrected the Slovenia (GURS) dataset licence label, which had asserted a specific
  CC version the sources don't agree on.

### Under the hood

- Tested, pure cores landed ahead of their interactive surfaces: measurement
  GeoJSON/CSV export, two-epoch DTM change detection, an axis-aligned clipping-box
  region core, a breadth-first full-cloud sampling planner, and a gzip (`.las.gz`)
  export path. Each is unit-tested in isolation; the UI that drives them follows.

## [0.4.7] - 2026-06-15

A correctness and honesty pass across the load, export, and analysis paths,
alongside a few accessibility and workflow additions.

### Added

- **Colourblind-safe classification palette.** A checkbox in the Classes panel
  recolours the classes with an Okabe-Ito categorical palette (ground orange,
  vegetation as lightness steps of bluish-green, buildings vermillion, water
  blue) that stays distinguishable under the common colour-vision deficiencies.
  The class label and count stay on every row, so colour is never the only cue.
- **Annotation grouping.** The Annotations panel and the PDF report now open
  with a one-line summary of the notes — totals, the per-category breakdown, and
  how many areas they fall across — so a dense set reads at a glance.
- **Workflow recorder.** Record a sequence of camera moves and tool actions and
  replay it (on the same scan), with a settings popup for the file format,
  save destination, start/stop shortcut, replay speed, a pre-record countdown,
  which action families are captured, and loop replay. Records actions only —
  never scan data.
- **Signal-tier cue on the Dataset Intelligence card.** A quiet coloured dot
  marks each row's qualitative tier; terrain complexity stays neutral (it is
  descriptive, not a quality) and a missing signal is muted. The colourblind
  toggle also re-themes these status dots and the confidence chip.
- **Recommended-view chip.** After a scan loads, a small dismissible chip
  suggests the best camera preset (top-down for a wide classified surface,
  oblique for a colour scan, isometric otherwise); one click applies it.
- **Profile stations on the cloud and in the report.** A cross-section profile
  drops small station markers along the section line in 3D, and the PDF report
  now draws the profile as a sharp vector chart, not just the station text.
- **More accessible report PDFs.** The document title is announced instead of
  the filename, and the document language is tagged for correct pronunciation.

### Fixed

- **Empty files are rejected with a clear message.** A file that decodes to
  zero points is no longer opened into a blank, unframable scene; it is
  rejected at the parse stage with a message explaining there are no points to
  display. A point cloud with no points now reports a finite bounding box
  rather than an infinite one, so nothing downstream can target a degenerate
  camera.
- **Reprojection never ships non-finite coordinates.** A transform whose output
  falls outside the target projection's valid area (proj4 returns Infinity or
  NaN without raising an error) is now treated as a failed transform: the
  coordinates are left in their source system and the converter reports how many
  points were affected, instead of writing a file with NaN coordinates.
- **Contour map sheet reports an unmeasured interpolation honestly.** When there
  are no contours to measure, the legend reads "Interpolated fraction — not
  measured" instead of a fabricated "0% interpolated".
- **Measured areas read the same in the PDF report as on screen.** The report's
  area formatting is single-sourced from the live measurement overlay, so a
  polygon documents itself in the same units (m² / ft² / acre) the user saw
  while measuring.
- **Point density reads "—" when it is unknown.** With neither a measured
  density nor the point count and bounds to derive one, the dataset card no
  longer shows a confident "Sparse"; it shows "—", matching how terrain
  complexity and ground visibility already report a missing signal.
- **Disposal.** The colour-recompute throttle's trailing timer is cleared when a
  viewer is torn down, and a streaming (COPC) cloud now closes its underlying
  file/range reader when detached, so neither lingers after teardown.
- **Load errors are described precisely.** A typed load failure now keeps its
  category as it crosses from the decode worker to the main thread, so the
  message shown is the exact one for the failure rather than a best-effort guess.
- **Foot-based coordinate overrides.** When a coordinate system is assigned by
  hand, its linear unit is resolved from the CRS registry rather than assumed to
  be metres, so a foot-based system scales measurements correctly.

### Changed

- **Large text scans load on tighter memory.** The XYZ/CSV loader releases its
  intermediate buffers as it builds the final arrays, lowering peak memory by a
  full copy of the cloud on the largest files.

- **One byte-size formatter** is shared across the stage, batch converter, debug
  overlay, and streaming panels, so a file size reads identically everywhere.
- **The unit test suite is split into four buckets** (`test:unit`,
  `test:terrain`, `test:ui`, `test:slow`) that together cover the whole suite,
  so it can run in parallel.

## [0.4.6] - 2026-06-14

Phase 1 of the design audit (visual-only; verdict-as-hero, two-tier surfaces,
quieter typography, mobile reflow, surface-quality chip density reduction) lands
alongside the GPU compute seam — the TerrainRasterEngine with equivalence-gated
WebGPU derivative/scatter kernels where the CPU stays the reference and the GPU
must prove per-session equivalence before it is trusted, falling back silently
otherwise. The interior floor plan remains an experimental PREVIEW, now backed by
an explicit wall-graph reconstruction and flood-fill room segmentation with
claim-accurate labels throughout. Plus nine label-vs-value drift fixes (incl.
foot-CRS / geographic-unit correctness and the edge-risk wording) and mobile
touch-target / safe-area improvements. Three more visible improvements:
the plumbed-but-headless floor-plan export knobs get a small
UI (still an experimental PREVIEW), the last flagged capture-quality
label-vs-value drift ("Coverage … % of footprint" → "Bounding area filled") is
closed, and the streaming loader's indeterminate text becomes an honest
determinate resident-node progress bar.

### Navigation, tooling & hardening

- **Standard views + parallel projection.** Six axis-aligned camera views
  (Top / Bottom / Front / Back / Left / Right) snap the camera to look straight
  at a face for distortion-free measuring, alongside an Orthographic toggle that
  switches to a near-parallel projection (a long-lens approximation that leaves
  the render pipeline, culling and picking untouched). The view geometry is pure
  and unit-tested.
- **Icon + label toolbars.** The bottom dock, the measurement toolbar, the
  Layers "Solo" control and the Export header gain a consistent custom line-icon
  set, each keeping its visible text label (icon-only toolbars measurably hurt
  first-time users). Inspect and Probe are deliberately differentiated (target
  vs eyedropper). On phones the measurement toolbar reflows into a vertical
  rail; on desktop it is a top-centre bar that no longer overlaps the
  left-docked panels.
- **Full-screen toggle** in the header, with a glyph that tracks the real
  Fullscreen state (so F11 / Esc are reflected too).
- **Contour map sheet (PDF) fixes.** The title no longer overlaps the legend on
  long filenames; the contour-interval unit now matches the scale bar (m / ft);
  and an ungeoreferenced sheet drops the E/N graticule suffixes and the north
  arrow rather than implying a compass frame it doesn't have.
- **Security.** Parameter-derived button labels are escaped via `textContent`;
  only trusted static icon SVG passes through the raw-markup path, each site
  registered on the `unsafeHtml` review allowlist.
- **Smaller polish.** "Solo" is disabled when only one class is present; the
  `?debug` overlay clarifies the wall-clock load total, reports the CPU/GPU
  terrain compute path, and stops printing a false "0 draw calls"; and the
  Preview "not recommended for" wording reads "outputs requiring independent
  validation".

### Design

Phase 1 of the v0.4.6 design audit — a visual-only pass (no logic, data, or
component-behaviour changes; every selector preserved, all unit tests
stay green) that evolves the existing `src/style.css` token system to make the
honesty-first verdict the unmistakable hero and calm everything around it.
Dark, Light, and High-contrast themes all verified WCAG AA on the new
combinations (verdict-on-card ≥5.8:1 in every theme; primary action ≥4.9:1).

- **Two-tier surfaces (audit 1.2).** New `--panel-raised` / `--panel-recessive`
  / `--shadow-raised` / `--hairline-strong` tokens (defined in `:root` and
  overridden per theme). The Analyse verdict card and the Inspector "Color by"
  control rail now read RAISED (lift shadow, firmer edge); the secondary
  stacked left panels (Measure / Annotation / ClassLegend / Export / Object)
  drop to a RECESSIVE translucent fill and lift back to the full panel on
  hover/focus-within — focal hierarchy at last, costing one token pair.
- **Verdict as hero (audit 1.1).** `.olv-analyse-assess-verdict` jumps from a
  hard-coded 19px to `--text-2xl`; the full-card rating tint (previously only
  on `is-blocked`) now applies to ALL states (good / preview / limited /
  blocked) at low alpha, so the card's background subtly carries the verdict
  colour. The card rises + fades in last (reusing `olv-ready-in`) so the eye
  lands on the truth first.
- **Quieter typography (audit 2.1).** `text-transform: uppercase` + `var(--mono)`
  are now reserved for top-level section labels and honest-status WORDS
  (Ready/Preview/Blocked). Sub-group eyebrows and metric sublabels —
  `.olv-visuals-group-label`, `.olv-render-sublabel`,
  `.olv-analyse-assess-metric-label`, `.olv-analyse-workflow-head`,
  `.olv-analyse-products-head`, `.olv-analyse-why-subhead`,
  `.olv-object-subhead`, `.olv-getstarted-eyebrow`,
  `.olv-analyse-product-reason-label` — move to calm sentence-case Manrope.
  Tabular numeric/coordinate readouts stay monospace (untouched).
- **Honesty as a visible system (audit 2.4).** A single reusable `.olv-caveat`
  primitive (left-rule + tinted bg, modelled on `.olv-di-warning`) with
  `--caveat-rule` / `--caveat-tint` tokens, applied uniformly to every honest
  limit: Suitability caveats (`.olv-object-note`), Blocked/Preview reasons
  (`.olv-analyse-reason`, `.olv-analyse-product-reason`), and export notes
  (`.olv-analyse-dem-note`, `.olv-analyse-export-note`). The
  "Private · on your device" trust pill (`.olv-badge`) is elevated to a
  confident pill with a CSS-drawn lock glyph and a firmer accent edge.
- **One primary action per state (audit 1.4).** A reusable `.olv-primary-action`
  recipe (solid `--accent` fill, `--on-accent` ink, weight 600 — modelled on
  the lasso toast) promoted in place onto the single primary of each state
  (fresh Run analysis, the DEM/Report download, Convert) so it's unmistakable;
  secondaries stay quiet outline/ghost.
- **Mobile reflow (audit 1.3, CSS-achievable part).** Below 767px the
  `.olv-left-panels` stack is capped to the top ~52vh with internal scroll and
  a soft bottom fade, so panels no longer blanket the canvas or the bottom dock
  and the verdict stays reachable. (A true single bottom-sheet with a
  View · Analyse · Layers segmented control needs JS — flagged as a follow-up.)
- **Surface-quality chip saturation (density reduction).** The Analyse verdict
  showed nine supporting-metric chips as one flat pile under the verdict +
  reason + export readiness + product rows — a lot to parse at once. The chips
  are now TIERED without hiding anything a trust decision needs: an
  always-visible PRIMARY row carries the three decisive chips (DTM quality, the
  headline number; Coverage, the frame; and the single WORST-rated remaining
  signal, so whatever is actually dragging the surface down is never buried),
  and the full nine move into an "All metrics" `<details>` disclosure grouped
  into meaningful clusters — **Coverage** (Coverage / Empty cells /
  Interpolation), **Surface** (Ground density / DTM quality / Edge risk),
  **Accuracy** (Vertical RMSE), **Georef** (CRS / Vertical datum) — instead of
  a flat list. The disclosure defaults OPEN on desktop and COLLAPSED on mobile
  (`_syncMetricsDisclosure`, a `matchMedia('(max-width: 640px)')` check; no chip
  is ever removed from the DOM, only the default open-state differs). A Georef
  cluster whose chips are all "unknown" is dimmed (`.is-uninformative`) since it
  adds nothing beyond the export-readiness line already shown. Honesty-first:
  the verdict, score, export readiness, reason, terrain-product rows and "Why?"
  causes all stay always-visible above the disclosure — only the full numeric
  breakdown is progressively disclosed. CSS + small-DOM grouping only
  (`_renderAssessMetrics` in `AnalysePanel.ts`); no selector consumed by a test
  changed. (A true single mobile bottom-sheet for the whole panel remains the
  flagged JS follow-up from audit 1.3.)

### Added

- **Floor-plan export options control (ObjectPanel).** The `snapMode`
  (`'auto' | 'strong' | 'off'`) and `adaptiveBand` settings — already plumbed
  through `extractFloorPlan` as `FloorPlanParams` and into `main.ts`
  `FLOORPLAN_OPTIONS`, but with no way to set them — now have a compact
  "Floor plan options" control directly under the "Floor plan preview" button:
  a 3-segment **Walls** picker (Auto · Square · As-is → snap `auto` / `strong` /
  `off`) plus an **Adaptive height** toggle, defaulting to the existing headless
  defaults. The selection flows through a single `ObjectPanel.floorPlanOptions()`
  getter that BOTH export paths (standalone SVG sheet + report-embedded PDF plan)
  spread into the same `extractFloorPlan` call, so the two artifacts can never
  diverge on the chosen policy. The floor plan stays an experimental PREVIEW; the
  control only chooses an extraction policy and does not imply survey-grade
  output. a11y: the segments are a real radio group (`role="radiogroup"`, named
  `<input type="radio">` + `<label>` chips, focus ring); the toggle is a labelled
  `<input type="checkbox">`. The honesty footer on the sheet still states which
  wall policy was used. Tests: `tests/floorPlanExportOptions.test.ts` (control
  defaults match `FLOOR_PLAN_EXPORT_DEFAULTS` / `FLOORPLAN_OPTIONS`; selecting a
  Walls segment or toggling Adaptive height flows into `floorPlanOptions()` — the
  object spread into `FloorPlanParams`; the getter returns a copy).
- **Determinate streaming-progress treatment (StreamingPanel).** The
  "Refining visible detail…" phase now carries a thin brand-gradient progress
  bar showing the RESIDENT-node fraction (loaded ÷ known nodes) over the faint
  track, with a tabular `X / Y nodes resident` + `X.XM / Y.YM pts` readout. The
  "Streaming ready" terminal state latches the bar full. When the total node
  count is not yet known the bar falls back to the indeterminate brand shimmer
  rather than fabricating a percentage. HONESTY: the bar reflects what is LOADED
  into the scene (resident octree nodes), explicitly labelled "resident" — it is
  not a download percentage (a streaming source has no fixed total bytes). New
  pure `streamingProgress()` helper carries the fraction/label logic. Tests:
  `tests/streamingProgress.test.ts` (hand-computed fraction incl. clamp to [0,1]
  and the unknown-total → indeterminate fallback, and the same-unit millions
  points readout).
- **GPU compute phase 2 — DTM min/count scatter on the GPU**
  (`src/terrain/engine/dtmScatter.ts`, `gpuBackend.ts`, `TerrainRasterEngine.ts`).
  The TerrainRasterEngine gains a `scatterMinCount` entry: point→cell binning
  for the INTEGER-STABLE DTM reductions — per-cell `min` elevation and per-cell
  `count` (the density layer) — as WGSL compute. Float min has no
  `atomic<f32>` in WebGPU, so the kernel mins in u32 space through an
  ORDER-PRESERVING bit key (the radix-sort trick: flip the sign bit for
  non-negative floats, all bits for negatives — u32 comparison then matches
  f32 numeric comparison), with `atomicMin` on the keys and `atomicAdd` on the
  counts; a finalize pass decodes the winning key back to f32 (or the canonical
  NaN `Float32Array.fill(NaN)` stores, for empty cells). Because min and count
  are order-INDEPENDENT, the equivalence is EXACT, not tolerance-bounded: the
  once-per-session probe now also scatters a synthetic 24×24 grid (dense
  contention cells, genuinely-empty cells, ±elevations, out-of-grid edge-clamp)
  and asserts the GPU grid is BIT-equal to the CPU reference
  (`scatterMinCountReference`, the exact transcription of `rasterizeDtm('min')`
  — and byte-identical to it on the f32 point buffers the pipeline feeds). The
  engine routes scatter to the GPU only when `probe.scatterExact === true`,
  with the same auto-fallback + telemetry as the derivative kernels (a dispatch
  throw demotes the session to CPU and the call is recomputed on the reference).
  `mean` (a float sum that reassociates), `median`, `percentile`, and `robust`
  are NOT atomics-tractable and stay on the CPU `rasterizeDtm` — only the
  min/count/density paths move, per the tech evaluation; the synchronous
  contour pipeline keeps calling the CPU `gridFromPoints` (the async
  GPU-eligible scatter is wired and proven, adopted when that stage goes async
  next phase, mirroring the phase-1 derivatives discipline). Tests:
  `tests/terrainRasterEngine.test.ts` (ordered-key round-trip + monotonicity,
  a hand-computed tiny-grid scatter, reference-vs-`rasterizeDtm` byte-equality,
  exact scatter probe gating + diverging-scatter fallback) and
  `tests/gpuBackendDispatch.test.ts` (mock-device scatter+finalize dispatch:
  buffer sizes/usages, sentinel-seeded key buffer, uniform packing, two-pass
  geometry, cleanup); `tests/e2e/gpuDerivatives.spec.ts` now also asserts the
  real-device scatter is exact (a `false` is the same forbidden divergence as a
  derivative mismatch).
- **Floor plan: adaptive wall-slice height band**
  (`src/terrain/space/floorplan/wallSlice.ts`). The hardcoded 0.7–1.8 m wall
  band now ADAPTS: `detectWallBand` builds a z-histogram of returns above the
  floor and finds the densest SUSTAINED vertical window (scored by its weakest
  bin, so a broad wall slab beats a one-bin floor/ceiling/furniture spike), and
  re-centres the band on it. Countertop / industrial scans whose walls sit
  outside 0.7–1.8 m (high clerestory, racking, mezzanines) now slice their
  actual walls instead of low clutter. It only MOVES the slice on genuinely
  off-centre evidence — a normal full-height room (uniform wall density) keeps
  the well-tested fixed band by a centre-preference tie-break — and falls back
  to the fixed band, then the widened retry, then full height. `floorBasis`
  gains a `bandBasis` companion ('fixed' | 'adaptive') and the sheet's honesty
  footer says when the band was re-centred. Default on; `adaptiveBand: false`
  pins the fixed band. Tests in `tests/floorPlan.test.ts` (the detector on
  hand-built histograms: uniform→fixed, high-zone→re-centre, narrow
  spike→reject, floor-clearance clamp) and an end-to-end high-clerestory room
  that climbs onto the 2.0–3.2 m walls and excludes the 0.5–0.9 m clutter.
- **Floor plan: furniture height-profile classifier feature**
  (`regularize.ts`, `occupancyGrid.ts`, `wallSlice.ts`). The wall slice now
  keeps per-band-point elevation (`zs`), and `extractFloorPlan` bins it into a
  per-cell height profile (`buildCellHeightProfile`) passed to
  `classifyIslands`. A component's vertical EXTENT now joins area / elongation /
  distance-to-wall: a THIN, TALL component (small column footprint that spans
  most of the band) is rescued to STRUCTURE instead of being demoted to
  furniture, while a WIDE full-height blob (a wardrobe) stays furniture by its
  footprint — height span alone is not enough, it is the thin-and-tall
  combination that reads as a column. The feature only ever RESCUES a compact
  component into walls on strong vertical evidence (never demotes a
  footprint-wall, so door-jamb safety is untouched), and is a no-op when no
  profile is supplied (pre-v0.4.6 behaviour). Tests in
  `tests/floorPlanRealism.test.ts` (a tall thin column kept vs a low cabinet
  lifted, a wide full-height wardrobe staying furniture, footprint-only when no
  profile).
- **Floor plan: plumbed extraction options (snap mode + adaptive band)**
  (`extractFloorPlan.ts`, `main.ts`). `FloorPlanParams` gains `adaptiveBand`
  and `snapMode`, threaded into the wall slice and the vectoriser's
  `resolveSnapAxes` (the `SNAP_MODE` auto/off/strong policy). `main.ts` plumbs
  a single documented `FLOORPLAN_OPTIONS` object (sane defaults — adaptive band
  on, snap auto) into BOTH export paths (the PDF report's embedded plan and the
  standalone SVG sheet), so the two can never extract with different settings.
  A dedicated ObjectPanel control is deferred — the plumbed options object is
  the seam a future control would set; the honesty footer already reports the
  band basis and snap policy used. Test: the pipeline suite asserts
  `bandBasis`, the adaptive re-centre note, and `snapMode: 'off'` are honoured.
- **TerrainRasterEngine seam + WebGPU derivative kernels**
  (`src/terrain/engine/`). One interface now owns terrain raster
  construction — `groundFilterPass` (SMRF), `gridFromPoints` (DTM
  rasterisation), and the grid-in → grid-out derivatives (Horn
  slope/aspect, ESRI hillshade) — behind two backends. The `cpuBackend` is
  PURE DELEGATION to the existing tested functions (`classifyGroundSmrf`,
  `rasterizeDtm`, `hornSlopeAspect`, `shadeFromSlopeAspect`): no logic
  moved, byte-identical outputs, and it remains the REFERENCE
  implementation and the always-available fallback (WebGL2-only devices
  run it unchanged). The `gpuBackend` ships the embarrassingly-parallel
  DERIVATIVES kernels only this phase — Horn slope/aspect and hillshade as
  WGSL compute, mirroring the CPU operation-for-operation (northing-up
  aspect negation, edge clamp, non-finite→centre fallback via a CPU-built
  validity mask since WGSL NaN tests are driver-unreliable, half-UP shade
  rounding); point→grid scatter and the ground filter stay on the CPU
  functions even when GPU is active (atomics-bound, deferred per the tech
  evaluation). Honesty-first by construction: a once-per-session
  EQUIVALENCE PROBE runs both backends on a synthetic 64×64 grid (hills +
  ramp + NaN holes + an exactly-flat patch) and the GPU is only activated
  if it agrees per-cell within 1e-4 (slope rise/run; aspect compared as an
  angular distance, only above a 1e-6 slope floor where direction is
  numerically meaningful) and ±1 grey level of shade — f64-vs-f32
  float-order and driver FMA/atan2-precision caveats are documented at the
  seam, and a GPU that diverges is a FAILURE, not a fast answer. Missing
  `navigator.gpu`, a failed device request, a failed probe, or a later
  dispatch throw each pin the session to CPU — silent to the user, but
  recorded in compute-path telemetry (`getLastTerrainRasterComputePath`,
  mirroring the worker-path telemetry), and a failed dispatch is recomputed
  on CPU so callers always get the reference answer. The contour
  pipeline's derivative stage now routes through the engine's synchronous
  CPU-reference entries (byte-identical to before — the async entries are
  the GPU-eligible ones the stage adopts when it goes async next phase).
  Tests: `tests/terrainRasterEngine.test.ts` (delegation byte-equality,
  the f32 kernel-transcription equivalence harness across synthetic grids,
  every fallback reason, probe idempotence) and
  `tests/gpuBackendDispatch.test.ts` (mock-device dispatch plumbing:
  buffer sizes/usages, uniform packing, workgroup geometry, cleanup);
  real-GPU verification is the self-skipping browser gate
  `tests/e2e/gpuDerivatives.spec.ts`, which fails loudly on a probe
  mismatch.
- **Wall graph** (`src/terrain/space/floorplan/wallGraph.ts`). The centerline
  skeleton (centerline.ts) is lifted into an explicit topological model:
  junction cells (≥ 3 skeleton neighbours, clustered 8-connectedly) and free
  endpoints become NODES; the skeleton paths between them become EDGES, each
  carrying a straightened centerline polyline (Douglas-Peucker via the
  vectorize machinery + an open-chain dominant-axis snap), ONE measured mean
  thickness (chamfer transform of the wall mask the graph describes — an
  echo-collapsed wall reports its collapsed thickness, not the echo's), and a
  per-edge observed fraction against the raw pre-close mask. Junction-free
  cycles get a synthetic loop node so every skeleton cell belongs to exactly
  one edge. The wall mask is then RE-EXTRUDED FROM THE GRAPH — constant
  thickness per wall run, join discs at junctions so corners close cleanly —
  with sub-cell mass recentring of the path (the integer skeleton of an
  even-width strip sits half a cell off the true medial axis) and a paint
  radius of (meanDist − 0.5) cells, which together reproduce the measured
  width exactly for both parities: the reconstruction never fattens a wall
  beyond the evidence and never recedes its faces (sheet W × D keeps agreeing
  with the Space panel). Falls back to the normalised mask (and drops the
  graph claim) when the graph is degenerate. Truth-grid tests
  (`tests/floorPlanWallGraph.test.ts`): T / + / L junction topologies, loop
  self-edges, hand-computed edge thickness (3-cell strip → ≈ 0.2 m half),
  half-observed runs reading ≈ 0.5, odd AND even strip widths round-tripping
  exactly, L-corner closure with bounded mass growth, watertight loop
  extrusion, and the open-chain snap's fixed/free end contracts.
- **Room segmentation** (`src/terrain/space/floorplan/roomDetect.ts`). Flood
  fill of the free space bounded by the graph-extruded walls PLUS the
  classified doorways' jamb-to-jamb spans (painted as temporary barriers — a
  door separates the rooms it connects). Chosen over planar graph faces
  deliberately: faces need a closed embedding and collapse on gappy real
  scans, while flood fill degrades gracefully. Honesty rules by construction:
  door-separated rooms stay DISTINCT (merging through classified doorways
  stays off); 'unknown' gaps are NEVER closed, so an unscanned divider merges
  its regions instead of fabricating a wall; a region leaking to the grid
  border is exterior, never claimed as a room. Per room: outer boundary
  polygon (existing trace + simplify machinery), area measured on the REGION
  MASK (not the simplified polygon), and a label anchor at the pole of
  inaccessibility (chamfer maximum) so labels sit inside L-shaped rooms.
  Regions under the architectural minimum room area (`ROOM_MIN_AREA_M2`, 4 m²
  — see the same-day calibration fix below) are slivers and dropped; the room
  list is also suppressed in favour of an honest "Open space" / "could not
  segment" outcome when it would not faithfully describe the floor; at most 16
  rooms are reported, largest first. Tests (`tests/floorPlanRooms.test.ts`):
  hand-counted two-room grid
  (320 / 324 cells exactly, including the provable 4-cell door-barrier bite),
  open-plan merge, unknown-gap non-closure, exterior leak → no rooms,
  sub-1 m² sliver rejection, exact L-enclosure area; end-to-end two-room scan
  with a 0.9 m door → exactly 2 rooms within ±2% of the hand-computed
  interiors (39.105 / 38.71 m²), a 2 m unknown gap → ONE merged room, and an
  L-shaped scan → one room at the hand-counted 58.66 m².
- **Rooms on the artifacts.** The SVG sheet labels each room
  "Room N · 12.3 m²" (sq ft under the imperial unit system) at its pole of
  inaccessibility when the text fits, prints a "Room schedule (flood-fill of
  the wall graph, approx.)" footer line with every room either way, and the
  Space Report PDF embed draws the same labels. The sheet subtitle and the
  PDF caption now say "wall-graph reconstruction" — but ONLY when the walls
  really were re-extruded from the graph (`fromWallGraph`); the fallback
  keeps the old "approximate wall-trace sketch" wording, and all standing
  "preview / experimental / not for construction" caveats remain. The old
  "≈ area" scanned-floor region labels still render when no rooms were
  segmented (and only then — no double labelling).
- **Styled confirm dialog** (`openConfirm` in `src/ui/Modal.ts`). A
  Promise-based replacement for `window.confirm()` built on the existing
  accessible Modal chrome. WHY: `window.confirm()` is unreliable in embedded
  WebViews — some suppress it entirely, returning `false` without ever showing
  a prompt, which silently blocked a user inside an iframe/app shell from
  approving a large-file or cellular download. The styled dialog renders
  identically everywhere the app does, focuses Cancel as the safe default, and
  treats any dismissal (Escape / backdrop / close-X) as "no". Wired into all
  three former native prompts: the mobile large-file open gate and the sample
  download gate (`Stage.ts`, now async), and the reset-session-stats gate
  (`Inspector.ts`). Tests: `tests/modalConfirm.test.ts` (resolve semantics,
  settle-once idempotence, Cancel-focus default, multi-line message split).
- **Gated-control reasons are now visible, not hover-only.** Two disabled
  controls whose "why" lived only in a `title` tooltip — invisible on touch,
  which has no hover — now restate the reason as a visible line in the flow:
  the Inspector's analysis-gated Coverage / Confidence colour chips ("Run
  terrain analysis first to enable Coverage and Confidence"), and the batch
  converter's disabled LAZ format pill (the in-browser-LAZ-not-yet note). The
  `title` attributes stay for pointer users.

### Changed

- **Honest capture-quality coverage label (last drift fix).** The Capture
  quality "Coverage … % of footprint" row (hint "Share of the footprint with
  returns") implied a share of a traced room outline, but the value is computed
  as occupied cells ÷ (cols × rows) over the scan's axis-aligned BOUNDING-BOX
  grid — a fill ratio of the EXTENT. Relabelled to **"Bounding area filled"**
  with a bare `%` value and a hint that says exactly that ("Share of the scan's
  bounding-box footprint grid whose cells contain returns — a fill ratio of the
  extent, not of a measured room outline"), in both the ObjectPanel row and the
  report-PDF layout, so label == computation. The math is unchanged. Tests:
  `tests/coverageLabelHonesty.test.ts` (pins the new "Bounding area filled" label
  — bare `%`, fill-ratio hint — in both surfaces and guards the old
  "% of footprint" / "Share of the footprint" phrasing from regressing).
- **Mobile touch targets bumped to ≥ 44 px** (the long-deferred mobile audit
  box from 0.4.4). On phones (`max-width: 767px`), the tool-dock chips
  (`.olv-dock .olv-tool`, previously 32 px), the batch-converter format / CRS
  pills (`.olv-bc-pill`), the measure-toolbar chain-operation chips
  (`.olv-mp-chain-chip`), the camera-preset chips (`.olv-cam-chip`), and the
  styled-confirm buttons now meet Apple's 44 px minimum tap height. Dock width
  stays content-driven (with a 44 px floor) so the six-button row still fits
  the narrowest iPhone — height carries the tap area in a dense horizontal
  toolbar. All rules live inside the phone media query, so desktop density is
  untouched.
- **Notch-safe toasts.** The lasso-result toast and the load-progress toast now
  subtract `env(safe-area-inset-left/right)` from their max-width so a
  landscape side-notch (sensor housing / rounded corner) can never clip them.
  `env()` is 0 on inset-free displays, so desktop width is unchanged. (The
  vertical safe-area handling for the dock / nav / toasts was already in place.)

### Fixed

- **Streaming scheduler per-tick allocation storm — "computer got really slow
  when I opened the project"** (`StreamingNodeStore.ts`, `StreamingScheduler.ts`).
  On a large streamed COPC (the 125.5 M-pt interior: 28 319 known nodes, ~495
  resident) the view-dependent scheduler runs ~10×/s for the whole session. Each
  tick walked `octree.nodes()` — `[...map.values()]`, a throwaway **28 319-element
  array** — THREE times: the "reconsider queued" reset pass, the full rescore,
  and (via `store.resident()` = `all().filter(...)`) the eviction pass, which
  allocated TWO such arrays. So every idle tick allocated ~3–4 full-hierarchy
  arrays and re-scanned all 28 k nodes just to touch a few hundred — GC churn +
  walk cost that scaled with the WHOLE octree, not the working set, and bogged
  the main thread the entire time the cloud was open (the stable-camera fast
  path skipped the *scoring* but NOT these walks). The store now maintains
  `resident` / `queued` SETS at every `setState` transition and exposes
  zero-allocation iterators (`iterate()`, `residentNodes()`, `queuedNodes()`);
  the scheduler's per-tick passes are now O(resident)/O(queued) with no
  per-tick array allocation. The dominant per-frame cost on scan-open is gone.
  (Investigated and ruled OUT as the open-path regression: the WebGPU
  equivalence probe — gated behind Analyse via `analyseContours.ts`, idempotent
  one-shot, never on the open path — and the O(N) brute-force hover pick, which
  only fires on pointer-move with the measure/probe tool armed, not at
  scan-open.) Guard test in `tests/streamingOctree.test.ts` proves the
  maintained sets stay bit-identical to a ground-truth `all().filter` walk
  across every lifecycle transition.
- **Big open interior misdetected as terrain — "Treat as" never auto-committed
  to Interior** (`scanShape.ts`). On the real 125.5 M-pt 360 industrial-interior
  scan the "Treat as" control would not commit to Interior automatically; the
  user had to set it by hand. Root cause was DETECTION, not the commit mechanism:
  `classifyScanShape` read this large open interior (≈11.8 × 15.0 m footprint,
  ~4 m ceiling) as TERRAIN. A 360 scanner sees a HIGH ceiling only at grazing
  angle, so full-height `wallCoverage` AND `ceilingCoverage` both landed ~12–22%
  — under the strict `WALL_INTERIOR` (0.25) and `ENCLOSURE_COVER` (0.45) bars —
  while the densely-sampled floor (≈100%) looked like a flat field. With the
  verdict at terrain, the planner correctly REFUSED the mid-session terrain flip,
  so no commit ever fired and the pill stayed on Auto past `SETTLE_RETRY_CAP`.
  The fix adds an **open-interior path**: accept a much lower wall-OR-ceiling
  presence (`WALL_OR_CEILING_OPEN_INTERIOR`, 0.10), safe because
  `floorCoverage ≥ 0.5` AND `overhangFraction ≥ 0.15` each independently exclude
  every terrain case (flat AND steep hilly terrain measure ~10–15% floor and ~0%
  overhang in testing). The verdict now reads `interior` (own honest 0.7
  confidence, "open interior space — high or sparsely-scanned ceiling"); the
  settle one-shot then commits the pill on its own. New test in
  `tests/scanShape.test.ts` reproduces the scan's exact shape signature
  (sparse ceiling, partial walls, full floor) and pins interior, with the
  terrain/forest controls verifying no regression.
- **Floor-plan region areas exceeded the stated floor area — incoherent sheet**
  (`floorPlanSvg.ts`). The sheet reported "Floor area 94.4 m²" yet "Approx.
  region areas … 106.6 m²" — the per-region breakdown summed to MORE than the
  headline floor area. The two figures measured different things: `floorAreaM2`
  is the NET scanned presence mask (measured before closing), while the region
  rings are vectorised from the CLOSED, hole-healed, outward-simplified mask, so
  their polygon sum is a GROSS extent that overshot. A region sum larger than the
  stated floor is incoherent on an honesty-first sheet, so a new
  `regionAreaReconcileScale` proportionally scales the regions down (factor ≤ 1,
  never up) so the breakdown sums to the floor area exactly — relative extents
  stay honest, no figure ever exceeds the headline. Applied to BOTH the footer
  sum and the in-plan per-region labels so the sheet never shows two areas for
  one region. New test in `tests/floorPlanQuickWins.test.ts`.
- **Floor-plan furniture-hint clutter — 37 grey specks stippled the sheet**
  (`extractFloorPlan.ts`). The contents classifier on a cluttered 360 interior
  lifted 37 compact islands and drew every one as a grey hint blob — noise, not
  a layout aid. The drawn set is now capped at the `MAX_CONTENTS_HINTS` (12)
  LARGEST by footprint after a sub-`MIN_CONTENTS_HINT_M2` (0.12 m²) speck filter
  — same found-vs-drawn honesty pattern as `MAX_UNKNOWN_GAPS`. The footer states
  the full found count, how many were drawn, and that the smallest were omitted
  to keep the sheet legible. New test in `tests/floorPlanRealism.test.ts` (many
  islands classified, ≤ 12 drawn, honest footer wording).
- **Floor-plan room segmentation calibration — no fake room schedule on an
  open plan** (`roomDetect.ts`, `extractFloorPlan.ts`, `floorPlanSvg.ts`).
  On a real open industrial interior (96 m² floor) the open floor LEAKS to the
  exterior boundary through unscanned boundary runs, so the flood fill
  classified the whole interior as exterior and the only enclosed regions were
  tiny sealed pockets between wall fragments — the sheet then printed "Room 1…5"
  totalling 8.3 m² (pockets of 1.0–2.8 m²), which read as broken. Three changes
  recalibrate it honestly: (a) the architectural **minimum room area** is raised
  from 1.0 m² to **4.0 m²** (`ROOM_MIN_AREA_M2`, parameterised — a 1–3 m² flood
  pocket is not a room; sub-threshold pockets are DROPPED, never numbered);
  (b) a **"could not segment" / open-plan guard** — when the kept rooms cover
  less than `ROOM_COVERAGE_MIN_FRAC` (35%) of the scanned floor area, the room
  list is suppressed and the model reports an honest outcome instead: a single
  **Open space · ~N m²** when one connected region dominates the floor
  (`OPEN_SPACE_MIN_FRAC`, 55%), else **"Rooms could not be reliably segmented
  from the wall returns"** — no fabricated schedule, while the wall poché,
  overall dimensions, and floor area still render; (c) a single unpartitioned
  region (no doorway split, not ≥2 rooms) that covers most of the floor is now
  presented as one **Open space** rather than "Room 1" of a schedule. The
  echo-collapse pass (`centerline.ts`) was re-verified — its output is a strict
  subset of the input wall mask (it only removes excess double-scanned wall
  mass, never erodes past raw returns), so the "25 m²-removed" figure is
  legitimate double-wall collapse, NOT the cause of the leak; left as-is and
  confirmed by the existing subset test. The room detector now takes the
  scanned floor area so it can apply the guard. New tests in
  `tests/floorPlanRooms.test.ts`: the raised min-area floor (9 m² enclosure is a
  room, 3.24 m² is not), the leaking-open-plan pathology in miniature → NOT a
  room schedule (`unsegmented`), one dominant region → `open-space`, threshold
  ordering, and the end-to-end open-plan / L-shape scans now read as a single
  open space; the genuine two-room partition still yields two distinct rooms.
- **Caveat collapse in the Space/Object panel** (`ObjectPanel.ts`, `style.css`).
  The interior scan panel stacked ~5 orange `.olv-object-note` caveats ("Based
  on points currently loaded…", "N stray returns excluded…", "Density scaled
  from sample…", "Ceilings sparsely captured…", "Wall and plane figures are
  pragmatic estimates…") that ate the panel vertically. The single most
  decision-critical line — **"pragmatic estimates, not a certified survey"** —
  now stays visible as a lead note; the remaining secondary caveats fold into
  ONE collapsed `<details>` disclosure ("About these figures (N) ▸") with native
  `<summary>` keyboard + `aria-expanded` semantics, a rotating caret, and a
  focus ring. Nothing is removed: the collapsed content stays in the DOM (the
  `currently loaded / streamed` and other strings remain reachable by tests and
  assistive tech, just hidden until expanded), and the floor-plan
  "experimental — requires visual validation" note stays visible when the
  preview button is present. The AnalysePanel was reviewed and left unchanged —
  its quality `reasons` already live inside the collapsed "Details" disclosure,
  so it had no surface-level pile-up. Pinned in `tests/objectPanelSpace.test.ts`
  (one disclosure, lead kept visible, every secondary caveat still in the DOM).
- **Edge-risk wording bug (Analyse "Why?" panel).** The surface-quality
  "Why? / How to improve" engine (`whyNotReasons.ts`) still described the
  high-edge-risk cause as "`N%` of cells are a long interpolation from real
  returns" — the wording that belongs to the gate's *tally* metric
  (`dtmCellStatus 'edgeRisk'`: interpolated cells far from any measurement).
  But the value it prints, `quality.edgeRiskRatio`, is wired from
  `cellMetrics.edgeRiskRatio` (`analyseContours.ts`) — the fraction of
  *measured* cells that sit near the data boundary (real returns, just least
  neighbour support). The same mislabel was fixed in `terrainAssessment.ts`
  before, but this second copy — which renders in the SAME surface-quality
  section, directly below the verdict — was missed, so a user could see the
  EDGE RISK chip (e.g. 53%) and a contradictory "long interpolation" reason at
  once. The cause now reads "`N%` of measured cells sit at the edge of the
  data, where the surface is least supported", matching the chip and the
  assessment reason verbatim. Pinned in `tests/whyNotReasons.test.ts` (the
  metric is no longer called "long interpolation"; the gate's own tally metric
  in `tests/dtmQuality.test.ts` legitimately keeps that phrasing).
- Sparse-regime doorway-close cap (`closeRadiusCells`): the closing radius
  was floored at 1 cell to heal hairline gaps, but in the sparse regime the
  adaptive cell can GROW to 0.3 m, where radius 1 bridges up to
  2·√2·0.3 ≈ 0.85 m diagonally — enough to seal a standard 0.6 m doorway.
  The floor now applies only while radius 1 cannot bridge `keepOpenM` even
  diagonally (2·√2·cell < keepOpen); past that, closing is disabled outright
  (the grown rasterisation has already fused returns within each fat cell, so
  the hairline-heal duty is moot). A door survives at EVERY cell size by
  construction. Pinned in `tests/floorPlan.test.ts` (0.21 m → 1; 0.25 m and
  0.30 m → 0; radius-0 closing is the identity).
- The Space Report PDF's embedded floor-plan dimension line now honours the
  caller's unit system (imperial prints feet first, metric metres first),
  matching the standalone SVG sheet and the measurement panel —
  `buildSpaceReportPdf` gains `unitSystem`, threaded from the live
  measurement unit system in `main.ts`.
- **Stride-scaled USGS QL presented as exact (terrain honesty asymmetry).**
  When the gather strides a huge cloud (≤300k points), ground density is scaled
  back to the full scan by a uniform-stride assumption (`samplePointScale`),
  and that scaled density grades the USGS 3DEP Quality Level. The space-scan
  path already disclosed "uniform-stride assumption" on its density/spacing, but
  the terrain QL chip, its tooltip, and the Terrain Report presented the grade
  as a directly-counted, exact figure. `analyseContours.ts` now emits a
  uniform-stride caveat into `result.warnings` whenever the density was scaled
  (`samplePointScale > 1`) — surfaced verbatim in the exported PDF report's
  Warnings section — and the Analyse panel's QL hint carries the same note, so
  the QL grade reads as the estimate it is. No caveat is emitted on an
  un-strided (scale 1) run. Pinned in `tests/densitySampleScale.test.ts`.

## [0.4.5] - 2026-06-10

The honesty-and-deliverables release: one readiness engine behind every export
verdict, a colourblind-safe confidence overlay, profile intelligence (summary,
station table, CSV, sampler controls), the Terrain Intelligence Report,
workflow presets, true measurement units on foot-CRS scans, and an accessible
onboarding tour.

### Fixed

- (2026-06-12 amendment) The streaming settle one-shot could STILL leave an
  interior scan uncommitted — the field report after the depth-gate +
  spend-on-verdict fix below. The remaining hole was the spend rule itself:
  "spend once detection reached a verdict" also spent on a verdict the
  planner REFUSED. Past the depth gate the resident set can still be
  ceiling-heavy (the gather walks the coarse nodes first), so the settled
  evaluation can read TERRAIN against a standing interior route; the
  mid-session no-flip guard rightly refuses that flip — no apply, no commit —
  but the one-shot counted it as "reached a verdict", spent itself, and the
  "Treat as" pill stayed on Auto forever while the panel showed Interior.
  `settleOneShotSpent` now spends only when the verdict actually LANDED
  (the planner applied it, or the settled soft-commit fired) or when no
  commit can ever come (pinned / manual override); a refused verdict and an
  undecidable frame both RE-ARM the one-shot. Re-attempts are gated on the
  resident set actually changing (re-reading an identical idle frame cannot
  change the verdict; a failed gather may retry at once) and bounded by
  `SETTLE_RETRY_CAP` (40) so a permanently refused scan can never
  re-classify on every poll forever. The exact failure sequence is pinned in
  `tests/streamingSettleCommit.test.ts`: settle at depth 2 reads terrain
  (refused, one-shot stays armed, no churn on the unchanged frame) → a later
  ready poll on grown geometry reads interior → the Interior pill commits;
  plus the retry-cap bound.
- (2026-06-12 amendment) Opening the interior floor-plan SVG (or the Space
  Report PDF embedding the same model) could make the machine crawl on a
  dense scan: the emitted geometry was unbounded. The DECORATIVE scanned-
  floor fill traced every furniture-occlusion shadow and unhealed pinhole
  into its own hole subpath — a synthetic dense patchy room reproduced 200+
  hole rings (~86% of all emitted vertices) on a single room, scaling
  linearly with scan area — the wall mask can reach 1024² cells, and every
  classified unknown gap became its own dashed segment. The model now ships
  with budgets: the floor fill drops holes, keeps only the largest outer
  regions (≤ 24), and simplifies at twice the wall tolerance; every layer
  has a vertex budget (walls 3 500 / floor 1 000 / contents 500 ≤
  `PLAN_VERTEX_BUDGET` 5 000) enforced by proportional Douglas-Peucker
  tightening then smallest-ring dropping (`capRingVertices` — DP only ever
  removes raster vertices, nothing is fabricated); and dashed unknown gaps
  are deduped and capped at the 32 widest (`MAX_UNKNOWN_GAPS`) while the
  footer keeps reporting the full classified tally. The dense-room sheet is
  byte-size pinned in `tests/floorPlanBudget.test.ts`; the same budgeted
  model feeds the PDF embed. Floor AREA is still measured on the raw
  presence mask before any of this — the printed figure is unaffected.
- (2026-06-12 amendment) The floor-plan sheet reads like an actual floor
  plan: overall W × D dimension lines are drawn architecturally (extension
  lines off the plan corners, 45° ticks, the measurement written on the
  line, depth label rotated along its line); the dims line prints the floor
  area from the scanned-floor fill region — never the bbox product, so an
  L-shaped room prints its true ~68 m², not 80 (`tests/
  floorPlanSheetCalibration.test.ts` pins it against the model figure); and
  the wall poché renders at a 0.10 m architectural minimum (a stud wall is
  ≥ ~0.09 m — the 5 cm mask-cell strip read toy-like), with the stroke
  symmetrically widening the traced strip and a footer note keeping the
  honest MEASURED thickness on the sheet. Geometry is untouched and walls
  measured at/above the minimum keep a hairline outline only.
- With "Treat scan as" on Auto, the terrain Surface-Quality/Analyse panel
  could surface on its own for a scan whose settled verdict is interior: a
  sparse mid-stream frame can momentarily read as terrain, and the streaming
  re-evaluation flipped the session's panels to terrain before the
  fully-resident geometry corrected the verdict. The routing decision now
  lives in a pure, matrix-tested planner (`planScanRoute`): a streaming
  re-evaluation can only re-route TOWARD the Object/Space panel (its purpose
  is rescuing interiors/objects misread on a sparse early frame) and never
  flips the session to terrain, and the terrain pipeline NEVER auto-runs from
  detection — only the explicit "Run terrain contours anyway" hatch or a
  manual Terrain override expands the Analyse panel and starts an analysis,
  exactly as before. The "Treat as" control also stops hiding what Auto
  resolved to: while Auto stays the selected mode, its label reads
  "Auto (Interior)" (or Object / Terrain) and the detected pill carries a
  small accent dot plus an aria-description, so "detected as interior" is
  visible at a glance instead of living only in hover titles. Once the
  verdict SETTLES — the open-time detection of a fully loaded static file,
  or the one-shot re-evaluation when a streaming cloud reaches "Streaming
  ready" — the control soft-commits: the detected pill becomes the selected
  segment (aria-pressed), still wearing its "detected" accent dot so the
  auto-detected origin stays visible, and Auto reverts to a plain pill whose
  click re-runs detection. The commit is detection-sourced, never a manual
  override: no "(manual)" note, no routing pin (the streaming guards behave
  exactly as before — `planScanRoute` still routes on the effective type),
  it resets to Auto on every new scan and on any user click, and it only
  fires when the settled verdict matches the route actually standing (a
  settled terrain read against a standing interior route never claims the
  pill — the routing guard refused it). Sparse mid-stream frames only ever
  route, never commit. Route-matrix
  tests pin every cell: interior/object-detected + Auto ⇒ Object panel, no
  terrain panel, no run; terrain-detected ⇒ panel shown collapsed, still no
  auto-run; hatch and manual overrides still run; re-evaluation never flips
  to terrain and still rescues an early terrain misread into interior.
- The settled soft-commit above could silently never land on a streamed scan:
  the "Streaming ready" poll fired the settle one-shot on the FIRST
  scheduler-idle frame and spent it unconditionally — but the scheduler often
  reads idle at the root level (depth 0, the same reality the streaming
  benchmark's coarse-stable guard documents) long before the cloud fills in,
  so the one-shot ran on a sparse frame whose verdict was terrain (refused by
  the mid-session no-flip guard — no apply, no commit) or undecidable (gather
  empty — no commit possible), and the GENUINE settle later could never move
  the "Treat as" pill off Auto ("Streaming ready" + Terrain disabled with the
  interior reason + Auto still selected). Two guards now keep the one-shot
  THE settled verdict: a depth gate (`settleTargetDepth` — the settled
  evaluation isn't even attempted until the resident set spans the
  hierarchy's own depth, capped at 2, mirroring the coarse-stable guard) and
  spend-on-verdict (`settleOneShotSpent` — `applyScanRoute` reports whether
  detection actually reached a verdict, or routing is pinned/manual; an
  undecidable frame leaves the one-shot armed so the next ready poll retries
  on fuller geometry). Routing semantics are unchanged — a reached verdict is
  final whatever the planner did with it. The screenshot sequence is pinned
  end-to-end against the real planner + "Treat as" control (stream → early
  interior verdict → Object panel → settle confirms the same verdict ⇒ the
  Interior pill commits), alongside the premature-root-idle and
  undecidable-frame regressions (`tests/streamingSettleCommit.test.ts`).
- The interior floor-plan export was replaced with a wall-trace extraction
  pipeline (preview — the export is labelled "Floor plan preview" and marked
  experimental, pending visual validation against real scans). The old
  generator traced one blob around a coarse (≤48-cell) occupancy grid of the
  WHOLE cloud — floor, furniture, and ceiling smeared together — and drew
  fabricated straight "wall" lines along the bounding-box edges; on a real
  360 scan the result was an unrecognisable sketch. The new pipeline
  (`terrain/space/floorplan/`) runs: a wall-height
  point slice 0.7–1.8 m above the detected floor (full-height fallback when
  no floor exists), an adaptive 2–5 cm density-thresholded wall mask,
  morphological closing that bridges scan dropouts but is capped so doorways
  (≥ 0.6 m) always stay open, boundary vectorisation with Douglas-Peucker
  simplification, and dominant-axis snapping that only engages when the wall
  direction histogram is clearly bimodal at 90° (no fabricated right
  angles on round or irregular rooms). The SVG sheet now draws solid wall
  poché with door openings as real gaps, a light scanned-floor interior
  fill, a scale bar and overall dimensions in the measurement panel's unit
  system (metric or imperial first), the local-frame orientation note, and
  the standing suitability caveat; the Space Report PDF embeds the same
  model. Hardened against the real-360-scan failure modes the first cut
  still tripped over: the export now re-gathers at the terrain budget
  (300 k points) instead of reusing the 60 k routing snapshot, the wall-mask
  cell GROWS (to ≤ 0.3 m, still under any doorway) when the slice is too
  sparse to support 5 cm cells instead of starving into speckle, the slice
  is clipped to the occupancy-weighted dense footprint first so 360 noise
  arms can no longer inflate the sheet's extents (connected-component mass,
  not a per-cell threshold — random arm clusters don't survive), and a
  missing floor peak falls back to a robust low-percentile band anchor
  (plus one widened-band retry) instead of smearing floor + furniture +
  ceiling into the "walls" at full height — the floor FILL still requires a
  real detected floor plane, and the sheet states which basis was used.
  A realism pass (`floorplan/regularize.ts`) then makes the honest trace
  READ like a floor plan: compact off-wall islands in the wall mask —
  furniture, shelving, plants caught by the wall-height band (43 of the 70
  poché subpaths on a real 360 sheet) — are lifted out of the wall
  poché and drawn as light grey room-contents hints (the architectural
  convention; toggleable, and the sheet says so), with near-wall fragments
  kept as walls so a jamb return severed by a door gap is never erased;
  stair-step jogs of up to one mask cell merge into single straight wall
  lines at the runs' length-weighted mean; sub-0.25 m out-and-back spurs
  (flat-tip and V-apex) are cut back while door jambs survive by
  construction (a jamb's flanks are the wall run itself); and zero-width
  tracing slivers die a mean-thickness filter. A second realism round
  (`floorplan/centerline.ts`), driven by the surviving artifact classes on
  the user's next real 360 sheet (blobby double-wall mass with voids punched
  through it, splatter-shaped contents hints, and gaps the sheet could not
  tell apart from doorways), promotes the wall-thickness normalisation that
  was deferred: a chamfer distance transform plus Zhang-Suen thinning fit a
  centerline through every wall strip (loops and door gaps preserved by
  construction), medial-axis spurs shorter than the local half-thickness are
  pruned, and the walls re-extrude at min(local, measured-median) thickness
  clamped to the traced mask — echo-fattened runs (a wall scanned from both
  sides, clutter fused against a wall) collapse onto their centerline at the
  thickness the building actually measures, while clean walls round-trip
  bit-identically (the pass only ever removes excess; its output is a strict
  subset of its input, so it can never invent wall). Free-standing masses
  far thicker than the building's walls (kitchen islands, sofa groups)
  demote from the poché to the contents layer instead of being traced as
  fake architecture. Contents hints simplify to the convex hull per blob —
  the honest "something stands here, about this big" footprint instead of
  raster splatter. And wall gaps are now CLASSIFIED by jamb evidence
  (`classifyWallGaps`): two wall ends whose runs point at each other
  squarely (within ~23°) across a clear 0.55–1.4 m opening are a doorway
  and stay genuinely open; facing ends without that evidence — ragged/skewed
  ends, non-door widths up to 2.5 m — are honest UNKNOWN gaps drawn as a
  dashed line on the SVG sheet and the Space Report PDF ("the wall may
  continue here; the scan can't say"), and anything wider stays an
  undecorated hole. The sheet's footer reports the collapsed echo mass, the
  demotions, and the door/unknown gap tally. The plan sheet and
  the Space panel also stop disagreeing about size (the real sheet read
  12.9 × 15.0 m while the panel claimed 24.72 × 13.76 m): the panel's
  dimensions now clip 360 noise arms with the SAME dense-footprint rule the
  plan uses (the model exposes the clip bbox), and both report the strays
  they excluded. Synthetic-room tests pin walls to within 5 cm + one cell,
  door preservation, floor area to ±2%, an L-shaped room's reflex corner,
  50% wall-dropout healing, a sealed two-room scan keeping BOTH room
  interiors (every loop above the speckle floor survives, never just the
  largest), a 4%-density strided sample staying traceable via the grown
  cell, a 20 m noise arm being clipped (extents stay the room's), the
  percentile and widened-band anchors, and the honest empty result below
  500 points; the realism round adds a 1 × 0.5 m mid-room island leaving
  the poché for a contents hint, a jittered wall straightening to one line,
  a 0.15 m stub spur dying while both door jambs survive, hand-truth jog /
  spike / sliver cases, and a plan-vs-panel extents cross-check on the
  noise-arm scene; the centerline round adds hand-computed chamfer
  distances, a fat strip thinning to a 1-cell line and a wall loop keeping
  its loop, spur-prune survivor/victim pairs, a clean room round-tripping
  through the normaliser vs a 0.5 m echo-fattened wall collapsing to the
  median, a free-standing fat mass demoting to contents, square-jamb /
  skewed / over-wide / L-corner gap classification truth, convex-hull
  containment, and an end-to-end double-walled room whose door classifies
  by its jambs while the echo mass collapses.
- The surface-quality panel's reason sentence no longer mislabels the
  edge-risk chip's figure. The chip (cellMetrics' edge-risk ratio) counts
  MEASURED cells sitting near the data boundary — cells with real returns
  that are merely least supported — but the Limited/Preview reason called
  that same number "cells that are a long interpolation from real returns",
  which describes the OTHER edge metric (the gate's tally of interpolated
  cells far from any measurement). The reason now reads "N% of measured
  cells sit at the edge of the data, where the surface is least supported";
  the gate's own wording (where the phrase is true) is unchanged. A field
  fixture pins the interior-360 case (Limited 52/100, interpolation 72%,
  edge risk 53%) so the chips and the reason sentence provably quote the
  same numbers.
- Activating Measure no longer opens the Measurements panel on top of the
  measure toolbar. The centred toolbar and the left panel column both
  anchored to the same `top: 56px` band, and entering measure mode
  auto-opens the Measurements panel into that column — so the panel painted
  over the toolbar's left half and hid the first kind pills (Distance /
  Polyline / Area…). The toolbar's height is dynamic (pills wrap at narrow
  widths, Finish polygon comes and goes), so instead of a static offset a
  ResizeObserver now mirrors the toolbar's real height into a CSS custom
  property (`--olv-measure-bar-clear`) that pushes the panel column — and
  its scroll budget — below the toolbar while it is visible, at every
  viewport width including phones, and snaps it back up when measure mode
  exits. The embed's `?measurements=1` path gets the same guard.
- Hardened the measurement stack against crash-class degenerate inputs after
  a report of the app dying mid-session with many chained distance
  measurements placed. The measurement-label collision layout — which runs
  inside the per-frame render loop and scales with the number of placed
  measurements — is now bounded by construction: a non-finite label anchor (a
  vertex projected at the camera plane) is placed as-is instead of joining
  collision tests, a push-down move must make strict progress so a float
  boundary can never re-trigger forever, and a hard pass cap converts any
  residual pathology into a cosmetic overlap instead of a frozen tab. The
  profile chart's elevation-tick and station-grid walks, and the profile
  PDF's grid loops, are guarded the same way: a denormal elevation span used
  to underflow the tick step to zero and push gridlines until the tab ran out
  of memory, and a corrupt (non-finite) chainage sample made the station walk
  infinite — both now degrade to an honest minimal axis or the "nothing to
  plot" branch. Chain aggregates and the station table tolerate unknown
  measurement kinds / dimensions from forward-compat session files instead
  of throwing in the panel's render path, and every degenerate unit factor,
  zero-length segment and NaN value is pinned to its honest "—" fallback by
  a new regression suite (`tests/measureCrashGuards.test.ts`).
- Replaced the "Fitness-for-use" wording stamped on PDF reports and export
  provenance (profile sheets, terrain/space reports, DXF/SVG/GeoJSON/README
  stamps) with plain language. The standing note now reads "Suitability: not
  survey-grade unless validated against ground-truth control." — same honesty
  contract, no QA jargon.
- Clicking "Terrain" in the TREAT SCAN AS control on an interior / object
  scan no longer shuts the Space/Object panel down into a dead end. The
  click tore the panel down and handed off to the Analyse panel still in its
  collapsed-chip state — the busy status, the (usually blocked) terrain
  result, and the Treat-as control that is the only way back were all hidden
  under the chip. The Terrain segment is now disabled with the visible
  reason while detection reads the scan as an interior or compact object
  (the explicit "Run terrain contours anyway" escape hatch remains the
  deliberate override); when terrain IS forced, the Analyse panel expands so
  the result and the way back are on screen; and switching back to
  Object / Interior / Auto always restores the Space/Object panel — even if
  geometry gathering fails at that moment it renders its honest empty state
  instead of tearing down.
- The live-deployment build no longer loses lazy feature chunks. Four
  dynamic `import()` calls lived inline in modules the deploy transform
  rewrites, which scrambled their specifiers: the Planetary Computer
  catalog search and the Visuals Studio Auto-balance chunks were silently
  never emitted (both features dead on the deployed site, working in a
  source checkout), and the idle-time LAS-loader pre-warm fetched a raw
  `/assets/io/loadLas` URL — a 404 logged on every boot. All four imports
  now route through the `lazyChunks.ts` seam that exists for exactly this,
  and the chunk-emission guard pins them so a re-inline fails the build
  loudly instead of shipping silently broken features.
- The Space panel no longer reports sideways metrics on 360-style interiors
  whose walls are densely scanned and whose floor is sparse or cluttered. The
  up-axis detector used to crown a dense flat wall as the "floor" — every
  figure on the panel (height, floor area, the floor-plan sketch) was then
  computed in a sideways frame, which is how a 5 m-tall room reported
  H = 23 m and exported a side elevation labelled as a floor plan. Detection
  now treats Z as the incumbent (point-cloud formats are Z-up by spec): a
  horizontal axis must beat it by a clear margin, full-height wall-like
  columns no longer count as floor evidence, and ties resolve to Z instead of
  X. On top of that, LAS/LAZ and streamed COPC/EPT scans now tell the
  detector their frame outright — the up-axis guess only runs at all for
  formats whose frame is genuinely ambiguous (PLY, OBJ, glTF), where it still
  detects Y-up phone scans exactly as before.
- Elevation profiles are now sampled along the scan's actual up axis. The
  sampler was hardcoded to Z-up, so a profile cut through a Y-up phone scan
  measured "height" along a horizontal axis.
- Measurements on foot-based coordinate systems now read in true units. The
  measure stack assumed render coordinates were metres, so a 10 ft span on a
  US-survey-foot scan displayed as "10 m" — wrong by a factor of 3.28 — in
  every readout: the distance/area/volume headlines, the on-canvas labels,
  the live placement hints, chain aggregates, the profile chart axes, the
  profile summary, the station data and the CSV/PDF exports. The scan CRS's
  linear-unit factor (the same seam the terrain and space panels already
  read) is now threaded into the measurement controller and applied exactly
  once at its display boundary — lengths ×f, areas ×f², volumes ×f³, and the
  profile sample series before it fans out — so formatted labels and raw
  chart numerals can never disagree. The measurement table in generated
  report PDFs (all six Report Engine templates) applies the same factor at
  its own formatting boundary, so a report handed to a client agrees with
  the on-screen panel to the digit. Metric and local scans are unaffected.
- The profile PDF no longer discards what the app already knows. Every sheet
  printed "auto (5 % of length)", "p25" and "Horizontal CRS — (not
  georeferenced)" even when the CRS service had resolved the frame and the
  sampler had used concrete parameters. The corridor width and ground
  percentile that actually shaped the estimate are now stamped onto the
  measurement when it commits, the resolved CRS and vertical datum are read
  at export time, and all of it lands on the sheet — in the summary block
  and in a compact provenance line in the header.
- The profile chart's vertical-scale control is now honest. The chips said
  "1:1 / 2:1 / 5:1 / 10:1", but the chart never drew true ratios — it
  stretches with the resizable panel, so "1:1" depended on how the panel was
  dragged, and at higher settings the curve silently spilled past the plot
  frame. The chips now read "Fit / 2× / 5× / 10×" (multiples of the fitted
  elevation scale), the curve is clipped to the plot box so relief leaving
  the visible band reads as a deliberate crop rather than a glitch, and the
  in-chart badge says the same thing. True stated 1:N scales remain on the
  PDF export, which computes real paper ratios.
- Imperial elevation tick labels on the profile chart no longer collapse
  into duplicates on sub-metre relief — they carry the decimals the tick
  step needs instead of rounding to whole feet. The chart tooltip's Δh also
  honours the unit toggle now, instead of always printing metres.
- The profile PDF sheet honours the unit toggle. The builder grew imperial
  support in this cycle's unit sweep — feet on the elevation axis and grid,
  US 100-ft stationing on the chainage axis, converted summary and station
  table — but the export button never told it which system was active, so
  every sheet still printed metric regardless. The panel now passes the
  same unit system the chart and CSV already read, and a sheet exported in
  imperial mode is imperial end-to-end: axes, gridline labels, summary
  block (length, relief, gain/loss, extremes, corridor) and the station
  table.
- XYZ and CSV exports of geographic (lat/lon) scans no longer truncate
  position to street-block precision. Coordinates were always written at a
  fixed 3 decimals — millimetres on a projected CRS, but ~110 m on a degree
  axis. When the cloud's CRS is geographic, x and y now carry 7 decimals
  (1e-7° ≈ 1 cm at the equator); z stays at 3 decimals, since heights are
  linear units even in a geographic CRS. Projected and local exports are
  byte-identical to before.
- The converter no longer reports "reprojected" as a clean success when the
  datum leg of the transform is known to be missing or degenerate. GDA94 →
  GDA2020 resolves to an identity shift here (the true plate-motion
  difference is ≈ 1.8 m), and NAD27 transforms run without NADCON grids
  (errors of 10 m or more) — both used to log the same success line as a
  genuine transform. They now log an explicit warning naming the problem, and
  the conversion report's CRS status says "APPROXIMATE datum shift" instead
  of a bare "reprojected". Same-datum reprojects and a skipped/unresolvable
  reproject behave as before (the latter already warned loudly).
- A skipped reproject no longer stamps the metre GeoKey on the output LAS.
  The linear-unit tag keyed off the requested MODE, so when the transform
  could not be resolved and the file stayed in its source (possibly
  US-survey-foot) CRS, it was still tagged 9001 "metre" — a unit lie baked
  into the deliverable. The tag now follows what actually happened: applied
  reproject → metre, skipped reproject / keep → the source CRS's own unit.
- Density, spacing and the USGS Quality Level now describe the scan, not the
  analysis subsample. Every analysis path strides big clouds down to a budget
  (≤ 60 k for the space panel, ≤ 300 k for terrain), but the density figures
  divided only the sampled count by the area — a stride-100 scan read 100×
  too sparse, the object panel's median spacing was inflated ~√(N/2000), and
  the QL grade judged the subsample instead of the survey. The space panel
  now scales by its known source count (and says so in its caveats), the
  object metrics correct the nearest-neighbour probe by √(P/N), and the
  terrain pipeline accepts the gather's stride (`samplePointScale`) and
  multiplies per-cell densities back to the scan before the QL grade is
  assigned. Coverage, confidence and RMSE are untouched — they genuinely
  measure the analysed points.
- The hold-out validation now builds its surface exactly like the live
  pipeline. It used to skip the blunder despike and the extrapolation guard
  and dropped the horizontal-unit scale, so the RMSE — and the confidence
  calibration fitted from it — measured a *different* surface than the one
  delivered. Both paths now construct their grid through one shared
  raster→grid constructor, making the divergence structurally impossible.
  The per-slope/zone residual tables also bin points with the same floor
  convention the raster was built with; the old `Math.round` attributed
  half of every cell's points to the neighbouring cell. The confidence
  calibration fitted from the unified validation additionally requires a
  minimum per-bin sample count before a bin may shape the curve — a
  2-sample bin's 50 % "reliability" is a coin flip, and because the remap
  extrapolates flat past its end knots, one near-empty noisy bin could
  drag every low-confidence cell on the live grid down with it.
- LAS export headers now tell the truth twice over: returns above the
  histogram range (> 5 for LAS 1.2's legacy tally, > 15 for 1.4's extended
  tally) clamp into the top slot to match how the point records clamp the
  field, instead of being counted as first returns; and the header min/max
  bounds are written from the quantised values the records reconstruct,
  not the raw input doubles — strict validators no longer flag points
  "outside the header bounds" by half a scale step.

- The onboarding tour is no longer keyboard- and screen-reader-hostile.
  Key terms in step copy ("colour mode", "Visuals Studio", "Chain") used
  to read as raw selection-blue text; they now render as properly themed
  highlights, and the card itself can no longer be accidentally
  text-selected by rapid Next-clicking. The card announces itself as a
  modal dialog (role, aria-modal, labelled by its title and described by
  its body), focus lands on the Next button at every step and Tab cycles
  within the card's buttons instead of escaping into the page behind the
  backdrop. Arrow keys step forward and back, Enter advances, and Esc now
  does what the welcome copy always promised — skips the tour and
  remembers that, instead of silently re-showing it next session. The
  step text is a polite live region, so each step's copy is actually
  announced even though focus stays parked on Next. The "Open a scan"
  step now spotlights the empty state's real open button — its old
  selector pointed at a dock button that has never existed, so the
  spotlight silently failed on every first run — the Measure step gained
  a stable hook on the dock button (its old selector matched only the
  enabled-state tooltip text), and a step whose target is present but
  hidden (the dock collapses on the empty state) now centres its card
  instead of pinning a 16-pixel spotlight to the screen corner.

### Added

- (2026-06-12 amendment) Floor Plan Preview sheet refinements — presentation
  and threading over data the pipeline already computes (the wall-graph /
  room-segmentation engine itself stays scheduled for 0.4.6; the export
  remains a labelled, experimental preview):
  - ARCHITECTURAL SHEET STYLING: the wall poché prints in near-black #111
    architectural ink on the white sheet (theme-agnostic), dimension and
    extension lines draw thinner (0.55 px), every CLASSIFIED doorway gets a
    door-leaf swing symbol (quarter-circle arc from one jamb, radius = the
    clear gap width, opening toward the plan centre — a drawing symbol, not
    a hinge-side claim), and a tidy bottom-right title block carries title,
    overall dims, floor area, scale text (nominal ratio + the graphic bar,
    which stays the trustworthy reference) and date, like a real sheet.
  - APPROXIMATE REGION AREAS: each kept floor-fill region prints its own
    polygon area ("≈ 12.3 m²") centred in regions ≥ 3 m² whose extent fits
    the label (centroid-inside check, no label squeezed into a sliver), and
    the footer lists every region's area. Labelled honestly as approximate
    scanned-floor extents — these are the floor-fill regions, NOT
    wall-measured rooms (that needs the 0.4.6 wall graph).
  - WALL CONFIDENCE: every wall ring now carries an OBSERVED fraction —
    its outline sampled against the PRE-CLOSE density mask, so cells filled
    by morphological closing read as interpolation, not observation
    (`wallRingObservedFrac`, threaded through the model). Rings under 60%
    observed (`OBSERVED_FRAC_MIN`) render as a yellow-tinted poché with the
    footer note "Tinted walls: interpolated from sparse evidence…" — coarse
    and honest, a boundary-sample statistic, not a survey confidence figure.
    Hole rings follow their containing outer so the poché stays punched.
  - SNAP CONTROL: the dominant-axis snap is now governed by a documented
    `SNAP_MODE` constant in `vectorize.ts` — 'auto' (default: snap only when
    the direction histogram is clearly bimodal at ~90°, exactly the previous
    behaviour), 'off' (never snap), 'strong' (force the strongest axis when
    the auto gates fail; the sheet footer then says right angles may be
    assumed where the scan shows none). A UI control is deferred; the
    resolver (`resolveSnapAxes`) reports mode + forced-ness for the footer.
  All four are pinned in `tests/floorPlanQuickWins.test.ts` (door-arc count
  and radius per classified doorway, area labels within ±2% of the region
  polygon area, observed-fraction threshold + tint partition, snap modes),
  and the sheet was render-verified in headless Chromium.
- A colourblind-safe "Confidence" colour mode — the Cividis twin of the
  Coverage trust overlay. The coverage mode's traffic-light ramp says the
  right thing but says it in colours ~8 % of users cannot tell apart, so
  the per-cell DTM confidence now also renders on three exact Cividis
  stops (the one palette the catalogue tags fully colour-blind safe):
  bright = strong (measured), mid = moderate (interpolated), dark = weak
  (extrapolated / gap) — deliberately the t 0.2 stop rather than the ramp
  floor, which would vanish into the dark canvas and read as "no data"
  instead of "untrustworthy data". The buckets are the SAME
  `gradeForConfidence` thresholds the coverage minimap legend, the
  dashed-contour evidence and the click-to-sample readout use, and the
  3D mode shares the coverage mode's grid-lookup core, so the two
  overlays can disagree only about hue, never about which cell a point
  samples or how trusted it is. Empty cells stay neutral grey (3D) or
  transparent (2D raster) — a hole is never painted as a confidence. The
  chip sits next to Coverage on the Inspector's COLOR BY rail (both
  analysis-gated, with the same "Run terrain analysis first" tooltip
  until a grid exists), and the Analyse panel's coverage tile gained a
  "Colour 3D by confidence" link that paints the tile's own buckets onto
  the cloud.
- Real raster icons for the web manifest. The manifest declared only the
  SVG favicon, so the installable-app baseline (a 192 px and a 512 px
  PNG) was unmet and install surfaces fell back to whatever they could
  scrape. `public/icon-192.png` and `public/icon-512.png` are rasterised
  from the official logo asset (see the brand bullet under Changed) by a
  new `scripts/make-brand-rasters.py` (Pillow, supersampled master so
  edges stay crisp at 192 px) and declared in `manifest.webmanifest`
  with `purpose: "any maskable"`. The same script also renders the
  180 px apple-touch-icon, the 16/32/48 `favicon.ico`, the vector
  `favicon.svg` and the `og-card.jpg` share image from the identical
  source, so every identity surface regenerates from the one logo file.
- Terrain Intelligence Report. One click on the Analyse panel
  ("Intelligence report (PDF)", next to the DEM and map-sheet exports)
  assembles everything the app already computed about a surface into a
  client-facing PDF. It opens with an Executive Summary — the assessment's
  own verdict sentence (status plus reason), the export readiness with its
  reason, and what the surface is honestly best for; never new prose —
  then Dataset Statistics: scan metadata plus, when the Inspector's
  Dataset Intelligence card has them, the card's exact density /
  complexity / ground-visibility / metric-stability bucket labels (the
  rows are simply omitted when the card is empty, never re-derived). The
  body carries the terrain assessment with its 0–100 score and reason,
  coverage analysis (measured / interpolated / empty / edge-risk ratios
  and mean confidence), the ASPRS/USGS quality metrics when they were
  measured, deduped warnings with their figures, the recommended-workflow
  checklist, the SAME six-product Terrain Products status list the panel
  leads with — one projection feeds both, so the PDF and the panel can
  never grade a product apart — and how-to-improve fixes when the surface
  is not fully good. Every string is sourced from an existing module — the
  report can never disagree with the on-screen panel — and the footer
  carries the same unified provenance block (software version, metric
  version, CRS, datum, coverage mode) every other export stamps, pinned by
  the cross-export provenance-consistency test. Unknown values print as
  em-dashes, never fabricated zeros, and the standing not-survey-grade
  note is always present.
- Workflow presets in the Visuals Studio. A new chip row — Terrain ·
  Construction · Mining · Forestry · Hydrology · Archaeology — sets up the
  whole look for a job in one click: colour mode, EDL depth shading, point
  size and sizing mode, background, and how much of the elevation band the
  height ramp spans (Mining and Hydrology use the untrimmed band so pit
  floors and subtle channels keep colour resolution; Archaeology pairs the
  strongest depth-edge shading with fine fixed points for micro-relief).
  Every preset is a pure bundle over knobs that already existed — no new
  rendering machinery. Hand-adjust any of those knobs afterwards and the
  rail switches to a "Custom" state chip instead of pretending you are
  still on the preset; clicking a preset returns to it exactly. The pills
  expose their pressed state through `aria-pressed`, so a screen reader
  hears which preset (or "Custom") is active instead of a colour-only
  highlight.
- Profile summary. Every profile now shows the civil headline numbers under
  its chart — length, elevation gain/loss, average grade, max grade, the
  steepest section as a station range, and the highest/lowest points with
  their stations — in the active unit system. The same summary is printed on
  the profile PDF sheet, computed by the same code, so the panel and the
  print can never disagree. Figures are only derived between adjacent covered
  stations: a coverage gap contributes nothing, and an unmeasurable figure
  reads "—", never 0.
- Profile CSV export. A "CSV" button next to the profile's "Export PDF"
  downloads the station data — station, chainage, ground elevation, the
  corridor point count behind each elevation, and grade to the next station —
  in the active unit system, with the unit named in the column headers. The
  station table was previously locked inside the PDF.
- In-panel station table. Each profile row now carries a collapsed "Station
  table" disclosure under its summary with the exact station / chainage /
  elevation / points / grade values — built from the same rows the CSV
  exports, so the screen and the file can never disagree. It is also the
  chart's accessible counterpart: the decorative SVG used to point screen
  readers at a station table that did not exist in the panel.
- Profile sampling controls. The parameters that shape every profile —
  corridor half-width, ground percentile, and sample count — are now
  user-settable, per profile, from a small disclosure under the chart whose
  always-visible caption states the values that actually produced the line
  ("Corridor ±2.5 m · ground p25 · 64 samples" — the same numbers the PDF
  header prints). Changing a value re-samples immediately; out-of-range
  inputs clamp to sane bounds (corridor 0.05–500 m, percentile 0–100; the
  sample picker offers 32–512 bins) rather than erroring; Reset returns to the defaults
  (auto corridor at 5 % of length, p25, 64 bins). On foot-CRS scans the
  corridor you type in display units is the corridor the sampler walks —
  the same unit seam the readouts use, applied in reverse. A 1 km section
  no longer silently aggregates a 100 m swath at ~16 m bin spacing with no
  way to see or change either. The values you settle on persist: they are
  remembered across reloads and applied to the next profile you draw, and
  Reset clears the remembered preference along with the row. Rapid edits —
  a held spinner arrow — coalesce into one re-sample instead of one per
  step.
- Intensity and classification ride along in XYZ/CSV exports. The columns
  appear only when the cloud actually carries the channel — raw 16-bit
  intensity and the raw ASPRS class code, after the r/g/b columns — and
  they are never a guessing game for the next tool: the CSV header row
  names every column, and an XYZ with the extra columns starts with a
  `# columns: …` comment line (a plain x-y-z export stays byte-identical
  to earlier releases). Both channels previously vanished on the way out.
- Terrain Products. The Analyse panel now leads with a compact status list —
  Profiles, Measurements, Terrain review, DTM/DEM export, Contours, Map
  sheet — each marked Ready ✓ / Preview ⚠ / Blocked ✕, and every product
  sitting below Ready carrying its own full "Reason:" line on a second row
  that wraps (the first cut ellipsized the reason into one line — "Preview
  Insufficient qua…"). The reason is the most specific string the readiness
  engine already minted for that product (`productReasonFor`): the export
  reason naming the exact georeferencing gap ("vertical datum unknown") when
  that is what holds a deliverable back, otherwise the assessment's surface
  line quoting the measured figure ("50% of the surface is interpolated"),
  with the short workflow note only as a last resort — and Ready rows carry
  no reason at all. The Terrain Intelligence Report's products section
  prints the same engine-selected text, word for word. It re-presents the
  assessment the panel already computed (nothing is re-judged), the status
  travels as a word next to the icon rather than by colour alone, and the
  original "Recommended workflow" checklist remains available beneath it,
  collapsed.
- Contour DXF files now open in CAD with their units declared and their
  labels attached. A minimal HEADER section carries `$INSUNITS` (metres by
  default, feet / US survey feet when the CRS resolves to them, honest
  "unitless" when unknown), so imports stop prompting for — or silently
  assuming — drawing units. The elevation labels that previously existed
  only in the SVG and PDF now ride along as TEXT entities on their own
  CONTOUR_TEXT layer, so they can be frozen or restyled independently of
  the linework.
- Contour SVG labels carry the decimals their interval needs — a 0.25 m
  interval prints 10.25 / 10.50 instead of collapsing every level onto
  "10" — and every sheet now states its interval and scale in the visible
  drawing ("Contour interval 0.5 m · 1 SVG unit = 1 m"), since the file
  previously carried no unit or scale cue a reader could see.
- Georeferenced ortho export. On a scan with a known CRS and world origin,
  the Studio's "View capture" (Orthographic RGB) button now renders a true
  top-down orthographic frame of the full footprint and downloads it as a
  small ZIP — the PNG plus a `.pgw` world file and a `.prj` — that QGIS and
  ArcGIS place exactly. The framed render is the only raster an affine
  world file can honestly describe, so the perspective view capture is
  never given one: scans without a CRS or origin, multi-cloud sessions
  with conflicting frames, and class-filtered exports (whose caveat banner
  would corrupt a placed raster's pixels) all keep the existing bare-PNG
  download and filename. The `.prj` is deliberately impossible to attach
  to local-frame coordinates (the v0.4.3 contour-georeferencing lesson,
  applied by construction).

### Changed

- (2026-06-12 amendment) Claim-accuracy wording pass on the two places the
  product talked itself up beyond its validation evidence. The interior
  floor-plan export is now labelled **"Floor plan preview"** everywhere the
  user sees it — the Space-panel button (with an "experimental — requires
  visual validation" note beside it), the standalone SVG sheet (subtitle
  "Floor Plan Preview — approximate wall-trace sketch" plus the same
  experimental caveat in the footer's warning style), and the Space Report
  PDF's embedded-plan section — code and module names are unchanged. And the
  standing deliverable-note wording minted by the readiness engine changed
  from "preview only — not for final deliverables" to **"preview only —
  additional validation recommended"** at its single source
  (`readinessEngine.deliverableNote`), so every consumer — the workflow
  checklist, Terrain Products rows, the Terrain Intelligence Report, and
  every DXF/SVG/GeoJSON/README provenance stamp — inherits the new wording
  verbatim; docs and the pinned test literals were updated to match. No
  behaviour change, wording only.
- The workflow recorder is disabled for this release (product decision).
  Its original `Cmd/Ctrl+Shift+R` chord collided with the browser's
  hard-refresh — toggling a recording reloaded the page and lost the live
  session — and rather than ship a mid-cycle rebind that risks fresh
  shortcut-collision confusion, the feature is switched off entirely while
  the "Replay a workflow file…" experience (the recipient must already have
  the same scan open) gets a proper design pass. The shortcut, the three
  Workflow command-palette actions, the shortcut-sheet entries and the
  recording badge are all absent in this build; `.olvworkflow` recording and
  replay will return in a later release. When it does, the shortcut will be
  `Cmd/Ctrl+Shift+U`: `U` is unbound in Chrome, Firefox and Safari, Edge's
  Read Aloud on `Ctrl+Shift+U` is page-interceptable (unlike reserved combos
  such as `Cmd+Shift+W` / `Cmd+Shift+T`), and no in-app binding uses `U`,
  bare or modified. The recorder engine and its unit tests remain in the
  tree behind the `WORKFLOW_RECORDER_ENABLED` flag in
  `src/ui/WorkflowController.ts`.
- The export-readiness verdict now has exactly one author. The same
  judgement — Ready / Preview / Blocked, the reason naming what holds it
  back, and the per-product good / caution / blocked grades — was derived
  or re-quoted with private mapping tables in four places (the terrain
  assessment minted the tier and reason inline, the recommended-workflow
  checklist re-graded it with its own note table, the Terrain Products
  list renamed the grades with a third table, and the provenance stamp
  and report rows each formatted the "Tier — reason" line themselves), so
  a future edit to any one table could have let an exported file grade a
  product differently from the panel. All of it now lives in
  `terrain/quality/readinessEngine.ts` — one `deriveReadiness` function
  returning `{tier, reason, productGrades}`, plus the shared word / glyph
  vocabulary and the one "Tier — reason" formatter — and every former
  author is a view over its output. No string changed: the engine was
  conformed to the existing wording, and the provenance-consistency and
  report-content suites pass unchanged; a new suite pins the
  single-source contract by swapping the engine's verdict for a sentinel
  and watching it surface verbatim in the assessment, the workflow
  checklist, the products list, every provenance stamp and the report.
- The brand now derives from the official OpenLiDARViewer logo file — no
  redrawn geometry anywhere. The invented orbit-rings mark that
  previously carried the identity (and the interim plain placeholder
  tile that briefly replaced it) are both gone; every identity surface
  is produced from the delivered asset itself. `public/brand-logo.svg`
  is the logo verbatim (the point-cloud-orb mark plus its raster
  wordmark band), and `public/brand-mark.svg` is the same file with only
  its root viewBox cropped to the mark region — nothing repainted. The
  in-app top bar and empty-state hero render that mark via `<img src>`
  (the asset never passes through the `unsafeHtml` escape hatch, so the
  XSS-guard allowlist keeps no brand entries), with the wordmark kept as
  real text beside/beneath it for light-theme and screen-reader
  legibility. All raster assets are RASTERISED from the logo file by the
  new `scripts/make-brand-rasters.py` (which retires the Pillow redraw
  script `make-manifest-icons.py`): `favicon.svg` is the mark's own
  pixels downscaled onto the #0a0e1a plate for contrast,
  `icon-192.png` / `icon-512.png` put the mark on the rounded brand-dark
  plate, `apple-touch-icon.png` is full-bleed with no alpha for iOS,
  `favicon.ico` (16/32/48) is the real asset downscaled — soft at 16 px
  by honest choice rather than redrawn — and `og-card.jpg` (1200×630)
  now carries the full official lockup on the deep-navy field with the
  "Visualize. Explore. Understand." tagline in cyan beneath it.
  `public/BRANDING-TODO.txt` is deleted: the logo arrived.

## [0.4.4] - 2026-06-09

Final release. Sections below fold in the post-audit hardening batch.

### Added

- Dropping several files at once now says what happened: the first file opens
  as before, and a toast names it and reports how many companions were
  ignored, pointing at the batch converter — instead of silently discarding
  everything past the first file.

- The batch converter can write LAS 1.4 (point data record formats 6/7), and
  it is now the default output format. The extended records carry the full
  8-bit classification, so classes above 31 — class 64, vendor codes up to
  255 — survive conversion intact where LAS 1.2's 5-bit field destroyed them
  (the audit defect). Format 7 is picked automatically when the cloud has
  colour (RGB upscaled 8→16 bit losslessly), format 6 otherwise; up to 15
  returns are tallied into the extended uint64 by-return counts. When the
  source carries a WKT CRS and coordinates are kept, the WKT travels into the
  1.4 file with the global-encoding WKT bit set (as the spec requires for
  formats 6+); when only an EPSG is known, the GeoKey tag is written instead
  and the log says so. These extended records are also what COPC requires, so
  this writer is the foundation for future COPC output.

### Changed

- The previous LAS output is now labelled "LAS 1.2" (next to "LAS 1.4") so the
  version choice is explicit, and it warns per file — instead of staying
  silent — when its 5-bit classification field clamps classes above 31,
  pointing at LAS 1.4 as the lossless choice.
- The Export panel now defaults to LAS 1.4, matching the batch converter's
  recommended format instead of pre-selecting the lossy LAS 1.2 legacy choice.
- Faint UI text (`--text-faint`) is lighter in the dark theme and darker in
  the light theme so hints, captions and placeholders clear WCAG AA contrast;
  the high-contrast theme already passed and is unchanged.
- The tool dock's toggle buttons (Measure, Inspect, Probe, Annotate, Analyse)
  keep a stable label and expose their on/off state through `aria-pressed`
  instead of swapping to "Measuring…"-style text — screen readers now hear
  the toggle state, and the dock no longer shifts layout on every toggle.
- The synchronous main-thread terrain fallback (used only when the analysis
  worker fails) now has a 1 M-point ceiling. Every production caller strides
  the analysis sample to ≤ 300 000 points, so the ceiling never fires today —
  it protects future full-resolution callers from a silent main-thread freeze
  by failing with a clear message instead.

### Fixed

- The Dataset Intelligence card — and every provenance stamp fed from the same
  constant: terrain reports, DEM-package READMEs, contour exports, space
  reports — no longer claims "Metric Version v0.4.1". The shared
  `TERRAIN_METRIC_VERSION` was not bumped when 0.4.4 changed the metric
  definitions (the aspect north–south mirror fix, cell-centre contour
  registration, and the compound-WKT horizontal-unit fix all change what the
  metrics report for the same cloud); it now reads v0.4.4 and its doc comment
  records why.
- The Dataset Intelligence card's "Analyzed Points" row no longer reads "0"
  forever on streamed COPC / EPT scans. The attach-time summary honestly
  starts at 0 (nothing analysed yet), but nothing ever updated it; a finished
  terrain run now folds its real analysed-point count — the same
  `dtm.analyzedPointCount` the terrain report's "Analysed points" row prints —
  back into the card, so the card and the PDF agree.
- The Help overlay's shortcut list no longer drifts from the actual bindings:
  it now lists the T / O / P camera presets, L (lasso volume), H (controls
  HUD) and Cmd/Ctrl-K (command palette), and the `?` entry says what `?`
  really does — open the keyboard shortcut sheet, which owns that key.
- Load-status announcements for screen readers now come from two permanently
  rendered, visually hidden live regions (polite status + assertive alert)
  instead of the toast itself — a toast hidden with `display:none` leaves the
  accessibility tree, so its announcements fired unreliably or not at all.
- The `?debug=1` overlay's frame stats now include streamed COPC / EPT
  clouds: resident points fold into the displayed count and GPU byte
  estimate, and the source's total point count folds into the total —
  previously a streamed scan reported zero points while clearly on screen.
- Contour exports from a streamed COPC / EPT scan keep their world origin
  and EPSG stamp: the map context now falls back to the streaming source's
  render origin and CRS when no static cloud is active, instead of silently
  degrading to a local frame.
- The scalar sRGB → linear EOTF copies in the photometric patch view and the
  colour-provenance card now delegate to the shared seam in `colorEncode.ts`,
  so the curve can no longer drift from what the GPU pipeline applies.
- Eye Dome Lighting obscurance is no longer computed in the wrong depth space.
  The renderer draws with a logarithmic depth buffer, but the EDL pass was
  inverting its depth samples with the standard perspective formula
  (`perspectiveDepthToViewZ`) — decoding log-encoded values as if they were
  perspective depth, so the depth cue read far too weak up close and erratic
  at range, silently defeating the unit-tested EDL maths. The pass now applies
  the matching logarithmic inversion,
  `eyeDist = near′ · 2^(depth · log2(far / near′))` with `near′ = max(near,
  1e-6)` — the exact inverse of three.js's near-anchored log-depth encoding on
  both the WebGPU backend and the WebGL 2 fallback — and keeps the perspective
  path for a renderer built without log depth. The depth mode is read back off
  the renderer at construction rather than assumed, and the inversion is
  pinned CPU-side by new unit tests (`logDepthToEyeDistance` in `edl.ts`),
  following the same mirrored-math pattern as the splat shader.
- Clicking Cancel on an in-flight "Open from URL" load no longer instantly
  restarts the very load it just aborted. The cancel handler flipped the
  button back to `type="submit"` while the click event was still
  dispatching, so the browser evaluated the click's default action against
  the new type and re-submitted the form — Cancel aborted the stream and
  then immediately kicked off the same request again. The handler now
  suppresses the click's default action before cancelling, so Cancel means
  cancel.

### Notes

- New regression tests pin provenance consistency across every exporter — the
  DEM README, contour GeoJSON / DXF / SVG, map-sheet PDF and terrain report
  are driven from one analysis run and must agree word-for-word on the
  surface-quality and export-readiness verdicts, CRS, datum, accuracy and
  software stamps — and pin the terrain-core fallback's stale-result
  (abort-during-worker-failure) and oversize (`MAX_FALLBACK_POINTS`) guards.
- A static-analysis guard now pins every `unsafeHtml` call site to a
  hand-reviewed allowlist — all seven current sites carry only literal SVG
  icons or chart markup composed from numeric inputs — and fails on any new
  site, any stale entry, or any argument naming user-shaped data (scan / file
  / dataset names, URL params, message payloads), so the `innerHTML` escape
  hatch in `dom.ts` cannot silently regress into an XSS sink.

### Earlier in this release

A correctness and hardening release driven by a full-codebase audit. Every fix
below was verified against the v0.4.3 source before being applied.

### Fixed — survey-output correctness

- The point Inspector no longer applies the world origin twice. World
  coordinates, and the Geographic / UTM rows derived from them, were shifted by
  a full extra origin (e.g. ~+500 000 E / +4 500 000 N on a UTM scan). The
  card now shows the true World position, and a separate Local group (renderer
  frame) only when an origin exists.
- Contour vector exports (GeoJSON, DXF, SVG) are now georeferenced. They
  previously wrote origin-recentred local coordinates while stamping a real
  EPSG CRS, landing hundreds of kilometres from truth in GIS software; contour
  elevation values were offset by the vertical origin as well. Exports now
  shift geometry and levels to world coordinates — and when no origin is
  available, the EPSG stamp is omitted and a "local frame" warning is attached
  instead of claiming a CRS.
- Horizontal linear units are read from the horizontal CRS only. A compound
  WKT (projected + vertical) in US survey feet was previously measured as
  metres because the vertical axis's UNIT won the scan (~3.28× error in every
  derived measure).
- Aspect (and therefore hillshade lighting) is no longer mirrored north–south
  on the northing-up analysis grids; a north-facing slope now reports north,
  and the default 315° sun lights from the northwest as labelled.
- Contours are registered to cell centres, removing a systematic half-cell
  southwest shift relative to the exported DEM GeoTIFF of the same surface.

### Fixed — stability and behaviour

- Malformed or hostile files can no longer trigger runaway allocations: LAZ,
  COPC, EPT and E57 decoders now validate file-declared point/record counts
  against the actual bytes available before allocating (a shared
  `validateDeclaredPointCount` guard), failing with a typed malformed-file error.
- Recoloring after the initial upload (color-mode switches, coverage grids,
  height trims, classification edits, streaming recolors) now applies the same
  sRGB→linear conversion as the first upload, through one shared seam —
  switching Elevation → RGB no longer washes out the cloud.
- Removing a cloud releases its classification and selection snapshots
  (previously retained for the session — up to ~5 MB per edited scan).
- The URL field's Cancel button actually cancels the in-flight download (the
  abort signal is now threaded through to the loader), and submitting an empty
  URL explains what is expected instead of silently doing nothing.
- Concurrent open requests are rejected race-free (the loading flag is set
  synchronously), with a toast — "Already loading — cancel the current load
  first." — instead of silence.
- Pressing `I` no longer fires the Inspect tool and the Iso camera preset on
  the same keystroke: bare `I` belongs to Inspect (as the help advertises);
  the Iso preset remains on the view chips and command palette. All bare-key
  handlers now honour and set `defaultPrevented` so collisions cannot recur.
- Panel-width persistence no longer throws (and blocks boot) when browser
  storage is unavailable; all storage access goes through one guarded helper.

### Added

- Load progress, errors, and toasts are announced to screen readers
  (`role="status"` / `role="alert"` with polite live regions).
- Share metadata (Open Graph / Twitter card), an SVG favicon, an
  apple-touch-icon link, and a web app manifest.
- A commented production `.htaccess` (long-lived immutable caching for hashed
  assets, HSTS, nosniff, referrer and permissions policies, WASM MIME type,
  and a Content-Security-Policy draft in report-only form for testing).

### Notes

- Aspect/hillshade truth-test fixtures that encoded the mirrored convention
  were corrected alongside the fix; new regression tests cover the Inspector
  origin, contour world-origin shift, compound-WKT units, cell-centre
  registration, and the decoder allocation guards.

## [0.4.3] - 2026-06-09

### Added

- Manual scan-type override: a "Treat as" control (Auto / Terrain / Object /
  Interior) in both the terrain Analyse panel and the Space / Object panel lets
  you correct a misjudged scan in one click. A non-auto choice takes precedence
  over auto-detection, stays pinned while the cloud streams in, and resets to
  Auto on each new scan. Metrics are still computed honestly for the chosen
  type; the panel notes when the type was set manually.

### Changed

- Export provenance is unified: GeoJSON, DXF, SVG, the printable map sheet, and
  the DEM package now all stamp the same provenance, derived once from the run —
  software and metric version, date, source, CRS, vertical datum, coverage,
  contour interval and style, Surface Quality and Export Readiness (with the
  reason), and the measured accuracy (RMSEz / NVA / VVA / USGS Quality Level) —
  so no two exported artifacts can disagree, and every one carries the
  not-survey-grade note.
- Scan-type detection re-evaluates once the streaming cloud has fully settled
  ("Streaming ready"), so a type decided on a sparse early frame (which could
  misread a 360 / interior scan) is corrected on the representative geometry.

### Fixed

- Terrain density and slope now respect the scan's real horizontal units. On a
  foot-based projected coordinate system, ground density is reported as genuine
  points per square metre (previously it was measured in square feet but
  labelled per square metre, understating density by ~10.8×) and the slope used
  for surface-quality checks is computed over a metre run. Metric (metre) data
  is unchanged. This matches the existing handling of the vertical axis.
- A surface rated "Limited" now states a Limited reason instead of borrowing the
  preview-tier wording, and the "% of the surface is interpolated" figure is
  consistent everywhere it appears — it always means the share of the captured
  surface that is interpolated rather than measured, no longer diluted by empty
  cells in some views.
- Export honesty wording is tighter: a georeferencing gap (unknown CRS / datum)
  is only listed as an export reason when it actually holds the export back
  below the surface quality, and when a surface is both below grade AND not
  georeferenced the export reason now names both, rather than only the
  coordinate-system gap.
- The Space / Object report now respects the scan's real horizontal units, so
  dimensions, area, and volume read correctly (and convert correctly between
  metres and feet) for foot-based and other non-metre coordinate systems
  instead of assuming metres.
- Interior floor / ceiling / storey detection is more robust: floor and ceiling
  planes are found from density-weighted height peaks (so a cluttered floor or a
  sparsely captured ceiling is still detected), and a second storey is only
  counted when there is a real floor-to-floor gap with mass between the levels —
  it stays clearly labelled as approximate.

## [0.4.2] - 2026-06-05

### Added

- Classification legend: a "Classes" panel lists one row per ASPRS class
  actually present in the loaded scan, each with the renderer's class colour
  swatch, the class name, and a live count of the points currently shown — so
  the legend reads as the true colour key for the view, not a static table.
- Per-class show/hide, isolate, and show-all: untick a class to drop it from
  the view, use "Solo" to isolate a single class, and "Show all" to bring
  everything back. A persistent "Filtered — showing N of M classes" banner
  stays up the whole time a filter is active, so a partial view can never be
  mistaken for the full cloud. Picking and inspection honour the filter too —
  you can only pick points in the classes you can see.
- Metrics follow the visible classes: when classes are hidden, the scan
  report recomputes over just the visible subset (ground, density, coverage,
  and the rest), and every filtered readout is stamped with the class scope it
  was measured under, so no filtered number is ever shown unqualified. Clearing
  the filter restores the full-cloud figures and removes the stamps.
- Streaming header metrics that can't be re-derived from the resident view are
  shown for the full cloud and clearly labelled "not class-scoped", rather than
  silently mixing a full-cloud figure into an otherwise filtered report.
- Filtered exports carry their scope: copied points, the PDF report, and the
  image and snapshot exports are all stamped with the active class filter, so a
  filtered artifact is self-describing — anyone opening it later can see exactly
  which classes it represents.
- Contour map PDF, pre-export dialog: the MAP PDF action now opens a dialog to
  set the title, "prepared by", a free Project / Notes block, the sheet size and
  orientation, the final contour interval, and the output filename — each
  pre-filled with a sensible default from the scan. A re-picked interval
  regenerates the contours from the already-computed surface (no re-analysis).
  The measured fields (CRS, vertical datum, scale, NVA / VVA / RMSEz, USGS
  Quality Level, date) are shown read-only and stay computed from the scan, so a
  deliverable can be titled and described freely without ever hand-editing the
  accuracy figures.
- Interface polish: a consistent button system across the app with clearer
  primary actions, accessible focus rings, and an obvious, rotating expand /
  collapse chevron on the collapsible panel headers (Analyse, Export / Convert).
- Contour shape style, selectable on export: a "Contour style" picker (in the
  Analyse export section and the map-PDF dialog) chooses how the contour lines
  are shaped — As measured (crisp), Smooth, Rounded, Generalized, or
  Semi-geometric — and applies to every contour export (PDF, SVG, DXF, GeoJSON).
  Smoothing stays honesty-gated: it never moves a low-confidence vertex or
  bridges a data gap, so a dashed / uncertain run can't be reshaped into a
  confident line, and each exported file is stamped with the style it was made
  with. The on-screen contours are unchanged (the default matches the previous
  smoothing).
- Non-terrain scan detection: indoor / 360 / phone-LiDAR room and object scans
  are now recognised as non-terrain (a floor-plus-ceiling enclosure, or a
  compact object) instead of being pushed through the terrain contour pipeline,
  which is a category error for them. Such scans get a Space / Object report —
  overall dimensions (L x W x H, in metres and feet), floor area, ceiling
  height, enclosed volume, floor / wall / ceiling plane detection, storey count,
  and a capture-quality block (point count, density, coverage, RGB) — with the
  same honesty caveats as terrain (figures are based on the loaded / streamed
  data, ceilings are often sparsely captured, nothing is survey-certified).
  Terrain contour analysis stays one click away for any scan. Object scans get a
  matching report at the same depth — oriented and axis-aligned dimensions
  (metres and feet), largest dimension, bounding-envelope volume (m³ and ft³),
  an approximate bounding-box surface area, and the same capture-quality block —
  with the figures honestly labelled as bounding envelopes, not solid or mesh
  measurements. Scan-type detection is more robust: an interior is recognised
  from its floor plus wall / floor-to-ceiling columns (so a real multi-room or
  360 house with a partial, occluded ceiling is no longer mistaken for terrain),
  and when a scan carries classification a vegetation-dominated canopy keeps a
  forested drone scan as terrain rather than reading the canopy as a ceiling.
  Streaming scans re-evaluate their type as more of the cloud arrives.
- Contour export, simplified: the redundant contour-interval picker and the
  contour-style selector were removed from the Analyse panel — both are now
  chosen in the export dialog — and the "MAP PDF" button is renamed
  "Export Contours" to read as the primary contour-deliverable action.

### Changed

- Terrain DTM now aggregates each grid cell by the MEDIAN of its ground returns
  instead of the arithmetic mean. The median (50% breakdown point) is resistant
  to outliers: a single high return (vegetation, a parked vehicle) or low return
  (multipath) in a cell no longer pulls the cell's elevation, so the bare-earth
  surface tracks the true ground more faithfully. This changes elevation values
  in cells that previously had a skewed mix of returns. The hold-out RMSE
  validation rebuilds its DTM with the same median aggregation, so the reported
  accuracy continues to measure the surface that ships, and the DEM export
  README's "Generation parameters" now records the cell aggregation used.
- Terrain quality is now reported on TWO independent axes instead of one
  conflated verdict: **Surface Quality** (is the terrain surface internally
  valid?) and **Export Readiness** (is it georeferenced enough to hand off?).
  Surface Quality is derived purely from surface metrics (coverage,
  interpolation, edge risk, density, ground visibility, hold-out RMSE) and is
  INDEPENDENT of the coordinate system and vertical datum — a dense, clean,
  well-covered scan with an unknown datum now reads as a good surface. Export
  Readiness equals Surface Quality further gated by georeferencing: an unknown
  CRS or vertical datum caps it to "preview" (with an explicit reason such as
  "vertical datum unknown"), even when the surface itself is good. The Analyse
  panel shows both axes; DEM and contour/map exports key off Export Readiness;
  and the DEM/map deliverables still carry their preliminary caveat whenever the
  georeferenced hand-off is not export-ready. The honesty contract is unchanged
  — an unknown datum still blocks an export-ready verdict and nothing claims
  survey-grade.

## [0.4.1] - 2026-06-04

### Added

- Terrain Assessment: a single top-level verdict — Good / Preview / Limited —
  at the top of the Analyse panel, with the 0–100 terrain quality score folded
  into the headline (e.g. "Preview · 64/100"), a one-line reason, what the
  surface is best for, and a caution where relevant. The detailed metrics
  (quality breakdown, coverage, confidence, RMSE, NVA/VVA, readiness,
  recommended grid) now sit behind a collapsed "Details" expander, so a
  non-specialist reads the bottom line first and drills in only on demand. The
  verdict speaks to data quality and fitness-for-use — it does not claim
  survey-grade or survey-certified output.
- DEM export: a one-click "DEM (ZIP)" button in the Analyse panel downloads the
  elevation rasters — bare-earth DTM, top-surface DSM, and canopy height (CHM) —
  each as both an Esri ASCII Grid (.asc) and a georeferenced Float32 GeoTIFF
  (.tif), with a .prj CRS sidecar when known and a metadata README (CRS,
  vertical datum, cell size, units, RMSEz / NVA / VVA, USGS Quality Level, and
  coverage). GeoTIFF carries its CRS by EPSG GeoKeys and a north-up
  ModelTiepoint, so it drops straight into QGIS / ArcGIS / GDAL. The raster
  writers ride a lazy chunk, and the export stays available even when the
  contour quality gate would block the vector exports.
- An "Analyse" button in the tool dock toggles the terrain analysis panel, so
  it can always be re-opened after it's closed — including when selecting the
  Profile tool tucks it away, or when an object scan demotes it behind the
  Object panel. On phones it lives in the dock's "More" (•••) menu, and the
  bottom-centre navigation control always stays clickable where the two meet.
- Multi-directional relief: the Analyse panel's hillshade is now a soft
  multi-directional shaded relief by default, with a toggle to a single sun and
  an adjustable sun azimuth and altitude. Re-lighting is instant — it reuses the
  cached slope/aspect grids — and the current relief exports as a PNG.
- Click-to-sample: clicking any analysed preview raster (relief or canopy)
  reports the bare-earth elevation, slope, and above-ground height at that cell,
  turning the static surface into a point-query tool. The sampled point is
  marked with a crosshair, the readout is announced to screen readers, and the
  relief tile carries a shaded-relief legend and clearer sun-off state.
- Canopy Height Model (CHM): the Analyse panel now renders above-ground height
  (DSM − DTM) as its own north-up preview on a green canopy ramp with a height
  legend, exportable as a print-resolution PNG — alongside the hillshade, which
  shares the same preview/export controls.
- Bare-earth elevation histogram: a compact distribution of the DTM's ground
  elevations in the Analyse panel, with the value range and cell count, for a
  quick read of the terrain's hypsometry.
- Distance measurements now report a compass bearing (zero-padded azimuth,
  e.g. "15.2 m · 042°") alongside the length; purely vertical pairs show length
  only. Bearing is measured in the map plane and handles non-Z-up scans.
- Typography refresh: the interface now uses Manrope for text and JetBrains
  Mono for figures and labels (both self-hosted, no external font requests),
  and the data panels render tabular figures so columns of numbers line up.
- Cross-section profile chart, professional numbers pass: the elevation axis
  now labels rounded "nice" values (e.g. 120 · 125 · 130) with matching
  gridlines instead of the raw min/max, and every numeral renders in JetBrains
  Mono with tabular figures from a positioned overlay — so the axis text no
  longer inherits the chart's horizontal stretch and reads crisply at any
  chart height. Units are spaced (e.g. "120 m") and decimals are consistent.
- Selecting the Profile measurement now clears the Analyse panel and brings
  the Measurements panel forward automatically, so the cross-section chart has
  room and the workflow focus is unambiguous.
- Readiness cards redesigned: ground confidence, DTM quality and contour
  readiness now read as a row each — the label and supporting line on the
  left, a large figure with its unit and a colour-coded rating pill on the
  right — so the headline number and its rating are scannable at a glance.

- Point cloud format converter: batch-convert files from the start screen, plus
  an in-project Export panel. Reads LAS, LAZ, XYZ and ASC; writes LAS, XYZ and
  ASC with a CRS assign or reproject step and an optional full-resolution pass.
- Vertical datum detection from LAS GeoTIFF / WKT, and LAS RGB reading so colour
  point clouds now display in colour. Wider reprojection CRS coverage.
- Terrain quality: a 0–100 quality score (surfaced in the Analyse panel) built
  from per-cell density, completeness and edge metrics, outlier-rejection DTM
  hardening, and hold-out RMSE stratified by slope and surface zone.
- DTM extrapolation guard: a filled cell whose supporting ground data lies only
  on one side is an extrapolation, not a bracketed interpolation, so its
  confidence is now demoted toward dashed/gap rather than reading as trusted.
  The guard scans eight rays and measures the angular spread of nearby data; a
  cell whose support is confined to an arc under 180° is treated as one-sided.
- Surface models in the Analyse panel: a top-surface DSM with above-ground
  height (canopy and structures), slope, and an exportable hillshade preview.
- Unit-correct terrain analysis: slope, roughness and hillshade convert
  geographic (degree) grids to metres, and the hold-out RMSE and quality score
  are reported in metres for foot-based CRSs.
- The Measurements panel is now width-resizable (drag the south-east handle)
  so the cross-section profile chart can be widened to read; the chosen width
  is remembered. The hillshade preview also exports at full resolution (~2048
  px) instead of the raw grid size.
- Cross-section profiles honour classification: when the cloud carries ASPRS
  classes, vegetation / building / noise returns are dropped before the
  bare-earth percentile, so trees no longer pull the profile floor up.
- Object-scan detection now finds the up axis from geometry (handles Y-up
  phone / glTF scans), instead of assuming Z-up.
- Object scans get object analysis: a scan that reads as a compact 3-D object
  (a phone scan of a sculpture, a chair, a room) is detected from its geometry,
  and an Object panel surfaces the right measurements — oriented dimensions
  (L×W×H), envelope volume, scan resolution, and capture completeness — instead
  of misleading contours. Terrain analysis stays one click away ("run anyway").
- Splash reorganized for clarity: the primary Open button now sits beside a
  peer Convert chip, and the location picker, location search and streaming demo
  are consolidated into one "Explore public LiDAR" card.
- Performance: the 2D tool overlays (measure / inspect / annotate) are
  re-projected only on rendered frames rather than every animation frame, so a
  static scene no longer does continuous overlay DOM work — lower idle CPU.
- Printable map-sheet PDF — a field deliverable: contours rendered as a framed
  map with a UTM coordinate graticule, scale bar, north arrow, a legend keying
  the line types, and a title block carrying the CRS, vertical datum, scale, and
  the NVA / VVA / USGS Quality Level accuracy with a survey-grade / preview note.
- Geodesic (surface-aware) void interpolation: empty DTM cells are filled by
  inverse-distance weighting along the terrain surface rather than in a
  straight line, so a gap in a valley is no longer filled from across a ridge —
  more accurate bare-earth heights near breaklines.
- DEM accuracy in survey standards: the Analyse panel reports NVA (95%
  confidence = RMSEz × 1.96), VVA (95th-percentile vegetated accuracy), and the
  USGS 3DEP Quality Level (QL0–QL3) the surface meets on point density and
  RMSEz together.
- Classification-aware contours: when the cloud carries ASPRS classification
  (from the file or the lasso editor), vegetation, building and noise returns
  are dropped before ground filtering so the bare-earth surface and contours
  can't anchor to canopy or rooftops. Above-ground height still uses the full
  cloud. The ground filter's slope-scaled tolerance is also capped so steep
  terrain can't admit low buildings or vehicles as ground.

## [0.4.0] - 2026-06-03

### Added

- Terrain analysis (preview): a confidence-aware DTM and contour pipeline with
  a mounted Analyse panel. Classifies ground, validates the surface, gates a
  professional export behind quality (CRS, vertical datum, coverage), and
  exports evidence-graded contours as GeoJSON, SVG, and DXF.
- Cross-section profiles export a full-page, scaled PDF with a
  station / elevation / grade table and civil summary.

### Fixed

- Long measurement readings and dataset/layer names no longer overflow their
  panels.

## [0.3.10] - 2026-06-02

Browser-based LiDAR and point-cloud viewer. Loads LAS, LAZ, E57, PLY, PCD,
PTS, PTX and streams COPC, EPT, and 3D Tiles, entirely client-side on WebGPU
with a WebGL2 fallback. Includes measurement, annotation, classification,
cross-section profiles, volume, PDF reporting, and image export.
