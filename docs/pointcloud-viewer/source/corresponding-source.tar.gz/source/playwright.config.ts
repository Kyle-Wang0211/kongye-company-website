import { defineConfig, devices } from '@playwright/test';

/**
 * End-to-end tests run against the production build served by `vite preview`.
 * Run locally with `npm run test:e2e` (install browsers first with
 * `npx playwright install --with-deps chromium`).
 */
/**
 * The port the smoke's web server binds. Deploy-root runs are handed a
 * kernel-assigned free port so two runs, or a stray process, cannot collide.
 */
const DEPLOY_PORT = Number(process.env.OLV_DEPLOY_PORT ?? 4173);

/**
 * The one origin the web server binds and every spec navigates against.
 *
 * 127.0.0.1 rather than `localhost` in deploy-root mode, because that server
 * binds loopback explicitly and a `localhost` resolving to ::1 first would find
 * nothing there. Defined once: baseURL and webServer.url disagreeing is how the
 * whole suite ended up pointed at a dead port.
 */
/**
 * `vite preview` binds 4173 unless told otherwise. A set OLV_DEPLOY_PORT moves
 * it (strictly, so an occupied port fails the run), which lets a benchmark
 * share the machine with e2e runs on the default port.
 */
const PREVIEW_PORT_ARGS = process.env.OLV_DEPLOY_PORT ? ` -- --port ${DEPLOY_PORT} --strictPort` : '';

const SERVER_URL = process.env.OLV_DEPLOY_ROOT
  ? `http://127.0.0.1:${DEPLOY_PORT}`
  : `http://localhost:${DEPLOY_PORT}`;

/**
 * One X display per Playwright worker for the Linux Firefox leg.
 *
 * That leg runs Firefox headful (see the `firefox` project below), and with a
 * single shared Xvfb screen and no window manager every worker's browser
 * window is mapped at the same spot, stacked on the others. A window covered
 * by another worker's newer one is fully obscured: Firefox stops handing it
 * animation frames while its page still reports visible and focused (measured
 * on the runner: requestAnimationFrame silent for seconds while a 250 ms
 * timer kept firing), so Playwright's "stable" check before a click never
 * finishes and a frame probe counts nothing. The same stacking moves the
 * pointer: each window mapped over or taken off ours sends a real leave or
 * enter at the parked X cursor, which is how a hovered control lost its hover
 * mid-test. CI starts one Xvfb per worker and lists them here; each worker
 * process launches its browser on the display of its own parallel slot, so no
 * window ever covers another. Unset everywhere else, where it changes nothing.
 */
const FIREFOX_DISPLAYS = (process.env.OLV_FIREFOX_DISPLAYS ?? '').split(',').filter(Boolean);
const FIREFOX_DISPLAY = FIREFOX_DISPLAYS.length
  ? FIREFOX_DISPLAYS[Number(process.env.TEST_PARALLEL_INDEX ?? 0) % FIREFOX_DISPLAYS.length]
  : undefined;

/**
 * Specs the blocking browser projects never collect. streamingNavPerf measures
 * frame times during a scripted fast navigation over a large streaming COPC, a
 * timing result that only means something on a real GPU. It is tagged `@gpu`
 * already; listing it here as well keeps it out of `deterministic`, `firefox`
 * and `webkit` even if the tag is edited. Run it with `--project=gpu`.
 */
const NOT_BLOCKING = /firefoxWebglPreflight|streamingNavPerf|e2e\/journeys\//;

/**
 * The UX journey specs (tests/e2e/journeys). Each one opens a scan and walks a
 * whole user task with a screenshot per step, so together they add several
 * minutes per engine. They run in their own `journeys-*` projects and their own
 * advisory CI job, and the blocking projects above never collect them.
 */
const JOURNEYS = /e2e\/journeys\/[^/]+\.spec\.ts$/;

/**
 * Firefox tests that run alone, after the rest of the Firefox suite. The
 * streaming terrain test runs up to four whole-scan terrain analyses on a
 * software renderer and takes about seven minutes on a CI runner. With two
 * workers, whatever shares the runner with it is starved: the terrain run in
 * terrainAccessLab's blank-profile test then missed its 20 s readiness window,
 * and the streaming test itself took 7.1 min against 2.6 min alone. The
 * `firefox-solo` project runs these once `firefox` is done, one at a time.
 */
const FIREFOX_SOLO = /the terrain analysis is resident-only until every node is resident/;

/** The `firefox` browser settings, shared with `firefox-solo`. */
const FIREFOX_USE = {
  ...devices['Desktop Firefox'],
  // Firefox's HEADLESS widget on Linux has no GL compositor, so
  // `canvas.getContext('webgl2')` returns null no matter how much of
  // Mesa is installed. That single fact caused every one of the 111
  // failures this leg reported: the viewer logs "GPU backend
  // initialisation failed. Neither WebGPU nor WebGL 2 produced a
  // usable context", the smoke specs trip their no-console-error
  // assertion, and everything that loads a scan waits for a frame
  // that never arrives.
  //
  // Measured on ubuntu 24.04 with a full Mesa stack present:
  //   headless, default prefs .................. webgl2 = null
  //   headless + webgl.force-enabled ........... webgl2 = null
  //   headless + LIBGL_ALWAYS_SOFTWARE=1 ....... webgl2 = null
  //   HEADFUL under Xvfb, default prefs ........ webgl2 = llvmpipe ✓
  // No pref makes headless work, and no pref is needed once it is
  // headful — so the fix is the window, not the configuration. Adding
  // Mesa packages on their own does nothing either; that was measured
  // too, and headless stayed null with the full stack installed.
  //
  // Only Linux is switched: macOS and Windows produce a context in
  // headless mode already, and going headful there would just pop a
  // real window open on a developer's desktop for every test. CI
  // wraps this leg in `xvfb-run` (see .github/workflows/ci.yml),
  // which is what supplies the display.
  headless: process.platform !== 'linux',
  ...(FIREFOX_DISPLAY ? { launchOptions: { env: { ...process.env, DISPLAY: FIREFOX_DISPLAY } } } : {}),
};

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  // `list` for readable console output; in CI also emit an `html` report so the
  // on-first-retry trace + failure screenshot are bundled into playwright-report/
  // and uploadable (the advisory browser jobs are continue-on-error, so their
  // failures are only diagnosable from an uploaded trace).
  // The JSON file is what CI reads to prove a blocking leg ran a non-zero
  // number of tests (scripts/assert-playwright-ran.mjs).
  reporter: process.env.CI
    ? [['list'], ['html', { open: 'never' }], ['json', { outputFile: 'playwright-results/results.json' }]]
    : 'list',
  use: {
    // Follows the web server: deploy-root runs get a kernel-assigned free port
    // and a loopback address, and a hardcoded 4173 here sent every spec to a
    // port nothing was listening on.
    baseURL: SERVER_URL,
    trace: 'on-first-retry',
    // Pre-seed localStorage so the onboarding tour overlay (which
    // auto-launches on first session per browser and intercepts
    // pointer events) is treated as already-completed for every
    // test. The key string mirrors `STORAGE_KEY` in
    // src/ui/onboarding/tourSteps.ts; if that constant changes,
    // update this string too. Without this seeding the first click
    // in any spec hits the tour backdrop instead of the target.
    storageState: {
      cookies: [],
      origins: [
        {
          // Must be the origin actually served, or the seed lands on a
          // different origin and the tour overlay is back. Deploy-root runs
          // move both host and port.
          origin: SERVER_URL,
          // The one-time navigation hint (NavBar FIRST_USE_HINT_KEY) is seeded
          // as seen for the same reason; navFirstUse.spec.ts clears it.
          localStorage: [
            { name: 'olv:tour:v1:completed', value: '1' },
            { name: 'olv.nav.firstUseHint', value: '1' },
          ],
        },
      ],
    },
  },
  // Two projects split the suite by whether a spec's result depends on the
  // runner's GPU. `deterministic` is the BLOCKING gate: DOM, layout, routing,
  // export and streaming-logic flows that must pass identically everywhere.
  // `gpu` is advisory: specs whose outcome varies with the WebGPU adapter a CI
  // runner happens to expose. Tag a spec into the advisory set by putting
  // `@gpu` in its describe/test title — untagged specs block, which is the safe
  // default (a new spec gates until proven GPU-variable).
  //
  // `firefox` and `webkit` run the same deterministic set on the other two
  // engines. A viewer that renders through WebGPU with a WebGL2 fallback cannot
  // claim to work in a browser nobody ran it in, and this project tested one.
  // They are ADVISORY in CI, not required: a new leg that goes red would
  // otherwise block every unrelated change while its failures are triaged.
  projects: [
    { name: 'deterministic', use: { ...devices['Desktop Chrome'] }, grepInvert: /@gpu|@bench|@soak/, testIgnore: NOT_BLOCKING },
    { name: 'gpu', use: { ...devices['Desktop Chrome'] }, grep: /@gpu/, grepInvert: /@bench|@soak/, testIgnore: /firefoxWebglPreflight/ },
    // Navigation benchmark runs. They measure frame pacing and replay whole
    // trajectories, which only means something on a real GPU and outlasts the
    // test timeout on a software renderer, so no CI job selects this project.
    { name: 'bench', use: { ...devices['Desktop Chrome'] }, grep: /@bench/, testIgnore: /firefoxWebglPreflight/ },
    // Long-session soak (golden journey repeated). Minutes long, so no CI job
    // selects it; run with `npm run test:e2e:soak`.
    { name: 'soak', use: { ...devices['Desktop Chrome'] }, grep: /@soak/, testIgnore: /firefoxWebglPreflight/ },
    {
      name: 'firefox',
      use: FIREFOX_USE,
      grepInvert: [/@gpu|@bench|@soak/, FIREFOX_SOLO],
      testIgnore: NOT_BLOCKING,
    },
    // FIREFOX_SOLO, on the same browser settings, started only after `firefox`
    // has finished. CI names both projects; the tests run one at a time.
    {
      name: 'firefox-solo',
      use: FIREFOX_USE,
      grep: FIREFOX_SOLO,
      grepInvert: /@gpu|@bench|@soak/,
      testIgnore: NOT_BLOCKING,
      dependencies: ['firefox'],
    },
    { name: 'webkit', use: { ...devices['Desktop Safari'] }, grepInvert: /@gpu|@bench|@soak/, testIgnore: NOT_BLOCKING },
    // iPhone WebKit: the same engine family as Mobile Safari, with a phone
    // viewport, a device pixel ratio of 3 and real touch events. It is the
    // closest an install-free local gate gets to an iPhone, and it is NOT an
    // iPhone: Playwright's WebKit is built from mainline rather than shipped as
    // Safari, and it renders on this machine's GPU rather than a mobile one.
    // So it gates layout, hit targets and touch, and it cannot speak to iOS
    // WebGL 2 limits, memory pressure on a large cloud, or WebGPU availability
    // on a real device. Those need a physical iPhone or a device farm.
    //
    // The failure mode is worse than missing coverage, and it was measured
    // rather than assumed. Probed here, this project reports `webgl2: true`,
    // `renderer: "WebKit WebGL"`, `navigator.gpu` present, `devicePixelRatio`
    // 3 and an iPhone OS 17_5 user agent. The GPU answers come from this
    // machine's adapter, so a capability check that passes here can still fail
    // on the device: WebGPU in particular is version-gated in Mobile Safari.
    // Treat a pass as evidence about layout and never as evidence about the
    // renderer.
    //
    // Advisory like the other engine legs, and scoped to the mobile viewport
    // contract rather than the whole deterministic set, so it stays a fast gate
    // instead of a second full suite that has to be triaged.
    {
      name: 'webkit-mobile',
      use: { ...devices['iPhone 15'] },
      testMatch: /visualsStudioMobile|smoke\.spec|touchGesture|phoneWorkspace/,
    },
    // The UX journeys, one project per engine, run by `npm run test:e2e:journeys`
    // and the advisory `e2e-journeys` CI job. The phone project collects only
    // the journeys the touch persona walks: open, navigate and layout.
    { name: 'journeys', use: { ...devices['Desktop Chrome'] }, testMatch: JOURNEYS },
    { name: 'journeys-webkit', use: { ...devices['Desktop Safari'] }, testMatch: JOURNEYS },
    { name: 'journeys-firefox', use: FIREFOX_USE, testMatch: JOURNEYS },
    // Tablet touch targets: a touch Chromium at iPad viewport sizes. Only the
    // tablet journey runs here; it sets its own viewports.
    { name: 'journeys-tablet', use: { ...devices['Desktop Chrome'], hasTouch: true, isMobile: true, viewport: { width: 820, height: 1180 } }, testMatch: /e2e\/journeys\/j11-/ },
    { name: 'journeys-mobile', use: { ...devices['iPhone 15'] }, testMatch: /e2e\/journeys\/j(1|3|10)-/ },
    // The graphics preflight is its own project so it can be run before the
    // suite without joining any project's default set. `deterministic` is a
    // required check, and an advisory leg must not move its test count.
    { name: 'firefox-preflight', use: { ...devices['Desktop Firefox'], headless: process.platform !== 'linux' }, testMatch: /firefoxWebglPreflight/ },
  ],
  webServer: {
    // SMOKE_LIVE boots the OBFUSCATED live artifact (the build users actually
    // get) so the smoke gate catches live-only breakage — scrambled
    // dynamic-import / worker-URL string literals, chunk-isolation regressions —
    // that the plain build can never surface. Default stays the plain build for
    // the fast e2e loop.
    // OLV_DEPLOY_ROOT serves an already-extracted deploy bundle and builds
    // NOTHING. It is how the smoke reaches the bytes that actually ship: the
    // normal legs test a build, packaging then produces a second build, and the
    // archive users download had never been started. See
    // scripts/smoke-deploy-zip.mjs, which sets this and binds the run to the
    // archive's SHA-256.
    // The directory and port travel in the environment, never in this command
    // string: `command` is shell text, and an extraction path containing a
    // space would split into two arguments. serve-deploy-bytes.mjs reads
    // OLV_DEPLOY_ROOT / OLV_DEPLOY_PORT itself.
    command: process.env.OLV_DEPLOY_ROOT
      ? 'node scripts/serve-deploy-bytes.mjs'
      : process.env.SMOKE_LIVE
        ? `npm run build:live && npm run preview${PREVIEW_PORT_ARGS}`
        : `npm run build && npm run preview${PREVIEW_PORT_ARGS}`,
    // The `?test=1` seam (`window.__OLV_TEST_API__`) is compiled in only when
    // OLV_TEST_SEAM=1 is set at build time; without it the block is dropped by
    // the minifier and every spec that drives the viewer programmatically
    // fails. The SMOKE_LIVE build is deliberately left without it: that leg
    // boots the artifact users are served, and its two specs never use the
    // seam. Playwright merges this over process.env for the spawned command.
    env: process.env.SMOKE_LIVE || process.env.OLV_DEPLOY_ROOT ? {} : { OLV_TEST_SEAM: '1' },
    // 127.0.0.1, not `localhost`, in deploy-root mode: the static server binds
    // loopback explicitly, and a `localhost` that resolves to ::1 first would
    // find nothing listening there.
    url: SERVER_URL,
    // Deploy-root mode NEVER reuses a server, in CI or out of it. The whole
    // claim of that mode is "these archive bytes were started and driven"; a
    // server someone left on the port answers every request, the specs pass,
    // and the archive is never opened. Reuse is a convenience for the local
    // build loop and is wrong here at any cost in start-up time. With reuse
    // off, an occupied port fails the run instead of silently satisfying it —
    // and scripts/smoke-deploy-zip.mjs asks the kernel for a free port anyway.
    // Bench runs never reuse either: the nav benchmark needs the `?benchmark=nav`
    // driver and probe from THIS checkout's plain build, and a preview left on
    // the port by another worktree or a live build answers every request while
    // `window.__olvNavDriver` never appears, so the run times out instead of
    // failing on the occupied port. scripts/governor-ab.mjs sets OLV_NO_SERVER_REUSE.
    reuseExistingServer:
      process.env.OLV_DEPLOY_ROOT || process.env.OLV_NO_SERVER_REUSE || process.argv.includes('--project=bench')
        ? false
        : !process.env.CI,
    timeout: 180_000,
  },
});
