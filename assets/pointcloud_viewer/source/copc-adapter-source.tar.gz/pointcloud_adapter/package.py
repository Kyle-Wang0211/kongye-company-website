"""Package the adapter beside the existing local-coordinate COPC viewer."""
import json
import shutil
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
root = base.parents[1]
destination = root / 'assets/pointcloud_viewer'
legacy = destination / 'legacy.html'
if not legacy.exists():
    shutil.copy2(destination / 'index.html', legacy)
shutil.rmtree(destination / 'copc', ignore_errors=True)
shutil.copytree(base / 'build', destination / 'copc')
legacy_names = [
    'streaming-ee0ea729a8f9e302cb38003addaffca0c1beecb0cd8453bef144a3667bb4add2.copc.laz',
    'streaming-183f60bfacc9cad581d7e0344b812ac6566780b9656dc1ddf1decfbdbc5ae150.copc.laz',
    'streaming-9a14584c6eae41b11800de4964561ed51d70f1c17fef43de58e3a6dbd0b956fc.copc.laz',
]
router = '''// These three immutable derivatives have source-local XYZ and no CRS WKT.
// Keep their existing renderer until their coordinate metadata is available.
const legacyNames = LEGACY_NAMES;
const source = new URLSearchParams(location.search).get('source');
const sourceUrl = source ? new URL(source, location.href) : null;
const legacy = sourceUrl?.origin === 'https://api.kongye.space'
  && legacyNames.includes(sourceUrl.pathname.split('/').pop());
const target = new URL(legacy ? './legacy.html' : './copc/index.html', location.href);
target.search = location.search;
if (sourceUrl) target.searchParams.set('source', sourceUrl.href);
target.hash = location.hash;
location.replace(target.href);
'''.replace('LEGACY_NAMES', json.dumps(legacy_names, indent=2))
(destination / 'route.js').write_text(router)
(destination / 'index.html').write_text('''<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>社区点云预览</title><style>html,body{margin:0;background:#000}</style></head><body><script type="module" src="./route.js"></script></body></html>''')
source = destination / 'source'
source.mkdir(exist_ok=True)
with tarfile.open(source / 'copc-adapter-source.tar.gz', 'w:gz') as archive:
    for entry in sorted(base.iterdir()):
        if entry.name not in {'node_modules', 'build', '.gitignore', '__pycache__'}:
            archive.add(entry, arcname='pointcloud_adapter/' + entry.name)
(source / 'index.html').write_text('''<!doctype html><meta charset="utf-8"><title>Viewer corresponding source</title><h1>Point cloud viewer source</h1><p>copc-adapter revision 198f6032e6b3898a08d11a19f08aaeedc98576d6, Apache-2.0. Streaming, scheduling and rendering source is unchanged. The integration reuses OpenLiDARViewer annotation and camera utilities under AGPL-3.0-only.</p><p><a href="copc-adapter-source.tar.gz">Corresponding integration, unchanged adapter, dependency lock and license notices</a></p><p>Build with Node 24 and npm 11. Run npm ci --ignore-scripts --no-audit --no-fund, then NODE_OPTIONS=--max-old-space-size=1024 node_modules/.bin/vite build --config vite.config.mjs in pointcloud_adapter/.</p><p><a href="corresponding-source.tar.gz">Existing OpenLiDARViewer complete source and legacy integration</a> · <a href="LICENSE">AGPL-3.0</a></p>''')
print(destination)
