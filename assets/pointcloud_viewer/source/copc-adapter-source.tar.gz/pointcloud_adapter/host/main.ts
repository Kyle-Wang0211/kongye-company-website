// Application composition only. COPC selection, scheduling, range requests,
// cancellation, decoding and point rendering are unchanged upstream code.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CopcThreeLayer, worldToDatasetLocal, datasetLocalToWorld, geographicToEcef, ecefToGeographic } from '../vendor/copc/packages/adapter/three';
import { createPointTransformer, createProjectPointTransformer } from '../vendor/copc/packages/adapter/core/coordinates/transform/createPointTransformer';
import { AnnotationOverlay } from '../vendor/olv/src/render/annotate/AnnotationOverlay';
import { fitBoxDistance } from '../vendor/olv/src/render/camera/cameraPresets';
import type { Annotation, SavedCameraState } from '../vendor/olv/src/render/annotate/types';

type Triple = [number, number, number];
const status = document.querySelector<HTMLDivElement>('#status')!;
const canvas = document.querySelector<HTMLCanvasElement>('#viewport')!;
const statistics = document.querySelector<HTMLOutputElement>('#statistics')!;
const formatter = new Intl.NumberFormat('zh-CN');
const mobile = matchMedia('(pointer: coarse)').matches;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);
const camera = new THREE.PerspectiveCamera(60, 1, 0.05, 1000000);
camera.up.set(0, 0, 1);
camera.position.set(1, 1, 1);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.screenSpacePanning = true;
controls.autoRotate = false;
const overlay = new AnnotationOverlay();
document.body.append(overlay.element);
let layer: CopcThreeLayer | undefined;
let loaded = false;
let disposed = false;
let annotations: Annotation[] = [];
let selectedId: string | null = null;
let onSelect: ((id: string | null) => void) | undefined;
let renderOrigin: Triple = [0, 0, 0];
let sourceToGeographic: ReturnType<typeof createPointTransformer>;
let geographicToSource: ReturnType<typeof createProjectPointTransformer>;

function notify(type: string, detail: object = {}) {
  const message = { source: 'pocketworld-olv', protocol: 'PW_POINT_CLOUD_STREAM_V1', type, ...detail };
  if (parent !== window) parent.postMessage(message, location.origin);
  const native = (window as Window & { PWPointCloudStream?: { postMessage(message: string): void } }).PWPointCloudStream;
  native?.postMessage(JSON.stringify(message));
}
function fail(error: unknown) {
  if (disposed || (error instanceof Error && error.name === 'AbortError')) return;
  status.textContent = error instanceof Error ? error.message : String(error);
  notify('error', { message: status.textContent });
  console.error(error);
}
let lastStatistics = '';
function updateStatistics() {
  if (!layer) return;
  const total = layer.getMetadata()?.pointCount;
  if (total === undefined) return;
  const current = layer.getRenderedPointCount();
  const text = `原文件总点数 ${formatter.format(total)} · 当前渲染点数 ${formatter.format(current)}`;
  if (text === lastStatistics) return;
  lastStatistics = text;
  statistics.textContent = text;
}
function updateView() {
  if (!loaded || disposed || document.hidden) return;
  // Do not wait for previous views. The upstream controller coalesces updates
  // and invalidates superseded requests when the camera changes.
  void layer!.update().catch(fail);
}
function legacyToLocal(value: Triple): Triple {
  const geographic = sourceToGeographic({ x: value[0] + renderOrigin[0], y: value[1] + renderOrigin[1], z: value[2] + renderOrigin[2] });
  const local = worldToDatasetLocal(geographicToEcef(geographic), layer!.getLocalFrame()!);
  return [local.x, local.y, local.z];
}
function localToLegacy(value: THREE.Vector3): Triple {
  const world = datasetLocalToWorld({ coordinateSystem: 'renderer-local', x: value.x, y: value.y, z: value.z }, layer!.getLocalFrame()!);
  const source = geographicToSource(ecefToGeographic(world));
  return [source.x - renderOrigin[0], source.y - renderOrigin[1], source.z - renderOrigin[2]];
}
function syncAnnotations() {
  overlay.sync(annotations.map(annotation => {
    const p = annotation.localPosition;
    const local = legacyToLocal([p.x, p.y, p.z]);
    return { ...annotation, localPosition: { x: local[0], y: local[1], z: local[2] } };
  }), selectedId);
}
function applyCameraState(state: SavedCameraState) {
  if (state.projection === 'orthographic') throw new Error('COPC adapter requires a perspective camera');
  const damping = controls.enableDamping;
  controls.enableDamping = false;
  controls.update();
  controls.enableDamping = damping;
  const position = legacyToLocal(state.position);
  const target = legacyToLocal(state.target);
  camera.position.fromArray(position);
  controls.target.fromArray(target);
  camera.fov = state.fov ?? 60;
  camera.updateProjectionMatrix();
  camera.lookAt(controls.target);
  camera.updateMatrixWorld(true);
  controls.update();
  updateView();
}
function getCameraState(): SavedCameraState {
  return { position: localToLegacy(camera.position), target: localToLegacy(controls.target), mode: 'orbit', fov: camera.fov, projection: 'perspective' };
}
function select(id: string | null) {
  selectedId = id;
  syncAnnotations();
  onSelect?.(id);
}
function jumpToAnnotation(id: string) {
  const annotation = annotations.find(item => item.id === id);
  if (!annotation) return;
  if (annotation.cameraState) {
    applyCameraState(annotation.cameraState);
  } else {
    const p = annotation.localPosition;
    const target = new THREE.Vector3(...legacyToLocal([p.x, p.y, p.z]));
    camera.position.add(target.clone().sub(controls.target));
    controls.target.copy(target);
    controls.update();
    updateView();
  }
  select(id);
}
overlay.setOnMarkerClick(jumpToAnnotation);
controls.addEventListener('change', updateView);
function resize() {
  const width = Math.max(1, canvas.clientWidth);
  const height = Math.max(1, canvas.clientHeight);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  updateView();
}
const resizeObserver = new ResizeObserver(resize);
resizeObserver.observe(canvas);
function render() {
  if (disposed || document.hidden) return;
  controls.update();
  camera.updateMatrixWorld(true);
  renderer.render(scene, camera);
  overlay.render(camera, canvas);
  updateStatistics();
}
renderer.setAnimationLoop(render);

async function open() {
  const raw = new URLSearchParams(location.search).get('source');
  if (!raw) throw new Error('请选择点云作品');
  const url = new URL(raw, location.href);
  if (url.origin !== location.origin && url.protocol !== 'https:') throw new Error('需要同源或 HTTPS 点云地址');
  layer = new CopcThreeLayer({
    url: url.href,
    backend: 'copc-js',
    colorMode: 'rgb',
    pointSize: 3,
    opacity: 1,
    coordinateCacheLayout: 'E',
    retainSourceCoordinatesForQueries: true,
    maxRenderedPoints: mobile ? 2000000 : 8000000,
    streaming: { maxNodes: mobile ? 64 : 128 },
    maxPointCacheBytes: (mobile ? 64 : 128) * 1024 * 1024,
  });
  layer.attachTo({ scene, camera, renderer });
  layer.addEventListener('error', event => fail(event.error));
  layer.addEventListener('firstvisible', () => {
    status.replaceChildren();
    notify('progress', { sourcePoints: layer!.getMetadata()!.pointCount, residentPoints: layer!.getRenderedPointCount() });
  });
  layer.addEventListener('viewsettled', () => {
    notify('progress', { sourcePoints: layer!.getMetadata()!.pointCount, residentPoints: layer!.getRenderedPointCount() });
  });
  await layer.load();
  if (disposed) return;
  const metadata = layer.getMetadata()!;
  updateStatistics();
  sourceToGeographic = createPointTransformer(metadata);
  geographicToSource = createProjectPointTransformer(metadata);
  const cube = metadata.cube;
  renderOrigin = [Math.floor((cube.minX + cube.maxX) / 2), Math.floor((cube.minY + cube.maxY) / 2), Math.floor((cube.minZ + cube.maxZ) / 2)];
  const b = metadata.bounds;
  const box = new THREE.Box3();
  for (const x of [b.minX, b.maxX]) for (const y of [b.minY, b.maxY]) for (const z of [b.minZ, b.maxZ]) {
    box.expandByPoint(new THREE.Vector3(...legacyToLocal([x-renderOrigin[0],y-renderOrigin[1],z-renderOrigin[2]])));
  }
  const center = box.getCenter(new THREE.Vector3());
  const distance = fitBoxDistance({ boxMin: box.min, boxMax: box.max, look: {x:-.5,y:-.5,z:-Math.SQRT1_2}, worldUp: {x:0,y:0,z:1}, fovDeg:60, aspect:canvas.clientWidth/canvas.clientHeight });
  camera.position.copy(center).add(new THREE.Vector3(distance*.5, distance*.5, distance*Math.SQRT1_2));
  controls.target.copy(center);
  camera.lookAt(center);
  camera.updateMatrixWorld(true);
  controls.update();
  loaded = true;
  const viewer = {
    applyCameraState,
    getCameraState,
    jumpToAnnotation,
    annotate: {
      loadAnnotations(items: Annotation[]) { annotations = items; syncAnnotations(); },
      setOnSelect(callback: (id: string | null) => void) { onSelect = callback; },
      select,
    },
    annotateElements: { overlay: overlay.element },
  };
  // Legacy bridge preserves source-local camera/annotation data at the boundary.
  // Native layer remains available for its original diagnostics and picking API.
  Object.assign(window, { pocketworldOlv: { viewer, cloud: { sourcePointCount:metadata.pointCount, renderOrigin }, layer, upstream:'198f6032e6b3898a08d11a19f08aaeedc98576d6' } });
  resize();
  updateView();
  notify('ready', { backend:'copc-adapter-three-webgl2', sourcePoints:metadata.pointCount });
}
function dispose() {
  if (disposed) return;
  disposed = true;
  loaded = false;
  renderer.setAnimationLoop(null);
  resizeObserver.disconnect();
  controls.dispose();
  overlay.dispose();
  layer?.destroy();
  renderer.dispose();
}
window.addEventListener('pagehide', dispose, { once:true });
window.addEventListener('pageshow', event => { if (event.persisted && disposed) location.reload(); });
document.addEventListener('visibilitychange', () => {
  if (!loaded || disposed) return;
  if (document.hidden) {
    renderer.setAnimationLoop(null);
    layer!.detachFrom();
  } else {
    layer!.attachTo({ scene, camera, renderer });
    renderer.setAnimationLoop(render);
    updateView();
  }
});
open().catch(fail);
