# Shared point-cloud integration

copc-adapter is pinned to `198f6032e6b3898a08d11a19f08aaeedc98576d6`.
The loader, scheduler, coordinate transforms, cache and Three renderer are unchanged upstream files under `vendor/copc`. The host composes original Three OrbitControls and OLV annotation/camera utilities. New application code only connects these APIs, the existing source-local camera/annotation bridge and loading statistics.

Build sequentially with Node 24 / npm 11. Install using `npm ci --ignore-scripts --no-audit --no-fund`, then run `NODE_OPTIONS=--max-old-space-size=1024 node_modules/.bin/vite build --config vite.config.mjs`. `python3 package.py` packages the shared Flutter assets. No Flutter or Rust build is required for this JavaScript payload.

The WASM is from the integrity-verified npm 0.8.0 artifact retained under `vendor`. Its release gitHead is `2ec05f5156e0847f140f4af3ef5df91c985efc84`. Rust source, Cargo.toml and Cargo.lock are identical to the pinned source revision. This establishes input equality, not a reproducible compiler identity. License identities and obligations are recorded under `licenses`.

Three immutable Rosedown derivatives contain local XYZ without CRS WKT. `route.js` keeps their existing OLV renderer. Georeferenced COPC uses the original copc-adapter implementation. No CRS is fabricated. The native and browser wrappers use the same packaged entry point.

Desktop/mobile active point budgets remain 8M/2M. Decoded CPU caches are 128/64 MiB, with 128/64 selected nodes and four upstream concurrent node loads. Cache limits exclude GPU and transient decoder memory. The page releases the renderer/layer on pagehide and detaches while hidden. The bottom-left counter shows source total and currently rendered points, not cumulative download progress.
