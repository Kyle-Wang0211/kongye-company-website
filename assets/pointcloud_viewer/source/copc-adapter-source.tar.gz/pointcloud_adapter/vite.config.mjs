import { defineConfig } from 'vite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const base = path.dirname(fileURLToPath(import.meta.url));
const modules = path.join(base, 'node_modules');
const adapter = path.join(base, 'vendor/copc/packages/adapter');
export default defineConfig({
  root: path.join(base, 'host'),
  base: './',
  resolve: { alias: [
    { find: /^three\/webgpu$/, replacement: path.join(modules, 'three/build/three.module.js') },
    { find: /^three$/, replacement: path.join(modules, 'three/build/three.module.js') },
    { find: /^three\/addons\/(.*)$/, replacement: path.join(modules, 'three/examples/jsm/$1') },
    { find: /^laz-perf$/, replacement: path.join(adapter, 'core/wasm/lazPerf.ts') },
    { find: /^laz-perf\/(.*)$/, replacement: path.join(modules, 'laz-perf/$1') },
    { find: /^copc$/, replacement: path.join(modules, 'copc/lib/index.js') },
    { find: /^proj4$/, replacement: path.join(modules, 'proj4/dist/proj4-src.js') },
  ] },
  worker: { format: 'es' },
  build: { outDir: path.join(base, 'build'), emptyOutDir: true, target: 'es2022' },
});
